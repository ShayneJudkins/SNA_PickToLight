﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using System.Net;

namespace PickToLightData_TestHarness
{
    public class ToyotaSCSWebAPI
    {
        public String UserName { get; set; } //AppID
        public String Password { get; set; } //AppSecret
        public String SkidURL { get; set; }
        public String TrailerURL { get; set; }

        //public static String Username = "24d058ee-4775-4426-9ae0-6d3e612b5e10";  //AppID
        //public static String Password = "W8aD2pM3qO7fS8xC3wE7bD1kX1nN8fG3gS8iN1kE8gH2iF3aX0";  //AppSecret
        //
        //public static String SkidURL = "https://api.toyota.com/tmna/prod/Logistics/v/SupplierOrderInformation/skid";
        //public static String TrailerURL = "https://api.toyota.com/tmna/prod/Logistics/v/SupplierOrderInformation/trailer";
        public ToyotaSCSWebAPI(string userName, string password, string skidURL, string trailerUrl)
        {
            UserName = userName;
            Password = password;
            SkidURL = skidURL;
            TrailerURL = trailerUrl;
        }

        //Authentication:
        //• Type: Basic authentication(AppID/AppSecret)
        //• Username: AppID
        //• Password: AppSecret
        //For every request below are the required:
        //• Use HTTPS only
        //• Header: Add Content type in http header(Content-Type: application/json)
        //• Authentication: Basic Auth
        //• Body: Skid Build Array/Shipment Load Object

        public T WebClientSkidBuild<T>(RequestSkidBuild reqSkidBuild) where T : new()
        {
            List<RequestSkidBuild> orders = new List<RequestSkidBuild>();
            orders.Add(reqSkidBuild);

            //string jsonRequest = JsonConvert.SerializeObject(reqSkidBuild);
            string jsonRequest = JsonConvert.SerializeObject(orders);
            //return WebClientSkidBuild<T>(jsonRequest);
            return SendRequest<T>(this.SkidURL, jsonRequest);
        }

        //public T WebClientSkidBuild<T>(string jsonRequest) where T : new()
        //{
        //    using (var w = new WebClient())
        //    {
        //        var json_data = string.Empty;
        //        // attempt to download JSON data as a string
        //        try
        //        {
        //            //Set Contet-Type to JSON
        //            w.Headers.Add(HttpRequestHeader.ContentType, "application/json");

        //            //ALL These seem to work!!
        //            //w.Headers[HttpRequestHeader.Authorization] = "Basic " + Convert.ToBase64String(Encoding.ASCII.GetBytes(this.UserName + ":" + this.Password));
        //            //w.Headers.Add("Authorization", "Basic " + Convert.ToBase64String(Encoding.Default.GetBytes(this.UserName + ":" + this.Password)));
        //            //w.Headers.Add("Authorization", "Basic " + Convert.ToBase64String(Encoding.ASCII.GetBytes(this.UserName + ":" + this.Password)));
        //            //w.Headers.Add(HttpRequestHeader.Authorization, "Basic " + Convert.ToBase64String(Encoding.ASCII.GetBytes(this.UserName + ":" + this.Password)));
        //            //w.Headers[HttpRequestHeader.Authorization] = "Basic " + Convert.ToBase64String(Encoding.UTF8.GetBytes(this.UserName + ":" + this.Password));
        //            //w.Headers.Add(HttpRequestHeader.Authorization, "Basic " + Convert.ToBase64String(Encoding.UTF8.GetBytes(this.UserName + ":" + this.Password)));

        //            //NOT NEEDED
        //            //w.Headers.Add(HttpRequestHeader.UserAgent, "Mozilla / 5.0(Windows; U; MSIE 9.0; Windows NT 9.0; en - US)");
        //            //w.Headers.Add(HttpRequestHeader.UserAgent, "WebClient");

        //            //w.Headers[HttpRequestHeader.Authorization] = "Basic " + credentials;

        //            //Needed?
        //            w.Encoding = System.Text.Encoding.UTF8;

        //            //JsonConvert.DeserializeObject<T>(json_data)
        //            //string jsonRequestObject = JsonConvert.SerializeObject(reqSkidBuild);
        //            json_data = w.UploadString(this.SkidURL, jsonRequest);
        //        }
        //        //catch (System.Net.WebException webEx)
        //        //{
        //        //    T genericClass = new T();
        //        //    genericClass.GetType().GetProperty("webException").SetValue(genericClass, webEx);
        //        //    return genericClass;
        //        //}
        //        catch (System.Exception ex)
        //        {
        //            //Also add an "Exception" variable to the Class??
        //            //And populate it like WebException above??

        //            T genericClass = new T();
        //            //if (ex.GetType().Name.Equals("WebException"))
        //            //{
        //                //Need this, with the Catch block above??
        //                //genericClass.GetType().GetProperty("webException").SetValue(genericClass, ex);
        //                genericClass.GetType().GetProperty("dotNetException").SetValue(genericClass, ex);
        //            //}
        //            return genericClass;
        //        }
        //        // if string with JSON data is not empty, deserialize it to class and return its instance 
        //        return !string.IsNullOrEmpty(json_data) ? JsonConvert.DeserializeObject<T>(json_data) : new T();
        //    }
        //}

        public T WebClientShipmentBuild<T>(RequestShipmentLoad reqShipmentLoad) where T : new()
        {
            List<RequestShipmentLoad> shipments = new List<RequestShipmentLoad>();
            shipments.Add(reqShipmentLoad);

            //string jsonRequest = JsonConvert.SerializeObject(reqSkidBuild);
            string jsonRequest = JsonConvert.SerializeObject(shipments);
            return SendRequest<T>(this.TrailerURL, jsonRequest);
        }

        public T SendRequest<T>(string url, string jsonRequest) where T : new()
        {
            using (var w = new WebClient())
            {
                var json_data = string.Empty;
                // attempt to download JSON data as a string
                try
                {
                    //Set Contet-Type to JSON
                    w.Headers.Add(HttpRequestHeader.ContentType, "application/json");

                    //ALL These seem to work!!
                    //w.Headers[HttpRequestHeader.Authorization] = "Basic " + Convert.ToBase64String(Encoding.ASCII.GetBytes(this.UserName + ":" + this.Password));
                    //w.Headers.Add("Authorization", "Basic " + Convert.ToBase64String(Encoding.Default.GetBytes(this.UserName + ":" + this.Password)));
                    //w.Headers.Add("Authorization", "Basic " + Convert.ToBase64String(Encoding.ASCII.GetBytes(this.UserName + ":" + this.Password)));
                    //w.Headers.Add(HttpRequestHeader.Authorization, "Basic " + Convert.ToBase64String(Encoding.ASCII.GetBytes(this.UserName + ":" + this.Password)));
                    //w.Headers[HttpRequestHeader.Authorization] = "Basic " + Convert.ToBase64String(Encoding.UTF8.GetBytes(this.UserName + ":" + this.Password));
                    w.Headers.Add(HttpRequestHeader.Authorization, "Basic " + Convert.ToBase64String(Encoding.UTF8.GetBytes(this.UserName + ":" + this.Password)));

                    //NOT NEEDED
                    //w.Headers.Add(HttpRequestHeader.UserAgent, "Mozilla / 5.0(Windows; U; MSIE 9.0; Windows NT 9.0; en - US)");
                    //w.Headers.Add(HttpRequestHeader.UserAgent, "WebClient");

                    //w.Headers[HttpRequestHeader.Authorization] = "Basic " + credentials;

                    //Needed?
                    w.Encoding = System.Text.Encoding.UTF8;

                    //JsonConvert.DeserializeObject<T>(json_data)
                    //string jsonRequestObject = JsonConvert.SerializeObject(reqSkidBuild);
                    //json_data = w.UploadString(this.SkidURL, jsonRequest);
                    json_data = w.UploadString(url, jsonRequest);
                }
                //catch (System.Net.WebException webEx)
                //{
                //    T genericClass = new T();
                //    genericClass.GetType().GetProperty("webException").SetValue(genericClass, webEx);
                //    return genericClass;
                //}
                catch (System.Exception ex)
                {
                    //Also add an "Exception" variable to the Class??
                    //And populate it like WebException above??

                    T genericClass = new T();
                    //if (ex.GetType().Name.Equals("WebException"))
                    //{
                    //Need this, with the Catch block above??
                    //genericClass.GetType().GetProperty("webException").SetValue(genericClass, ex);
                    genericClass.GetType().GetProperty("dotNetException").SetValue(genericClass, ex);
                    //}
                    return genericClass;
                }
                // if string with JSON data is not empty, deserialize it to class and return its instance 
                return !string.IsNullOrEmpty(json_data) ? JsonConvert.DeserializeObject<T>(json_data) : new T();
            }
        }

    }
}

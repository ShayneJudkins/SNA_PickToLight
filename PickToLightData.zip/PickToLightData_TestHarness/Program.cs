﻿using Newtonsoft.Json;
using PickToLightData;
using SNA.WinService.PickToLightServer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace PickToLightData_TestHarness
{
    class Program
    {
        static Logger _logger; // = new Logger("TestHarness");

        //static void Main(string[] args)
        //{
        //    //Console.WriteLine("Adding test row to ScanOWK...");
        //    //string barcode = "C1415-ALT”A2” MOTOR            1367C2AA151698200252100NAHND05   NACXD00   00006SW MANUFACTURING    CWMF18   SWYD02   2017051720170515135800C7137D18    0001001021TMC                 L SAF    4.4  A MAX     20                                           ";
        //    //try
        //    //{
        //    //    PickToLightData.ScanOWK.CreateScanEntry("TestDevice", "TestDeviceId", "Device MAC?", "Use ResultId?", barcode, "\\\\ServerName\\DeviceName\\YYYMMDD\\ResultID\\");
        //    //}
        //    //catch (Exception ex)
        //    //{
        //    //    if (ex.InnerException != null)
        //    //    {
        //    //        Console.WriteLine("Exception creating the Scan Entry: " + ex.Message + " (Inner Exception: " + ex.InnerException + ")");
        //    //    }
        //    //    else
        //    //    {
        //    //        Console.WriteLine("Exception creating the Scan Entry: " + ex.Message);
        //    //    }
        //    //}
        //    //Console.WriteLine("Done adding test row to ScanOWK...");
        //    //Console.ReadKey(true);

        //    ////OrderNumber	MainRoute	SubRoute
        //    ////2017091502	IMPE04      SPCL02
        //    //string manifestNum = "2017091502";
        //    //string mainRoute = "";
        //    //string subRoute = "";
        //    //Console.WriteLine("Looking up MainRoute and SubRoute for Manifest (" + manifestNum + ")...");
        //    //try
        //    //{
        //    //    PickToLightData.ScanOWK.PopulateManifestRoutes(manifestNum, out mainRoute, out subRoute);
        //    //    Console.WriteLine("MainRoute (" + mainRoute + ") Should Be (IMPE04)");
        //    //    Console.WriteLine("SubRoute (" + subRoute + ") Should Be (SPCL02)");
        //    //}
        //    //catch (Exception ex)
        //    //{
        //    //    if (ex.InnerException != null)
        //    //    {
        //    //        Console.WriteLine("Exception calling PopulateManifestRoutes(): " + ex.Message + " (Inner Exception: " + ex.InnerException + ")");
        //    //    }
        //    //    else
        //    //    {
        //    //        Console.WriteLine("Exception calling PopulateManifestRoutes(): " + ex.Message);
        //    //    }
        //    //}
        //    //Console.WriteLine("Done...");
        //    //Console.ReadKey(true);



        //    Logger _logger = new Logger("TestHarness");
        //    //int _port = 11000;
        //    int _port = 11100; //11000 is the port for the "old" Code and 31001 I sometimes use, too. The BanderDisplay uses 12000

        //    IPAddress _pickToLightServerIP = System.Net.IPAddress.Parse("10.2.9.23");

        //    //if (_pickToLightServerIP.Length > 10 && _pickToLightServerIP.Split('.').Length == 4) //At least 11 characters (10.10.10.10) and 3 periods/dots.
        //    if (_pickToLightServerIP != null)
        //    {
        //        //TCPClient tcpClient = new TCPClient(_pickToLightServerIP, port);
        //        TCPClient tcpClient = new TCPClient(_logger, _pickToLightServerIP, _port);
        //        string commandToSend = "";
        //        commandToSend = PickToLightCommands.PopulatePingCommand("Ping Test");
        //        Console.WriteLine("Sending Command: " + commandToSend);
        //        StringBuilder commandResponse = new StringBuilder();
        //        tcpClient.SendCommand(commandToSend, commandResponse);
        //        Console.WriteLine("Response Received: " + commandResponse);

        //        commandToSend = PickToLightCommands.PopulateLogCommand("TestHarness", "TestThread", System.Threading.Thread.CurrentThread.ManagedThreadId, "Test from TestHarness");
        //        Console.WriteLine("Sending Command: " + commandToSend);
        //        commandResponse.Clear();
        //        tcpClient.SendCommand(commandToSend, commandResponse);
        //        Console.WriteLine("Response Received: " + commandResponse);

        //        Console.WriteLine("Reconnecting... (BECAUSE SendCommand() always Closes the Socket!!!!!!!!!!)");

        //        tcpClient = new TCPClient(_logger, _pickToLightServerIP, _port);
        //        Console.WriteLine("Sending Command: " + commandToSend);
        //        commandResponse.Clear();
        //        tcpClient.SendCommand(commandToSend, commandResponse);
        //        Console.WriteLine("Response Received: " + commandResponse);


        //        Console.WriteLine("Reconnecting...");
        //        commandToSend = PickToLightCommands.PopulateLinePartCommand("AUTO2");
        //        tcpClient = new TCPClient(_logger, _pickToLightServerIP, _port);
        //        Console.WriteLine("Sending Command: " + commandToSend);
        //        commandResponse.Clear();
        //        tcpClient.SendCommand(commandToSend, commandResponse);
        //        Console.WriteLine("Response Received: " + commandResponse);

        //        Console.WriteLine("Reconnecting...");
        //        commandToSend = PickToLightCommands.PopulateLinePartCommand("AUTO3");
        //        tcpClient = new TCPClient(_logger, _pickToLightServerIP, _port);
        //        Console.WriteLine("Sending Command: " + commandToSend);
        //        commandResponse.Clear();
        //        tcpClient.SendCommand(commandToSend, commandResponse);
        //        Console.WriteLine("Response Received: " + commandResponse);

        //        Console.WriteLine("Reconnecting...");
        //        commandToSend = PickToLightCommands.PopulateLinePartCommand("AUTOXXX");
        //        tcpClient = new TCPClient(_logger, _pickToLightServerIP, _port);
        //        Console.WriteLine("Sending Command: " + commandToSend);
        //        commandResponse.Clear();
        //        tcpClient.SendCommand(commandToSend, commandResponse);
        //        Console.WriteLine("Response Received: " + commandResponse);

        //        Console.WriteLine("Press any key...");
        //        Console.ReadKey(true);
        //    }
        //    else
        //    {
        //        Console.WriteLine("The PickToLightServerIP setting is invalid or not specified!");
        //    }

        //}

        static void Main(string[] args)
        {
            _logger = new Logger("TestHarness");

            int scanManifestID = 169222;
            Console.WriteLine("Getting SQL Entry for ScanManifest ID: " + scanManifestID.ToString());
            ScanManifest scanManifest = PickToLightData.ScanManifest.GetScanEntry(scanManifestID);
            if(scanManifest != null) //Make sure we can read the row for the idScanManifest
            {
                ToyotaSkidBuildRequest(scanManifest);
            }
            Console.WriteLine("Press any key...");
            Console.ReadKey(true);
        }

        //private void ToyotaSkidBuildRequest(ScanManifest scanManifest)
        private static void ToyotaSkidBuildRequest(ScanManifest scanManifest)
        {
            ///
            //Determine what all PartNumber/PANSREQ been been "Picked" by looking in "ScanOWK" where "CreatedBy=PickToLightClient".
            //Store Each PartNumber and PANSREQ  as "Ordered" (or "Planned").
            //Store Each PartNumber and Number of Unique/Distinct (Barcode) Scans as "Picked" (or "Pulled" or "Shipped").
            //(Maybe I should create a Class or Struct with "PartNumber", "PansOrdered", "PansPicked".)
            ///
            //var list = new[] { new { sn = "a1", sd = "b1" } }.ToList(); // declaring structure
            //list.Clear();                                               // clearing dummy element
            //list.Add(new { sn = "a", sd = "b" });                       // adding real element
            //foreach (var leaf in list) if (leaf.sn == "a") break;       // using it
            var partsOrdered = new Dictionary<string, int>();
            var partsPulled = new Dictionary<string, int>();
            var partsPulledDuplicate = new Dictionary<string, int>();

            bool DEBUG = false; // true;   // false;

            List<ScanOWK> pickerScansForAllPartsIncludingDuplicates = new List<ScanOWK>();
            List<ToyotaShipment> toyotaOrderShipments = new List<ToyotaShipment>();

            ////(As a "backup", if we can get PalletizationCode from CMS and at least one part for each Palletization has been scanned, but the order isn't complete, we should send email notifiation!

            //First, we need to determine if a SkidBuildRequest is necessary.
            //Determine if this is the only Manifest / Skid for the order:
            using(var ctx = new PickToLightEntities())
            {
                //  Use the NAMC (NAMCDestination) and SupplierCode from the Manifest to get the TRPT that corresponds to the NAMC in ToyotaShipments
                NAMC_TRPT_CrossRef namcTRPTcrossRef;
                namcTRPTcrossRef = (from n in ctx.NAMC_TRPT_CrossRef
                                    where scanManifest.NAMC == n.NAMCDestination && scanManifest.SupplierCode == n.SupplierCode
                                    select n).SingleOrDefault<NAMC_TRPT_CrossRef>();
                if(DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaSkidBuildRequest()----- NAMC_TRPT_CrossRef.TRPT = " + namcTRPTcrossRef.TRPT + "  (where scanManifest.NAMC (" + scanManifest.NAMC.ToString() + ") == n.NAMCDestination && scanManifest.SupplierCode (" + scanManifest.SupplierCode.ToString() + ") == n.SupplierCode)");

                //  Using OrderNumber, NAMC, Supplier Code and Dock Code, get Rows from ToyotaShipments where COMPLETED = FALSE (0)!!!
                //  (The NAMC in ToyotaShipments is a combination of the NAMC and Supplier Code!)
                toyotaOrderShipments = (from s in ctx.ToyotaShipments
                                 where namcTRPTcrossRef.TRPT == s.NAMC
                                 && scanManifest.OrderNumber == s.ORDERNUM
                                 && scanManifest.DockCode == s.DOCKCODE
                                 && s.Completed == false
                                 select s).ToList(); //Do a "ToList()" here??
                if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaSkidBuildRequest()----- Found " + toyotaOrderShipments.Count().ToString() + " toyotaOrderShipments, where namcTRPTcrossRef.TRPT (" + namcTRPTcrossRef.TRPT.ToString() + ") == s.NAMC && scanManifest.OrderNumber (" + scanManifest.OrderNumber.ToString() + ") == s.ORDERNUM && scanManifest.DockCode (" + scanManifest.DockCode.ToString() + ") == s.DOCKCODE");
                //RIGHT HERE, IF THERE AREN'T ANY SHIPMENTS (not Completed), WE NEED TO STOP AND SEND A MESSAGE!!! Normally, this shouldn't happen!!!!)
                if (toyotaOrderShipments.Count() == 0)
                {
                    Console.WriteLine("NOTE: The most common reason for this Exception is when the spImportToyotaShipments (SQL Stored Procedure called via a SQL Job) has NOT been executed or had problems importing this Order. -----ToyotaSkidBuildRequest()----- NO ToyotaShipments (not marked as COMPLETED) exist for scanManifest.OrderNumber = " + scanManifest.OrderNumber + " AND scanManifest.DockCode = " + scanManifest.DockCode + " AND NAMC_TRPT_CrossRef.TRPT = " + namcTRPTcrossRef.TRPT + "  (where scanManifest.NAMC (" + scanManifest.NAMC.ToString() + ") == n.NAMCDestination && scanManifest.SupplierCode (" + scanManifest.SupplierCode.ToString() + ") == n.SupplierCode)");
                    SendEMailNotificationAndLogException("NOTE: The most common reason for this Exception is when the spImportToyotaShipments (SQL Stored Procedure called via a SQL Job) has NOT been executed or had problems importing this Order. -----ToyotaSkidBuildRequest()----- NO ToyotaShipments (not marked as COMPLETED) exist for scanManifest.OrderNumber = " + scanManifest.OrderNumber + " AND scanManifest.DockCode = " + scanManifest.DockCode + " AND NAMC_TRPT_CrossRef.TRPT = " + namcTRPTcrossRef.TRPT + "  (where scanManifest.NAMC (" + scanManifest.NAMC.ToString() + ") == n.NAMCDestination && scanManifest.SupplierCode (" + scanManifest.SupplierCode.ToString() + ") == n.SupplierCode)");
                    return;
                }
                //  There will be one Row per Part…get all the Parts with ORDERQTY, PANQTY and PANSREQ…
                foreach(var shipment in toyotaOrderShipments)
                {
                    if(DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaSkidBuildRequest()----- Shipment for SNAPARTNUM:" + shipment.SNAPARTNUM + " PANSREQ:" + shipment.PANSREQ + " ORDERQTY:" + shipment.ORDERQTY + " PANQTY:" + shipment.PANQTY + "   (ORDERNUM:" + shipment.ORDERNUM + " NAMC:" + shipment.NAMC + " DOCKCODE:" + shipment.DOCKCODE + " SUBROUTE:" + shipment.SUBROUTE + "  SHIPDATE:" + shipment.SHIPDATE + " SHIPTIME:" + shipment.SHIPTIME + " CUSTPARTNUM:" + shipment.CUSTPARTNUM + ")");
                    if(partsOrdered.ContainsKey(shipment.CUSTPARTNUM))
                    {
                        partsOrdered[shipment.CUSTPARTNUM] = partsOrdered[shipment.CUSTPARTNUM] + Int32.Parse(shipment.PANSREQ.ToString());
                    }
                    else
                    {
                        partsOrdered.Add(shipment.CUSTPARTNUM, Int32.Parse(shipment.PANSREQ.ToString()));
                        //Also "seed" partsPulled and partsPulledDuplicate with 0 values....
                        partsPulled.Add(shipment.CUSTPARTNUM, 0);
                        partsPulledDuplicate.Add(shipment.CUSTPARTNUM, 0);
                    }

                    //     Get all the matching ScanOWK entries for Pickers (PickToLightClient).
                    //          Each "unique" ROW (NAMC, SupplierCode, OrderNumber,DockCode,PartNumber,Box...) is one PAN (PANREQ)
                    //var pickerScans = (from p in ctx.ScanOWKs //Define this outsite the "using", so it can be accessed below to send to DoSkidBuildTransaction()
                    List<ScanOWK> pickerScans = (from p in ctx.ScanOWKs
                                       where scanManifest.NAMC == p.NAMCDestination  //Use the NAMC from the Manifest!
                                       && scanManifest.SupplierCode == p.SupplierCode
                                       && scanManifest.OrderNumber == p.OrderNumber
                                       && scanManifest.DockCode == p.DockCode
                                       && p.Decoded == true
                                       && p.CreatedBy.Equals("PickToLightClient")
                                       && shipment.CUSTPARTNUM == p.PartNumber
                                       && p.Created < scanManifest.Created //We should only process the Scans that happened BEFORE this "B Manifest"....
                                       orderby p.Created
                                       select p).ToList();
                    //Iterate through and log info just for debug.
                    foreach (var scan in pickerScans)
                    {
                        //[SupplierCode]
                        //,[DockCode]
                        //,[KanbanNumber]
                        //,[PartNumber]
                        //,[SupplierTextLine1]   //SNA Part #
                        //FROM [PickToLightDev].[dbo].[OWKSupplierText]
                        var kanban = (from k in ctx.OWKSupplierTexts
                                      where scan.SupplierCode == k.SupplierCode
                                      && scan.DockCode == k.DockCode
                                      && scan.PartNumber == k.PartNumber
                                      select k).FirstOrDefault<OWKSupplierText>();
                        if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaSkidBuildRequest()----- PickerScans -- Palletization:" + scan.PalletizationCode + " LineSideAddress:" + scan.LineSideAddress + " PartNumber:" + scan.PartNumber + " SNAPartNumber:" + kanban.SupplierTextLine1 + " Kanban:" + scan.KanbanNumber + " LotSize:" + scan.LotSize + " BoxNumber:" + scan.BoxNumber + " BoxTotal:" + scan.BoxTotal + "   (OrderNumber:" + scan.OrderNumber + " NAMCDestination:" + scan.NAMCDestination + " DockCode:" + scan.DockCode + " SubRoute:" + scan.SubRoute + "  ShipDate:" + scan.ShipDate + " ShipTime:" + scan.ShipTime + " CreatedBy:" + scan.CreatedBy + " ScannedBy:" + scan.ScannedBy + " Created:" + scan.Created.ToString() + ")");
                        //Let's add these parts to "pickerScansForAllPartsIncludingDuplicates" so they can be passed to the method that sends them to Toyota...
                        scan.SupplierInformation = kanban.SupplierTextLine1; //Save the SNAPartNumber as "SupplierInformation.
                        pickerScansForAllPartsIncludingDuplicates.Add(scan);
                    }
                    //          Actually, can use the "Barcode" to Group By or get "Distinct", to omit any duplicate Scans!
                    int numPartsPulled = pickerScans.Count(); //This includes Duplicate Scans!!
                    int numUniquePartsPulled = pickerScans.Select(barcode => barcode.Barcode).Distinct().Count(); //This omits any duplicates!
                    if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaSkidBuildRequest()----- PickerScans (" + numPartsPulled.ToString() + ") with distinct/unique barcode:" + numUniquePartsPulled.ToString());
                    if (partsPulled.ContainsKey(shipment.CUSTPARTNUM))
                    {
                        partsPulled[shipment.CUSTPARTNUM] = partsPulled[shipment.CUSTPARTNUM] + numUniquePartsPulled;
                    }
                    else //This normally shouldn't happen, becasue all "partsPulled" are seeded with a 0 above.....but just in case they pulled the wrong part!
                    {
                        partsPulled.Add(shipment.CUSTPARTNUM, numUniquePartsPulled);
                    }
                    //Store the duplicate scans too, just so the notification can be tailored!
                    if(numPartsPulled != numUniquePartsPulled)
                    {
                        if (partsPulledDuplicate.ContainsKey(shipment.CUSTPARTNUM))
                        {
                            partsPulledDuplicate[shipment.CUSTPARTNUM] = partsPulledDuplicate[shipment.CUSTPARTNUM] + numPartsPulled;
                        }
                        else //This normally shouldn't happen, becasue all "partsPulledDuplicate" are seeded with a 0 above.....but just in case they pulled the wrong part!
                        {
                            partsPulledDuplicate.Add(shipment.CUSTPARTNUM, numPartsPulled);
                        }
                    }
                }
            }

            if (DEBUG)
            {
                foreach (var pair in partsPulled)
                {
                    //Console.WriteLine("Pulled = {0}, {1}", pair.Key, pair.Value);
                    _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaSkidBuildRequest()----- Part# " + pair.Key + " Pulled: " + pair.Value + " Ordered:" + partsOrdered[pair.Key]);
                }
                foreach (var pair in partsOrdered)
                {
                    //Console.WriteLine("Pulled = {0}, {1}", pair.Key, pair.Value);
                    _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaSkidBuildRequest()----- Part# " + pair.Key + " Ordered: " + pair.Value + "  Pulled:" + partsPulled[pair.Key]);
                }
            }

            //     If the Order is complete, send it off for confirmation.
            //     Otherwise, "log" it and continue on.

            //if partsOrdered = partsPulled, order is 100% complete, SEND it!
            //if partsOrdered has at least 1 part pulled in partsPulled, then send Email notification and warn of possible intervention.
            //Otherwise, (one of the PartNumbers doesn't have ANY parts pulled for it) lets just assume another Manifest is coming and we will pick up the entire order then!

            bool EachPartHasAtLeastOneScan = true;
            bool AllPartsHaveBeenCompleted = true;
            bool AllPartsHaveBeenCompletedWithDuplicates = false;

            foreach (var pair in partsOrdered)
            {
                if (partsPulled[pair.Key] == 0)
                {
                    EachPartHasAtLeastOneScan = false;
                    if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaSkidBuildRequest()----- Part# " + pair.Key + " had ZERO parts Pulled. (DON'T DO ANYTHING??? WAIT FOR ANOTHER MANIFEST???)");
                }
                else if (partsPulled[pair.Key] >= pair.Value)
                {
                    if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaSkidBuildRequest()----- Part# " + pair.Key + " was FULLY Pulled. (IF ALL PARTS ARE FULLY PULLED, SEND SkidBuild!)");
                }
                else
                {
                    AllPartsHaveBeenCompleted = false;
                    if (partsPulledDuplicate[pair.Key] >= pair.Value)
                    {
                        AllPartsHaveBeenCompletedWithDuplicates = true;
                        if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaSkidBuildRequest()----- Part# " + pair.Key + " was NOT FULLY Pulled because the same barcode/boxnumber was scanned multiple times! (SEND A NOTIFICATION THAT ONLY XXX were PULLED FOR PART#, UNLESS ONE OF THE PARTS PULLED ARE ZERO, THEN IGNORE!)");
                    }
                    else
                    {
                        AllPartsHaveBeenCompletedWithDuplicates = false;
                        if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaSkidBuildRequest()----- Part# " + pair.Key + " was NOT FULLY Pulled. (SEND A NOTIFICATION THAT ONLY XXX were PULLED FOR PART#, UNLESS ONE OF THE PARTS PULLED ARE ZERO, THEN IGNORE!)");
                    }
                }
            }

            if (EachPartHasAtLeastOneScan)
            {
                if (AllPartsHaveBeenCompleted)
                {
                    DoSkidBuildTransaction(scanManifest, pickerScansForAllPartsIncludingDuplicates, toyotaOrderShipments); //NOTE, pickerScans parameter may not be unique, hence the name!
                    _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "INFO", "-----ToyotaSkidBuildRequest()----- Sent to Toyota SCS API for Approval!");
                }
                else
                {
                    if (AllPartsHaveBeenCompletedWithDuplicates)
                    {
                        SendNotificationEmail_OrderNotComplete(scanManifest, true, "");
                        _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "ERROR", "-----ToyotaSkidBuildRequest()----- EMAIL Notifcation Sent! (AllPartsHaveBeenCompletedWithDuplicates = " + (AllPartsHaveBeenCompletedWithDuplicates ? "TRUE" : "FALSE"));
                    }
                    else
                    {
                        SendNotificationEmail_OrderNotComplete(scanManifest, false, "");
                        _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "INFO", "-----ToyotaSkidBuildRequest()----- EMAIL Notifcation Sent! (AllPartsHaveBeenCompletedWithDuplicates = " + (AllPartsHaveBeenCompletedWithDuplicates ? "TRUE" : "FALSE"));
                    }
                }
            }
            else
            {
                //MOST of the time, this means there is still another Manifest to Pull, so just wait.
                _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "INFO", "-----ToyotaSkidBuildRequest()----- One of the PartNumbers doesn't have ANY parts pulled, so don't send to TSCS API, also NO Email Notification!");
            }
        }

        //private void DoSkidBuildTransaction(ScanManifest scanManifest, List<ScanOWK> nonUniquePickerScans, List<ToyotaShipment> toyotaOrderShipments)
        private static void DoSkidBuildTransaction(ScanManifest scanManifest, List<ScanOWK> nonUniquePickerScans, List<ToyotaShipment> toyotaOrderShipments)
        {
            bool DEBUG = false;   // true;
            bool TestException = false; //true

            // TODO - FINISH!
            if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- scanManifest.ID:" + scanManifest.ID.ToString() + " scanManifest.NAMC:" + scanManifest.NAMC.ToString() + " scanManifest.SupplierCode:" + scanManifest.SupplierCode.ToString() + " scanManifest.DockCode:" + scanManifest.DockCode.ToString() + " scanManifest.OrderNumber:" + scanManifest.OrderNumber.ToString() + " scanManifest.OrderSequence:" + scanManifest.OrderSequence.ToString());
            //int numUniquePartsPulled = pickerScans.Select(barcode => barcode.Barcode).Distinct().Count(); //This omits any duplicates!
            int parsedInt;
            List<ScanOWK> uniquePickerScans = (from ps in nonUniquePickerScans
                                               group ps by ps.Barcode  //There can be duplicates, so group on Barcode and take the last Scan.
                                                   into grp
                                                   select new ScanOWK     //Or, I could make the list of Kanban's here!
                                                   {
                                                       Barcode = grp.Key,
                                                       ID = grp.Select(ex => ex.ID).LastOrDefault(), //There can be duplicates, so group on Barcode and take the last Scan.
                                                       SupplierCode = grp.Select(ex => ex.SupplierCode).LastOrDefault(),
                                                       DockCode = grp.Select(ex => ex.DockCode).LastOrDefault(),
                                                       KanbanNumber = grp.Select(ex => ex.KanbanNumber).LastOrDefault(),
                                                       PartNumber = grp.Select(ex => ex.PartNumber).LastOrDefault(),
                                                       LineSideAddress = grp.Select(ex => ex.LineSideAddress).LastOrDefault(),
                                                       StoreAddress = grp.Select(ex => ex.StoreAddress).LastOrDefault(),
                                                       LotSize = grp.Select(ex => ex.LotSize).LastOrDefault(),
                                                       SupplierName = grp.Select(ex => ex.SupplierName).LastOrDefault(),
                                                       MainRoute = grp.Select(ex => ex.MainRoute).LastOrDefault(),
                                                       SubRoute = grp.Select(ex => ex.SubRoute).LastOrDefault(),
                                                       UnloadDate = grp.Select(ex => ex.UnloadDate).LastOrDefault(),
                                                       ShipDate = grp.Select(ex => ex.ShipDate).LastOrDefault(),
                                                       ShipTime = grp.Select(ex => ex.ShipTime).LastOrDefault(),
                                                       OrderNumber = grp.Select(ex => ex.OrderNumber).LastOrDefault(),
                                                       BoxNumber = grp.Select(ex => ex.BoxNumber).LastOrDefault(),
                                                       BoxTotal = grp.Select(ex => ex.BoxTotal).LastOrDefault(),
                                                       NAMCDestination = grp.Select(ex => ex.NAMCDestination).LastOrDefault(),
                                                       PalletizationCode = grp.Select(ex => ex.PalletizationCode).LastOrDefault(),
                                                       DeviceName = grp.Select(ex => ex.DeviceName).LastOrDefault(),
                                                       DeviceIdentifier = grp.Select(ex => ex.DeviceIdentifier).LastOrDefault(),
                                                       ScannedBy = grp.Select(ex => ex.ScannedBy).LastOrDefault(),
                                                       Created = grp.Select(ex => ex.Created).LastOrDefault(),
                                                       CreatedBy = grp.Select(ex => ex.CreatedBy).LastOrDefault(),
                                                       Filler = "" //Later on, we will "stuff" the SkidId into this field, since we aren't using it for building the Kanbans...
                                                   }).ToList();
            ///
            ///Let's just go straight to "Kanban"! 
            ///No!!!!!!! Because I need things like Scan Created (DateTime) to figure out what Manifest the OWK belongs to!
            //////
            //List<Kanban> kanbans =  (from ps in nonUniquePickerScans
            //                         group ps by ps.Barcode  //There can be duplicates, so group on Barcode and take the last Scan.
            //                         into grp
            //                         select new Kanban
            //                         {
            //                             lineSideAddress = grp.Select(ex => ex.LineSideAddress).LastOrDefault(),
            //                             partNumber  = grp.Select(ex => ex.PartNumber).LastOrDefault(),
            //                             kanban = grp.Select(ex => ex.KanbanNumber).LastOrDefault(),
            //                             qpc = (Int32.TryParse(grp.Select(ex => ex.LotSize).LastOrDefault(),out parsedInt) ? parsedInt : 0),
            //                             boxNumber = (Int32.TryParse(grp.Select(ex => ex.BoxNumber).LastOrDefault(), out parsedInt) ? parsedInt : 0),
            //                             manifestNumber = "", //This is sent via EDI, but not sure if we pull it or not!
            //                             rfId = "" //Currently, we aren't tracking RF!
            //                         }).ToList();

            //RequestSkidBuild reqSkidBuild = new RequestSkidBuild("ExampleFromGarry");
            RequestSkidBuild reqSkidBuild = new RequestSkidBuild();

            ////////////////////////////////////////Build the RequestSkidBuild!!!!!////////////////////////////////////////

            ///I could do all this in a constructor for "RequestSkidBuild" and pass scanManifest and kanbans...

            reqSkidBuild.order = scanManifest.OrderNumber;
            reqSkidBuild.supplier = scanManifest.SupplierCode;
            reqSkidBuild.plant = scanManifest.NAMC;
            reqSkidBuild.dock = scanManifest.DockCode;


            //
            //Skid Build – Order Level
            //Shipment Load – Skid Level
            //Shipment Load – Trailer Level
            //
            //
            //We will need a SkidBuild (actually now SkidBuild), Exception Code table to choose the Codes from.
            //     (SkidBuildOrderLevelExceptionCodes, Columns = "Code,NVARCHAR(2)" and "Description,NVARCHAR(100)"....)
            //
            //Also, one for "Shipment Load - Skid Level" and "Shipment Load = Trailer Level"...
            //
            //We will need a ShipmentLoad - SkidLevel, Exception Code table to choose the Codes from.
            //     (ShipmentLoadSkidLevelExceptionCodes, Columns = "Code,NVARCHAR(2)" and "Description,NVARCHAR(100)"....)
            //We will need a ShipmentLoad = TrailerLevel, Exception Code table to choose the Codes from.
            //     (ShipmentLoadTrailerLevelExceptionCodes, Columns = "Code,NVARCHAR(2)" and "Description,NVARCHAR(100)"....)
            //
            //Add an Exception for Code 20
            //
            //It appears if there aren't any Exceptions, we don't have to add any!!!
            //BUT.... the method that builds the JSON adds a "null" exception... so lets add an empty one for now so the Request format is correct!)
            //BUT.... the method that builds the JSON adds a "null" exception... so lets add an empty one for now so the Request format is correct!)
            //
            //++++++++++
            //UPDATED 11/25/18!
            //++++++++++
            //Now, we can set this to null and have it omitted from the Request, because we can:
            //Tell the Serializer to ignore this by adding the Json Attribute: [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
            //to the "exceptions" property in the RequestSkidBuild class.
            //-----
            //reqSkidBuild.exceptions = new List<APIexception>();
            //APIexception exceptionItem1 = new APIexception();
            //exceptionItem1.exceptionCode = (TestException ? "20" : "");
            //exceptionItem1.comments = (TestException ? "Expendable Packaging" : "");
            //reqSkidBuild.exceptions.Add(exceptionItem1);
            ////////APIexception exceptionItem2 = new APIexception();
            ////////exceptionItem2.exceptionCode = "";
            ////////exceptionItem2.comments = "";
            ////////reqSkidBuild.exceptions.Add(exceptionItem2);
            //-----
            //++++++++++
            if (TestException)
            {
                reqSkidBuild.exceptions = new List<APIexception>();
                APIexception exceptionItem1 = new APIexception();
                exceptionItem1.exceptionCode = "20";
                exceptionItem1.comments = "Expendable Packaging";
                reqSkidBuild.exceptions.Add(exceptionItem1);
            }
            else
            {
                reqSkidBuild.exceptions = null;
            }

            //First, let's get all the Manifests that have been scanned for this Order...
            //(OrderNumber, SupplierCode, NAMC and DockCode)
            //(But only this one (that we are processing) AND the ones "older" than this one.)
            //This can be done by "ID", since we have the ScanManifest and are only querying ScanManifest.
            List<ScanManifest> manifestScans = new List<ScanManifest>();
            using (var ctx = new PickToLightEntities())
            {
                //if (DEBUG) _logger.Log("-----ToyotaSkidBuildRequest()----- NAMC_TRPT_CrossRef.TRPT = " + namcTRPTcrossRef.TRPT + "  (where scanManifest.NAMC (" + scanManifest.NAMC.ToString() + ") == n.NAMCDestination && scanManifest.SupplierCode (" + scanManifest.SupplierCode.ToString() + ") == n.SupplierCode)");
                //if (DEBUG) _logger.Log("-----ToyotaSkidBuildRequest()----- Found " + toyotaOrderShipments.Count().ToString() + " toyotaOrderShipments, where namcTRPTcrossRef.TRPT (" + namcTRPTcrossRef.TRPT.ToString() + ") == s.NAMC && scanManifest.OrderNumber (" + scanManifest.OrderNumber.ToString() + ") == s.ORDERNUM && scanManifest.DockCode (" + scanManifest.DockCode.ToString() + ") == s.DOCKCODE");
                //if (DEBUG) _logger.Log("-----ToyotaSkidBuildRequest()----- Shipment for SNAPARTNUM:" + shipment.SNAPARTNUM + " PANSREQ:" + shipment.PANSREQ + " ORDERQTY:" + shipment.ORDERQTY + " PANQTY:" + shipment.PANQTY + "   (ORDERNUM:" + shipment.ORDERNUM + " NAMC:" + shipment.NAMC + " DOCKCODE:" + shipment.DOCKCODE + " SUBROUTE:" + shipment.SUBROUTE + "  SHIPDATE:" + shipment.SHIPDATE + " SHIPTIME:" + shipment.SHIPTIME + " CUSTPARTNUM:" + shipment.CUSTPARTNUM + ")");

                manifestScans = (from m in ctx.ScanManifests
                                 where scanManifest.OrderNumber == m.OrderNumber
                                 && scanManifest.SupplierCode == m.SupplierCode
                                 && scanManifest.NAMC == m.NAMC
                                 && scanManifest.DockCode == m.DockCode
                                 && m.Decoded == true
                                 && m.CreatedBy.Equals("PickToLightClient")
                                 && scanManifest.ID > m.ID //Let's just use the "ID", since its faster, because its the Primary Key and Indexed.
                                 //&& m.Created < scanManifest.Created //We should only process the Scans that happened BEFORE this "B Manifest"....
                                 orderby m.Created
                                 select m).ToList();
            }

            //Now, lets go through all the OWK Scans, Sorted by Palletization Code, then Created (Date/Time) (...NO, Just use "ID"!).
            //For each one, lets just use the Manifest that was Scanned "most recent".
            //In other words, only use the Manifests that Match the Palletization Code...
            //  sorted by Created (Date/Time) (or just ID)...
            //  and get the "Last" (newest) one that came before (less than) the OWK Scan we are processing.
            //Lets store the SkidID in a field that we aren't going to use, like "Filler"...
            foreach (var scan in uniquePickerScans.OrderBy(p => p.PalletizationCode).OrderBy(p => p.ID))
            {
                if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- uniquePickerScans.OrderBy(PalletizationCode).OrderBy(ID) -- Palletization:" + scan.PalletizationCode + " Created:" + scan.Created.ToString() + " LineSideAddress:" + scan.LineSideAddress + " PartNumber:" + scan.PartNumber + " SNAPartNumber:" + scan.SupplierInformation + " Kanban:" + scan.KanbanNumber + " LotSize:" + scan.LotSize + " BoxNumber:" + scan.BoxNumber + " BoxTotal:" + scan.BoxTotal + "   (OrderNumber:" + scan.OrderNumber + " NAMCDestination:" + scan.NAMCDestination + " DockCode:" + scan.DockCode + " SubRoute:" + scan.SubRoute + "  ShipDate:" + scan.ShipDate + " ShipTime:" + scan.ShipTime + " CreatedBy:" + scan.CreatedBy + " ScannedBy:" + scan.ScannedBy + ")");
                ScanManifest manifestScan = (from m in manifestScans
                                             where scan.PalletizationCode == m.PalletizationCode
                                             && scan.Created > m.Created //Only get the Manifests that were scanned BEFORE this one...
                                             orderby m.ID
                                             select m).LastOrDefault();
                //Now, lets save the SkidId this OWK belongs to, in the "Filler" column (if we can find a Manifest/SkidId!!)
                if (manifestScan != null)
                {
                    if (string.IsNullOrEmpty(manifestScan.OrderSequence) == false)
                    {
                        int orderSequenceLength = manifestScan.OrderSequence.Length;
                        if (orderSequenceLength > 3) //The Skid
                        {
                            //The SkidId+AorBcode is the last 4 characters: XX001A, 14001B, 11002A, 1A002B, etc......
                            //But, we don't need the last character (AorBcode), we only need the 3 character "SkidId" 001, 002, 003, etc.
                            scan.Filler = manifestScan.OrderSequence.Substring(orderSequenceLength - 4, 3);
                        }
                    }
                }
            }
            //If we didn't find a matching Manifest for any of the OWK Scans, we need to send an EmailNotification and just return...
            //(Do that here, or in the "foreach" above????)
            //Actually...the logic in this "foreach" and the next "foreach" could all be combined in the one above!!!
            string manifestNotFoundMessage = "";
            foreach (var scan in uniquePickerScans.OrderBy(p => p.PalletizationCode).OrderBy(p => p.ID))
            {
                if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- uniquePickerScans.OrderBy(PalletizationCode).OrderBy(ID) -- Palletization:" + scan.PalletizationCode + " Filler (SkidId):" + scan.Filler.ToString() + " Created:" + scan.Created.ToString() + " LineSideAddress:" + scan.LineSideAddress + " PartNumber:" + scan.PartNumber + " Kanban:" + scan.KanbanNumber + " LotSize:" + scan.LotSize + " BoxNumber:" + scan.BoxNumber + " BoxTotal:" + scan.BoxTotal + "   (OrderNumber:" + scan.OrderNumber + " NAMCDestination:" + scan.NAMCDestination + " DockCode:" + scan.DockCode + " SubRoute:" + scan.SubRoute + "  ShipDate:" + scan.ShipDate + " ShipTime:" + scan.ShipTime + " CreatedBy:" + scan.CreatedBy + " ScannedBy:" + scan.ScannedBy + ")");
                if (string.IsNullOrEmpty(scan.Filler))
                {
                    if (string.IsNullOrEmpty(manifestNotFoundMessage))
                    {
                        manifestNotFoundMessage = "Unable to find a matching Manifest Scan for the following Scan OWKs:";
                    }
                    manifestNotFoundMessage += "SNAPart# " + scan.SupplierInformation + "<br>-----> Kanban# " + scan.KanbanNumber + " Box# " + scan.BoxNumber + " ScannedBy " + scan.ScannedBy + " Scanned " + scan.Created.ToString();
                }
            }
            if (string.IsNullOrEmpty(manifestNotFoundMessage) == false)//If one of the Manifests wasn't found, send the notification and return!
            {
                SendNotificationEmail_OrderNotComplete(scanManifest, false, manifestNotFoundMessage);
                if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "ERROR", "-----DoSkidBuildTransaction()----- SendNotificationEmail_OrderNotComplete, manifestNotFoundMessage = " + manifestNotFoundMessage);
                return;
            }
            //Now, lets build the Skids and Kanbans!
            //Actually...the logic in this "foreach" and the "foreach" above could all be combined in the first one!!!
            string lastPalletizationCode = "";
            string lastSkidId = "";
            reqSkidBuild.skids = new List<Skid>();
            Skid skidItem = null;
            Kanban kanbanItem = null;
            foreach (var scan in uniquePickerScans.OrderBy(p => p.PalletizationCode).OrderBy(p => p.ID))
            {
                //First, let's see if we have a new "Skid", if so, add one, then we all all the KanBans for that Skid.
                if (lastPalletizationCode != scan.PalletizationCode || lastSkidId != scan.Filler)
                {
                    lastPalletizationCode = scan.PalletizationCode;
                    lastSkidId = scan.Filler;
                    if (skidItem != null)
                    {
                        ////It appears we don't hve to add the rfidDetails!!!
                        ////BUT.... the method that builds the JSON adds a "null" rfidDetails... so lets add an empty one for now so the Request format is correct!)
                        //skidItem.rfidDetails = new List<RfidDetail>();

                        //RfidDetail rfidItem1 = new RfidDetail();
                        //rfidItem1.rfId = null; //rfId = "";
                        //rfidItem1.type = "";
                        //skidItem.rfidDetails.Add(rfidItem1);
                        ////RfidDetail rfidItem2 = new RfidDetail();
                        ////rfidItem2.rfId = null; //rfId = "";
                        ////rfidItem2.type = "";
                        ////skidItem.rfidDetails.Add(rfidItem2);

                        reqSkidBuild.skids.Add(skidItem); //New SkidItem, add it! (This is for the first one and every new one, exceot the last one, which is added outside the "foreach"...)
                    }
                    skidItem = new Skid();
                    skidItem.palletization = scan.PalletizationCode;
                    skidItem.skidId = scan.Filler;
                    skidItem.kanbans = new List<Kanban>();
                }
                kanbanItem = new Kanban();
                kanbanItem.lineSideAddress = scan.LineSideAddress;
                kanbanItem.partNumber = scan.PartNumber;
                kanbanItem.kanban = scan.KanbanNumber;
                kanbanItem.qpc = (Int32.TryParse(scan.LotSize, out parsedInt) ? parsedInt : 0);
                kanbanItem.boxNumber = (Int32.TryParse(scan.BoxNumber, out parsedInt) ? parsedInt : 0);
                kanbanItem.manifestNumber = null; //manifestNumber = "";
                kanbanItem.rfId = null; //rfId = "";
                skidItem.kanbans.Add(kanbanItem);
            }
            ////It appears we don't have to add the rfidDetails!!!
            ////BUT.... the method that builds the JSON adds a "null" rfidDetails... so lets add an empty one for now so the Request format is correct!)
            //skidItem.rfidDetails = new List<RfidDetail>();

            //RfidDetail rfidItem = new RfidDetail();
            //rfidItem.rfId = null; //rfId = "";
            //rfidItem.type = "";
            //skidItem.rfidDetails.Add(rfidItem);
            ////RfidDetail rfidItem2 = new RfidDetail();
            ////rfidItem2.rfId = null; //rfId = "";
            ////rfidItem2.type = "";
            ////skidItem.rfidDetails.Add(rfidItem2);
            reqSkidBuild.skids.Add(skidItem); //Add the last SkidItem.

            //Lets order the Skids by SkidId (001,002,Etc) and the Kanbans by Part#, then Box#.
            //It makes the Request String/Json/SQL all easier to evaluate/debug/look at!
            reqSkidBuild.skids.Sort((a, b) => a.skidId.CompareTo(b.skidId));
            foreach (var skid in reqSkidBuild.skids)
            {
                //skid.kanbans.Sort((a, b) => a.partNumber.CompareTo(b.partNumber));
                skid.kanbans = skid.kanbans.OrderBy(o => o.partNumber).ThenBy(o => o.boxNumber).ToList();
            }

            SkidBuildOrder newSkidBuildOrder = CreateSkidBuildSQLEntry(reqSkidBuild, scanManifest.ScannedBy);
            if(newSkidBuildOrder == null)
            {
                _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "EXCEPTION", "-----DoSkidBuildTransaction()==== Problem creating SkidBuild SQL Rows for scanManifest.ID: " + scanManifest.ID + ", scanManifest.NAMC:"  + scanManifest.NAMC.ToString() + ", scanManifest.SupplierCode:" + scanManifest.SupplierCode.ToString() + " scanManifest.DockCode:" + scanManifest.DockCode);
            }

            ////////////////////////////////////////Build the RequestSkidBuild!!!!!////////////////////////////////////////

            String Username = "24d058ee-4775-4426-9ae0-6d3e612b5e10";  //AppID
            String Password = "W8aD2pM3qO7fS8xC3wE7bD1kX1nN8fG3gS8iN1kE8gH2iF3aX0";  //AppSecret

            String SkidURL = "https://api.toyota.com/tmna/prod/Logistics/v/SupplierOrderInformation/skid";
            String TrailerURL = "https://api.toyota.com/tmna/prod/Logistics/v/SupplierOrderInformation/trailer";

            //if (DEBUG) _logger.Log("-----DoSkidBuildTransaction()-----++++++++++New Skid Build Request++++++++++");
            //if (DEBUG) _logger.Log("-----DoSkidBuildTransaction()SkidURL: " + SkidURL);
            //if (DEBUG) _logger.Log("-----DoSkidBuildTransaction()Request (ObjectDumper): " + ObjectDumper.Dump(reqSkidBuild));
            //if (DEBUG) _logger.Log("-----DoSkidBuildTransaction()Request (JSON): " + JsonConvert.SerializeObject(reqSkidBuild));

            ToyotaSCSWebAPI tscsWebAPI = new ToyotaSCSWebAPI(Username, Password, SkidURL, TrailerURL);

            APIresponse response = null;

            //Testing API Communication!
            //response = tscsWebAPI.SendRequest<APIresponse>(SkidURL, "[{\"order\":\"2018090501SA\"}]");
            //if (DEBUG) _logger.Log("-----DoSkidBuildTransaction()==========(Only Sending Order, for test...) Response: " + Misc.ClassToString(response));

            List<RequestSkidBuild> orders = new List<RequestSkidBuild>();
            orders.Add(reqSkidBuild);
            string jsonRequest = JsonConvert.SerializeObject(orders);
            if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()=======Request (JSON): " + jsonRequest);
            response = tscsWebAPI.SendRequest<APIresponse>(SkidURL, jsonRequest);
            //Console.WriteLine("-----DoSkidBuildTransaction()==========Response: " + Misc.ClassToString(response));
            //Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            //Console.WriteLine("-----DoSkidBuildTransaction()==========Response (ObjectDumper): " + ObjectDumper.Dump(response));
            //Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            //if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()==========Response: " + Misc.ClassToString(response));
            if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()==========Response (ObjectDumper): " + ObjectDumper.Dump(response));

            //
            //HandleAPIResponse() creates the SQL Rows for APIResponse, APIResonseMessage and SkidBuildOrderResponse (Maybe ShipmentLoadTrailerResponse in future???)
            //      It also "parses" the response and determines what to do? Like update ToyotaShipments or SkidBuildOrder Tables, or send an EMAIL Notification to "Managers" or "Developers"????
            //      RIGHT??? Make sure it does do all that!
            //
            HandleAPIResponse(response, newSkidBuildOrder, toyotaOrderShipments, scanManifest.ScannedBy);


            //
            //Simulate more responses, just to test Methods and proper SQL creation!
            //
            //Bad UserName
            Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            Console.WriteLine("Press any Key and I will Send A BAD UserName!");
            Console.ReadKey(true);
            tscsWebAPI.UserName = "BAD";
            response = tscsWebAPI.SendRequest<APIresponse>(SkidURL, jsonRequest);
            //Console.WriteLine("-----DoSkidBuildTransaction()==========Response: " + Misc.ClassToString(response));
            //Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            //Console.WriteLine("-----DoSkidBuildTransaction()==========Response (ObjectDumper): " + ObjectDumper.Dump(response));
            //Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            HandleAPIResponse(response, newSkidBuildOrder, toyotaOrderShipments, scanManifest.ScannedBy);

            //Wrong URL "method"
            Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            Console.WriteLine("Press any Key and I will Send the wrong URL/WebMethod!");
            tscsWebAPI.UserName = Username;
            Console.ReadKey(true);
            response = tscsWebAPI.SendRequest<APIresponse>("https://api.toyota.com/tmna/prod/Logistics/v/SupplierOrderInformation/skidBAD", jsonRequest);
            //Console.WriteLine("-----DoSkidBuildTransaction()==========Response: " + Misc.ClassToString(response));
            //Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            //Console.WriteLine("-----DoSkidBuildTransaction()==========Response (ObjectDumper): " + ObjectDumper.Dump(response));
            //Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            HandleAPIResponse(response, newSkidBuildOrder, toyotaOrderShipments, scanManifest.ScannedBy);

            //Sending to HTTP URL
            Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            Console.WriteLine("Press any Key and I will Send to HTTP URL!");
            Console.ReadKey(true);
            response = tscsWebAPI.SendRequest<APIresponse>("http://api.toyota.com/tmna/prod/Logistics/v/SupplierOrderInformation/skid", jsonRequest);
            //Console.WriteLine("-----DoSkidBuildTransaction()==========Response: " + Misc.ClassToString(response));
            //Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            //Console.WriteLine("-----DoSkidBuildTransaction()==========Response (ObjectDumper): " + ObjectDumper.Dump(response));
            //Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            HandleAPIResponse(response, newSkidBuildOrder, toyotaOrderShipments, scanManifest.ScannedBy);

            //Wrong URL...
            Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            Console.WriteLine("Press any Key and I will Send the wrong URL... No Method!");
            Console.ReadKey(true);
            response = tscsWebAPI.SendRequest<APIresponse>("https://api.toyota.com/tmna/prod/Logistics/v/SupplierOrderInformation/", jsonRequest);
            //Console.WriteLine("-----DoSkidBuildTransaction()==========Response: " + Misc.ClassToString(response));
            //Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            //Console.WriteLine("-----DoSkidBuildTransaction()==========Response (ObjectDumper): " + ObjectDumper.Dump(response));
            //Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            HandleAPIResponse(response, newSkidBuildOrder, toyotaOrderShipments, scanManifest.ScannedBy);

            //Sending only an Order #
            Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            Console.WriteLine("Press any Key and I will Send only an Order Num!");
            Console.ReadKey(true);
            response = tscsWebAPI.SendRequest<APIresponse>(SkidURL, "[{\"order\":\"2018090501SA\"}]");
            //Console.WriteLine("-----DoSkidBuildTransaction()==========Response: " + Misc.ClassToString(response));
            //Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            //Console.WriteLine("-----DoSkidBuildTransaction()==========Response (ObjectDumper): " + ObjectDumper.Dump(response));
            //Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            HandleAPIResponse(response, newSkidBuildOrder, toyotaOrderShipments, scanManifest.ScannedBy);
            
            //Sending only an Order #, but with multiple APIMessages!!
            Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            Console.WriteLine("Press any Key and I will Send only an Order Num, but testing Multi APIResponseMessage SQL!!!");
            Console.ReadKey(true);
            response = tscsWebAPI.SendRequest<APIresponse>(SkidURL, "[{\"order\":\"2018090501SA\"}]");
            //Console.WriteLine("-----DoSkidBuildTransaction()==========Response: " + Misc.ClassToString(response));
            //Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            //Console.WriteLine("-----DoSkidBuildTransaction()==========Response (ObjectDumper): " + ObjectDumper.Dump(response));
            //Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            //RIGHT HERE, LETS TEST:
            //NOTE: There can be multiple APIResponseMessages received, and within each of those there can be multiple Messages!
            //Test multiple APIResponseMessages, some with ONE Message and some with more than one!!
            Message tempTesting = new Message();
            tempTesting.message = new List<string>();
            tempTesting.keyObject = "Extra APIMessage for testing SQL. (One Message.)";
            tempTesting.message.Add("This is the only Message in this Test.");
            response.messages.Add(tempTesting);
            tempTesting = new Message();
            tempTesting.message = new List<string>();
            tempTesting.keyObject = response.messages[0].keyObject;
            tempTesting.message.Add("Extra APIMessage for testing SQL. (First of two Messages.).");
            tempTesting.message.Add("Added another Message for Testing, Message 2");
            response.messages.Add(tempTesting);
            HandleAPIResponse(response, newSkidBuildOrder, toyotaOrderShipments, scanManifest.ScannedBy);
            //
            //Simulate more responses (above), just to test Methods and proper SQL creation!
            //
        }

        //private void SendNotificationEmail_OrderNotComplete(ScanManifest scanManifest, bool CompletedWithDuplicates, string manifestNotFoundMessage)
        private static void SendNotificationEmail_OrderNotComplete(ScanManifest scanManifest, bool CompletedWithDuplicates, string manifestNotFoundMessage)
        {
            String emailSendTo = "";
            using (var ctx = new PickToLightEntities())
            {
                AppSetting email = (from s in ctx.AppSettings
                                    where s.Name == "TSCS_EmailNotification"
                                    select s).SingleOrDefault<AppSetting>();
                if (email != null)
                {
                    emailSendTo = email.Value;
                }
            }
            if (string.IsNullOrEmpty(emailSendTo))
            {
                emailSendTo = "sjudkins@shiroki-na.com";
            }

            _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "INFO", "-----SendNotificationEmail_OrderNotComplete()----- to " + emailSendTo);

            // TODO - FINISH!
            string body = "<br>This Manifest was just pulled, but the system is unable to send it to the \"Toyota SCS\" for Approval.<br>" +
                        "The details of this Order are available on the SNA Toyota Shipping Confirmation System site.<br>" +
                        "Please corect and submit to Toyota for Approval, ASAP!<br>" +
                        "<br>" +
                //"             ID: " + scanManifest.ID.ToString() + "<br>" +
                //"    OrderNumber:" + scanManifest.OrderNumber.ToString() + "<br>" +
                //"  OrderSequence:" + scanManifest.OrderSequence.ToString() + "<br>" +
                //"   SupplierCode:" + scanManifest.SupplierCode.ToString() + "<br>" +
                //"           NAMC: " + scanManifest.NAMC.ToString() + "<br>" +
                //"       DockCode:" + scanManifest.DockCode.ToString() + "<br>" +
                        "<table>" +
                        "<tr><td>ID:</td><td>" + scanManifest.ID.ToString() + "</td></tr>" +
                        "<tr><td>OrderNumber:</td><td>" + scanManifest.OrderNumber.ToString() + "</td></tr>" +
                        "<tr><td>OrderSequence:</td><td>" + scanManifest.OrderSequence.ToString() + "</td></tr>" +
                        "<tr><td>SupplierCode:</td><td>" + scanManifest.SupplierCode.ToString() + "</td></tr>" +
                        "<tr><td>NAMC:</td><td>" + scanManifest.NAMC.ToString() + "</td></tr>" +
                        "<tr><td>DockCode:</td><td>" + scanManifest.DockCode.ToString() + "</td></tr>" +
                        "</table><br>" +
                        "(Provide Link to SHIROKInet for this _Manifest/ToyotaShipment_.)<br>";
            if (CompletedWithDuplicates) //I'm going to eliminate most (or ALL) of these by changing the PickToLightClient software!
            {
                body = body + "<br><span style=\"font-size:120%;font-weight:bold\">(Note: There were \"Duplicate Scans\" (the same OWK Label was scanned multiple times) in the system for this Manifest!!)</span>";
                _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "ERROR", "-----SendNotificationEmail_OrderNotComplete()----- The same Barcode/BoxNumber was scanned Multiple times! scanManifest.ID:" + scanManifest.ID.ToString() + " scanManifest.NAMC:" + scanManifest.NAMC.ToString() + " scanManifest.SupplierCode:" + scanManifest.SupplierCode.ToString() + " scanManifest.DockCode:" + scanManifest.DockCode.ToString() + " scanManifest.OrderNumber:" + scanManifest.OrderNumber.ToString() + " scanManifest.OrderSequence:" + scanManifest.OrderSequence.ToString());
            }
            else
            {
                _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "INFO", "-----SendNotificationEmail_OrderNotComplete()----- scanManifest.ID:" + scanManifest.ID.ToString() + " scanManifest.NAMC:" + scanManifest.NAMC.ToString() + " scanManifest.SupplierCode:" + scanManifest.SupplierCode.ToString() + " scanManifest.DockCode:" + scanManifest.DockCode.ToString() + " scanManifest.OrderNumber:" + scanManifest.OrderNumber.ToString() + " scanManifest.OrderSequence:" + scanManifest.OrderSequence.ToString());
            }
            if (string.IsNullOrEmpty(manifestNotFoundMessage) == false) //Right now, this is used to include the OWKs that couldn't be matched up with a Manifest...
            {
                body = body + "<br><span style=\"font-size:120%;font-weight:bold\">" + manifestNotFoundMessage + "</span>";
                _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "ERROR", "-----SendNotificationEmail_OrderNotComplete()----- Unable to figure out the matching Manifest for some of the OWKs! scanManifest.ID:" + scanManifest.ID.ToString() + " scanManifest.NAMC:" + scanManifest.NAMC.ToString() + " scanManifest.SupplierCode:" + scanManifest.SupplierCode.ToString() + " scanManifest.DockCode:" + scanManifest.DockCode.ToString() + " scanManifest.OrderNumber:" + scanManifest.OrderNumber.ToString() + " scanManifest.OrderSequence:" + scanManifest.OrderSequence.ToString());
                _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "ERROR", "-----SendNotificationEmail_OrderNotComplete()----- manifestNotFoundMessage: " + manifestNotFoundMessage);
            }

            Misc.SendEmail("PickToLightServer@shiroki-na.com", emailSendTo, "Toyota SCS SkidBuild Issue - ATTENTION REQUIRED!", body);
        }

        //private void SendEMailNotificationAndLogException(string exceptionMessage)
        private static void SendEMailNotificationAndLogException(string exceptionMessage)
        {
            _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "EXCEPTION", "-----SendEMailNotificationAndLogException()----- Message:" + exceptionMessage);

            String emailSendTo = "";
            using (var ctx = new PickToLightEntities())
            {
                AppSetting email = (from s in ctx.AppSettings
                                    where s.Name == "TSCS_ApplicationException_EmailNotification"
                                    select s).SingleOrDefault<AppSetting>();
                if (email != null)
                {
                    emailSendTo = email.Value;
                }
            }
            if (string.IsNullOrEmpty(emailSendTo))  // If no Email in AppSettings for "TSCS_ApplicationException_EmailNotification", try "TSCS_EmailNotification" 
            {
                using (var ctx = new PickToLightEntities())
                {
                    AppSetting email = (from s in ctx.AppSettings
                                        where s.Name == "TSCS_EmailNotification"
                                        select s).SingleOrDefault<AppSetting>();
                    if (email != null)
                    {
                        emailSendTo = email.Value;
                    }
                }
            }
            if (string.IsNullOrEmpty(emailSendTo))
            {
                emailSendTo = "sjudkins@shiroki-na.com";
            }

            _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "INFO", "-----SendEMailNotificationAndLogException()----- to " + emailSendTo);

            // TODO - FINISH!
            string body = "<br><span style=\"font-size:120%;font-weight:bold;color:red;\">There is a SERIOUS problem in the PickToLightServer program. Please investigate!!!</span><br>" +
                        "<br> Exception Message: " + exceptionMessage;
                        //"<br> This occured after receiving a Pick To Light Command (P2L_COMMAND_ScanManifestEnd) for this Manifest:<br>"
                        //"<table>" +
                        //"<tr><td>ID:</td><td>" + scanManifest.ID.ToString() + "</td></tr>" +
                        //"<tr><td>OrderNumber:</td><td>" + scanManifest.OrderNumber.ToString() + "</td></tr>" +
                        //"<tr><td>OrderSequence:</td><td>" + scanManifest.OrderSequence.ToString() + "</td></tr>" +
                        //"<tr><td>SupplierCode:</td><td>" + scanManifest.SupplierCode.ToString() + "</td></tr>" +
                        //"<tr><td>NAMC:</td><td>" + scanManifest.NAMC.ToString() + "</td></tr>" +
                        //"<tr><td>DockCode:</td><td>" + scanManifest.DockCode.ToString() + "</td></tr>" +
                        //"</table><br>" +
                        //"(Provide Link to SHIROKInet for this _Manifest/ToyotaShipment_.)<br>";

            Misc.SendEmail("PickToLightServer@shiroki-na.com", emailSendTo, "Toyota SCS - Application Exception!!!!", body);
        }

        //private void SendEMailNotificationToFixValidationErrors(SkidBuildOrder SkidBuildOrder,string emailMessage)
        private static void SendEMailNotificationToFixValidationErrors(SkidBuildOrder SkidBuildOrder, string emailMessage)
        {
            _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "ERROR", "-----SendEMailNotificationToFixValidationErrors()----- Message:" + emailMessage);

            String emailSendTo = "";
            using (var ctx = new PickToLightEntities())
            {
                AppSetting email = (from s in ctx.AppSettings
                                    where s.Name == "TSCS_EmailNotification"
                                    select s).SingleOrDefault<AppSetting>();
                if (email != null)
                {
                    emailSendTo = email.Value;
                }
            }
            if (string.IsNullOrEmpty(emailSendTo))
            {
                emailSendTo = "sjudkins@shiroki-na.com";
            }

            _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "INFO", "-----SendEMailNotificationToFixValidationErrors()----- to " + emailSendTo);

            // TODO - FINISH!
            string body = emailMessage +
            "<br> This occured while processing a \"Pick To Light Command\" (P2L_COMMAND_ScanManifestEnd), for this Manifest:<br>" +
            "<table style=\"margin-left: 10px;\">" +
            "<tr><td>ID:</td><td>" + SkidBuildOrder.ID.ToString() + "</td></tr>" +
            "<tr><td>OrderNumber:</td><td>" + SkidBuildOrder.OrderNumber.ToString() + "</td></tr>" +
            "<tr><td>SupplierCode:</td><td>" + SkidBuildOrder.SupplierCode.ToString() + "</td></tr>" +
            "<tr><td>Plant (NAMC):</td><td>" + SkidBuildOrder.Plant.ToString() + "</td></tr>" +
            "<tr><td>DockCode:</td><td>" + SkidBuildOrder.DockCode.ToString() + "</td></tr>" +
            "</table><br>" +
            "(Provide Link to SHIROKInet for this SkidBuildOrder.)<br>";

            Misc.SendEmail("PickToLightServer@shiroki-na.com", emailSendTo, "Toyota SCS - Validation Errors!!!!", body);
        }

        //private int CreateSkidBuildSQLEntry(RequestSkidBuild reqSkidBuild, string pickerName)
        private static SkidBuildOrder CreateSkidBuildSQLEntry(RequestSkidBuild reqSkidBuild, string pickerName)
        {
            SkidBuildOrder newPalletBuildOrder = null; // new SkidBuildOrder();

            //
            //public partial class SkidBuildOrder()
            //{
            //public int ID { get; set; }
            //public string OrderNumber { get; set; }
            //public string SupplierCode { get; set; }
            //public string Plant { get; set; }
            //public string DockCode { get; set; }
            //public string ConfirmationNumber { get; set; }
            //public System.DateTime Created { get; set; }
            //public string CreatedBy { get; set; }
            //public System.DateTime Modified { get; set; }
            //public string ModifiedBy { get; set; }
            //this.SkidBuildOrderExceptions = new HashSet<SkidBuildOrderException>();
            //this.SkidBuildOrderResponses = new HashSet<SkidBuildOrderResponse>();
            //this.SkidBuildSkids = new HashSet<SkidBuildSkid>();
            //}

            var SkidBuildOrder = new SkidBuildOrder();

            SkidBuildOrder.OrderNumber = reqSkidBuild.order;
            SkidBuildOrder.SupplierCode = reqSkidBuild.supplier;
            SkidBuildOrder.Plant = reqSkidBuild.plant;
            SkidBuildOrder.DockCode = reqSkidBuild.dock;
            //SkidBuildOrder.Created = DateTime.Now; SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
            SkidBuildOrder.CreatedBy = pickerName;
            //SkidBuildOrder.Modified = DateTime.Now;  SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
            SkidBuildOrder.ModifiedBy = pickerName; //= ""; //Empty or NULL, until actually Modified?? Or, store the CreatedBy user??

            //
            //Now add the Skids...
            //
            //
            //public partial class SkidBuildSkid
            //{
            //public int ID { get; set; }
            //public int SkidBuildOrderID { get; set; }
            //public string SkidId { get; set; }
            //public string PalletizationCode { get; set; }
            //public string RFId { get; set; }
            //public System.DateTime Created { get; set; }
            //public string CreatedBy { get; set; }
            //public System.DateTime Modified { get; set; }
            //public string ModifiedBy { get; set; }
            //this.SkidBuildKanbans = new HashSet<SkidBuildKanban>();
            //}
            //Use Foreign Key and add the Skids
            if (reqSkidBuild.skids != null)
            {
                if (reqSkidBuild.skids.Count > 0)
                {
                    SkidBuildSkid SkidBuildSkid;
                    foreach (var skid in reqSkidBuild.skids)
                    {
                        SkidBuildSkid = new SkidBuildSkid();
                        //SkidBuildSkid.SkidBuildOrderID = //ID of SkidBuildOrder, but it hasn't been created yet!! May need to change the ordering here...
                        SkidBuildSkid.SkidId = skid.skidId.PadLeft(3, '0');
                        SkidBuildSkid.PalletizationCode = skid.palletization;
                        //SkidBuildSkid.Created = DateTime.Now;  SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
                        SkidBuildSkid.CreatedBy = pickerName;
                        //SkidBuildSkid.Modified = DateTime.Now;  SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
                        SkidBuildSkid.ModifiedBy = pickerName; //= ""; //Empty or NULL, until actually Modified?? Or, store the CreatedBy user??
                        //WAIT, Add this AFTER the kanbans!! -- SkidBuildOrder.SkidBuildSkids.Add(SkidBuildSkid);
                        //
                        //Now add the Kanbans, for this Skid!!
                        //
                        //
                        //public partial class SkidBuildKanban
                        //{
                        //public int ID { get; set; }
                        //public int SkidBuildSkidID { get; set; }
                        //public string PartNumber { get; set; }
                        //public string KanbanNumber { get; set; }
                        //public Nullable<int> QPC { get; set; }
                        //public Nullable<int> BoxNumber { get; set; }
                        //public string LineSideAddress { get; set; }
                        //public string RFId { get; set; }
                        //public string ManifestNumber { get; set; }
                        //public System.DateTime Created { get; set; }
                        //public string CreatedBy { get; set; }
                        //public System.DateTime Modified { get; set; }
                        //public string ModifiedBy { get; set; }
                        //}
                        if (skid.kanbans != null)
                        {
                            if (skid.kanbans.Count > 0)
                            {
                                SkidBuildKanban SkidBuildKanban;
                                foreach (var kanban in skid.kanbans)
                                {
                                    SkidBuildKanban = new SkidBuildKanban();

                                    //SkidBuildSkid.SkidBuildSkidID = //ID of SkidBuildSkid, but it hasn't been created yet!! May need to change the ordering here...
                                    SkidBuildKanban.PartNumber = kanban.partNumber;
                                    SkidBuildKanban.KanbanNumber = kanban.kanban;
                                    SkidBuildKanban.QPC = kanban.qpc;
                                    SkidBuildKanban.BoxNumber = kanban.boxNumber;
                                    SkidBuildKanban.LineSideAddress = kanban.lineSideAddress;
                                    SkidBuildKanban.RFId = kanban.rfId; //Will be Empty or NULL, not doing RFID right now!
                                    SkidBuildKanban.ManifestNumber = null;  //Not doing ManifestNumbers right now...
                                    //SkidBuildKanban.Created = DateTime.Now;  SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
                                    SkidBuildKanban.CreatedBy = pickerName;
                                    //SkidBuildKanban.Modified = DateTime.Now;  SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
                                    SkidBuildKanban.ModifiedBy = pickerName; //= ""; //Empty or NULL, until actually Modified?? Or, store the CreatedBy user??
                                    SkidBuildSkid.SkidBuildKanbans.Add(SkidBuildKanban);
                                }
                            }
                        }
                        SkidBuildOrder.SkidBuildSkids.Add(SkidBuildSkid);
                    }
                }
            }

            //
            //public partial class SkidBuildOrderException
            //{
            //public int ID { get; set; }
            //public int SkidBuildOrderID { get; set; }
            //public string Code { get; set; }
            //public string Comments { get; set; }
            //public System.DateTime Created { get; set; }
            //public string CreatedBy { get; set; }
            //public System.DateTime Modified { get; set; }
            //public string ModifiedBy { get; set; }
            //}
            //
            //Use Foreign Key and add the Exceptions
            if (reqSkidBuild.exceptions != null)
            {
                if (reqSkidBuild.exceptions.Count > 0)
                {
                    SkidBuildOrderException SkidBuildOrderException;
                    foreach (var exception in reqSkidBuild.exceptions)
                    {
                        SkidBuildOrderException = new SkidBuildOrderException();
                        //SkidBuildSkid.SkidBuildOrderID = //ID of SkidBuildOrder, but it hasn't been created yet!! May need to change the ordering here...
                        SkidBuildOrderException.Code = exception.exceptionCode;
                        SkidBuildOrderException.Comments = exception.comments;
                        //SkidBuildOrderException.Created = DateTime.Now;  SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
                        SkidBuildOrderException.CreatedBy = pickerName;
                        //SkidBuildOrderException.Modified = DateTime.Now;  SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
                        SkidBuildOrderException.ModifiedBy = pickerName; //= ""; //Empty or NULL, until actually Modified?? Or, store the CreatedBy user??
                        SkidBuildOrder.SkidBuildOrderExceptions.Add(SkidBuildOrderException);
                    }
                }
            }

            using (PickToLightEntities context = new PickToLightEntities())
            {
                context.SkidBuildOrders.Add(SkidBuildOrder);
                context.SaveChanges();
                //return (SkidBuildOrder.ID); //return the newly created ID!
                //Console.WriteLine("New SkidBuildOrder ID: " + SkidBuildOrder.ID.ToString());
                newPalletBuildOrder = SkidBuildOrder;
            }
            return (newPalletBuildOrder);
        }

        //private APIResponse CreateAPIResponseSQLEntry(int newPalletBuildOrderID, APIresponse response, string pickerName)
        private static APIResponse CreateAPIResponseSQLEntry(int newPalletBuildOrderID, APIresponse response, string pickerName)
        {
            bool DEBUG = false;

            //
            //public partial class APIResponse()
            //{
            //public int ID { get; set; }
            //public string Exception { get; set; }
            //public Nullable<int> Code { get; set; }
            //public string ConfirmationNumber { get; set; }
            //public string ConfirmedOrderNumber { get; set; }
            //public string ConfirmedOrderSupplierCode { get; set; }
            //public string ConfirmedOrderPlant { get; set; }
            //public string ConfirmedOrderDockCode { get; set; }
            //public string ConfirmedTrailerSupplierCode { get; set; }
            //public string ConfirmedTrailerRoute { get; set; }
            //public string ConfirmedTrailerRun { get; set; }
            //public string ConfirmedTrailerNumber { get; set; }
            //public Nullable<System.DateTime> ConfirmedTrailerPickUp { get; set; }
            //public string HTTPCode { get; set; }
            //public string HTTPMessage { get; set; }
            //public string HTTPMoreInformation { get; set; }
            //public System.DateTime Created { get; set; }
            //public string CreatedBy { get; set; }
            //this.APIResponseMessages = new HashSet<APIResponseMessage>();
            //this.SkidBuildOrderResponses = new HashSet<SkidBuildOrderResponse>();
            //}

            APIResponse aPIResponse = new APIResponse();

            //aPIResponse.Exception = "Parse dotNetException Object, HERE OR END OF Method????";
            aPIResponse.Code = response.code;
            aPIResponse.ConfirmationNumber = string.IsNullOrEmpty(response.confirmationNumber) ? "" : response.confirmationNumber;
            if (response.confirmedOrders != null)
            {
                if (response.confirmedOrders.Count > 1) //We don't send "batch orders", only one order at a time!!!
                {
                    Console.WriteLine("TODO - //Called From - CreateAPIResponseSQLEntry() - SendEMailNotificationAndLogException");
                    Console.WriteLine("Application ERROR! More than one confirmedOrder received in API Response!!!");
                    SendEMailNotificationAndLogException("Application ERROR! More than one confirmedOrder received in API Response!!!");
                }
                if (response.confirmedOrders.Count > 0)
                {
                    aPIResponse.ConfirmedOrderNumber = string.IsNullOrEmpty(response.confirmedOrders[0].order) ? "" : response.confirmedOrders[0].order; //response.confirmedOrders[0].order;
                    aPIResponse.ConfirmedOrderSupplierCode = string.IsNullOrEmpty(response.confirmedOrders[0].supplier) ? "" : response.confirmedOrders[0].supplier; //response.confirmedOrders[0].supplier;
                    aPIResponse.ConfirmedOrderPlant = string.IsNullOrEmpty(response.confirmedOrders[0].plant) ? "" : response.confirmedOrders[0].plant; //response.confirmedOrders[0].plant;
                    aPIResponse.ConfirmedOrderDockCode = string.IsNullOrEmpty(response.confirmedOrders[0].dock) ? "" : response.confirmedOrders[0].dock; //response.confirmedOrders[0].dock;
                }
            }
            //This isn't called for a ShipLoad, or IS IT????
            if (response.confirmedTrailer != null)
            {
                aPIResponse.ConfirmedTrailerSupplierCode = string.IsNullOrEmpty(response.confirmedTrailer.supplier) ? "" : response.confirmedTrailer.supplier; //response.confirmedTrailer.supplier;
                aPIResponse.ConfirmedTrailerRoute = string.IsNullOrEmpty(response.confirmedTrailer.route) ? "" : response.confirmedTrailer.route; //response.confirmedTrailer.route;
                aPIResponse.ConfirmedTrailerRun = string.IsNullOrEmpty(response.confirmedTrailer.run) ? "" : response.confirmedTrailer.run; //response.confirmedTrailer.run;
                aPIResponse.ConfirmedTrailerNumber = string.IsNullOrEmpty(response.confirmedTrailer.trailerNumber) ? "" : response.confirmedTrailer.trailerNumber; //response.confirmedTrailer.trailerNumber;
                DateTime dateTime;
                if (DateTime.TryParse(response.confirmedTrailer.pickUp, out dateTime) == false)
                {
                    aPIResponse.ConfirmedTrailerPickUp = null;
                    Console.WriteLine("TODO - //Called From - CreateAPIResponseSQLEntry() - SendEMailNotificationAndLogException");
                    Console.WriteLine("Application ERROR! Unable to parse the confirmed trailer Pickup Date/Time in API Response!!!");
                    SendEMailNotificationAndLogException("Application ERROR! Unable to parse the confirmed trailer Pickup Date/Time in API Response!!!");
                }
                else
                {
                    aPIResponse.ConfirmedTrailerPickUp = dateTime;
                }
            }

            aPIResponse.HTTPCode = string.IsNullOrEmpty(response.httpCode) ? "" : response.httpCode; //response.httpCode;
            aPIResponse.HTTPMessage = string.IsNullOrEmpty(response.httpMessage) ? "" : response.httpMessage; //response.httpMessage;
            aPIResponse.HTTPMoreInformation = string.IsNullOrEmpty(response.moreInformation) ? "" : response.moreInformation; //response.moreInformation;
            //aPIResonse.Created = DateTime.Now;  SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
            aPIResponse.CreatedBy = pickerName;

            //Now add APIResponseMessages
            if (response.messages != null)
            {
                if (response.messages.Count > 0)
                {
                    //
                    //public partial class APIResponseMessage
                    //{
                    //    public int ID { get; set; }
                    //    public int APIResponseID { get; set; }
                    //    public string KeyObject { get; set; }
                    //    public string Message { get; set; }
                    //    public System.DateTime Created { get; set; }
                    //    public string CreatedBy { get; set; }
                    //
                    //    public virtual APIResponse APIResponse { get; set; }
                    //}
                    //NOTE: There can be multiple APIResponseMessages received, and within each of those there can be multiple Messages!
                    APIResponseMessage aPIResponseMessage;
                    foreach (var message in response.messages)
                    {
                        if (message.message != null)
                        {
                            if (message.message.Count == 1)
                            {
                                aPIResponseMessage = new APIResponseMessage();
                                //aPIResponseMessage.APIResponseID = //ID of APIResponse, but it hasn't been created yet!! May need to change the ordering here...
                                aPIResponseMessage.KeyObject = string.IsNullOrEmpty(message.keyObject) ? "" : message.keyObject; //message.keyObject;
                                aPIResponseMessage.Message = string.IsNullOrEmpty(message.message[0]) ? "" : message.message[0]; //message.message[0];
                                //aPIResponseMessage.Created = DateTime.Now;  SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
                                aPIResponseMessage.CreatedBy = pickerName;
                                aPIResponse.APIResponseMessages.Add(aPIResponseMessage);
                            }
                            else if (message.message.Count > 1) //If more than one message for this "APIResponseMessage", add additional Rows!
                            {
                                //NOTE: This handles multiple "messages" inside an "APIResponseMessage"!
                                foreach (var innerMessage in message.message)
                                {
                                    aPIResponseMessage = new APIResponseMessage();
                                    //aPIResponseMessage.APIResponseID = //ID of APIResponse, but it hasn't been created yet!! May need to change the ordering here...
                                    aPIResponseMessage.KeyObject = string.IsNullOrEmpty(message.keyObject) ? "" : message.keyObject; //message.keyObject;
                                    aPIResponseMessage.Message = string.IsNullOrEmpty(innerMessage) ? "" : innerMessage; //innerMessage; //message.message[0];
                                    //aPIResponseMessage.Created = DateTime.Now;  SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
                                    aPIResponseMessage.CreatedBy = pickerName;
                                    aPIResponse.APIResponseMessages.Add(aPIResponseMessage);
                                }
                            }
                        }
                    }
                }
            }


            //This is a Many-To-Many Table, or "Mapping" table....we need the ID of one of the ForeignKeys, possibly both....
            //If we are going to do this here, we AT LEAT need the ID of the "SkidBuildOrder" for "SkidBuildOrderID"...
            //Now add SkidBuildOrderResponses - This isn't called for a ShipLoad, or IS IT????
            //
            //
            //public partial class SkidBuildOrderResponse
            //{
            //    public int ID { get; set; }
            //    public int APIResponseID { get; set; }
            //    public int SkidBuildOrderID { get; set; }
            //    public System.DateTime Created { get; set; }
            //    public string CreatedBy { get; set; }

            //    public virtual APIResponse APIResponse { get; set; }
            //    public virtual SkidBuildOrder SkidBuildOrder { get; set; }
            //}
            if (newPalletBuildOrderID > 0)
            {
                SkidBuildOrderResponse SkidBuildOrderResponse = new SkidBuildOrderResponse();
                //SkidBuildOrderResponse.APIResponseID = //ID of APIResponse, but it hasn't been created yet!! May need to change the ordering here...
                //SkidBuildOrderResponse.SkidBuildOrderID = //ID of SkidBuildOrder, but it hasn't been created yet!! May need to change the ordering here...
                //SkidBuildOrderResponse.SkidBuildOrderID = 21; //Hard Code the ID for this first Test Run!
                SkidBuildOrderResponse.SkidBuildOrderID = newPalletBuildOrderID;
                //SkidBuildOrderResponse.Created = DateTime.Now;  SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
                SkidBuildOrderResponse.CreatedBy = pickerName;
                aPIResponse.SkidBuildOrderResponses.Add(SkidBuildOrderResponse);
            }
            else
            {
                Console.WriteLine("TODO - //Called From - CreateAPIResponseSQLEntry() - SendEMailNotificationAndLogException (newPalletBuildOrderID <= 0!!!!)");
                SendEMailNotificationAndLogException("Application ERROR! CreateAPIResponseSQLEntry() was called with newPalletBuildOrderID <= 0!!!!");
            }
            

            aPIResponse.Exception = ""; // "Parse dotNetException Object, HERE OR BEGIN of Method????";

            if (response.dotNetException != null)
            {
                aPIResponse.Exception = "Exception Type (" + response.dotNetException.GetType().Name + ")  ";
                //All status codes are standard HTTP status codes. The below ones are used in this API.
                //2XX - Success of some kind
                //4XX - Error occurred in client’s part
                //5XX - Error occurred in server’s part
                //--
                //200 OK, Created, Accepted, Validation errors
                //400 Bad request
                //401 Authentication failure
                //403 Forbidden
                //404 Resource not found
                //405 Method Not Allowed
                //409 Conflict
                //412 Precondition Failed
                //413 Request Entity Too Large
                //500 Internal Server Error
                //501 Not Implemented
                //503 Service Unavailable

                //class System.Exception();
                //
                //public Exception(string message);
                //[SecuritySafeCritical]
                //protected Exception(SerializationInfo info, StreamingContext context);
                //public Exception(string message, Exception innerException);

                //public virtual IDictionary Data { get; }
                //public virtual string HelpLink { get; set; }
                //public int HResult { get; protected set; }
                //public Exception InnerException { get; }
                //public virtual string Message { get; }
                //public virtual string Source { get; set; }
                //public virtual string StackTrace { get; }
                //public MethodBase TargetSite { get; }
                //
                //public virtual Exception GetBaseException();

                if (response.dotNetException.GetType().Name.Equals("WebException"))
                {
                    //All status codes are standard HTTP status codes. The below ones are used in this API.
                    //2XX - Success of some kind
                    //4XX - Error occurred in client’s part
                    //5XX - Error occurred in server’s part

                    //public int ID { get; set; }
                    //public string Exception { get; set; }
                    //public Nullable<int> Code { get; set; }
                    //
                    //public string HTTPCode { get; set; }
                    //public string HTTPMessage { get; set; }
                    //public string HTTPMoreInformation { get; set; }

                    //Console.WriteLine("A WebException has been caught.");
                    System.Net.WebException webException = (System.Net.WebException)response.dotNetException;
                    //
                    //public class WebException : InvalidOperationException, ISerializable
                    //
                    //public WebException();
                    //public WebException(string message);
                    //protected WebException(SerializationInfo serializationInfo, StreamingContext streamingContext);
                    //public WebException(string message, Exception innerException);
                    //public WebException(string message, WebExceptionStatus status);
                    //public WebException(string message, Exception innerException, WebExceptionStatus status, WebResponse response);
                    //
                    //public WebResponse Response { get; }
                    //public WebExceptionStatus Status { get; }
                    //
                    
                    //WebResponse webResponse;
                    //WebExceptionStatus webExceptionStatus;

                    if(webException.Response != null)
                    {
                        HttpWebResponse httpResponse = (HttpWebResponse)webException.Response;
                        aPIResponse.Exception = aPIResponse.Exception + "Response Status Code (" + httpResponse.StatusCode.ToString() + ")  ";
                        if(string.IsNullOrEmpty(aPIResponse.HTTPCode))
                        {
                            //Console.WriteLine((int)httpResponse.StatusCode + " - " + httpResponse.StatusCode);
                            //aPIResponse.HTTPCode = httpResponse.StatusCode.ToString(); //NO! This can be longer than three???
                            aPIResponse.HTTPCode = ((int)httpResponse.StatusCode).ToString(); //Use the int value!
                        }
                    }

                    // Write out the WebException message.  
                    //Console.WriteLine(webException.ToString());
                    aPIResponse.Exception = aPIResponse.Exception + webException.ToString();
                    // Get the WebException status code.  
                    WebExceptionStatus status = webException.Status;
                    //Console.WriteLine(status.ToString());
                    aPIResponse.Exception = aPIResponse.Exception + "WebException Status Code (" + status.ToString() + ")  ";
                    if(string.IsNullOrEmpty(aPIResponse.HTTPCode))
                    {
                        //Console.WriteLine((int)httpResponse.StatusCode + " - " + httpResponse.StatusCode);
                        //aPIResponse.HTTPCode = status.ToString(); //NO! This can be longer than three???
                        aPIResponse.HTTPCode = ((int)status).ToString(); //Use the int value!
                    }
                    //// If status is WebExceptionStatus.ProtocolError,   
                    ////   there has been a protocol error and a WebResponse   
                    ////   should exist. Display the protocol error.  
                    //if (status == WebExceptionStatus.ProtocolError)
                    //{
                    //    Console.WriteLine("The server returned protocol error ");
                    //    //// Get HttpWebResponse so that you can check the HTTP status code.  
                    //    //HttpWebResponse httpResponse = (HttpWebResponse)webException.Response;
                    //    //Console.WriteLine((int)httpResponse.StatusCode + " - " + httpResponse.StatusCode);
                    //}  
                }
                else  //An exception that isn't a WebException!
                {
                    //Console.WriteLine("A WebException has been caught.");

                    //aPIResponse.Exception = "Exception Type (" + response.dotNetException.GetType().Name + ")";

                    //genericClass.GetType().GetProperty("webException").SetValue(genericClass, ex);
                    //genericClass.GetType().GetProperty("dotNetException").SetValue(genericClass, ex);

                    aPIResponse.Exception = aPIResponse.Exception + "Message (" + response.dotNetException.Message + ")  ";

                    if (response.dotNetException.InnerException != null && response.dotNetException.InnerException.Message.Length > 0)
                    {
                        aPIResponse.Exception = aPIResponse.Exception + "Inner (" + response.dotNetException.InnerException.Message + ")  ";
                    }
                }
            }

            if (aPIResponse.Exception.Length > 4000)
            {
                string trimmedIndicator = " *TRIMMED*";
                aPIResponse.Exception = aPIResponse.Exception.Substring(0, 4000 - trimmedIndicator.Length) + trimmedIndicator;
            }

            using (PickToLightEntities context = new PickToLightEntities())
            {
                context.APIResponses.Add(aPIResponse);
                try
                {
                    context.SaveChanges();
                }
                catch(Exception ex)
                {
                    Console.WriteLine("Exception Saving API Response: " + ex.Message);
                    foreach(var err in context.GetValidationErrors())
                    {
                        Console.WriteLine(  "Validation Error -- Valid? " + (err.IsValid ? "YES" : "NO"));
                            //" Entity: " + err.Entry.Entity.ToString() + " CurrentValues: " + err.Entry.CurrentValues.ToString() + " State: " + err.Entry.State.ToString());
                        foreach (var valErr in err.ValidationErrors)
                        {
                            Console.WriteLine("    ValidationErrors - PropertyName: " + valErr.PropertyName + " ErrorMessage: " + valErr.ErrorMessage);
                        }
                    }
                    StringBuilder exceptionMessage = new StringBuilder();
                    exceptionMessage.Append("Application Exception in CreateAPIResponseSQLEntry(), saving API Response: " + ex.Message);
                    foreach(var err in context.GetValidationErrors())
                    {
                        exceptionMessage.Append("<br>Validation Error -- Valid? " + (err.IsValid ? "YES" : "NO"));
                        foreach (var valErr in err.ValidationErrors)
                        {
                            exceptionMessage.Append("  PropertyName: " + valErr.PropertyName + " ErrorMessage: " + valErr.ErrorMessage);
                        }
                    }
                    SendEMailNotificationAndLogException(exceptionMessage.ToString());
                }
                //return (aPIResponse.ID); //return the newly created ID!
                //Console.WriteLine("New APIResponse ID: " + aPIResponse.ID.ToString());
            }
            return(aPIResponse);
        }

        //private void HandleAPIResponse(APIresponse response, SkidBuildOrder newPalletBuildOrder, List<ToyotaShipment> toyotaOrderShipments, string pickerName)
        private static void HandleAPIResponse(APIresponse response, SkidBuildOrder newPalletBuildOrder, List<ToyotaShipment> toyotaOrderShipments, string pickerName)
        {
            APIResponse aPIResponse = CreateAPIResponseSQLEntry(newPalletBuildOrder.ID, response, pickerName);

            //if (string.IsNullOrEmpty(aPIResponse.Exception) == false || response.dotNetException != null)
            if (string.IsNullOrEmpty(aPIResponse.Exception) == false)
            {
                //TODO!   Right here, don't I need to REMOVE any Confirmation Numbers from previous successes????
                //
                //TODO - Create SendEMailNotificationAndLogException() method to Log and EMAIL this to the "DEVELOPER"!
                //There was an Exception... So someone should have been emailed at this point, this is just a safety net to be sure that someone was!
                //SendEMailNotificationAndLogException("There was an Exception... So someone should have been emailed at this point, this is just a safety net to be sure that someone was!");
                Console.WriteLine("TODO - In HandleAPIResponse() - There was an Exception when sending the SkidBuild! Exception was (" + aPIResponse.Exception + ")");
                SendEMailNotificationAndLogException("In HandleAPIResponse() - There was an Exception when sending the SkidBuild! Exception was (" + aPIResponse.Exception + ")");
            }
            else if(response.code.ToString().StartsWith("2"))
            {
                //Store the ConfirmationNumber in the SkidBuildOrder table for this Order!
                //Mark SkidBuildOrder "Success"...
                //Indicate the ToyotaShipments used for the Order are "Shipped", done, completed, etc.
                if(aPIResponse.ConfirmationNumber != null && aPIResponse.ConfirmationNumber.Length > 0)
                {
                    Console.WriteLine("+++++++++++++++++++Order was Successfully sent and Approved!!!, The Confirmation Number was " + aPIResponse.ConfirmationNumber + "+++++++++++++++++++");
                    Console.WriteLine("");
                    //Console.WriteLine("TODO - //In HandleAPIResponse() - Store the ConfirmationNumber in the SkidBuildOrder table for this Order!");
                    Console.WriteLine("//In HandleAPIResponse() - Updating ConfirmationNumber in SkidBuildOrderID:" + newPalletBuildOrder.ID.ToString());
                    PickToLightData.SkidBuildOrder.UpdateConfirmationNumber(newPalletBuildOrder.ID, aPIResponse.ConfirmationNumber);

                    Console.WriteLine("TODO - //In HandleAPIResponse() - Mark ToyotaShipments used for the Order as \"Completed\"...");
                    PickToLightData.ToyotaShipment.UpdateToyotaShipmentsCompleted(toyotaOrderShipments, aPIResponse.ConfirmationNumber);
                }
                else
                {
                    Console.WriteLine("+++++++++++++++++++Order was Successfully sent, but not Approved, due to one or more Validation Errors:");
                    StringBuilder emailMessage = new StringBuilder();
                    emailMessage.Append("<br><span style=\"font-size:120%;font-weight:bold\">Skid Build Order was <u><span style=\"color:red;\">NOT APPROVED</span></u>, due to one or more Validation Errors:</span>");
                    foreach(var message in aPIResponse.APIResponseMessages)
                    {
                        Console.WriteLine("                   KeyObject: " + message.KeyObject);
                        Console.WriteLine("                   Message: " + message.Message);
                        //emailMessage.Append("<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;KeyObject: " + message.KeyObject);
                        //emailMessage.Append("<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Message: " + message.Message);
                        emailMessage.Append("<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Message: " + message.Message + "  (KeyObject: " + message.KeyObject + ")");
                        emailMessage.Append("<br>");
                    }
                    //EMAIL the above information to the "Managers"...
                    SendEMailNotificationToFixValidationErrors(newPalletBuildOrder, emailMessage.ToString());
                }
            }
            else
            {
                //TODO!   Right here, don't I need to REMOVE any Confirmation Numbers from previous successes????
                Console.WriteLine("In HandleAPIResponse() - There wasn't an Exception, but the transaction failed, because the response code was " + response.code.ToString());
                SendEMailNotificationAndLogException("In HandleAPIResponse() - There wasn't an Exception, but the transaction failed, because the response code was " + response.code.ToString());
            }
        }
    }
}

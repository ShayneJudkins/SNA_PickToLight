﻿using SNA.WinService.PickToLightServer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using PickToLightData;

namespace PickToLightBanderDisplay
{
    //
    //Moved to UIMultiThreadExtensions.cs
    //
    ////using System;
    ////using System.Windows.Forms;

    //public static class ControlExtensions
    //{
    //    /// <summary>
    //    /// Executes the Action asynchronously on the UI thread, does not block execution on the calling thread.
    //    /// </summary>
    //    /// <param name="control"></param>
    //    /// <param name="code"></param>
    //    public static void UIThread(this Control @this, Action code)
    //    {
    //        if (@this.InvokeRequired)
    //        {
    //            @this.BeginInvoke(code);
    //        }
    //        else
    //        {
    //            code.Invoke();
    //        }
    //    }
    //}

    public partial class MainForm : Form
    {
        bool TESTING = false; //true;

        int _startingOWKID = 6587231; //4167250;

        const int iGS = 29; //ASCII Group Separator
        const char cGS = (char)29;
        const byte bGS = 0x1D;
        const string sGS = "\x1D";
        string[] saGS = { "\x1D" };
        char[] caGS = { (char)29 };

        //private TCPServer _tcpServer = null;
        private TCPServerV2 _tcpServer = null;
        private static int _port = 12000;   //Use 12000 for Bander Display!!!
        private static string _hostName = "";
        private static string _ipAddress = "";

        private static string _banderDisplayName = ""; //Currently just "BanderDisplay1" or "BanderDisplay2"...
        private static int _banderDisplayNum; //Currently just 1 or 2

        private static string _pickToLightServer = "";
        private static System.Net.IPAddress _pickToLightServerIP;
        private static int _pickToLightServerPort = 11100;

        private static Logger _logger;

        //private static SkidBuild _skidBuild = new SkidBuild() { ScanManifestID = -1 }; //ScanManifestID = -1 when there isn't a "Skid Build" in progress (no Manifest scanned)
        private static SkidBuild _skidBuild;

        public MainForm()
        {
            InitializeComponent();

            try
            {
                if(TESTING)
                { 
                    System.Windows.Forms.Button btnNext = new System.Windows.Forms.Button();
                    System.Windows.Forms.Button btnPrev = new System.Windows.Forms.Button();
                    System.Windows.Forms.Button btnReload = new System.Windows.Forms.Button();
                    System.Windows.Forms.Button btnManifestLoad = new System.Windows.Forms.Button();

                    btnReload.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                    //btnReload.Location = new System.Drawing.Point(0, 150);
                    btnReload.Margin = new System.Windows.Forms.Padding(0);
                    btnReload.Name = "btnReload";
                    btnReload.Size = new System.Drawing.Size(20, 20);
                    btnReload.Text = "R";
                    btnReload.UseVisualStyleBackColor = true;
                    btnReload.Click += new System.EventHandler(btnReload_Click);
                    // 
                    // btnPrev
                    // 
                    btnPrev.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                    //btnPrev.Location = new System.Drawing.Point(20, 150);
                    btnPrev.Margin = new System.Windows.Forms.Padding(0);
                    btnPrev.Name = "btnPrev";
                    btnPrev.Size = new System.Drawing.Size(20, 20);
                    btnPrev.Text = "<";
                    btnPrev.UseVisualStyleBackColor = true;
                    btnPrev.Click += new System.EventHandler(btnPrev_Click);
                    // 
                    // btnNext
                    // 
                    btnNext.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                    //btnNext.Location = new System.Drawing.Point(40, 150);
                    btnNext.Margin = new System.Windows.Forms.Padding(0);
                    btnNext.Name = "btnNext";
                    btnNext.Size = new System.Drawing.Size(20, 20);
                    btnNext.Text = ">";
                    btnNext.UseVisualStyleBackColor = true;
                    btnNext.Click += new System.EventHandler(btnNext_Click);
                    // 
                    // btnManifestLoad
                    // 
                    btnManifestLoad.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                    //btnNext.Location = new System.Drawing.Point(40, 150);
                    btnManifestLoad.Margin = new System.Windows.Forms.Padding(0);
                    btnManifestLoad.Name = "btnManifestLoad";
                    btnManifestLoad.Size = new System.Drawing.Size(20, 20);
                    btnManifestLoad.Text = "M";
                    btnManifestLoad.UseVisualStyleBackColor = true;
                    btnManifestLoad.Click += new System.EventHandler(btnManifestLoad_Click);

                    messageFLPanel.Controls.Add(btnReload);
                    messageFLPanel.Controls.Add(btnPrev);
                    messageFLPanel.Controls.Add(btnNext);
                    messageFLPanel.Controls.Add(btnManifestLoad);
                }

                Thread.CurrentThread.Name = "Main Thread";

                _logger = new Logger("Pick To Light Bander Display");

                // Log a service start message to the Application log.
                //Even though LoadSettings() hasn't been called, the LogMode defaults to NoLogging.
                //So, this will work as expected!
                _logger.LogMainEvent("PickToLightBanderDisplay is Starting.");

                //Clear Error/Status
                lblScanStatus.UIThread(ctl => { ctl.Text = ""; ctl.ForeColor = Color.Black; });
                lblError.UIThread(ctl => { ctl.Text = ""; ctl.ForeColor = Color.Black; });
                lblMessage.UIThread(ctl => { ctl.Text = ""; ctl.ForeColor = Color.Black; });

                //Load the Service Settings from the Config File!
                LoadSettings();

                //Set the Windows Form Properties that don't show up in intellisense...
                //pnlPlantTable.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
                //manifestTLPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
                //pnlConfirmationTable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
                //pnlBoxTable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
                dockTLPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
                subRouteTLPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
                messageFLPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;


                //// Harcoded / Static ScanOWK IDs with delay for testing Form layout...
                ////
                ////PickToLightData.ScanOWK scanOWK = PickToLightData.ScanOWK.GetScanEntry(4167250);
                ////if(scanOWK != null) //Is this even possible?
                ////{
                ////    Populate(scanOWK);
                ////}
                ////Thread.Sleep(5000);
                ////scanOWK = PickToLightData.ScanOWK.GetScanEntry(4167251);
                ////if(scanOWK != null) //Is this even possible?
                ////{
                ////    Populate(scanOWK);
                ////}
                ////Thread.Sleep(5000);
                //PickToLightData.ScanOWK scanOWK = PickToLightData.ScanOWK.GetScanEntry(_startingOWKID);
                //if (scanOWK != null) //Is this even possible?
                //{
                //    string confirmationNumber = "";
                //    SkidBuildOrder skidBuildOrder = SkidBuildOrder.GetSkidBuildOrder(scanOWK.NAMCDestination, scanOWK.SupplierCode, scanOWK.OrderNumber, scanOWK.DockCode);
                //    if (skidBuildOrder != null) confirmationNumber = skidBuildOrder.ConfirmationNumber;
                //    Populate(scanOWK, confirmationNumber);
                //}


                //How do I determine which Bander Display this is? (BanderDisplay1 or BanderDisplay2)
                //Look it up in the "AppSettings" table...
                _hostName = System.Net.Dns.GetHostName();
                if (Misc.GetResolvedConnectionIPAddress(_hostName, out _ipAddress) == false)
                {
                    _logger.LogError("Unable to resolve IP for ServerName(" + _hostName + ")!");
                    throw new Exception("Unable to resolve IP for ServerName (" + _hostName + ")!");
                }
                if (LoadAppSettings()) //Gets values for _banderDisplayName and port.
                {
                    if (string.IsNullOrEmpty(_banderDisplayName))
                    {
                        if (_hostName.EndsWith("2"))
                        {
                            _banderDisplayName = "BanderDisplay2";
                            _banderDisplayNum = 2;
                        }
                        else
                        {
                            _banderDisplayName = "BanderDisplay2";
                            _banderDisplayNum = 1;
                        }
                        _logger.LogError("Using " + _banderDisplayName + ", since hostname is " + _hostName + " and unable to find a matching BanderDisplay entry in AppSettings for ServerName(" + _hostName + ") or IP (" + _ipAddress + ")!");

                    }

                    _skidBuild = new SkidBuild(); //Initialized to -1 in Init() { ScanManifestID = -1 }; //ScanManifestID = -1 when there isn't a "Skid Build" in progress (no Manifest scanned)
                    _skidBuild.Init((_banderDisplayNum == 2 ? "Bander2" : "Bander1"));

                    PopulateManifestPanel(); //Initialize panel.
                    PopulateOrderPanel();    //Initialize panel.
                    PopulateKanbanPanel();   //Initialize panel.

                    GetSkidBuild(); //Send the "SBQ" (SkidBuildQuery) command to the PickToLightServer to get the current Skid Build for this Bander.

                    // Create the Server Object and Start it.
                    _tcpServer = new TCPServerV2(_logger, _ipAddress, _port); //We can pass a port here or use the Default of 11100. Since PickToLightServer uses 11100, lets use a different one...
                    _tcpServer.CommandReceived += TCPServer_CommandReceived;
                    _tcpServer.StartServer();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception in Main()! Message:" + ex.Message, "Application ERROR!!");
                this.Close();
            }
        }

        public void LoadSettings()
        {
            string appSetting;

            try
            {
                //Read in the LogMode (NoLogging, FileLog, EventLog, SQLLog)
                appSetting = GetSetting("LogMode");
                //if(String.IsNullOrEmpty(appSetting))
                if (appSetting.Length == 0)
                {
                    _logger.LogMode = Logger.LogModes.NoLogging;
                    _logger.LogFolder = "LogMode=NoLogging";
                }
                else
                {
                    if (appSetting.ToUpper().Equals("NOLOGGING"))
                    {
                        _logger.LogMode = Logger.LogModes.NoLogging;
                        _logger.LogFolder = "LogMode=NoLogging";
                    }
                    else if (appSetting.ToUpper().Equals("FILELOG"))
                    {
                        _logger.LogMode = Logger.LogModes.FileLog;
                        //Read in the LogFolder (Used when LogMode = FileLog)
                        appSetting = GetSetting("LogFolder");
                        //if(String.IsNullOrEmpty(appSetting))
                        if (appSetting.Length > 0)
                        {
                            if (Directory.Exists(appSetting))
                            {
                                _logger.LogFolder = appSetting;
                            }
                            else
                            {
                                _logger.LogError("LogFolder (" + _logger.LogFolder + ") does not exist!");
                            }
                        }
                    }
                    else if (appSetting.ToUpper().Equals("EVENTLOG"))
                    {
                        _logger.LogMode = Logger.LogModes.EventLog;
                        _logger.LogFolder = "LogMode=EventLog";
                    }
                    else if (appSetting.ToUpper().Equals("SQLLOG"))
                    {
                        _logger.LogMode = Logger.LogModes.SQLLog;
                        _logger.LogFolder = "LogMode=SQLLog";
                    }
                    else // Unrecognized, so lets do EventLog!
                    {
                        _logger.LogMode = Logger.LogModes.EventLog;
                        _logger.LogFolder = "LogMode=EventLog";
                    }
                }

                //Read in the PickToLightServer
                appSetting = GetSetting("PickToLightServer");
                //if(String.IsNullOrEmpty(appSetting))
                if (appSetting.Length == 0)
                {
                    throw new ConfigurationErrorsException("PickToLightServer is missing or empty!");
                }
                else
                {
                    _pickToLightServer = appSetting;
                    if (Misc.GetResolvedConnectionIPAddress(appSetting, out _pickToLightServerIP) == false)
                    {
                        _logger.LogError("Unable to resolve IP for ServerName(" + _pickToLightServer + ")!");
                        throw new ConfigurationErrorsException("Unable to resolve IP for ServerName (" + _pickToLightServer + ")!");
                    }
                }

                //Log all the Settings loaded to the EventLog
                _logger.LogMainEvent("LogMode = (" + _logger.LogMode.ToString() + "), LogFolder = (" + _logger.LogFolder + ")");
            }
            catch (Exception e)
            {
                _logger.LogError("Exception in LoadSettings: " + e.Message);
                throw new ConfigurationErrorsException("Exception in LoadSettings: " + e.Message);
            }
        }

        private static string GetSetting(string appSetting)
        {

            if (ConfigurationManager.AppSettings == null)
            {
                return "";
            }
            if (ConfigurationManager.AppSettings.Get(appSetting) == null)
            {
                return "";
            }

            return ConfigurationManager.AppSettings.Get(appSetting);
        }

        public bool LoadAppSettings()
        {
            try
            {
                using (var ctx = new PickToLightEntities())
                {
                    AppSetting banderDisplay = (from a in ctx.AppSettings
                                                where a.Name.StartsWith("BanderDisplay") &&
                                                      (a.Value.Contains(_hostName) || a.Value.Contains(_ipAddress))
                                                select a).FirstOrDefault<AppSetting>();
                    if (banderDisplay == null)
                    {
                        _logger.LogError("Unable to find a matching BanderDisplay entry in AppSettings for ServerName(" + _hostName + ") or IP (" + _ipAddress + ")!");
                        return (false);
                    }
                    else
                    {
                        _banderDisplayName = banderDisplay.Name;
                        _banderDisplayNum = (_banderDisplayName.EndsWith("2") ? 2 : 1);

                        //Lets get the Value and see if it has a valid port and we can listen on that one instead....
                        //This will be the only way to listen on a port other than the default of 12000
                        //0–1023 (0x000–0x03FF) are reserved for "well-known ports" and typically have certain restrictions.
                        //1024–65535(0x0400–0xFFFF) are putatively open for anybody to use
                        //I am going to restrict the port range to 10000-65000
                        char delimeter = ','; //Default the delimeter to a comma, but we can allow a colon, since hostname:port is often used.
                        if (banderDisplay.Value.Contains(':')) delimeter = ':';
                        string[] valueFields = banderDisplay.Value.Split(delimeter);
                        if (valueFields.Length != 2)
                        {
                            _logger.LogError(banderDisplay.Name + " in AppSettings doesn't have a valid Value (" + banderDisplay.Value + "). It should contain the hostname (or IP) then a comma or colon delimiter, then the port. (Example: BANDER1-VIEW:12000)");
                            return(false);
                        }
                        else
                        {
                            System.Net.IPAddress ipAddress;
                            if (valueFields[0].Contains('.')) //The value is an IP address
                            {
                                if (System.Net.IPAddress.TryParse(valueFields[0], out ipAddress) == false)
                                {
                                    _logger.LogError(banderDisplay.Name + " in AppSettings doesn't have a valid Value (" + banderDisplay.Value + "). Unable to parse the IP address specified! It should contain the hostname (or IP) then a comma or colon delimiter, then the port. (Example: BANDER1-VIEW:12000)");
                                    return (false);
                                }
                            }
                            else //Assume the first value is the hostname.
                            {
                                if (Misc.GetResolvedConnectionIPAddress(valueFields[0], out ipAddress) == false) //Use this method, becasue "GetHostAddresses" returns IPV6, IPV4, etc.
                                {
                                    _logger.LogError(banderDisplay.Name + " in AppSettings doesn't have a valid Value (" + banderDisplay.Value + "). Unable to resolve the hostname to an IP address specified! It should contain the hostname (or IP) then a comma or colon delimiter, then the port. (Example: BANDER1-VIEW:12000)");
                                    return (false);
                                }
                            }

                            int port = -1;
                            if (int.TryParse(valueFields[1], out port) == false)
                            {
                                _logger.LogError(banderDisplay.Name + " in AppSettings doesn't have a valid Value (" + banderDisplay.Value + "). The port number is not an integer! It should contain the hostname (or IP) then a comma or colon delimiter, then the port. (Example: BANDER1-VIEW:12000)");
                                return (false);
                            }
                            if (port < 10000 || port > 65000)
                            {
                                _logger.LogError(banderDisplay.Name + " in AppSettings doesn't have a valid Value (" + banderDisplay.Value + "). The port number is not between 10000 and 65000! It should contain the hostname (or IP) then a comma or colon delimiter, then the port. (Example: BANDER1-VIEW:12000)");
                                return (false);
                            }
                            else
                            {
                                _port = port;
                            }
                        }

                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Exception in LoadAppSettings()! Message:" + ex.Message, "Application ERROR!!");
                return (false);
            }
            return (true);
        }

        public void GetSkidBuild() //Send the "SBQ" (SkidBuildQuery) command to the PickToLightServer to get the current Skid Build for this Bander.
        {
            //Do we need a different method (or a parameter?) for when the program starts, versus when a command comes in??

            int manifestID = SendSkidBuildQueryCommand();
            if (manifestID > 0) //Got manifestID
            {
                //First, make sure I can read in the manifest and then the other SkidBuild fields...
                //Now, process the SkidBuildBegin...
                BeginSkidBuildForManifest(manifestID);
            }
            else
            {
                lblError.UIThread(ctl => { ctl.Text = "No SkidBuild for " + _banderDisplayName + ", Please Scan the Manifest to Begin!"; ctl.ForeColor = Color.Red; });
            }

        }

        /// <summary>
        /// Sends the SBQ command, which returns the ManifestID that is currently assigned to this Bander/Display.
        /// Or, if there is a problem, it will return -1. Generally, this method should only be needed when this application starts.
        /// </summary>
        /// <returns></returns>
        private int SendSkidBuildQueryCommand()
        {
            //if (_pickToLightServerIP.Length > 10 && _pickToLightServerIP.Split('.').Length == 4) //At least 11 characters (10.10.10.10) and 3 periods/dots.
            if (_pickToLightServerIP != null)
            {
                string commandToSend = "";
                commandToSend = PickToLightCommands.PopulateSkidBuildQueryCommand(_banderDisplayNum);
                TCPClient tcpClient = new TCPClient(_logger, _pickToLightServerIP, _pickToLightServerPort);
                StringBuilder commandResponse = new StringBuilder();
                tcpClient.SendCommand(commandToSend, commandResponse);
                if (commandResponse.Length > 0)
                {
                    string[] commandFields = commandResponse.ToString().Split(caGS);

                    if (commandFields.Length < 1) //No GS found!
                    {
                        _logger.LogError("*****SendSkidBuildQueryCommand()***** ERROR: No GS in command!");
                        return (-1);
                    }

                    if (commandFields[0] != PickToLightCommands.P2L_COMMAND_SkidBuildQuery)
                    {
                        _logger.LogError("*****SendSkidBuildQueryCommand()***** ERROR: Response is for wrong command!");
                        return (-1);
                    }

                    int manifestID = -1;
                    if (int.TryParse(commandFields[1], out manifestID) == false)
                    {
                        _logger.LogError("*****SendSkidBuildQueryCommand()***** ERROR: P2L_COMMAND_SkidBuildQuery command received, but manifestID is NOT an integer!");
                        return (-1);
                    }
                    return (manifestID);
                }
            }
            else
            {
                _logger.LogError("The PickToLightServerIP setting is invalid or not specified! (This shouldn't get this far, it should be caught when Loading the settings during startup!)");
                return (-1);
            }
            return (-1);
        }

        private void BeginSkidBuildForManifest(int manifestID)
        {
            //So... where is our validation logic?
            //Do we just allow any manifest to be chosen here?
            //Or do we check to see if we are waiting on an "End" or a manual scan?
            //Do we need to look at the last OWK (and next to last OWK) that was scanned?
            //What do we handle here and what do we handle in PickToLightServer??
            //FOR NOW, I am going to let PickToLightServer handle the validation and just process what it sends...
            lblError.UIThread(ctl => { ctl.Text = ""; ctl.ForeColor = Color.Red; });
            string errorMessage = "";
            if (_skidBuild.PopulateManifestFields(manifestID, out errorMessage) == false)
            {
                AddToMessagePump(errorMessage, true); //This is only false/error if the ManifestID can't be read or some other database/networking error...
            }
            else
            { 
                if (_skidBuild.PopulateExtraFields(out errorMessage) == false) AddToMessagePump(errorMessage, true); //This is only false/error if the NAMC or SubRoute can't be found or some other database/networking error...
            }
            //else
            //{ 
            //    lblError.UIThread(ctl => { ctl.Text = "Error reading Manifest from Database!!"; ctl.ForeColor = Color.Red; });
            //}
            PopulateManifestPanel();
            PopulateOrderPanel();
            PopulateKanbanPanel();
        }

        private void EndSkidBuildForManifest(int manifestID)
        {
            AddToMessagePump("End Skid Build for " + _skidBuild.DockCode + " - " + _skidBuild.OrderNumber + " - " + _skidBuild.PalletizationCode + " - " + _skidBuild.SkidId.Substring(0,3) , false);
            lblError.UIThread(ctl => { ctl.Text = "SkidBuild has been closed. Please Scan Manifest for new Skid Build!"; ctl.ForeColor = Color.Red; });
            _skidBuild.Init(_skidBuild.Bander); //Clear the current values...
            PopulateManifestPanel();
            PopulateOrderPanel();
            PopulateKanbanPanel();
        }

        public void BanderScanned(ScanOWK scanOWK)
        {
            //Every time a new OWK is scanned:
            // Update the ScanStatus with Good/Bad.
            // "Re-Load" the "Extra" fields for the Manifest, in case they have changed. (SubRoute, RfIds, Confirmation#)
            if (scanOWK.Decoded)
            {
                _logger.Log("-----ProcessP2LCommand()----- Good Scan! Barcode was decoded. ScanOWK value:"
                    + " ID [" + scanOWK.ID.ToString() + "],"
                    + " Order/Manifest # [" + scanOWK.OrderNumber + "],"
                    + " Part Num & Description [" + scanOWK.SupplierInformation + "],"
                    + " SubRoute [" + scanOWK.SubRoute + "],"
                    + " MainRoute [" + scanOWK.MainRoute + "],"
                    );
                lblScanStatus.UIThread(ctl => { ctl.Text = "GOOD SCAN" + scanOWK.ID; ctl.ForeColor = Color.Green; });
                
                //If this is for the correct Order/Skid, update the ShipDate!
                if (_skidBuild.ScanManifestID > 0 &&
                    _skidBuild.SupplierCode == scanOWK.SupplierCode &&
                    _skidBuild.NAMC == scanOWK.NAMCDestination &&
                    _skidBuild.DockCode == scanOWK.DockCode &&
                    _skidBuild.OrderNumber == scanOWK.OrderNumber &&
                    _skidBuild.PalletizationCode == scanOWK.PalletizationCode)
                    //The SkidId isn't on the OWK... we just have to assume its right, besides we are only updating the ShipDate/Time!
                    //_skidBuild.SkidId == skidId)
                {
                    lblShipDateTime.UIThread(ctl => { ctl.Text = "Load: " + scanOWK.ShipDate + " " + scanOWK.ShipTime; ctl.ForeColor = Color.Black; });
                }
            }
            else
            {
                _logger.Log("-----ProcessP2LCommand()----- Bad Scan! Barcode was NOT decoded! ScanOWK ID = [" + scanOWK.ID + "]");
                lblScanStatus.UIThread(ctl => { ctl.Text = "**BAD SCAN**"; ctl.ForeColor = Color.Red; });
            }

            string errorMessage = "";
            //We need to do this even if the Scan didn't decode, because these fields are populated by other Scans...
            if (_skidBuild.ScanManifestID > 0) //Make sure we have a SkidBuild assigned...
            {
                if (_skidBuild.PopulateExtraFields(out errorMessage) == false)
                {
                    AddToMessagePump(errorMessage, true); //This is only false/error if the NAMC or SubRoute can't be found or some other database/networking error...
                }
            }
            PopulateManifestPanel();
            PopulateOrderPanel();
            PopulateKanbanPanel();
        }

        /// <summary>
        /// Populate the Manifest Panel using the current SkidBuild (which was populated from the Manifest scanned by the "kitter").
        /// </summary>
        public void PopulateManifestPanel()
        {
            if (_skidBuild.ScanManifestID < 0) //ScanManifestID = -1 when there isn't a "Skid Build" in progress (no Manifest scanned)
            {
                //lblSupplier.Visible = false;
                //lblDock.Visible = false;
                //lblSubRoute.Visible = false;
                //lblOrderNumber.Visible = false;
                //lblRFid.Visible = false;
                //lblPalletizationCode.Visible = false;
                //lblSkidID.Visible = false;
                //lblConfirmationNumber.Visible = false;

                lblSupplierValue.UIThread(ctl => { ctl.Text = "N/A"; ctl.ForeColor = Color.Red; });
                lblPlantValue.UIThread(ctl => { ctl.Text = "N/A"; ctl.ForeColor = Color.Red; });
                lblDockValue.UIThread(ctl => { ctl.Text = "N/A"; ctl.ForeColor = Color.Red; });
                lblShipDateTime.UIThread(ctl => { ctl.Text = "N/A"; ctl.ForeColor = Color.Red; });
                lblSubRouteValue.UIThread(ctl => { ctl.Text = "N/A"; ctl.ForeColor = Color.Red; });
                lblSkidNumOfTotal.UIThread(ctl => { ctl.Text = "N/A"; ctl.ForeColor = Color.Red; });
                lblOrderNumberValue.UIThread(ctl => { ctl.Text = "N/A"; ctl.ForeColor = Color.Red; });
                lblRFidValue.UIThread(ctl => { ctl.Text = "N/A"; ctl.ForeColor = Color.Red; });
                lblPalletizationCodeValue.UIThread(ctl => { ctl.Text = "N/A"; ctl.ForeColor = Color.Red; });
                lblSkidIDValue.UIThread(ctl => { ctl.Text = "N/A"; ctl.ForeColor = Color.Red; });
                lblConfirmationNumberValue.UIThread(ctl => { ctl.Text = "N/A"; ctl.ForeColor = Color.Red; });
            }
            else
            {
                //Use the new "UIThread" method Extension to get rid of Exceptions.
                lblSupplierValue.UIThread(ctl => { ctl.Text = _skidBuild.SupplierCode; ctl.ForeColor = Color.Black; });
                lblPlantValue.UIThread(ctl => { ctl.Text = _skidBuild.TradingPartner; ctl.ForeColor = Color.Black; });
                lblDockValue.UIThread(ctl => { ctl.Text = _skidBuild.DockCode; ctl.ForeColor = Color.Black; });
                lblShipDateTime.UIThread(ctl => { ctl.Text = "Load: "; ctl.ForeColor = Color.Black; });
                lblSubRouteValue.UIThread(ctl => { ctl.Text = _skidBuild.SubRoute; ctl.ForeColor = Color.Black; });
                //How do I build this string??
                //lblSkidNumOfTotal.UIThread(ctl => { ctl.Text = _skidBuild.SupplierCode; ctl.ForeColor = Color.Black; });
                //Remove this and make the SupplierCode larger??
                lblSkidNumOfTotal.UIThread(ctl => { ctl.Text = ""; ctl.ForeColor = Color.Red; });
                lblOrderNumberValue.UIThread(ctl => { ctl.Text = _skidBuild.OrderNumber; ctl.ForeColor = Color.Black; });
                string rfIDString = "";
                if (string.IsNullOrEmpty(_skidBuild.RfIdBase) == false) rfIDString = "Base: " + _skidBuild.RfIdBase + " ";
                if (string.IsNullOrEmpty(_skidBuild.RfIdLid) == false) rfIDString += "Lid: " + _skidBuild.RfIdLid;
                if (string.IsNullOrEmpty(rfIDString)) rfIDString = "----------";
                lblRFidValue.UIThread(ctl => { ctl.Text = rfIDString; ctl.ForeColor = Color.Black; });
                lblPalletizationCodeValue.UIThread(ctl => { ctl.Text = _skidBuild.PalletizationCode; ctl.ForeColor = Color.Black; });
                lblSkidIDValue.UIThread(ctl => { ctl.Text = _skidBuild.SkidId; ctl.ForeColor = Color.Black; });
                if (string.IsNullOrEmpty(_skidBuild.ConfirmationNumber))
                {
                    lblConfirmationNumberValue.UIThread(ctl => { ctl.Text = "NEEDED! Submit Order when done!"; ctl.ForeColor = Color.Red; });
                }
                else
                {
                    //lblConfirmationNumberValue.UIThread(ctl => { ctl.Text = _skidBuild.ConfirmationNumber; ctl.ForeColor = Color.Black; });
                    lblConfirmationNumberValue.UIThread(ctl => { ctl.Text = "Order Approved"; ctl.ForeColor = Color.Green; });
                }
            }

            //lblError.UIThread(ctl => { ctl.Text = "Read " + scanOWK.ID; ctl.ForeColor = Color.Black; });

            //lblError.UIThread(ctl => { ctl.Text = "*****NO READ*****"; ctl.ForeColor = Color.Red; });
        }

        /// <summary>
        /// Populate the Kanban Panel with the "Plan" (and Scans) using the SkidBuild and the OWK Scans.
        /// </summary>
        public void PopulateOrderPanel()
        {
            //using (var ctx = new PickToLightEntities())
            //{
            //    var orders = (from s in ctx.ToyotaShipments
            //                  where s.NAMC.Equals(_skidBuild.TradingPartner) &&
            //                        s.DOCKCODE.Equals(_skidBuild.DockCode) &&
            //                        s.ORDERNUM.Equals(_skidBuild.OrderNumber)
            //                  //select s).ToList();
            //                  select new
            //                  {
            //                      s.SNAPARTNUM,
            //                      s.CUSTPARTNUM,
            //                      s.PANSREQ
            //                  }).ToList();

            //    if (orders.Count == 0)
            //    {
            //        //Nothing found
            //    }
            //    else
            //    {
            //        //ListView lvOrders = new ListView();
            //        //lvOrders.Da
            //        DataGridView dgvOrders = new DataGridView();
            //        //dgvOrders.Dock = DockStyle.None;
            //        dgvOrders.Dock = DockStyle.Fill;
            //        dgvOrders.AutoGenerateColumns = true;
            //        dgvOrders.DefaultCellStyle.DataSourceNullValue = null;  //Need this? Or is the default of "DBNull.Value" ok?
            //        dgvOrders.DataSource = orders;
            //        dgvOrders.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders;
            //        dgvOrders.BorderStyle = BorderStyle.Fixed3D;
            //        //Populate the Order List/Grid
            //        skidsFLPanel.Controls.Clear();
            //        skidsFLPanel.Controls.Add(dgvOrders);

            //        //ListView lvOrders = new ListView();

            //    }
            //}

            using (var ctx = new PickToLightEntities())
            {
                string bander = "Bander" + _banderDisplayNum.ToString();
                var scans = (from s in ctx.ScanOWKs
                             where s.DeviceName.Equals(bander)
                                   && (TESTING == false || s.ID <= _startingOWKID)
                             //s.DOCKCODE.Equals(_skidBuild.DockCode) &&
                             //s.ORDERNUM.Equals(_skidBuild.OrderNumber)
                             //select s).ToList();
                             orderby s.ID descending
                             select new
                             {
                                 //SupplierCode = s.Decoded ? s.SupplierCode : "BAD",
                                 //NAMCDestination = s.Decoded ? s.NAMCDestination : "BAD",
                                 //DockCode = s.Decoded ? s.DockCode : "BAD",
                                 Dock = s.Decoded ? (s.NAMCDestination + " " + s.DockCode) : "BAD",
                                 OrderNumber = s.Decoded ? s.OrderNumber : "BAD",
                                 //PalletizationCode = s.PalletizationCode,
                                 Pallet = s.Decoded ? s.PalletizationCode : "BAD",
                                 KanbanNumber = s.Decoded ? s.KanbanNumber : "BAD",
                                 Box = s.Decoded ? (s.BoxNumber + " of " + s.BoxTotal) : "BAD",
                                 //Box = s.BoxNumber,
                                 //TotalBoxes = s.BoxTotal,
                                 Scanned = s.Created
                             }).Take(15).ToList();

                //Same as a Left Outer Join (to get the Manifest and therefore the "SkidId")
                //
                //This can only be done against the Picker Scans (CreatedBy = "PickToLightClient")
                //
                //var scans = (from s in ctx.ScanOWKs
                //             where s.DeviceName.Equals(bander)
                //             join m in ctx.ScanManifests on
                //                new { NAMC = s.NAMCDestination, s.DockCode, s.OrderNumber, s.PalletizationCode,  }
                //                equals
                //                new { m.NAMC, m.DockCode, m.OrderNumber, m.PalletizationCode }
                //             //s.DOCKCODE.Equals(_skidBuild.DockCode) &&
                //             //s.ORDERNUM.Equals(_skidBuild.OrderNumber)
                //             //select s).ToList();
                //             orderby s.ID descending
                //             select new
                //             {
                //                 //SupplierCode = s.Decoded ? s.SupplierCode : "BAD",
                //                 //NAMCDestination = s.Decoded ? s.NAMCDestination : "BAD",
                //                 //DockCode = s.Decoded ? s.DockCode : "BAD",
                //                 Dock = s.Decoded ? (s.NAMCDestination + " " + s.DockCode) : "BAD",
                //                 OrderNumber = s.Decoded ? s.OrderNumber : "BAD",
                //                 //PalletizationCode = s.PalletizationCode,
                //                 Pallet = s.Decoded ? s.PalletizationCode : "BAD",
                //                 KanbanNumber = s.Decoded ? s.KanbanNumber : "BAD",
                //                 Box = s.Decoded ? (s.BoxNumber + " of " + s.BoxTotal) : "BAD",
                //                 //Box = s.BoxNumber,
                //                 //TotalBoxes = s.BoxTotal,
                //                 Scanned = s.Created
                //             }).Take(15).ToList();

                if (scans.Count == 0)
                {
                    //Nothing found
                }
                else
                {
                    //ListView lvOrders = new ListView();
                    //lvOrders.Da
                    DataGridView dgvOrders = new DataGridView();
                    dgvOrders.Dock = DockStyle.None;
                    //dgvOrders.Dock = DockStyle.Left;  // None of these seem to work, only "None".
                    dgvOrders.Width = 0;
                    dgvOrders.Height = 0;
                    dgvOrders.AutoSize = true;
                    dgvOrders.AutoGenerateColumns = true;
                    dgvOrders.ScrollBars = ScrollBars.None;
                    dgvOrders.Margin = new Padding(0);
                    dgvOrders.Padding = new Padding(0);
                    //dgvOrders.BackgroundColor = Color.Red;
                    dgvOrders.ReadOnly = true;

                    dgvOrders.BorderStyle = BorderStyle.None;
                    dgvOrders.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Raised;
                    dgvOrders.ColumnHeadersDefaultCellStyle.BackColor = Color.LightGray;
                    dgvOrders.EnableHeadersVisualStyles = false; //If TRUE, the grid will use the style from the current users default theme.
                    dgvOrders.DefaultCellStyle.DataSourceNullValue = null;  //Need this? Or is the default of "DBNull.Value" ok?
                    dgvOrders.DefaultCellStyle.Padding = new Padding(0);

                    dgvOrders.Font = new Font("Microsoft Sans Serif", 10);

                    dgvOrders.DataSource = scans;
                    dgvOrders.DataBindingComplete += DgvOrders_DataBindingComplete;
                    //Moved to DgvOrders_DataBindingComplete
                    ////dgvOrders.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders;
                    //dgvOrders.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                    //dgvOrders.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
                    //dgvOrders.BorderStyle = BorderStyle.Fixed3D;
                    //dgvOrders.Height = 390;
                    //dgvOrders.Width = 1050;

                    //dgvOrders.Location = new Point(50, 10);


                    Label lblLast15 = new Label();
                    lblLast15.AutoSize = true;
                    lblLast15.Text = "Last 15 Scans for Bander" + _banderDisplayNum.ToString();
                    lblLast15.BackColor = Color.LightGray;
                    lblLast15.Font = new Font("Microsoft Sans Serif", 18);
                    lblLast15.Top = 10;

                    //Populate the Order List/Grid
                    //skidsFLPanel.Controls.Clear();
                    //skidsFLPanel.Invoke()
                    skidsFLPanel.UIThread(ctl => { ctl.Controls.Clear(); });
                    //skidsFLPanel.FlowDirection = FlowDirection.TopDown;
                    skidsFLPanel.UIThread(ctl => { ctl.FlowDirection = FlowDirection.TopDown; });
                    //skidsFLPanel.Controls.Add(lblLast15);
                    skidsFLPanel.UIThread(ctl => { ctl.Controls.Add(lblLast15); });
                    //skidsFLPanel.Controls.Add(dgvOrders);
                    skidsFLPanel.UIThread(ctl => { ctl.Controls.Add(dgvOrders); });
                    
                    //skidsFLPanel.Controls[0].Location = new Point(50, 10);
                    //skidsFLPanel.Margin = new Padding(0);
                    //skidsFLPanel.Padding = new Padding(0);
                    //skidsFLPanel.BackColor = Color.Green;

                    //ListView lvOrders = new ListView();

                }
            }
        }

        private void DgvOrders_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            DataGridView dgvOrders = (DataGridView)sender;

            //dgvOrders.Dock = DockStyle.Fill;

            dgvOrders.RowHeadersVisible = false;
            //dgvOrders.SelectionMode = DataGridViewSelectionMode.CellSelect;

            dgvOrders.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dgvOrders.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;

            //dgvOrders.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders;
            //dgvOrders.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
            dgvOrders.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;

            dgvOrders.AutoResizeColumns();
            dgvOrders.AutoResizeColumnHeadersHeight();
            dgvOrders.AutoResizeRows();
            //dgvOrders.AutoResizeRowHeadersWidth(DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders);

            //int rowCount = scans.Count;
            //int rowCount = 15;
            //int columnCount = 9;

            //Rectangle r = dgvOrders.GetCellDisplayRectangle(columnCount - 1, rowCount - 1, false);
            ////Rectangle r = dgvOrders.GetCellDisplayRectangle(columnCount - 1, 14, true); // To just get the Height...
            //Size s = dgvOrders.ClientSize;
            //s.Height = r.Y + r.Height;
            //s.Width = r.X + r.Width;
            //dgvOrders.ClientSize = s;

            dgvOrders.ClearSelection();
        }

        public void PopulateKanbanPanel()
        { 
                    ////
                    ////ADD THIS!!! If SkidId = "???", we have a problem. We don't know which Skid the Part belongs to!
                    ////
                    ////This logic includes processing an rfID for ALL Orders.
                    ////For now, we also need logic that can execute for NAMC's that don't require an rfID at this time...
                    ////SO WHAT ARE YOU WAITING ON? ADD THAT LOGIC!!
                    ////
                    ////For this OWK(Skid), show what we think are all the Boxes for this particular Skid, in "Skid Details" just below the "Header".
                    ////Then, show the rest of the "Order Summary" below the "Skid Details".
                    ////
                    ////So, right here, if its the SAME OWK as last time:
                    ////  Just "refresh" the screen.
                    ////Otherwise, if its a new OWK, but for the SAME Order (NAMCDestination OR SupplierCode, OrderNumber and DockCode)...
                    ////  Check to see if this is a new Skid. Is there a way?? If it is a new Skid:
                    ////      Does this Skid have an rfID assigned? If it does NOT:
                    ////          Leave the screen populated as before (but refresh that OWK, just in case...).
                    ////          But tell the Kitter "Don't start another Skid until this Skid has an RFid assigned or has been marked with a NON CONFORMANCE sticker!!"
                    ////          And add a message to the bottom about the parts waiting for the next Order (NAMC, OrderNumber, DockCode)
                    ////      Otherwise, it DOES have an rfID assigned, so:
                    ////          Just "refresh" the screen.
                    ////  Otherwise, it is NOT a new Skid:
                    ////      Just "refresh" the screen.
                    ////Otherwise, a NEW OWK/Order is scanned:
                    ////  Was the Previous Order Confirmed? If it WAS:
                    ////      Populate the screen with the OWK as normal, but at the bottom of the screen add: NAMC, OrderNumber, DockCode and Confirmation#!!
                    ////  Otherwise, the previous order has NOT been confirmed!
                    ////      Leave the screen populated as before (but refresh that OWK, just in case...).
                    ////      But tell the Kitter "Don't start another Order until this Order has an RFid assigned or has been marked with a NON CONFORMANCE sticker!!"
                    ////      And add a message to the bottom about the parts waiting for the next Order (NAMC, OrderNumber, DockCode)
                    ////
                    ////Using this logic, after the Kitter scans the Manifest and then the rfID....
                    ////  PickToLightServer should send the proper Bander a "Skid_RFid_Scanned" along with the NAMC, OrderNumber, DockCode and the SkidId??

            //if (scanOWK.Decoded)
            //{
            //    string snaPartNum = "";

            //    //Try using the new Extension to get rid of Exceptions.
            //    lblPlantValue.UIThread(ctl => { ctl.Text = scanOWK.NAMCDestination; ctl.ForeColor = Color.Black; });
            //    lblDockValue.UIThread(ctl => { ctl.Text = scanOWK.DockCode; ctl.ForeColor = Color.Black; });
            //    lblOrderNumberValue.UIThread(ctl => { ctl.Text = scanOWK.OrderNumber; ctl.ForeColor = Color.Black; });
            //    lblPalletizationCodeValue.UIThread(ctl => { ctl.Text = scanOWK.PalletizationCode; ctl.ForeColor = Color.Black; });

            //    //lblBoxNumValue.UIThread(ctl => { ctl.Text = scanOWK.BoxNumber; ctl.ForeColor = Color.Black; });
            //    //lblKanbanValue.UIThread(ctl => { ctl.Text = scanOWK.KanbanNumber; ctl.ForeColor = Color.Black; });
            //    //lblMainRouteValue.UIThread(ctl => { ctl.Text = scanOWK.MainRoute; ctl.ForeColor = Color.Black; });
            //    lblSubRouteValue.UIThread(ctl => { ctl.Text = scanOWK.SubRoute; ctl.ForeColor = Color.Black; });

            //    if (confirmationNumber.Length > 0)
            //    {
            //        lblConfirmationNumberValue.UIThread(ctl => { ctl.Text = confirmationNumber; ctl.ForeColor = Color.Black; });
            //    }
            //    else
            //    {
            //        lblConfirmationNumberValue.UIThread(ctl => { ctl.Text = "<NEEDED!>"; ctl.ForeColor = Color.Red; });
            //    }

            //    lblError.UIThread(ctl => { ctl.Text = "Read " + scanOWK.ID; ctl.ForeColor = Color.Black; });

            //    //lblPlantValue.UIThread(ctl => { ctl.Text = scanOWK.OrderNumber; ctl.ForeColor = Color.Black; });
            //    //top2Label.UIThread(ctl => { ctl.Text = scanOWK.MainRoute + "  -  " + scanOWK.SubRoute; ctl.ForeColor = Color.Black; });
            //    //labelKanBan.UIThread(ctl => { ctl.Text = scanOWK.KanbanNumber; ctl.ForeColor = Color.Black; });
            //    //labelNAMC.UIThread(ctl => { ctl.Text = scanOWK.NAMCDestination; ctl.ForeColor = Color.Black; });
            //    //bottomLabel.UIThread(ctl => { ctl.Text = scanOWK.SupplierInformation; ctl.ForeColor = Color.Black; });

            //    //COMMENT OUT, CRASHING  - pictureBox.UIThread(ctl => { ctl.Image = Image.FromFile(picturePath); });
            //    //pictureBox.UIThread(ctl => { ctl.Image = _notFoundImage; });
            //}
            //else
            //{
            //    //Try using the new Extension to get rid of Exceptions.
            //    lblPlantValue.UIThread(ctl => { ctl.Text = ""; ctl.ForeColor = Color.Black; });
            //    lblDockValue.UIThread(ctl => { ctl.Text = ""; ctl.ForeColor = Color.Black; });
            //    lblOrderNumberValue.UIThread(ctl => { ctl.Text = ""; ctl.ForeColor = Color.Black; });
            //    lblPalletizationCodeValue.UIThread(ctl => { ctl.Text = ""; ctl.ForeColor = Color.Black; });

            //    //lblBoxNumValue.UIThread(ctl => { ctl.Text = ""; ctl.ForeColor = Color.Black; });
            //    //lblKanbanValue.UIThread(ctl => { ctl.Text = ""; ctl.ForeColor = Color.Black; });
            //    //lblMainRouteValue.UIThread(ctl => { ctl.Text = ""; ctl.ForeColor = Color.Black; });
            //    lblSubRouteValue.UIThread(ctl => { ctl.Text = ""; ctl.ForeColor = Color.Black; });

            //    //if(confirmationNumber.Length > 0)
            //    //{
            //    //    lblConfirmationValue.UIThread(ctl => { ctl.Text = confirmationNumber; ctl.ForeColor = Color.Black; });
            //    //}
            //    //else
            //    //{
            //    //    lblConfirmationValue.UIThread(ctl => { ctl.Text = "<NEEDED!>"; ctl.ForeColor = Color.Red; });
            //    //}

            //    lblConfirmationNumberValue.UIThread(ctl => { ctl.Text = ""; ctl.ForeColor = Color.Black; });

            //    lblError.UIThread(ctl => { ctl.Text = "*****NO READ*****"; ctl.ForeColor = Color.Red; });

            //    //top1Label.UIThread(ctl => { ctl.Text = "No Read!"; ctl.ForeColor = Color.Red; });
            //    //top2Label.UIThread(ctl => { ctl.Text = ""; ctl.ForeColor = Color.Red; });
            //    //labelKanBan.UIThread(ctl => { ctl.Text = ""; ctl.ForeColor = Color.Red; });
            //    //labelNAMC.UIThread(ctl => { ctl.Text = ""; ctl.ForeColor = Color.Red; });
            //    //bottomLabel.UIThread(ctl => { ctl.Text = "Scan Failed!"; ctl.ForeColor = Color.Red; });
            //    //COMMENT OUT, CRASHING  - pictureBox.UIThread(ctl => { ctl.Image = Image.FromFile("//hq-media/Public/GT PickLine Pictures/BadRead.jpg"); });
            //    //pictureBox.UIThread(ctl => { ctl.Image = _badReadImage; });
            //}

        }

        void AddToMessagePump(string Message, bool isError)
        {
            //If the message is an error (isError=true), then we want to make it red/bigger/flashing???
            //throw new Exception("Not Implemented");

            //I may use this to keep a log with DateTime of the last X errors on one of the Form Panels!
            //But, for now, just use the lblError
            lblError.UIThread(ctl => { ctl.Text = Message; ctl.ForeColor = (isError ? Color.Red : Color.Black); });
        }

        void TCPServer_CommandReceived(object sender, PickToLightCommandEventArgsV2 e)
        {
            _logger.Log("PickToLightBanderDisplay CommandReceived Event, Command = (" + e.Command + ") Length = (" + e.Command.Length + ")");
            if (ProcessP2LCommand(e) == false)
            {
                string commandResponse = String.Format("Command Received and Processed: <{0}> Length: <{1}>", e.Command, e.Command.Length.ToString());
                e.SendWithProtocol(commandResponse);
            }
            //e.ClientSocket.Send(Encoding.ASCII.GetBytes(String.Format("Command Received and Processed: <{0}> Length: <{1}>", e.Command, e.Command.Length.ToString())));
        }

        //Return false if we didn't process it and just need to send the regular reply back.
        bool ProcessP2LCommand(PickToLightCommandEventArgsV2 e)
        {
            string[] commandFields = e.Command.Split(caGS);

            if (commandFields.Length < 1) //No GS found!
            {
                _logger.LogError("*****ProcessP2LCommand()***** ERROR: No GS in command!");
                return (false);
            }

            switch (commandFields[0])
            {
                //commandToSend = P2L_COMMAND_SkidBuildEnd + sGS + manifestID + sGS + banderNum;
                case PickToLightCommands.P2L_COMMAND_SkidBuildEnd:
                    if (commandFields.Length < 3)
                    {
                        _logger.LogError("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_SkidBuildEnd command received, but no ScanManifest ID or Bander Number!");
                        return (false);
                    }
                    int idScanManifest = -1;
                    if (int.TryParse(commandFields[1], out idScanManifest) == false)
                    {
                        _logger.LogError("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_SkidBuildEnd command received, but ScanManifest ID is NOT an integer!");
                        return (false);
                    }
                    int banderNum = -1;
                    if (int.TryParse(commandFields[2], out banderNum) == false)
                    {
                        _logger.LogError("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_SkidBuildEnd command received, but Bander Number is NOT an integer!");
                        return (false);
                    }
                    if (_banderDisplayNum != banderNum)
                    {
                        _logger.LogError("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_SkidBuildEnd command received, but for the WRONG Bander Number!");
                        return (false);
                    }

                    //Keep this??
                    _logger.Log("-----ProcessP2LCommand()----- P2L_COMMAND_SkidBuildEnd was received for ScanManifest ID [" + idScanManifest.ToString() + "] and Bander Number [" + banderNum.ToString() + "]...");

                    //TODO: Create a new SQL Table to track "P2L_COMMAND" received and add a new row here!
                    //      Or, just use the "Log" table, but create a SQL View!!!!

                    //Read in the ID from the Table and decide what to do.
                    try
                    {
                        EndSkidBuildForManifest(idScanManifest);
                        //e.SendWithProtocol(PickToLightCommands.PopulateSkidBuildEndCommandErrorResponse("Please close out the previous Skid Build before scanning a new one!"));
                        //e.SendWithProtocol(PickToLightCommands.PopulateSkidBuildEndCommandOKResponse());
                        e.SendWithProtocol(e.Command); //Just reply with the Command that was sent. We don't need to tell "PickToLightServer" if it was "OK" or "Error", because it decides that before sending it!!!
                        return (true);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError("Exception processing P2L_COMMAND_SkidBuildEnd: " + ex.Message);
                        return (false);
                        throw;
                    }

                    return (false); //Should never get here.

                    break;

                //commandToSend = P2L_COMMAND_SkidBuildBegin + sGS + manifestID + sGS + banderNum;
                case PickToLightCommands.P2L_COMMAND_SkidBuildBegin:
                    if (commandFields.Length < 3)
                    {
                        _logger.LogError("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_SkidBuildBegin command received, but no ScanManifest ID or Bander Number!");
                        return (false);
                    }
                    idScanManifest = -1;
                    if (int.TryParse(commandFields[1], out idScanManifest) == false)
                    {
                        _logger.LogError("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_SkidBuildBegin command received, but ScanManifest ID is NOT an integer!");
                        return (false);
                    }
                    banderNum = -1;
                    if (int.TryParse(commandFields[2], out banderNum) == false)
                    {
                        _logger.LogError("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_SkidBuildBegin command received, but Bander Number is NOT an integer!");
                        return (false);
                    }
                    if (_banderDisplayNum != banderNum)
                    {
                        _logger.LogError("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_SkidBuildBegin command received, but for the WRONG Bander Number!");
                        return (false);
                    }

                    //Keep this??
                    _logger.Log("-----ProcessP2LCommand()----- P2L_COMMAND_SkidBuildBegin was received for ScanManifest ID [" + idScanManifest.ToString() + "] and Bander Number [" + banderNum.ToString() + "]...");

                    //TODO: Create a new SQL Table to track "P2L_COMMAND" received and add a new row here!
                    //      Or, just use the "Log" table, but create a SQL View!!!!

                    //Read in the ID from the Table and decide what to do.
                    try
                    {
                        BeginSkidBuildForManifest(idScanManifest);
                        //e.SendWithProtocol(PickToLightCommands.PopulateSkidBuildBeginCommandErrorResponse("Please close out the previous Skid Build before scanning a new one!"));
                        //e.SendWithProtocol(PickToLightCommands.PopulateSkidBuildBeginCommandOKResponse());
                        e.SendWithProtocol(e.Command); //Just reply with the Command that was sent. We don't need to tell "PickToLightServer" if it was "OK" or "Error", because it decides that before sending it!!!
                        return (true);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError("Exception processing P2L_COMMAND_SkidBuildBegin: " + ex.Message);
                        return (false);
                        throw;
                    }

                    return (false); //Should never get here.

                    break;

                case PickToLightCommands.P2L_COMMAND_BanderDisplay:
                    if (commandFields.Length < 2)
                    {
                        _logger.LogError("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_BanderDisplay command received, but no ScanOWK entryID!");
                        return (false);
                    }
                    int idScanOWK = -1;
                    if (int.TryParse(commandFields[1], out idScanOWK) == false)
                    {
                        _logger.LogError("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_BanderDisplay command received, but ScanOWK entryID is NOT an integer!");
                        return (false);
                    }

                    //Keep this??
                    _logger.Log("-----ProcessP2LCommand()----- P2L_COMMAND_BanderDisplay was received for ScanOWK ID [" + idScanOWK.ToString() + "]...");

                    //TODO: Create a new SQL Table to track "P2L_COMMAND" received and add a new row here??

                    //Read in the ID from the Table and decide what to do.
                    try
                    {
                        ScanOWK scanOWK = ScanOWK.GetScanEntry(idScanOWK);
                        if (scanOWK != null) //Is this even possible?
                        {
                            BanderScanned(scanOWK);

                            string commandResponse = PickToLightCommands.PopulateBanderDisplayCommandResponse(idScanOWK);
                            e.SendWithProtocol(commandResponse);
                            return (true);
                        }
                    }
                    catch (Exception ex)
                    {
                        if (ex.InnerException != null)
                        {
                            _logger.LogError("Exception in ProcessP2LCommand(): " + ex.Message + " (Inner Exception: " + ex.InnerException + ")");
                        }
                        else
                        {
                            _logger.LogError("Exception in ProcessP2LCommand(): " + ex.Message);
                        }
                        return (false);
                        throw;
                    }

                    return (false); //Should never get here.

                    break;

                default:
                    break;
            }
            return (false);
        }

        //public void Populate(ScanOWK scanOWK, string confirmationNumber)
        //{
        //    //show part #, order #, route, ship times, and NAMC


        //    //
        //    //ADD THIS!!! If SkidId = "???", we have a problem. We don't know which Skid the Part belongs to!
        //    //
        //    //This logic includes processing an rfID for ALL Orders.
        //    //For now, we also need logic that can execute for NAMC's that don't require an rfID at this time...
        //    //SO WHAT ARE YOU WAITING ON? ADD THAT LOGIC!!
        //    //
        //    //For this OWK(Skid), show what we think are all the Boxes for this particular Skid, in "Skid Details" just below the "Header".
        //    //Then, show the rest of the "Order Summary" below the "Skid Details".
        //    //
        //    //So, right here, if its the SAME OWK as last time:
        //    //  Just "refresh" the screen.
        //    //Otherwise, if its a new OWK, but for the SAME Order (NAMCDestination OR SupplierCode, OrderNumber and DockCode)...
        //    //  Check to see if this is a new Skid. Is there a way?? If it is a new Skid:
        //    //      Does this Skid have an rfID assigned? If it does NOT:
        //    //          Leave the screen populated as before (but refresh that OWK, just in case...).
        //    //          But tell the Kitter "Don't start another Skid until this Skid has an RFid assigned or has been marked with a NON CONFORMANCE sticker!!"
        //    //          And add a message to the bottom about the parts waiting for the next Order (NAMC, OrderNumber, DockCode)
        //    //      Otherwise, it DOES have an rfID assigned, so:
        //    //          Just "refresh" the screen.
        //    //  Otherwise, it is NOT a new Skid:
        //    //      Just "refresh" the screen.
        //    //Otherwise, a NEW OWK/Order is scanned:
        //    //  Was the Previous Order Confirmed? If it WAS:
        //    //      Populate the screen with the OWK as normal, but at the bottom of the screen add: NAMC, OrderNumber, DockCode and Confirmation#!!
        //    //  Otherwise, the previous order has NOT been confirmed!
        //    //      Leave the screen populated as before (but refresh that OWK, just in case...).
        //    //      But tell the Kitter "Don't start another Order until this Order has an RFid assigned or has been marked with a NON CONFORMANCE sticker!!"
        //    //      And add a message to the bottom about the parts waiting for the next Order (NAMC, OrderNumber, DockCode)
        //    //
        //    //Using this logic, after the Kitter scans the Manifest and then the rfID....
        //    //  PickToLightServer should send the proper Bander a "Skid_RFid_Scanned" along with the NAMC, OrderNumber, DockCode and the SkidId??

        //    //if(scanOWK.Decoded)
        //    //{
        //    //    lblScanStatus.UIThread(ctl => { ctl.Text = "GOOD SCAN" + scanOWK.ID; ctl.ForeColor = Color.Green; });

        //    //    //Show all the Scans for this Skid and for the entire Order.

        //    //    //If this OWK doesn't match the SkidBuild Manifest, tell the user:
        //    //    //  "Wrong Bander!! Please scan with BanderX and load on that Skid."
        //    //    //  --OR--
        //    //    //  "Please closeout the current SkidBuild and scan the Manifest for the new Skid!!"
        //    //    //  "The current scan is for a new Skid. Please closeout the current SkidBuild!!"

        //    //}
        //    //else
        //    //{
        //    //    lblScanStatus.UIThread(ctl => { ctl.Text = "**BAD SCAN**"; ctl.ForeColor = Color.Red; });

        //    //}

        //}

        //public void Populate(PickToLightData.ScanOWK scanOWK)
        //{
        //    //Image image = new Image();
        //    //image = Image.FromFile("//hq-media/Public/GT PickLine Pictures/010B/1411-AL/Motor 1411-AL.jpg");
        //    //pictureBox.Image = image;
        //    //pictureBox.Image = Image.FromFile("//gt-fs01/gordonsville/GT-Production Control/Shared/2017/Finished Good Rollers 2017/Conveyor/010B/1411-AL/Motor 1411-AL.jpg");

        //    if(scanOWK.Decoded)
        //    {
        //        //See if the file is present, if it is, show it, if not show "No Picture Available".
        //        //Lookup SNA part using SUpplier Information and/or Part Number
        //        string snaPartNum = "";
        //        //snaPartNum = scanOWK.SupplierInformation
        //        //snaPartNum = scanOWK.PartNumber

        //        //TODO: Check for part image and load it... (For now, don't even check it.)
        //        //
        //        //string pictureFolder = "//hq-media/Public/GT PickLine Pictures/" + snaPartNum;
        //        //string picturePath = "//hq-media/Public/GT PickLine Pictures/NotFound.jpg";
        //        ////PATH: "//hq-media/Public/GT PickLine Pictures/<SNA PART#>/1.jpg"
        //        ////EXAMPLE: "//hq-media/Public/GT PickLine Pictures/1411-AL/1.jpg" (can have more than one image to cycle through...1.jpg...2.jpg...etc)
        //        //if (Directory.Exists(pictureFolder))
        //        //{
        //        //    if (File.Exists(pictureFolder + "/1.jpg")) //There can be multiple pics to cycle through... start with "1.jpg".
        //        //    {
        //        //        picturePath = pictureFolder + "/1.jpg";
        //        //    }
        //        //}

        //        //PickToLightData.ScanOWK scan = PickToLightData.ScanOWK.GetScanEntry(idScanOWK);
        //        //top1Label.Text = scan.MainRoute + "  -  " + scan.SubRoute;
        //        //pictureBox.Image = Image.FromFile("//hq-media/Public/GT PickLine Pictures/1411-AL/Pan.jpg");

        //        //this.UIThread(() => this.top1Label.Text = scanOWK.OrderNumber);
        //        //this.UIThread(() => this.top1Label.ForeColor = Color.Black);
        //        //this.UIThread(() => this.top2Label.Text = scanOWK.MainRoute + "  -  " + scanOWK.SubRoute);
        //        //this.UIThread(() => this.top2Label.ForeColor = Color.Black);
        //        //this.UIThread(() => this.bottomLabel.Text = scanOWK.SupplierInformation);
        //        //this.UIThread(() => this.bottomLabel.ForeColor = Color.Black);
        //        //this.UIThread(() => this.pictureBox.Image = Image.FromFile("//hq-media/Public/GT PickLine Pictures/NotFound.jpg"));
        //        //this.UIThread(() => this.pictureBox.Image = Image.FromFile(picturePath));
        //        //
        //        //Try using the new Extension to get rid of Exceptions.
        //        top1Label.UIThread(ctl => { ctl.Text = scanOWK.OrderNumber; ctl.ForeColor = Color.Black; });
        //        top2Label.UIThread(ctl => { ctl.Text = scanOWK.MainRoute + "  -  " + scanOWK.SubRoute; ctl.ForeColor = Color.Black; });
        //        bottomLabel.UIThread(ctl => { ctl.Text = scanOWK.SupplierInformation; ctl.ForeColor = Color.Black; });
        //        //COMMENT OUT, CRASHING  - pictureBox.UIThread(ctl => { ctl.Image = Image.FromFile(picturePath); });
        //        pictureBox.UIThread(ctl => { ctl.Image = _notFoundImage; });
        //    }
        //    else
        //    {
        //        //this.UIThread(() => this.top1Label.Text = "No Read!");
        //        //this.UIThread(() => this.top1Label.ForeColor = Color.Red);
        //        //this.UIThread(() => this.top2Label.Text = "");
        //        //this.UIThread(() => this.top2Label.ForeColor = Color.Red);
        //        ////LOAD the "NO READ" image!
        //        //this.UIThread(() => this.pictureBox.Image = Image.FromFile("//hq-media/Public/GT PickLine Pictures/BadRead.jpg"));
        //        //this.UIThread(() => this.bottomLabel.Text = "Scan Failed!");
        //        //this.UIThread(() => this.bottomLabel.ForeColor = Color.Red);
        //        //
        //        //Try using the new Extension to get rid of Exceptions.
        //        top1Label.UIThread(ctl => { ctl.Text = "No Read!"; ctl.ForeColor = Color.Red; });
        //        top2Label.UIThread(ctl => { ctl.Text = ""; ctl.ForeColor = Color.Red; });
        //        bottomLabel.UIThread(ctl => { ctl.Text = "Scan Failed!"; ctl.ForeColor = Color.Red; });
        //        //COMMENT OUT, CRASHING  - pictureBox.UIThread(ctl => { ctl.Image = Image.FromFile("//hq-media/Public/GT PickLine Pictures/BadRead.jpg"); });
        //        pictureBox.UIThread(ctl => { ctl.Image = _badReadImage; });
        //    }

        //}

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (string.IsNullOrEmpty(Thread.CurrentThread.Name))
            {
                Thread.CurrentThread.Name = "Form Closing";
            }

            // Log a service stop message to the Application log.
            _logger.LogMainEvent("PickToLightBanderDisplay is Closing.");

            // Stop the Server. Release it.
            //_tcpServer.StopServer();
            //TODO: I don't think we should EVER set TCPServer instance to null AFTER calling StopServer(), because the TCPServer "deconstructor" handles that!
            // (It causes the Logger to throw an Exception when it tries to log to the db!)
            if (_tcpServer != null)
            {
                _tcpServer.StopServer();
                //_tcpServer = null;
            }
            //TODO: Is this necessary?? Removing it for now!
            //Thread.CurrentThread.Join(1000);
            Application.Exit();
        }

        #region ClickEvents (For Testing Only)
        private void btnNext_Click(object sender, EventArgs e)
        {
            //Get the next OWK scanned for THIS Bander, so the query that shows the "last 15" can use that number as the "last" number...
            using (var ctx = new PickToLightEntities())
            {
                string bander = "Bander" + _banderDisplayNum.ToString();
                var scans = (from s in ctx.ScanOWKs
                             where s.DeviceName.Equals(bander)
                                   && s.ID >_startingOWKID
                             orderby s.ID ascending
                             select new { ID = s.ID }).Take(1).ToList();
                if (scans.Count == 0)
                {
                    lblError.UIThread(ctl => { ctl.Text = "No more scans to get!"; ctl.ForeColor = Color.Red; });
                }
                else
                {
                    _startingOWKID = scans[0].ID;
                }
            }
            ScanOWK scanOWK = ScanOWK.GetScanEntry(_startingOWKID);
            if(scanOWK != null) BanderScanned(scanOWK);
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
            //Get the previous OWK scanned for THIS Bander, so the query that shows the "last 15" can use that number as the "last" number...
            using (var ctx = new PickToLightEntities())
            {
                string bander = "Bander" + _banderDisplayNum.ToString();
                var scans = (from s in ctx.ScanOWKs
                             where s.DeviceName.Equals(bander)
                                   && s.ID < _startingOWKID
                             orderby s.ID descending
                             select new { ID = s.ID }).Take(1).ToList();
                if (scans.Count == 0)
                {
                    lblError.UIThread(ctl => { ctl.Text = "No more scans to get!"; ctl.ForeColor = Color.Red; });
                }
                else
                {
                    _startingOWKID = scans[0].ID;
                }
            }
            ScanOWK scanOWK = ScanOWK.GetScanEntry(_startingOWKID);
            if (scanOWK != null) BanderScanned(scanOWK);
        }

        private void btnManifestLoad_Click(object sender, EventArgs e)
        {
            //Load the Manifest that matches the current scanned OWK.
            ScanOWK scanOWK = ScanOWK.GetScanEntry(_startingOWKID);
            if (scanOWK != null)
            {
                //If this scan was "bad", lets tell the user we cant do this until we get a "Good Scan".
                //This is just for "testing", anyway.
                if(scanOWK.Decoded == false)
                {
                    lblError.UIThread(ctl => { ctl.Text = "Last OWK was a BAD READ, need a GOOD SCAN!"; ctl.ForeColor = Color.Red; });
                    return;
                }
                int manifestID = -1;
                using (var ctx = new PickToLightEntities())
                {
                    //First, I have to get the "Picker" Scan for this OWK
                    //(Then, I can get the Manifest Scan that came just before that Picker Scan
                    var pickerOWK = (from o in ctx.ScanOWKs
                                     where o.SupplierCode.Equals(scanOWK.SupplierCode)
                                        && o.NAMCDestination.Equals(scanOWK.NAMCDestination)
                                        && o.DockCode.Equals(scanOWK.DockCode)
                                        && o.OrderNumber.Equals(scanOWK.OrderNumber)
                                        && o.PalletizationCode.Equals(scanOWK.PalletizationCode)
                                        && o.CreatedBy.Equals("PickToLightClient")
                                        && o.PartNumber.Equals(scanOWK.PartNumber)
                                        && o.BoxNumber.Equals(scanOWK.BoxNumber)
                                     select o).SingleOrDefault<ScanOWK>();
                    if (pickerOWK == null)
                    {
                        lblError.UIThread(ctl => { ctl.Text = "Unable to find the matching Picker Scan!!!"; ctl.ForeColor = Color.Red; });
                        return;
                    }
                    //Now, get the Manifest Scan that came just before this Picker Scan...
                    //Use the ScannedBy AND and DeviceName!
                     var manifest = (from m in ctx.ScanManifests
                                     where m.SupplierCode.Equals(scanOWK.SupplierCode)
                                        && m.NAMC.Equals(scanOWK.NAMCDestination)
                                        && m.DockCode.Equals(scanOWK.DockCode)
                                        && m.OrderNumber.Equals(scanOWK.OrderNumber)
                                        && m.PalletizationCode.Equals(scanOWK.PalletizationCode)
                                        && m.ScannedBy.Equals(pickerOWK.ScannedBy)
                                        && m.DeviceName.Equals(pickerOWK.DeviceName)
                                        && m.Created <= scanOWK.Created
                                     orderby m.ID descending
                                     select m).Take(1).SingleOrDefault<ScanManifest>();
                    //select new { ID = m.ID }).Take(1).ToList();
                    if (manifest == null)
                    {
                        lblError.UIThread(ctl => { ctl.Text = "Unable to find the matching Manifest for the Picker Scan (ID="+scanOWK.ID.ToString()+")!!!"; ctl.ForeColor = Color.Red; });
                        return;
                    }
                    manifestID = manifest.ID;
                }
                BeginSkidBuildForManifest(manifestID);
            }
            else
            {
                lblError.UIThread(ctl => { ctl.Text = "No scanOWK found for ID " + _startingOWKID.ToString() + " !!!"; ctl.ForeColor = Color.Red; });
            }
        }

        private void btnReload_Click(object sender, EventArgs e)
        {
            ScanOWK scanOWK = ScanOWK.GetScanEntry(_startingOWKID);
            if (scanOWK != null) BanderScanned(scanOWK);
        }
        #endregion
    }
}

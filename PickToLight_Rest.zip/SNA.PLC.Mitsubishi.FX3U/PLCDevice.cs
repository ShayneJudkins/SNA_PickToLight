﻿using ActUtlTypeLib;
using ActSupportMsgLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using SNA.WinService.PickToLightServer;

// May need "<startup useLegacyV2RuntimeActivationPolicy="true">" in app.config!!!!!
// The documentation says I do, but it seems to run fine either way....
// WAIT... DOES it require x86 (32Bit)???? NO! I don't think it does!!!
// ALSO... target CPU MUST be x86 (32Bit)!!!
// ALSO... target CPU MUST be x86 (32Bit)!!!
// WAIT... DOES it require x86 (32Bit)???? NO! I don't think it does!!!

namespace SNA.PLC.Mitsubishi.FX3U
{
    public class PLCDevice
    {
        /* =================DEBUG MODE, USED To WRITE TO ALTERNATE REGISTERS FOR TESTING!!!!!================= */
        /* =================(D3000-D3003 for Commands AND D3100, D3200 for Manifest Numbers================= */
        private bool DEBUG_MODE = false; //true;

        private int DEFAULT_LOGICAL_STATION_NUMBER = 0;

        private ActUtlType _plcDevice = null;
        private ActSupportMsg _supportMsg = null;

        private Logger _logger;

        private short _commandSeq = 111; // This is so we can start the commandSeq at the same number when in DEBUG_MODE!!

        /// <summary>
        /// Constructors.
        /// </summary>
        public PLCDevice(Logger logger)
        {
            _logger = logger;
            Init(DEFAULT_LOGICAL_STATION_NUMBER, "");
        }

        public PLCDevice(Logger logger, int plcLogicalStationNumber)
        {
            _logger = logger;
            Init(plcLogicalStationNumber, "");
        }

        public PLCDevice(Logger logger, int plcLogicalStationNumber, string plcPassword)
        {
            _logger = logger;
            Init(plcLogicalStationNumber,plcPassword);
        }

        /// <summary>
        /// Destructor.
        /// </summary>
        ~PLCDevice()
        {
            Stop();
        }

        /// <summary>
        /// Calls Close() to close the Device then deallocates the PLC Device Object.
        /// </summary>
        public void Stop()
        {
            _logger.LogMainEvent("Stop communicating with PLC and De-Allocate object...");
            if (_plcDevice != null)
            {
                Close();
                _plcDevice = null;
            }
        }

        /// <summary>
        /// Init method that creates a PLCDevice Object for the
        /// Logical Station Number in the parameter.
        /// </summary>
        /// <param name="plcLogicalStationNumber"></param>
        /// <param name="plcPassword"></param>
        private void Init(int plcLogicalStationNumber, string plcPassword)
        {
            try
            {
                _plcDevice = new ActUtlType();
                _plcDevice.ActLogicalStationNumber = plcLogicalStationNumber;
                _plcDevice.ActPassword = plcPassword;

                _supportMsg = new ActSupportMsg();

                //
                //Let's NOT Open it automatically.... may change this...
                //
                //Now, Open the device.
                //Open();
            }
            catch (Exception ex)
            {
                _plcDevice = null;
                if (ex.InnerException != null)
                {
                    _logger.LogError("Exception creating PLCDevice as ActUtlType(): " + ex.Message + " (Inner Exception: " + ex.InnerException + ")");
                }
                else
                {
                    _logger.LogError("Exception creating PLCDevice as ActUtlType(): " + ex.Message);
                }
            }
        }

        /// <summary>
        /// If PLC Device is allocated, call the PLC Device Open() method.
        /// Log any errors received from PLC Device.
        /// </summary>
        public bool Open()
        {
            _logger.LogMainEvent("Opening PLC Device...");

            if (_plcDevice == null)
            {
                _logger.LogError("ERROR! PLC Device isn't allocated!");
                return (false);
            }

            try
            {
                int iReturnCode = _plcDevice.Open();
                if (iReturnCode != 0) // When PLC Device returns error code, log the error message.
                {
                    LogDeviceError(iReturnCode);
                    return (false);
                }
            }
            catch (Exception ex)
            {
                _plcDevice = null;
                if (ex.InnerException != null)
                {
                    _logger.LogError("Exception Opening PLC Device: " + ex.Message + " (Inner Exception: " + ex.InnerException + ")");
                }
                else
                {
                    _logger.LogError("Exception Opening PLC Device: " + ex.Message);
                }
                return (false);
            }
            return (true);
        }

        /// <summary>
        /// If PLC Device is allocated, call the PLC Device Close() method.
        /// Log any errors received from PLC Device.
        /// </summary>
        public void Close()
        {
            _logger.LogMainEvent("Closing PLC Device...");

            if (_plcDevice == null)
            {
                _logger.LogError("ERROR! PLC Device isn't allocated!");
                return;
            }

            try
            {
                int iReturnCode = _plcDevice.Close();
                if (iReturnCode != 0) // When PLC Device returns error code, log the error message.
                {
                    LogDeviceError(iReturnCode);
                    return;
                }
            }
            catch (Exception ex)
            {
                _plcDevice = null;
                if (ex.InnerException != null)
                {
                    _logger.LogError("Exception Closing PLC Device: " + ex.Message + " (Inner Exception: " + ex.InnerException + ")");
                }
                else
                {
                    _logger.LogError("Exception Closing PLC Device: " + ex.Message);
                }
            }
        }

        /// <summary>
        /// Read a Register from the PLC Device.
        /// The Register stores a "Word" (two bytes or 16 bits) value.
        /// This value can be converted to a short (16 bit) int.
        /// </summary>
        /// <param name="register">Word Device/Register to read such as "D1000".</param>
        /// <param name="valueRead">The value that was read, formatted as a two digit number (using String.Format("D2")).</param>
        public bool ReadRegister(string register, out string valueRead)
        {
            int returnCode;
            short buffRead;

            valueRead = "";

            _logger.Log("Reading PLC Device Register (" + register + ")...");

            if (_plcDevice == null)
            {
                _logger.LogError("ERROR! PLC Device isn't allocated!");
                return(false);
            }

            try
            {
                returnCode = _plcDevice.ReadDeviceBlock2(register, 1, out buffRead);
                if (returnCode == 0)
                {
                    valueRead = buffRead.ToString("D2");
                    return (true);
                }
                else // When PLC Device returns error code, log the error message.
                {
                    //Check to see if the "Receive Error" ("1808301" OR "Receive error") was received.
                    //If it was, retry.
                    int iSupportReturnCode;
                    // Return code of ActSupportMsg passed to GetErrorMessage method to get Device Error.
                    string errorMessage;
                    iSupportReturnCode = _supportMsg.GetErrorMessage(returnCode, out errorMessage);
                    //Was the Error Parsed?
                    if (iSupportReturnCode != 0)
                    {
                        _logger.LogError("Error retrieving the error message using the ActSupportMsg class. (GetErrorMessage() return code = " + iSupportReturnCode.ToString() + " Error code = 0x" + returnCode.ToString("X") + ").");
                        return (false);
                    }
                    if (errorMessage.Contains("1808301") || errorMessage.Contains("Receive error"))
                    {
                        _logger.LogError("******************** Receive Error in ReadRegister() with Register [" + register + "]! Trying again in 1/2 a second!");
                        //Pause/wait 1/2 of a second (500 miliseconds).
                        MyPause(500);
                        returnCode = _plcDevice.ReadDeviceBlock2(register, 1, out buffRead);
                        if (returnCode != 0)
                        {
                            LogDeviceError(returnCode);
                            return (false);
                        }
                        else
                        {
                            valueRead = buffRead.ToString("D2");
                            return (true);
                        }
                    }
                    else
                    {
                        LogDeviceError(returnCode);
                        return (false);
                    }
                }
            }
            catch (Exception ex)
            {
                if (ex.InnerException != null)
                {
                    _logger.LogError("Exception Reading Register of PLC Device: " + ex.Message + " (Inner Exception: " + ex.InnerException + ")");
                }
                else
                {
                    _logger.LogError("Exception Reading Register of PLC Device: " + ex.Message);
                }
            }
            return(false);
        }

        /// <summary>
        /// Write a value to a Register in the PLC Device
        /// The Register stores a "Word" (two bytes or 16 bits) value.
        /// This value can be converted to a short (16 bit) int.
        /// </summary>
        /// <param name="register">Word Device/Register to write such as "D1000".</param>
        /// <param name="stringValue">The value to write (converted to a 16-bit or "short" integer).</param>
        public bool WriteRegister(string register, string stringValue)
        {
            int returnCode;
            short buffWrite;

            _logger.Log("Writing to PLC Device Register (" + register + ")...");

            if (_plcDevice == null)
            {
                _logger.LogError("ERROR! PLC Device isn't allocated!");
                return (false);
            }

            if (string.IsNullOrEmpty(stringValue))
            {
                _logger.LogError("The Value to Write is NULL or Empty!");
                return(false);
            }

            try
            {
                buffWrite = Convert.ToInt16(stringValue);
                returnCode = _plcDevice.WriteDeviceBlock2(register, 1, ref buffWrite);
                if (returnCode != 0) // When PLC Device returns error code, log the error message.
                {
                    LogDeviceError(returnCode);
                    return(false);
                }
            }
            catch (Exception ex)
            {
                if (ex.InnerException != null)
                {
                    _logger.LogError("Exception Writing Register (" + register + ") of PLC Device: " + ex.Message + " (Inner Exception: " + ex.InnerException + ")");
                }
                else
                {
                    _logger.LogError("Exception Writing Register (" + register + ") of PLC Device: " + ex.Message);
                }
            }
            return (true);
        }

        /// <summary>
        /// Read the Bander Manifest # from the PLC Device.
        /// Bander 1 is stored in Register D1100-D1110.
        /// Bander 2 is stored in Register D1200-D1210.
        /// 11/12/19 - Modified to store up to 40 characters (The PLC and HMI can handle up to 40!).
        ///            I was only storing the order number, but that isn't enough to uniquely identify the order.
        ///            Now, I am going to store "SupplierCode":"NAMC":DockCode":"OrderNumber" (22602:01TMK:N2:2019041125SB).
        /// </summary>
        /// <param name="useBander1">If true, get Bander 1 Manifest #, otherwise get bander 2 Manifest #.</param>
        /// <param name="manifestNum">The value that was read.</param>
        public void ReadBanderManifest(bool useBander1, out string manifestNum)
        {
            int returnCode;
            short[] buffRead = new short[40];
            Encoding ascii = Encoding.ASCII;
            Byte[] byarrBufferByte = new Byte[40 * 2];
            Byte[] byarrTemp = new Byte[2];
            int iNumber;
            string banderDevice = "D1100";

            manifestNum = "";

            if (DEBUG_MODE)
            {
                if (useBander1)
                {
                    banderDevice = "D3100";
                }
                else
                {
                    banderDevice = "D3200";
                }
            }
            else
            {
                if (useBander1)
                {
                    banderDevice = "D1100";
                }
                else
                {
                    banderDevice = "D1200";
                }
            }

            //_logger.Log("Reading Order/Manifest # assigned to Bander (" + (useBander1 ? "1" : "2") + ")...");

            if (_plcDevice == null)
            {
                _logger.LogError("ERROR! PLC Device isn't allocated!");
                return;
            }

            try
            {
                returnCode = _plcDevice.ReadDeviceBlock2(banderDevice, 40, out buffRead[0]);
                if (returnCode != 0) // When PLC Device returns error code, log the error message.
                {
                    //Check to see if the "Receive Error" ("1808301" OR "Receive error") was received.
                    //If it was, retry.
                    int iSupportReturnCode;
                    // Return code of ActSupportMsg passed to GetErrorMessage method to get Device Error.
                    string errorMessage;
                    iSupportReturnCode = _supportMsg.GetErrorMessage(returnCode, out errorMessage);
                    //Was the Error Parsed?
                    if (iSupportReturnCode != 0)
                    {
                        _logger.LogError("Error retrieving the error message using the ActSupportMsg class. (GetErrorMessage() return code = " + iSupportReturnCode.ToString() + " Error code = 0x" + returnCode.ToString("X") + ").");
                        return;
                    }
                    if (errorMessage.Contains("1808301") || errorMessage.Contains("Receive error"))
                    {
                        _logger.LogError("******************** Receive Error in ReadBanderManifest() with Register [" + banderDevice + "]! Trying again in 1/2 a second!");
                        //Pause/wait 1/2 of a second (500 miliseconds).
                        MyPause(500);
                        returnCode = _plcDevice.ReadDeviceBlock2(banderDevice, 40, out buffRead[0]);
                        if (returnCode != 0)
                        {
                            LogDeviceError(returnCode);
                            return;
                        }
                    }
                    else
                    {
                        LogDeviceError(returnCode);
                        return;
                    }
                }
                //Convert the 'buffRead' to the array using BitConverter/Encoding class.
                for (iNumber = 0; iNumber < 40; iNumber++)
                {
                    byarrTemp = BitConverter.GetBytes(buffRead[iNumber]);
                    byarrBufferByte[iNumber * 2] = byarrTemp[0];
                    byarrBufferByte[iNumber * 2 + 1] = byarrTemp[1];
                }

                //Since we always read 40 Characters, a "NULL Terminated" string will have Decimal 0 ('\0') after the last character, so Trim those along with Spaces!
                manifestNum = ascii.GetString(byarrBufferByte).Trim(new char[] { '\0' }); //Trim NULL ('\0') also.
            }
            catch (Exception ex)
            {
                if (ex.InnerException != null)
                {
                    _logger.LogError("Exception Reading Manifest from PLC Device: " + ex.Message + " (Inner Exception: " + ex.InnerException + ")");
                }
                else
                {
                    _logger.LogError("Exception Reading Manifest from PLC Device: " + ex.Message);
                }
            }
        }

        /// <summary>
        /// Write the Bander Manifest # to the PLC Device.
        /// Bander 1 is stored in Register D1100-D1110.
        /// Bander 2 is stored in Register D1200-D1210.
        /// 11/12/19 - Modified to store up to 40 characters (The PLC and HMI can handle up to 40!).
        ///            I was only storing the order number, but that isn't enough to uniquely identify the order.
        ///            Now, I am going to store "SupplierCode":"NAMC":DockCode":"OrderNumber" (22602:01TMK:N2:2019041125SB).
        /// </summary>
        /// <param name="useBander1">If true, write Bander 1 Manifest #, otherwise write bander 2 Manifest #.</param>
        /// <param name="manifestNum">The value to write.</param>
        public void WriteBanderManifest(bool useBander1, string manifestNum)
        {
            int returnCode;
            short[] sharrBufferForDeviceValue = new short[40];
            Byte[] byarrBufferByte;
            // Create an ASCII encoding.
            Encoding ascii = Encoding.ASCII;
            int iLengthOfBuffer, iNumber;
            string banderDevice = "D1100";

            if (DEBUG_MODE)
            {
                if (useBander1)
                {
                    banderDevice = "D3100";
                }
                else
                {
                    banderDevice = "D3200";
                }
            }
            else
            {
                if (useBander1)
                {
                    banderDevice = "D1100";
                }
                else
                {
                    banderDevice = "D1200";
                }
            }

            //_logger.Log("Writing Order Info assigned to Bander (" + (useBander1 ? "1" : "2") + ")...");

            if (_plcDevice == null)
            {
                _logger.LogError("ERROR! PLC Device isn't allocated!");
                return;
            }

            if (string.IsNullOrEmpty(manifestNum))
            {
                _logger.LogError("The Value to Write is NULL or Empty!");
                return;
            }

            try
            {
                //Encoding asciiObjectEncoding = new Encoding();
                byarrBufferByte = ascii.GetBytes(manifestNum);
                iLengthOfBuffer = Math.Min(byarrBufferByte.Length, 80);

                for (iNumber = 0; iNumber <= iLengthOfBuffer - 2; iNumber += 2)
                {
                    sharrBufferForDeviceValue[iNumber / 2] = BitConverter.ToInt16(byarrBufferByte, iNumber);
                }

                returnCode = _plcDevice.WriteDeviceBlock2(banderDevice, 40, ref sharrBufferForDeviceValue[0]);
                if (returnCode != 0) // When PLC Device returns error code, log the error message.
                {
                    LogDeviceError(returnCode);
                    return;
                }
            }
            catch (Exception ex)
            {
                if (ex.InnerException != null)
                {
                    _logger.LogError("Exception Writing Manifest to PLC Device: " + ex.Message + " (Inner Exception: " + ex.InnerException + ")");
                }
                else
                {
                    _logger.LogError("Exception Writing Manifest to PLC Device: " + ex.Message);
                }
            }
        }

        public bool WriteCommand(string commandString)
        {
            int returnCode;
            short[] buffWrite = new short[3];
            string commandRegister = "D1000";

            if (DEBUG_MODE)
            {
                commandRegister = "D3000";
            }

            _logger.Log("Writing Command to PLC Device Register (" + commandRegister + ")...");

            if (_plcDevice == null)
            {
                _logger.LogError("ERROR! PLC Device isn't allocated!");
                return(false);
            }

            if (string.IsNullOrEmpty(commandString))
            {
                _logger.LogError("The Value to Write is NULL or Empty!");
                return(false);
            }

            try
            {
                // When in DEBUG_MODE and we are JUST starting up, lets get the current Command Sequence
                // (So we can DEBUG monitoring the Registers easier.)
                if (DEBUG_MODE && _commandSeq == 111)
                {
                    string commandSeqRead;
                    if (ReadRegister("D1000", out commandSeqRead))
                        if (short.TryParse(commandSeqRead, out _commandSeq) == false)
                        {
                            _commandSeq = 1;
                        }
                        else
                        {
                            //var shortOne = (short)1;
                            //_commandSeq = _commandSeq - shortOne; //We may need to subtract one here??? YES... (too long to explain, but we need it, lol)
                            _commandSeq -= 1;
                        }
                }
                _commandSeq++;
                if (_commandSeq > 100)
                {
                    _commandSeq = 1;
                }

                
                buffWrite[0] = _commandSeq;
                buffWrite[1] = Convert.ToInt16(commandString.Substring(0, 2));
                buffWrite[2] = Convert.ToInt16(commandString.Substring(2, 2));

                returnCode = _plcDevice.WriteDeviceBlock2(commandRegister, 3, ref buffWrite[0]);
                if (returnCode != 0) // When PLC Device returns error code, log the error message.
                {
                    LogDeviceError(returnCode);
                    return (false);
                }
            }
            catch (Exception ex)
            {
                if (ex.InnerException != null)
                {
                    _logger.LogError("Exception Writing Command to PLC Device Register (" + commandRegister + "): " + ex.Message + " (Inner Exception: " + ex.InnerException + ")");
                }
                else
                {
                    _logger.LogError("Exception Writing Command to PLC Device Register (" + commandRegister + "): " + ex.Message);
                }
            }
            return (true);
        }

        public void WriteNoRead()
        {
            int returnCode;
            string badReadCommand = "02";
            short[] buffWrite = new short[2];
            string commandRegister = "D1000";

            if (DEBUG_MODE)
            {
                commandRegister = "D3000";
            }

            _logger.Log("Writing NoRead Command to PLC Device Register (" + commandRegister + ")...");

            if (_plcDevice == null)
            {
                _logger.LogError("ERROR! PLC Device isn't allocated!");
                return;
            }

            try
            {
                // When in DEBUG_MODE and we are JUST starting up, lets get the current Command Sequence
                // (So we can DEBUG monitoring the Registers easier.)
                if (DEBUG_MODE && _commandSeq == 111)
                {
                    string commandSeqRead;
                    if (ReadRegister("D1000", out commandSeqRead))
                        if (short.TryParse(commandSeqRead, out _commandSeq) == false)
                        {
                            _commandSeq = 1;
                        }
                        else
                        {
                            //var shortOne = (short)1;
                            //_commandSeq = _commandSeq - shortOne; //We may need to subtract one here??? YES... (too long to explain, but we need it, lol)
                            _commandSeq -= 1;
                        }
                }
                _commandSeq++;
                if (_commandSeq > 100)
                {
                    _commandSeq = 1;
                }
                buffWrite[0] = _commandSeq;
                buffWrite[1] = Convert.ToInt16(badReadCommand.Substring(0, 2));

                returnCode = _plcDevice.WriteDeviceBlock2(commandRegister, 2, ref buffWrite[0]);
                if (returnCode != 0) // When PLC Device returns error code, log the error message.
                {
                    LogDeviceError(returnCode);
                    return;
                }
            }
            catch (Exception ex)
            {
                if (ex.InnerException != null)
                {
                    _logger.LogError("Exception Writing NoRead Command to PLC Device Register (" + commandRegister + "): " + ex.Message + " (Inner Exception: " + ex.InnerException + ")");
                }
                else
                {
                    _logger.LogError("Exception Writing NoRead Command to PLC Device Register (" + commandRegister + "): " + ex.Message);
                }
            }
        }

        public void StopConveyor(string messageNumber)
        {
//            int returnCode;
//            string stopConveyorCommand = "00";
//            short[] buffWrite = new short[2];
//            string commandRegister = "D1000";
//            string messageNumberCommand = "03"; //As a default use Message Number "03 - ERROR: server Process reported an Error!"

//            if (_plcDevice == null)
//            {
//                _logger.LogError("ERROR! PLC Device isn't allocated!");
//                return;
//            }

//            if (DEBUG_MODE)
//            {
//                commandRegister = "D3000";
//            }

//            short shortMessageNumber;

//            if(Int16.TryParse(messageNumber,out shortMessageNumber))
//            {
//                if(shortMessageNumber < 0 || shortMessageNumber > 99)
//                {
//                    messageNumberCommand = "03"; 
//                }
//                else
//                {
//                    messageNumberCommand = shortMessageNumber.ToString();
//                }

//            }
//            else
//            {
//                //As a default use Message Number "03 - ERROR: server Process reported an Error!"
//                messageNumberCommand = "03";
//            }

//            _logger.Log("Writing StopConveyor Command to PLC Device Register (" + commandRegister + ") with MessageNumber (" + messageNumberCommand + ")...");

//CONTINUE HERE!!!
//CONTINUE HERE!!!
//CONTINUE HERE!!!
//CONTINUE HERE!!!

//            try
//            {
//                // When in DEBUG_MODE and we are JUST starting up, lets get the current Command Sequence
//                // (So we can DEBUG monitoring the Registers easier.)
//                if (DEBUG_MODE && _commandSeq == 111)
//                {
//                    string commandSeqRead;
//                    if (ReadRegister("D1000", out commandSeqRead))
//                        if (short.TryParse(commandSeqRead, out _commandSeq) == false)
//                        {
//                            _commandSeq = 1;
//                        }
//                        else
//                        {
//                            //var shortOne = (short)1;
//                            //_commandSeq = _commandSeq - shortOne; //We may need to subtract one here??? YES... (too long to explain, but we need it, lol)
//                            _commandSeq -= 1;
//                        }
//                }
//                _commandSeq++;
//                if (_commandSeq > 100)
//                {
//                    _commandSeq = 1;
//                }
//                buffWrite[0] = _commandSeq;
//                buffWrite[1] = Convert.ToInt16(badReadCommand.Substring(0, 2));

//                returnCode = _plcDevice.WriteDeviceBlock2(commandRegister, 2, ref buffWrite[0]);
//                if (returnCode != 0) // When PLC Device returns error code, log the error message.
//                {
//                    LogDeviceError(returnCode);
//                    return;
//                }
//            }
//            catch (Exception ex)
//            {
//                if (ex.InnerException != null)
//                {
//                    _logger.LogError("Exception Writing NoRead Command to PLC Device Register (" + commandRegister + "): " + ex.Message + " (Inner Exception: " + ex.InnerException + ")");
//                }
//                else
//                {
//                    _logger.LogError("Exception Writing NoRead Command to PLC Device Register (" + commandRegister + "): " + ex.Message);
//                }
//            }
        }

        /// <summary>
        /// Log any errors received from PLC Device.
        /// </summary>
        private void LogDeviceError(int iActReturnCode)
        {
            int iSupportReturnCode;
            string errorMessage;

            //Allocate in Init()
            //ActSupportMsg supportMsg = new ActSupportMsg();
            iSupportReturnCode = _supportMsg.GetErrorMessage(iActReturnCode, out errorMessage);
            if (iSupportReturnCode != 0)
            {
                errorMessage = "Error retrieving the error message using the ActSupportMsg class. (GetErrorMessage() return code = " + iSupportReturnCode.ToString() + " Error code = 0x" + iActReturnCode.ToString("X") + ").";
            }

            //Use the "Logger"!!!
            _logger.LogError(errorMessage);
        }

        /// <summary>
        /// Pauses for a specific number of milliseconds, without consumming the resources of "Sleep()".
        /// </summary>
        private void MyPause(int milisecondsToPause)
        {
            Stopwatch sw = new Stopwatch(); // sw cotructor
            sw.Start(); // starts the stopwatch

            //for (int i = 0; ; i++)
            //{
            //    // if in 100000th iteration (could be any other large number
            //    // depending on how often you want the time to be checked) 
            //    if (i % 10000 == 0)
            //    {
            //        sw.Stop(); // stop the time measurement
            //        if (sw.ElapsedMilliseconds > milisecondsToPause) // check if desired period of time has elapsed
            //        {
            //            break; // if more than 5000 milliseconds have passed, stop looping and return to the existing code
            //        }
            //        else
            //        {
            //            sw.Start(); // if less than 5000 milliseconds have elapsed, continue looping and resume time measurement
            //        }
            //    }
            //}

            //This solution is less CPU and thread dependent...
            while(true)
            {
                //No need to count iterations, just set them
                //Really need to account for CPU speed, etc. though, as a
                //CPU twice as fast runs this loop twice as many times,
                //while a slow one may greatly overshoot the desired time
                //interval. Iterations too high = overshoot, too low = excessive overhead 
                System.Threading.Thread.SpinWait(100000);
                //No need to stop the stopwatch, simply "mark the lap"
                if (sw.ElapsedMilliseconds > 5000)
                {
                    break;
                }
            }
            sw.Stop();
        }
    }
}
﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SNA.WinService.PickToLightServer
{
    public class TCPServerV2
    {
        /// <summary>
        /// Default Constants.
        /// </summary>
        const int MAX_BUFFER = 10240; //How big to make the send (tx) and receive (rx) buffers for sending and receiving bytes.
        public static int DEFAULT_PORT = 11100; //11000 is the "old" Code and 31001 I sometimes use, too.
        public static string sSTX = "\u0002";
        public static string sETX = "\u0003";
        public static char cSTX = (char)2;
        public static char cETX = (char)3;
        public static byte bSTX = 0x02;
        public static byte bETX = 0x03;
        public static byte[] baSTX = new byte[] { 0x02 };
        public static byte[] baETX = new byte[] { 0x03 };

        private Logger _logger;

        /// <summary>
        /// Local Variables Declaration.
        /// </summary>
        private TcpListener _TCPListener = null;
        private List<ClientNode> _ClientNodes;

        //Define event using generic delegate:
        public event EventHandler<PickToLightCommandEventArgsV2> CommandReceived;

        /// <summary>
        /// Constructors.
        /// </summary>
        public TCPServerV2(Logger logger, string serverName)
        {
            _logger = logger;
            IPAddress ipAddress = null;
            if (Misc.GetResolvedConnectionIPAddress(serverName, out ipAddress) == false)
            {
                _logger.LogError("Unable to resolve IP for ServerName(" + serverName + ")!");
                throw new Exception("Unable to resolve IP for ServerName (" + serverName + ")!");
            }
            Init(new IPEndPoint(ipAddress, DEFAULT_PORT));
        }

        public TCPServerV2(Logger logger, string serverName, int port)
        {
            _logger = logger;
            IPAddress ipAddress = null;
            if (Misc.GetResolvedConnectionIPAddress(serverName, out ipAddress) == false)
            {
                _logger.LogError("Unable to resolve IP for ServerName(" + serverName + ")!");
                throw new Exception("Unable to resolve IP for ServerName (" + serverName + ")!");
            }
            Init(new IPEndPoint(ipAddress, port));
        }

        public TCPServerV2(Logger logger, IPAddress serverIP)
        {
            _logger = logger;
            Init(new IPEndPoint(serverIP, DEFAULT_PORT));
        }

        public TCPServerV2(Logger logger, IPAddress serverIP, int port)
        {
            _logger = logger;
            Init(new IPEndPoint(serverIP, port));
        }

        public TCPServerV2(Logger logger, IPEndPoint ipNport)
        {
            _logger = logger;
            Init(ipNport);
        }

        /// <summary>
        /// Destructor.
        /// </summary>
        ~TCPServerV2()
        {
            StopServer();
        }

        /// <summary>
        /// Init method that create a server (TCP Listener) Object based on the
        /// IP Address and Port information that is passed in.
        /// </summary>
        /// <param name="ipNport"></param>
        private void Init(IPEndPoint ipNport)
        {
            try
            {
                _ClientNodes = new List<ClientNode>(); //The code I took this from defaults to a capacity of 2 (new List<ClientNode>(2))
            }
            catch (Exception e)
            {
                _ClientNodes = null;
                _logger.LogError("Exception creating List<ClientNode>(): " + e.Message);
                throw new Exception("Exception creating List<ClientNode>(): " + e.Message);
            }

            try
            {
                _TCPListener = new TcpListener(ipNport);

            }
            catch (Exception e)
            {
                _TCPListener = null;
                _logger.LogError("Exception creating TcpListener(): " + e.Message);
                throw new Exception("Exception creating TcpListener(): " + e.Message);
            }
        }

        /// <summary>
        /// Method that starts TCP/IP Server.
        /// </summary>
        public void StartServer()
        {
            if (_TCPListener != null)
            {
                _TCPListener.Start();
                _TCPListener.BeginAcceptTcpClient(onCompleteAcceptTcpClient, _TCPListener);
                _logger.Log("Waiting for client request with BeginAcceptTcpClient()...");
                //// Create a ArrayList for storing SocketListeners before
                //// starting the server.
                //m_socketListenersList = new ArrayList();

                //// Start the Server and start the thread to listen client 
                //// requests.
                //m_server.Start();
                //m_serverThread = new Thread(new ThreadStart(TCPServerV2Thread));
                ////m_serverThread.Name = "TCPServerV2 Server Thread";
                ////_logger.LogMainEvent("ServerThread Created, now Start() it...");
                //m_serverThread.Start();

                //// Create a low priority thread that checks and deletes client
                //// SocketConnection objcts that are marked for deletion.
                //m_purgingThread = new Thread(new ThreadStart(TCPServerV2PurgingThread));
                ////m_purgingThread.Name = "TCPServerV2 Purging Thread";
                ////_logger.LogMainEvent("PurgingThread Created, now Start() it...");
                //m_purgingThread.Priority = ThreadPriority.Lowest;
                //m_purgingThread.Start();
            }
        }

        void onCompleteAcceptTcpClient(IAsyncResult iar)
        {
            if (String.IsNullOrEmpty(Thread.CurrentThread.Name)) Thread.CurrentThread.Name = "TCPServerV2 Client Connected Thread";

            TcpListener tcpl = (TcpListener)iar.AsyncState;
            TcpClient tclient = null;
            ClientNode cNode = null;

            try
            {
                tclient = tcpl.EndAcceptTcpClient(iar);

                //printLine("Client Connected...");
                _logger.Log("A new Client has Connected (" + tclient.Client.RemoteEndPoint.ToString() + ")");


                tcpl.BeginAcceptTcpClient(onCompleteAcceptTcpClient, tcpl);

                lock (_ClientNodes)
                {
                    _ClientNodes.Add((cNode = new ClientNode(tclient, new byte[MAX_BUFFER], new byte[MAX_BUFFER], tclient.Client.RemoteEndPoint.ToString())));
                    //lbClients.Items.Add(cNode.ToString());
                }

                tclient.GetStream().BeginRead(cNode.Rx, 0, cNode.Rx.Length, onCompleteReadFromTCPClientStream, tclient);

                //mRx = new byte[MAX_BUFFER];
                //mTCPClient.GetStream().BeginRead(mRx, 0, mRx.Length, onCompleteReadFromTCPClientStream, mTCPClient);


            }
            catch (Exception ex)
            {
                //MessageBox.Show(exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                _logger.LogError("Exception in TCPServerV2, onCompleteAcceptTcpClient(): " + ex.Message);
            }
        }

        void onCompleteReadFromTCPClientStream(IAsyncResult iar)
        {
            if (String.IsNullOrEmpty(Thread.CurrentThread.Name)) Thread.CurrentThread.Name = "TCPServerV2 Stream Read Thread";

            TcpClient tcpc;
            int nCountReadBytes = 0;
            string strRecv;
            ClientNode cn = null;

            try
            {
                lock (_ClientNodes)
                {
                    tcpc = (TcpClient)iar.AsyncState;

                    cn = _ClientNodes.Find(x => x.strId == tcpc.Client.RemoteEndPoint.ToString());

                    nCountReadBytes = tcpc.GetStream().EndRead(iar);

                    if (nCountReadBytes == 0) // this happens when the client is disconnected
                    {
                        //MessageBox.Show("Client disconnected.");
                        _logger.Log("Client disconnected (" + cn.strId + ")");
                        _ClientNodes.Remove(cn);
                        //lbClients.Items.Remove(cn.ToString());
                        return;
                    }

                    //strRecv = Encoding.ASCII.GetString(cn.Rx, 0, nCountReadBytes).Trim();
                    strRecv = Encoding.ASCII.GetString(cn.Rx, 0, nCountReadBytes);   //Trim the END??? NO!!!???

                    //printLine(DateTime.Now + " - " + cn.ToString() + ": " + strRecv);
                    _logger.Log("BytesRead: " + nCountReadBytes.ToString());
                    _logger.Log("Received: " + strRecv);

                    ParseReceiveBuffer(cn, nCountReadBytes);

                    cn.Rx = new byte[MAX_BUFFER];

                    tcpc.GetStream().BeginRead(cn.Rx, 0, cn.Rx.Length, onCompleteReadFromTCPClientStream, tcpc);
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                _logger.LogError("Exception in TCPServerV2, onCompleteReadFromTCPClientStream(): " + ex.Message);

                lock (_ClientNodes)
                {
                    //printLine("Client disconnected: " + cn.ToString());
                    _logger.Log("Client disconnected (" + cn.strId + ")");
                    _ClientNodes.Remove(cn);
                    //lbClients.Items.Remove(cn.ToString());
                }

            }
        }

        /// <summary>
        /// This method parses data that is sent by a client using TCP/IP.
        /// As per the "Protocol" between client and this Listener, client 
        /// sends each command starting with STX and ending with ETX.
        /// But since the data is transmitted from client to here by TCP/IP protocol,
        /// it is not guaranteed that each line arrives properly. So the job of this
        /// method is to parse out a complete command that starts with STX and ends
        /// with ETX from the data that comes from the client and then process that
        /// command.
        /// </summary>
        /// <param name="byteBuffer"></param>
        /// <param name="size"></param>
        private void ParseReceiveBuffer(ClientNode cn, int size)
        {
            string data = Encoding.ASCII.GetString(cn.Rx, 0, size);
            int commandEndIndex = 0;
            int commandStartIndex = 0;
            StringBuilder commandBuffer = new StringBuilder();

            // Check whether data from client has more than one command, where each command ends with ETX.
            // If so break data into different commands and process separately. (Each command starts with STX.)

            //NO.. in this NEW version, just look for first character of STX and last Character ETX.
            //(Only one "command"...)
            do
            {
                commandEndIndex = data.IndexOf(sETX);
                if (commandEndIndex != -1)
                {
                    commandBuffer = commandBuffer.Append(data, 0, commandEndIndex);
                    //Find where the "Command" starts, it will begin with the STX character.
                    commandStartIndex = commandBuffer.ToString().IndexOf(sSTX);
                    if (commandStartIndex != -1)
                    {
                        //STX found, so remove everything up to the STX
                        commandBuffer.Remove(0, commandStartIndex + sSTX.Length);
                        // Process the command received (everything between STX and ETX).
                        //Use the Event!
                        OnCommandReceived(new PickToLightCommandEventArgsV2(commandBuffer.ToString(), cn.tclient));
                        //No longer needed, using Event "CommandReceived"...
                        //TODO: BUT... what if there isn't a handler for "OnCommandReceived"? Can we then call ProcessClientCommand()? Or, should we remove it?
                        //ProcessClientCommand(m_commandBuf.ToString());
                        //Now, clear the command buffer.
                        commandBuffer.Remove(0, commandBuffer.Length);
                        //Now, copy everything after the command (ETX) that we just processed,
                        //back to the main data buffer to continue parsing it.
                        //(Make sure there IS more data after the ETX first!
                        if (data.Length > commandEndIndex + sETX.Length)
                        {
                            data = data.Substring(commandEndIndex + sETX.Length, data.Length - commandEndIndex - sETX.Length);
                        }
                        else
                        {
                            data = "";
                        }
                    }
                    else
                    {
                        //Error, we got the ETX before the STX, LOG IT and clear the buffer after the ETX!!
                        _logger.LogError("ParseReceiveBuffer() invalid data format, received ETX and no STX!\n\t data = (" + data + ")\n\t commandBuffer = (" + commandBuffer.ToString() + ")");
                        //If there is any data AFTER the ETX, copy it back to the main data buffer.
                        if (data.Length > commandEndIndex + sETX.Length)
                        {
                            data = data.Substring(commandEndIndex + sETX.Length, data.Length - commandEndIndex - sETX.Length);
                        }
                        else
                        {
                            data = "";
                        }
                    }
                }
                else
                {
                    // Just append to the existing buffer.
                    commandBuffer = commandBuffer.Append(data);
                }
            } while (commandEndIndex != -1);
        }

        protected virtual void OnCommandReceived(PickToLightCommandEventArgsV2 e)
        {
            if (CommandReceived != null)
            {
                CommandReceived.Invoke(this, e);
            }
            //else isn't needed, if null is handled in "socketListener_CommandReceived()"
            //else
            //{
            //    ProcessClientCommand(e.Command);
            //}
            //Should be able to replace above with this... but maybe I want to keep this and call ProcessClientCommand() if null...
            //CommandReceived?.Invoke(this, e); // This NULL check is in C# version 6 and above... compiler must not be that version? OH WELL.. need to do something on NULL anyway!
        }

        /// <summary>
        /// Method that stops the TCP/IP Server.
        /// </summary>
        public void StopServer()
        {
            if (String.IsNullOrEmpty(Thread.CurrentThread.Name)) Thread.CurrentThread.Name = "TCPServerV2 Stop Server Thread";

            _logger.Log("Stopping TCPServerV2...");
            //New Networking Code
            if (_ClientNodes != null)
            {
                foreach (ClientNode client in _ClientNodes)
                {
                    _logger.Log("Stopping ClientNode: " + client.strId);
                    client.tclient.Client.Close(1); //Give the Socket 1 second to send any remaining data??? Or remove the timeout (Close())
                    client.tclient.Close();
                }
                _ClientNodes = null;
            }
            if (_TCPListener != null)
            {
                //New Networking Code
                _logger.Log("Stopping TcpListener...");
                _TCPListener.Stop();
                _TCPListener = null;

                //// It is important to Stop the server first before doing
                //// any cleanup. If not so, clients might being added as
                //// server is running, but supporting data structures
                //// (such as m_socketListenersList) are cleared. This might
                //// cause exceptions.

                //// Stop the TCP/IP Server.
                //m_stopServer = true;
                //_logger.Log("Stopping TCP/IP Server with Stop()...");
                //m_server.Stop();

                //// Wait for one second for the the thread to stop.
                //m_serverThread.Join(1000);

                //// If still alive; Get rid of the thread.
                //if (m_serverThread.IsAlive)
                //{
                //    _logger.Log("TCP Server Thread is still alive, calling Abort()...");
                //    m_serverThread.Abort();
                //}
                //m_serverThread = null;

                //m_stopPurging = true;
                //m_purgingThread.Join(1000);
                //if (m_purgingThread.IsAlive)
                //{
                //    _logger.Log("Purging Thread is still alive, calling Abort()...");
                //    m_purgingThread.Abort();
                //}
                //m_purgingThread = null;

                //// Free Server Object.
                //m_server = null;

                //// Stop All clients.
                //_logger.Log("Stop all clients with StopAllSocketListeners()...");
                //StopAllSocketListeners();
            }
        }

        /// <summary>
        /// Method that stops all clients and clears the list.
        /// </summary>
        //private void StopAllSocketListeners()
        //{
        //    foreach (TCPSocketListener socketListener in m_socketListenersList)
        //    {
        //        _logger.Log("Stop socketListener with StopSocketListener()...");
        //        socketListener.StopTCPSocketListenerThread();
        //    }
        //    // Remove all elements from the list.
        //    m_socketListenersList.Clear();
        //    m_socketListenersList = null;
        //}

        /// <summary>
        /// TCP/IP Server Thread that is listening for clients.
        /// </summary>
        //private void TCPServerV2Thread()
        //{
        //    Thread.CurrentThread.Name = "TCPServerV2Thread";
        //    _logger.Log("The TCP Server Thread has started.");

        //    // Client Socket variable;
        //    Socket clientSocket = null;
        //    TCPSocketListener socketListener = null;
        //    while (!m_stopServer)
        //    {
        //        try
        //        {
        //            // Wait for any client requests and if there is any 
        //            // request from any client accept it (Wait indefinitely).
        //            _logger.Log("Waiting for client request with AcceptSocket()...");
        //            clientSocket = m_server.AcceptSocket();

        //            // Create a SocketListener object for the client.
        //            _logger.Log("Creating new socketListener...");
        //            socketListener = new TCPSocketListener(clientSocket, _logger);

        //            //TODO: Check to see if there is a "CommandReceived" handler for TCPServerV2 and pass to TCPSocketListener!
        //            socketListener.CommandReceived += socketListener_CommandReceived;

        //            //*****
        //            //*****Is it really "Thread Safe", to do this HERE????*****
        //            //*****
        //            // Add the socket listener to an array list in a thread 
        //            // safe fashon.
        //            //Monitor.Enter(m_socketListenersList);
        //            lock (m_socketListenersList)
        //            {
        //                m_socketListenersList.Add(socketListener);
        //            }
        //            //Monitor.Exit(m_socketListenersList);

        //            // Start communicating with the client in a different thread.
        //            _logger.Log("Start communicating with the client using a different thread...");
        //            socketListener.StartSocketListener();
        //        }
        //        catch (SocketException se)
        //        {
        //            if (!m_stopServer)
        //            {
        //                _logger.LogError("SocketException in TCPServerV2Thread():" + se.Message);
        //            }
        //            m_stopServer = true;
        //        }
        //    }
        //}

        //private void socketListener_CommandReceived(object sender, PickToLightCommandEventArgs e)
        //{
        //    if (CommandReceived != null)
        //    {
        //        _logger.Log("TCPServerV2 CommandReceived Event, Command = (" + e.Command + ")");
        //        OnCommandReceived(new PickToLightCommandEventArgsV2(e.Command, e.ClientSocket));
        //    }
        //    else
        //    {
        //        _logger.LogError("TCPServerV2 CommandReceived Event, No CommandReceived Handler!  Command = (" + e.Command + ")");
        //        //If no handler, do this:
        //        //("ProcessClientCommand()" from TCPSocketListener 
        //        //e.ClientSocket.Send(Encoding.ASCII.GetBytes(String.Format("Command Received (NOT PROCESSED!): <{0}> Length: <{1}>", e.Command, e.Command.Length.ToString())));
        //        //Include the <STX><ETX> protocol!!!!
        //        string commandResponse = String.Format("Command Received (NOT PROCESSED!): <{0}> Length: <{1}>", e.Command, e.Command.Length.ToString());
        //        e.SendWithProtocol(commandResponse, e.ClientSocket);
        //    }
        //}

        //
        //Should these two methods be here? Or in the TCPServerV2 class?
        //(They work in the "PickToLightCommandEventArgs" class..leave them for now!)
        //
        //public int SendWithProtocol(byte[] commandResponse, Socket clientSocket)
        //{
        //    byte[] protocolBuffer = new byte[baSTX.Length + commandResponse.Length + baETX.Length];
        //    Buffer.BlockCopy(baSTX, 0, protocolBuffer, 0, baSTX.Length);
        //    Buffer.BlockCopy(commandResponse, 0, protocolBuffer, baSTX.Length, commandResponse.Length);
        //    Buffer.BlockCopy(baETX, 0, protocolBuffer, baSTX.Length + commandResponse.Length, baETX.Length);
        //    return (clientSocket.Send(commandResponse));
        //}

        //public int SendWithProtocol(String commandResponse, Socket clientSocket)
        //{
        //    return (clientSocket.Send(Encoding.ASCII.GetBytes(sSTX + commandResponse + sETX)));
        //}

        /// <summary>
        /// Thread method for purging Client Listeneres that are marked for
        /// deletion (i.e. clients with socket connection closed). This thead
        /// is a low priority thread and sleeps for 10 seconds and then check
        /// for any client SocketConnection obects which are obselete and 
        /// marked for deletion.
        /// </summary>
        //private void TCPServerV2PurgingThread()
        //{
        //    Thread.CurrentThread.Name = "TCPServerV2PurgingThread";
        //    _logger.Log("The TCP Server Purging Thread has started.");

        //    while (!m_stopPurging)
        //    {
        //        ArrayList deleteList = new ArrayList();

        //        //*****
        //        //*****Is it really "Thread Safe", to do this HERE????*****
        //        //*****
        //        // Check for any clients SocketListeners that are to be
        //        // deleted and put them in a separate list in a thread safe
        //        // fashon.
        //        //Monitor.Enter(m_socketListenersList);
        //        lock (m_socketListenersList)
        //        {
        //            foreach (TCPSocketListener socketListener
        //                         in m_socketListenersList)
        //            {
        //                if (socketListener.IsMarkedForDeletion())
        //                {
        //                    deleteList.Add(socketListener);
        //                    socketListener.StopTCPSocketListenerThread();
        //                }
        //            }

        //            // Delete all the client SocketConnection ojects which are
        //            // in marked for deletion and are in the delete list.
        //            for (int i = 0; i < deleteList.Count; ++i)
        //            {
        //                m_socketListenersList.Remove(deleteList[i]);
        //            }
        //        }
        //        //Monitor.Exit(m_socketListenersList);

        //        deleteList = null;
        //        Thread.Sleep(10000);
        //    }
        //}
    }

    public class ClientNode : IEquatable<string>
    {
        public TcpClient tclient;
        public byte[] Tx, Rx;
        public string strId;

        public ClientNode(int maxBuffer)
        {
            Tx = new byte[maxBuffer];
            Rx = new byte[maxBuffer];
            strId = string.Empty;
            tclient = new TcpClient();
        }

        public ClientNode(TcpClient _tclient, byte[] _tx, byte[] _rx, string _str)
        {
            tclient = _tclient;
            Tx = _tx;
            Rx = _rx;
            strId = _str;
        }

        public ClientNode(TcpClient _tclient, int maxBuffer)
        {
            tclient = _tclient;
            Tx = new byte[maxBuffer];
            Rx = new byte[maxBuffer];
            strId = string.Empty;
        }

        bool IEquatable<string>.Equals(string other)
        {
            if (string.IsNullOrEmpty(other)) return false;

            if (tclient == null) return false;

            return strId.Equals(other);
        }

        public string ToString()
        {
            return strId;
        }
    }
}

﻿using PickToLightData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SNA.WinService.PickToLightServer
{
    public class SkidBuild
    {
        //The "Bander" can be pulled from any of these fields in the ScanOWK Table:
        //[DeviceName]
        //[DeviceIdentifier]
        //[ScannedBy]
        //Right now, the only values are "Bander1" and "Bander2".
        public string Bander { get; set; }
        public int ScanManifestID { get; set; }
        public string SupplierCode { get; set; }
        public string NAMC { get; set; }
        public string DockCode { get; set; }
        public string OrderNumber { get; set; }
        public string PalletizationCode { get; set; }
        public string SkidId { get; set; }
        public string TradingPartner { get; set; }
        public string SubRoute { get; set; }
        public string RfIdBase { get; set; }
        public string RfIdLid { get; set; }
        public string ConfirmationNumber { get; set; }

        public void Init(string banderName)
        {
            this.Bander = banderName;
            this.ScanManifestID = -1;
            this.SupplierCode = "";
            this.NAMC = "";
            this.DockCode = "";
            this.OrderNumber = "";
            this.PalletizationCode = "";
            this.SkidId = "";
            this.TradingPartner = "";
            this.SubRoute = "";
            this.RfIdBase = "";
            this.RfIdLid = "";
            this.ConfirmationNumber = "";
        }

        public bool PopulateManifestFields(int manifestID, out string errorMessage)
        {
            errorMessage = "";

            //Let's clear/erase the current values in case there is a problem!
            Init(this.Bander);

            try
            {
                ScanManifest scanManifest = PickToLightData.ScanManifest.GetScanEntry(manifestID);
                if (scanManifest != null) //Make sure we can read the row for the idScanManifest
                {
                    this.ScanManifestID = manifestID;
                    this.SkidId = (scanManifest.OrderSequence.Length < 4 ? "ERR" : scanManifest.OrderSequence.Substring(scanManifest.OrderSequence.Length - 4, 4)); //The SkidId+AorBcode is the last 4 characters: XX001A, 14001B, 11002A, 1A002B, etc......
                    this.SupplierCode = scanManifest.SupplierCode;
                    this.NAMC = scanManifest.NAMC;
                    this.DockCode = scanManifest.DockCode;
                    this.OrderNumber = scanManifest.OrderNumber;
                    this.PalletizationCode = scanManifest.PalletizationCode;
                }
                else
                {
                    errorMessage = "Unable to find matching ID (" + manifestID.ToString() + ") in ScanManifest Table!!";
                }
            }
            catch (Exception ex)
            {
                errorMessage = "EXCEPTION in SkidBuild.PopulateManifestFields: " + ex.Message;
                return (false);
            }

            return (String.IsNullOrEmpty(errorMessage));
        }

        public bool PopulateExtraFields(out string errorMessage)
        {
            errorMessage = "";

            try
            {
                using (var ctx = new PickToLightEntities())
                {
                    NAMC_TRPT_CrossRef crossRef = (from n in ctx.NAMC_TRPT_CrossRef
                                                   where n.NAMCDestination == this.NAMC && n.SupplierCode == this.SupplierCode
                                                   select n).SingleOrDefault<NAMC_TRPT_CrossRef>();
                    if (crossRef == null)
                    {
                        //_logger.LogError("Unable to find the Trading Partner name in the NAMC_TRPT_CrossRef table using SupplierCode (" +
                        //                 this.SupplierCode + ") and NAMC (" + this.NAMC + ")!!!");
                        errorMessage = "No Trading Partner found using (" +
                                         this.SupplierCode + ", " + this.NAMC + ")!";
                        //return (false);
                        this.TradingPartner = "ERROR";
                    }
                    else
                    {
                        this.TradingPartner = crossRef.TRPT;
                    }

                    //public string SubRoute { get; set; }
                    ScanOWK owk = (from o in ctx.ScanOWKs
                                   where o.SupplierCode == this.SupplierCode &&
                                         o.NAMCDestination == this.NAMC &&
                                         o.DockCode == this.DockCode &&
                                         o.OrderNumber == this.OrderNumber &&
                                         o.PalletizationCode == this.PalletizationCode
                                   select o).FirstOrDefault<ScanOWK>();
                    if (owk == null)
                    {

                        //WAIT...Should I check the "ToyotaShipments" table here??? Maybe even FIRST??

                        //_logger.LogError("Unable to find the SubRoute in the ScanOWK table using SupplierCode (" + this.SupplierCode +
                        //                 ") and NAMC (" + this.NAMC + ") DockCode (" + this.DockCode + ") and OrderNumber (" +
                        //                 this.OrderNumber + ") PalletizationCode (" + this.PalletizationCode + ")!!!");
                        errorMessage = "No Scans found using (" + this.SupplierCode + ", " + this.NAMC +
                                        ", " + this.DockCode + ", " + this.OrderNumber + ", " + this.PalletizationCode + ")!";
                        //return (false);
                        this.SubRoute = "ERR";
                    }
                    else
                    {
                        this.SubRoute = owk.SubRoute;
                    }

                    //public string RFidBase { get; set; }
                    //RFidType = "Lid", "Base", "Empty Tote"
                    ScanSkidRfTag rfTag = (from r in ctx.ScanSkidRfTags
                                           where r.SupplierCode == this.SupplierCode &&
                                                 r.NAMC == this.NAMC &&
                                                 r.DockCode == this.DockCode &&
                                                 r.OrderNumber == this.OrderNumber &&
                                                 r.PalletizationCode == this.PalletizationCode &&
                                                 r.SkidId == this.SkidId.Substring(0, 3) && //Only the first three digits of the SkidId are used in the ScanSkidRfTag table, because we don't care about A or B!
                                                 r.RFidType.Equals("Base")
                                           select r).SingleOrDefault<ScanSkidRfTag>();
                    if (rfTag != null)
                    {
                        this.RfIdBase = rfTag.RFid;
                    }
                    else
                    {
                        this.RfIdBase = "";
                    }

                    //public string RFidLid { get; set; }
                    //RFidType = "Lid", "Base", "Empty Tote"
                    rfTag = (from r in ctx.ScanSkidRfTags
                             where r.SupplierCode == this.SupplierCode &&
                                   r.NAMC == this.NAMC &&
                                   r.DockCode == this.DockCode &&
                                   r.OrderNumber == this.OrderNumber &&
                                   r.PalletizationCode == this.PalletizationCode &&
                                   r.SkidId == this.SkidId.Substring(0, 3) && //Only the first three digits of the SkidId are used in the ScanSkidRfTag table, because we don't care about A or B!
                                   r.RFidType.Equals("Lid")
                             select r).SingleOrDefault<ScanSkidRfTag>();
                    if (rfTag != null)
                    {
                        this.RfIdLid = rfTag.RFid;
                    }
                    else
                    {
                        this.RfIdLid = "";
                    }
                }

                //public string ConfirmationNumber { get; set; }
                //See if there is a SkidBuild for this Manifest..
                SkidBuildOrder skidBuildOrder = SkidBuildOrder.GetSkidBuildOrder(this.NAMC, this.SupplierCode, this.OrderNumber, this.DockCode);
                if (skidBuildOrder != null)
                {
                    this.ConfirmationNumber = (string.IsNullOrEmpty(skidBuildOrder.ConfirmationNumber) ? "" : skidBuildOrder.ConfirmationNumber); //Let's convert a NULL to an Empty String, just because...
                }
                else
                {
                    this.ConfirmationNumber = "";
                }

            }
            catch(Exception ex)
            {
                errorMessage = "EXCEPTION in SkidBuild.PopulateExtraFields(): " + ex.Message;
                return (false);
            }

            return (String.IsNullOrEmpty(errorMessage));
        }

        public void Persist()
        {
            string banderSkidName = this.Bander + "Skid"; //The Bander (name) is "Bander1" and "Bander2", but the AppSettings are "Bander1Skid" and "Bander2Skid"
            using (var ctx = new PickToLightEntities())
            {
                AppSetting banderSkidBuild = (from a in ctx.AppSettings
                                              where a.Name.Equals(banderSkidName)
                                              select a).SingleOrDefault<AppSetting>();
                if (banderSkidBuild == null)
                {
                    ctx.AppSettings.Add(new AppSetting
                    {
                        Name = banderSkidName,
                        Value = this.ScanManifestID.ToString(),
                        CreatedBy = "PickToLightServer", //this.ServiceName,
                        ModifiedBy = "PickToLightServer", //this.ServiceName,
                        Description = "Stores the ScanManifestID that is currently being built on " + this.Bander + "."
                    });
                    ctx.SaveChanges();
                }
                else
                {
                    banderSkidBuild.Value = this.ScanManifestID.ToString();
                    ctx.SaveChanges();
                }
            }

        }

        public void Recover()
        {
            string banderSkidName = this.Bander + "Skid"; //The Bander (name) is "Bander1" and "Bander2", but the AppSettings are "Bander1Skid" and "Bander2Skid"
            using (var ctx = new PickToLightEntities())
            {
                AppSetting banderSkidBuild = (from a in ctx.AppSettings
                                              where a.Name.Equals(banderSkidName)
                                              select a).SingleOrDefault<AppSetting>();
                if (banderSkidBuild == null)
                {
                    //No AppSetting for this Bander, so Persist it (which will add an empty/blank setting) and return!.
                    Persist();
                    return;
                }
                else
                {
                    //Read the ScanManifestID Value field/column...
                    int scanManifestID = -1;
                    if (int.TryParse(banderSkidBuild.Value, out scanManifestID))
                    {
                        //If we got one, go ahead and Populate the fields with the ScanManifest Row/Entry.
                        string errorMessage = "";
                        if( PopulateManifestFields(scanManifestID, out errorMessage))
                        {
                            //If no error, also Populate the Extra fields.
                            PopulateExtraFields(out errorMessage); //I don't really care about any errors here...
                        }
                    }
                }
            }
        }
    }
}

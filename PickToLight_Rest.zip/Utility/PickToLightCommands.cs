﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;


namespace SNA.WinService.PickToLightServer
{
    public class PickToLightCommands
    {
        const int iGS = 29; //ASCII Group Separator
        const char cGS = (char)29;
        const byte bGS = 0x1D;
        const string sGS = "\x1D";
        string[] saGS = { "\x1D" };
        char[] caGS = { (char)29 };

        public const string P2L_COMMAND_Ping = "PING";  //Test communication.
        public const string P2L_COMMAND_RegisterClient = "RC";  //Will be the replacement for "PING". Currently only used by "ShipmentLoad" app.
        public const string P2L_COMMAND_ScanTransfer = "ST";
        public const string P2L_COMMAND_BanderDisplay = "BD";
        //public const string P2L_COMMAND_ScanManifest = "SM"; //Remove this one TOO, soon!
        //public const string P2L_COMMAND_ScanInternalKanban = "SIK";
        //public const string P2L_COMMAND_ScanToyotaOWK = "SOWK";
        public const string P2L_COMMAND_ScanManifestEnd = "SME"; //This is sent by the PickToLightClient program, used by the "pickers".
        public const string P2L_COMMAND_Log = "LOG";  //Log
        public const string P2L_COMMAND_LinePart = "LP";  //Request the Part Number being produced at the given Assembly Line.
        public const string P2L_COMMAND_ShipmentLoadBegin = "SLB";  //Request from client to start (or edit an existing) Shipment Load.
        public const string P2L_COMMAND_ShipmentLoadSubmit = "SLS";  //Request from client to Submit a ShipmentLoadTrailer Request to the Toyota SCS API for Approval/Confirmation.
        public const string P2L_COMMAND_SkidBuildBegin = "SBB";  //Request from client to start a Skid Build. (The ID of the ScanManifest is passed.)
        public const string P2L_COMMAND_SkidBuildEnd = "SBE";  //Request from client to "end" a Skid Build. (The ID of the ScanManifest is passed.)
        public const string P2L_COMMAND_SkidBuildQuery = "SBQ";  //Request from Bander Display to get the Skid Build (Manifet) assigned to it. (Useful after a reboot, crash, etc.)
        public const string P2L_COMMAND_SkidBuildOrderSubmit = "SBO";  //Request from client to Submit a SkidBuildOrder Request to the Toyota SCS API for Approval/Confirmation.

        static public string PopulateScanTransferCommand(bool barcodeDecoded, int entryID)
        {
            string commandToSend = "";
            if (barcodeDecoded)
            {
                //commandToSend = "ST" + entryID.ToString();
                commandToSend = P2L_COMMAND_ScanTransfer + sGS + entryID.ToString();
            }
            else
            {
                //commandToSend = "STXXX";
                commandToSend = P2L_COMMAND_ScanTransfer + sGS + "0";
            }

            return commandToSend;

            ////if (_pickToLightServerIP.Length > 10 && _pickToLightServerIP.Split('.').Length == 4) //At least 11 characters (10.10.10.10) and 3 periods/dots.
            //if (_pickToLightServerIP != null)
            //{
            //    //TCPClient tcpClient = new TCPClient(_pickToLightServerIP, port);
            //    TCPClient tcpClient = new TCPClient(_logger, _pickToLightServerIP, _port);
            //    StringBuilder commandResponse = new StringBuilder();
            //    tcpClient.SendCommand(commandToSend, commandResponse);
            //}
            //else
            //{
            //    //_logger.LogToEventLog("The TransferScannerIP setting has (" + _transferScannerIP.Split('.').Length.ToString() + ") periods!");
            //    _logger.LogError("The PickToLightServerIP setting is invalid or not specified! (This shouldn't get this far, it should be caught when Loading the settings during startup!)");
            //    return;
            //}
        }

        static public string PopulateScanTransferCommandResponse(int entryID, int banderNum)
        {
            string responseToSend = "";
            responseToSend = P2L_COMMAND_ScanTransfer + sGS + entryID.ToString() + sGS + banderNum.ToString();
            return responseToSend;
        }

        static public string PopulateScanManifestEndCommand(int manifestID)
        {
            string commandToSend = "";
            commandToSend = P2L_COMMAND_ScanManifestEnd + sGS + manifestID.ToString();

            return commandToSend;
        }

        static public string PopulateScanManifestEndCommandResponse(int manifestID)
        {
            string responseToSend = P2L_COMMAND_ScanManifestEnd + sGS + manifestID.ToString(); //For now, just return the ScanManifest ID???
            return responseToSend;
        }

        static public string PopulateBanderDisplayCommand(int entryID)
        {
            string commandToSend = P2L_COMMAND_BanderDisplay + sGS + entryID.ToString();
            return commandToSend;
        }

        //static public string PopulateBanderDisplayCommandResponse(int entryID, int banderNum)
        static public string PopulateBanderDisplayCommandResponse(int entryID)
        {
            //string responseToSend = P2L_COMMAND_BanderDisplay + sGS + entryID.ToString() + sGS + banderNum.ToString();
            string responseToSend = P2L_COMMAND_BanderDisplay + sGS + entryID.ToString();
            return responseToSend;
        }

        static public string PopulateClientScanCommandResponse(string p2l_Command, int entryID, ServerCommandResponse serverCommandResponse)
        {
            string responseToSend = "";

            //responseToSend = P2L_COMMAND_ScanManifest + sGS + entryID.ToString() + sGS + serverCommandResponse.NowScanThis.ToString() + sGS + serverCommandResponse.ShowErrorDialog.ToString() + sGS + serverCommandResponse.UserInstructions + sGS + serverCommandResponse.ErrorMessage + sGS + serverCommandResponse.ProgramOutput;
            responseToSend = p2l_Command + sGS + entryID.ToString() + sGS + serverCommandResponse.NowScanThis.ToString() + sGS + serverCommandResponse.ShowErrorDialog.ToString().ToUpper() + sGS + serverCommandResponse.UserInstructions + sGS + serverCommandResponse.ErrorMessage + sGS + serverCommandResponse.ProgramOutput;
            return responseToSend;
        }

        static public string PopulateRegisterClientCommand(string data)
        {
            string commandToSend = "";
            commandToSend = P2L_COMMAND_RegisterClient + sGS + data;

            return commandToSend;
        }

        static public string PopulateRegisterClientCommandResponse(string data)
        {
            string responseToSend = "";
            responseToSend = P2L_COMMAND_RegisterClient + sGS + data;
            return responseToSend;
        }

        static public string PopulatePingCommand(string data)
        {
            string commandToSend = "";
            commandToSend = P2L_COMMAND_Ping + sGS + data;

            return commandToSend;
        }

        static public string PopulatePingCommandResponse(string data)
        {
            string responseToSend = "";
            responseToSend = P2L_COMMAND_Ping + sGS + data;
            return responseToSend;
        }

        static public string PopulateLogCommand(string source, string threadName, int threadID, string data)
        {
            string commandToSend = "";
            //PickToLightData.Log.CreateLogEntry(_serviceName, Thread.CurrentThread.Name, Thread.CurrentThread.ManagedThreadId, stringToLog);
            commandToSend = P2L_COMMAND_Log + sGS + source + sGS + threadName + sGS + threadID.ToString() + sGS + data;
            return commandToSend;
        }

        //returnCode = 0 (Successful)
        //returnCode = -1 (Missing Parameter)
        //returnCode = -2 (ThreadID is not Int)
        //returnCode = >0 (SQL ERROR!)
        static public string PopulateLogCommandResponse(int returnCode)
        {
            string responseToSend = "";
            responseToSend = P2L_COMMAND_Log + sGS + returnCode.ToString();
            return responseToSend;
        }

        static public string PopulateLinePartCommand(string lineName)
        {
            string commandToSend = "";
            commandToSend = P2L_COMMAND_LinePart + sGS + lineName;
            return commandToSend;
        }

        static public string PopulateLinePartCommandResponse(string lineName, string snaPartNum)
        {
            string responseToSend = "";
            responseToSend = P2L_COMMAND_LinePart + sGS + lineName + sGS + snaPartNum;
            return responseToSend;
        }

        /// <summary>
        /// The ShipmentLoadBegin command is sent by a client to try to start a ShipmentLoad using the parameters SupplierCode, ShipDate, ShipTime and SubRoute.
        /// NOTE: SubRoute is optional, because we don't receieve a SubRoute for the Canadian Trading Partner (TMMC GT).
        /// (Actually, for now...I am ignoring SubRoute completely, because it isn't sent from the Canadian NAMCs anyway.)
        /// </summary>
        /// <param name="supplierCode"></param>
        /// <param name="shipDate"></param>
        /// <param name="shipTime"></param>
        /// <param name="subRoute"></param>
        /// <returns></returns>
        static public string PopulateShipmentLoadBeginCommand(string supplierCode, string shipDate, string shipTime, string subRoute)
        {
            string commandToSend = "";
            //commandToSend = P2L_COMMAND_ShipmentLoadBegin + sGS + supplierCode + sGS + subRoute + sGS + shipDate + sGS + shipTime;
            //(Ignoring  SubRoute for now, because it isn't sent from the Canadian NAMCs anyway.)
            commandToSend = P2L_COMMAND_ShipmentLoadBegin + sGS + supplierCode + sGS + shipDate + sGS + shipTime + sGS + subRoute;
            return commandToSend;
        }

        /// <summary>
        /// The ShipmentLoadBegin command is sent by a client to try to start a ShipmentLoad using the parameters SupplierCode, ShipDate, ShipTime and SubRoute.
        /// NOTE: SubRoute is optional, because we don't receieve a SubRoute for the Canadian Trading Partner (TMMC GT).
        /// (Actually, for now...I am ignoring SubRoute completely, because it isn't sent from the Canadian NAMCs anyway.)
        /// The "Response" to this command consists of two "fields", the "responseCode" and "data". The possible values for each parameter are explained below...
        /// </summary>
        /// <param name="responseCode">0 = New. There is no pending ShipmentLoad. (data is "ShipmentLoadPlan" (RequestShipmentLoad) which is a JSON object that contains the "plan" information for this ShipmentLoad.)
        ///                            &gt;0 = Existing ShipmentLoadID. - Allow to fix/edit, add/remove exceptions and resend. (data is ALSO the "ShipmentLoadPlan" (RequestShipmentLoad) which is a JSON object that contains the "plan" information for this ShipmentLoad.)
        ///                            -1=Error - Could be a missing SkidBuild or some type of actual ERROR, just show the text in the "data" field and "start over" (go back to INIT Stage).</param>
        /// <param name="data">When responseCode &gt;=0, The "ShipmentLoadPlan" (RequestShipmentLoad) (in a JSON object).
        ///                    When responseCode &lt;0, The ERROR/Exception to show the cient user.</param>
        /// <returns></returns>
        static public string PopulateShipmentLoadBeginCommandResponse(int responseCode, string data)
        {
            string responseToSend = "";
            //responseToSend = P2L_COMMAND_ShipmentLoadBegin + sGS + responseCode + sGS + data
            //responseCode:  0=New. There is no pending ShipmentLoad. (data is "ShipmentLoadPlan" (RequestShipmentLoad) which is a JSON object that contains the "plan" information for this ShipmentLoad.)
            //              >0=Existing ShipmentLoadID. - Allow to fix/edit, add/remove exceptions and resend. (data is ALSO the "ShipmentLoadPlan" (RequestShipmentLoad) which is a JSON object that contains the "plan" information for this ShipmentLoad.)
            //              -1=Error - Could be a missing SkidBuild or some type of actual ERROR, just show the text in the "data" field and "start over" (go back to INIT Stage).
            //data: (responseCode>=0) - The "ShipmentLoadPlan" (RequestShipmentLoad) (in a JSON object). 
            //      (responseCode<0) - The ERROR/Exception to show the cient user.
            responseToSend = P2L_COMMAND_ShipmentLoadBegin + sGS + responseCode.ToString() + sGS + data;
            return responseToSend;
        }

        /// <summary>
        /// The ShipmentLoadSubmit command is sent by a client to Submit a ShipmentLoadTrailer Request to the Toyota SCS API for Approval/Confirmation.
        /// </summary>
        /// <param name="shipmentLoadTrailerID"></param>
        /// <returns></returns>
        static public string PopulateShipmentLoadSubmitCommand(int shipmentLoadTrailerID)
        {
            string commandToSend = "";
            //commandToSend = P2L_COMMAND_ShipmentLoadSubmit + sGS + supplierCode + sGS + subRoute + sGS + shipDate + sGS + shipTime;
            //(Ignoring  SubRoute for now, because it isn't sent from the Canadian NAMCs anyway.)
            commandToSend = P2L_COMMAND_ShipmentLoadSubmit + sGS + shipmentLoadTrailerID;
            return commandToSend;
        }

        /// <summary>
        /// The ShipmentLoadSubmit command is sent by a client to Submit a ShipmentLoadTrailer Request to the Toyota SCS API for Approval/Confirmation.
        /// The "Response" to this command consists of two "fields", the "responseCode" and "data". The possible values for each parameter are explained below...
        /// </summary>
        /// <param name="approved">True (Was submitted and Approved.)
        ///                        False (Was not approved, the message parameter contains the reason.)</param>
        /// <param name="message">When approved parameter is true (1), this contains the Confirmation # to show.
        ///                       When approved parameter is false (0), this contains the message to show the user.</param>
        /// <returns></returns>
        static public string PopulateShipmentLoadSubmitCommandResponse(bool approved, string message)
        {
            string responseToSend = "";
            responseToSend = P2L_COMMAND_ShipmentLoadSubmit + sGS + (approved ? "1" : "0") + sGS + message;
            return responseToSend;
        }

        static public string PopulateSkidBuildBeginCommand(int manifestID, int banderNum)
        {
            //commandToSend = P2L_COMMAND_SkidBuildBegin + sGS + manifestID + sGS + banderNum;
            string commandToSend = "";
            commandToSend = P2L_COMMAND_SkidBuildBegin + sGS + manifestID.ToString() + sGS + banderNum.ToString();

            return commandToSend;
        }

        static public string PopulateSkidBuildBeginCommandErrorResponse(string message)
        {
            //We need to return Success/Failure and if Failure, then WHY

            //OK
            //responseToSend = P2L_COMMAND_SkidBuildBegin + sGS + "0" + sGS + TradingPartner + sGS + SubRoute + sGS + RFIdBase + sGS + RFIdLid + sGS + ConfirmationNumber
            //Error
            //responseToSend = P2L_COMMAND_SkidBuildBegin + sGS + "1" + sGS + message
            //
            //responseCode:  0=OK. No problems, go ahead and use that Manifest for that Bander (BanderNum is pulled from the "CreatedBy" field in the SQL row)
            //               1=Error - This Manifest can't be used on that Bander. (Just show it and stay on the "ScanManifest" page.)
            //(data fields): (responseCode=0) - The extra fields we were able to retrieve using the Scanned Manifest. 
            //      message: (responseCode=1) - The ERROR/Exception to show the client user.
            //Note: I may need to change this to work similar to the ShipmentLoad!!)
            //      and if there is an already "approved" transaction, then only let the user scan those boxes for this skid...
            //      But, in the near future, none of the transactions will be created/approved until AFTER this step! So...
            //Although, I could use the "Plan" and make it work like the TSCS apps..... YEAH, now that's the future, but just keeping it simple for now!

            string responseToSend = P2L_COMMAND_SkidBuildBegin + sGS + 1 + sGS + message;
            return responseToSend;
        }

        static public string PopulateSkidBuildBeginCommandOKResponse(string tradingPartner, string subRoute, string rfIdBase, string rfIdLid, string confirmationNumber)
        {
            //We need to return Success/Failure and if Failure, then WHY

            //OK
            //responseToSend = P2L_COMMAND_SkidBuildBegin + sGS + "0" + sGS + TradingPartner + sGS + SubRoute + sGS + RFIdBase + sGS + RFIdLid + sGS + ConfirmationNumber
            //Error
            //responseToSend = P2L_COMMAND_SkidBuildBegin + sGS + "1" + sGS + message
            //
            //responseCode:  0=OK. No problems, go ahead and use that Manifest for that Bander (BanderNum is pulled from the "CreatedBy" field in the SQL row)
            //               1=Error - This Manifest can't be used on that Bander. (Just show it and stay on the "ScanManifest" page.)
            //(data fields): (responseCode=0) - The extra fields we were able to retrieve using the Scanned Manifest. 
            //      message: (responseCode=1) - The ERROR/Exception to show the client user.
            //Note: I may need to change this to work similar to the ShipmentLoad!!)
            //      and if there is an already "approved" transaction, then only let the user scan those boxes for this skid...
            //      But, in the near future, none of the transactions will be created/approved until AFTER this step! So...
            //Although, I could use the "Plan" and make it work like the TSCS apps..... YEAH, now that's the future, but just keeping it simple for now!

            string responseToSend = P2L_COMMAND_SkidBuildBegin + sGS + 0 + sGS + tradingPartner + sGS + subRoute + sGS + rfIdBase + sGS + rfIdLid + sGS + confirmationNumber;
            return responseToSend;
        }

        //static public string PopulateSkidBuildBeginCommandResponse(int responseCode, string data)
        //{
        //    //We need to return Success/Failure and if Failure, then WHY

        //    //responseToSend = P2L_COMMAND_SkidBuildBegin + sGS + responseCode + sGS + data

        //    //responseCode:  0=OK. No problems, go ahead and use that Manifest for that Bander (BanderNum is pulled from the "CreatedBy" field in the SQL row)
        //    //               1=Error - The error/reason why the Manifest can't be used on that Bander. (Just show it and stay on the "ScanManifest" page.)
        //    //data: (responseCode=0) - The extra fields we were able to retrieve using the Scanned Manifest (send the SkidBuild class as a JSON object). 
        //    //      (responseCode=1) - The ERROR/Exception to show the client user.
        //    //Note: I may need to change this to work similar to the ShipmentLoad!!)
        //    //      and if there is an already "approved" transaction, then only let the user scan those boxes for this skid...
        //    //      But, in the near future, none of the transactions will be created/approved until AFTER this step! So...
        //    //Although, I could use the "Plan" and make it work like the TSCS apps..... YEAH, now that's the future, but just keeping it simple for now!

        //    string responseToSend = P2L_COMMAND_SkidBuildBegin + sGS + responseCode.ToString() + sGS + data;
        //    return responseToSend;
        //}

        static public string PopulateSkidBuildEndCommand(int manifestID, int banderNum)
        {
            //commandToSend = P2L_COMMAND_SkidBuildEnd + sGS + manifestID + sGS + banderNum;
            string commandToSend = "";
            commandToSend = P2L_COMMAND_SkidBuildEnd + sGS + manifestID.ToString() + sGS + banderNum.ToString();

            return commandToSend;
        }

        static public string PopulateSkidBuildEndCommandResponse(int responseCode, string message)
        {
            //We need to return Success/Failure and if Failure, then WHY  (sometimes there will be a message on "Success" too..

            // The SkidBuildEnd command is sent by a client to try to END a SkidBuild using the scanned Manifest.
            // The "Response" to this command has two different formats.
            //    The "OK" or "Success" format consists of 2 "fields", the "responseCode" (0) and "message" (to show the user).
            //    The "Error" format consists of 2 "fields", the "responseCode" (1) and "message" (to show the user).
            //
            //    //OK
            //    //responseToSend = P2L_COMMAND_SkidBuildEnd + sGS + "0" + sGS + message
            //    //Error
            //    //responseToSend = P2L_COMMAND_SkidBuildEnd + sGS + "1" + sGS + message
            //    //
            //    //responseCode:  0=OK. No problems, go ahead and prompt the user to Submit the Manifest/Order. (But if the message contains anything, show it to the user!)
            //    //               1=Error - This Manifest can't be closed out. (Just show it and stay on the "HandleManifest" page.)
            //    //(data fields): (responseCode=0) - The message to show the client user.
            //    //      message: (responseCode=1) - The ERROR/Exception to show the client user.
            //
            //    string responseToSend = P2L_COMMAND_SkidBuildEnd + sGS + 1 + sGS + message;
            //    string responseToSend = P2L_COMMAND_SkidBuildEnd + sGS + 0 + sGS + message;

            string responseToSend = P2L_COMMAND_SkidBuildEnd + sGS + responseCode.ToString() + sGS + message;
            return responseToSend;
        }

        static public string PopulateSkidBuildQueryCommand(int banderNum)
        {
            //commandToSend = P2L_COMMAND_SkidBuildQuery + sGS + banderNum;
            string commandToSend = "";
            commandToSend = P2L_COMMAND_SkidBuildQuery + sGS + banderNum.ToString();

            return commandToSend;
        }

        static public string PopulateSkidBuildQueryCommandResponse(int manifestID)
        {
            //If no manifest assigned, manifestID = -1!!!

            //responseToSend = P2L_COMMAND_SkidBuildQuery + sGS + manifestID

            string responseToSend = P2L_COMMAND_SkidBuildQuery + sGS + manifestID.ToString();
            return responseToSend;
        }

    }

    public class PickToLightCommandEventArgsV2 : System.EventArgs
    {
        string sSTX = "\u0002";
        string sETX = "\u0003";
        byte[] baSTX = new byte[] { 0x02 };
        byte[] baETX = new byte[] { 0x03 };

        public String Command { get; set; }
        public TcpClient tcpClient { get; set; }

        public PickToLightCommandEventArgsV2(String command, TcpClient client)
        {
            Command = command;
            tcpClient = client;
        }

        public int SendWithProtocol(byte[] commandResponse)
        {
            byte[] protocolBuffer = new byte[baSTX.Length + commandResponse.Length + baETX.Length];
            Buffer.BlockCopy(baSTX, 0, protocolBuffer, 0, baSTX.Length);
            Buffer.BlockCopy(commandResponse, 0, protocolBuffer, baSTX.Length, commandResponse.Length);
            Buffer.BlockCopy(baETX, 0, protocolBuffer, baSTX.Length + commandResponse.Length, baETX.Length);
            return (this.tcpClient.Client.Send(commandResponse));
        }

        public int SendWithProtocol(String commandResponse)
        {
            return (this.tcpClient.Client.Send(Encoding.ASCII.GetBytes(sSTX + commandResponse + sETX)));
        }
    }

    public class ServerCommandResponse
    {
        public enum WhatToScan { ManifestBegin, InternalKanban, ToyotaOWK, ManifestEnd, NoChange };

        public WhatToScan NowScanThis { get; set; }
        public bool ShowErrorDialog { get; set; }
        public string UserInstructions { get; set; }    //Blank/Empty when the UserInstructions don't need to be changed on the Client Display!
        public string ErrorMessage { get; set; }        //Blank/Empty when the ErrorMessage to display on the Client Display should be Blank/Empty!
        public string ProgramOutput { get; set; }       //Blank/Empty when the ProgramOutput doesn't need to be changed on the Client Display!
    };
}

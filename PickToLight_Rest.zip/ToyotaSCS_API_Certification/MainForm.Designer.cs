﻿namespace ToyotaSCS_API_Certification
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TextBoxManifestID = new System.Windows.Forms.TextBox();
            this.ButtonProcessManifestID = new System.Windows.Forms.Button();
            this.TextBoxOutput = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.CheckBoxSEND = new System.Windows.Forms.CheckBox();
            this.ComboBoxScenarioPrefix = new System.Windows.Forms.ComboBox();
            this.ComboBoxScenarioSuffix = new System.Windows.Forms.ComboBox();
            this.numericUpDownTwoDigits1 = new ToyotaSCS_API_Certification.NumericUpDownTwoDigits();
            this.panel1 = new System.Windows.Forms.Panel();
            this.ButtonProcessShipmentLoadTrailerID = new System.Windows.Forms.Button();
            this.TextBoxShipmentLoadTrailerID = new System.Windows.Forms.TextBox();
            this.ButtonProcessSkidBuildOrderID = new System.Windows.Forms.Button();
            this.TextBoxSkidBuildOrderID = new System.Windows.Forms.TextBox();
            this.CheckBoxExpendablePackagingException = new System.Windows.Forms.CheckBox();
            this.CheckBoxUseCameraScans = new System.Windows.Forms.CheckBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.ButtonClearOutput = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownTwoDigits1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // TextBoxManifestID
            // 
            this.TextBoxManifestID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxManifestID.Location = new System.Drawing.Point(218, 14);
            this.TextBoxManifestID.Name = "TextBoxManifestID";
            this.TextBoxManifestID.Size = new System.Drawing.Size(77, 26);
            this.TextBoxManifestID.TabIndex = 0;
            // 
            // ButtonProcessManifestID
            // 
            this.ButtonProcessManifestID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonProcessManifestID.Location = new System.Drawing.Point(8, 13);
            this.ButtonProcessManifestID.Name = "ButtonProcessManifestID";
            this.ButtonProcessManifestID.Size = new System.Drawing.Size(204, 28);
            this.ButtonProcessManifestID.TabIndex = 1;
            this.ButtonProcessManifestID.Text = "Process ScanManifest ID:";
            this.ButtonProcessManifestID.UseVisualStyleBackColor = true;
            this.ButtonProcessManifestID.Click += new System.EventHandler(this.ButtonProcessManifestID_Click);
            // 
            // TextBoxOutput
            // 
            this.TextBoxOutput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TextBoxOutput.Location = new System.Drawing.Point(0, 0);
            this.TextBoxOutput.Multiline = true;
            this.TextBoxOutput.Name = "TextBoxOutput";
            this.TextBoxOutput.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TextBoxOutput.Size = new System.Drawing.Size(1130, 568);
            this.TextBoxOutput.TabIndex = 20;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(334, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "Scenario:";
            // 
            // CheckBoxSEND
            // 
            this.CheckBoxSEND.AutoSize = true;
            this.CheckBoxSEND.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CheckBoxSEND.Location = new System.Drawing.Point(612, 16);
            this.CheckBoxSEND.Name = "CheckBoxSEND";
            this.CheckBoxSEND.Size = new System.Drawing.Size(103, 24);
            this.CheckBoxSEND.TabIndex = 5;
            this.CheckBoxSEND.Text = "SEND IT!";
            this.CheckBoxSEND.UseVisualStyleBackColor = true;
            // 
            // ComboBoxScenarioPrefix
            // 
            this.ComboBoxScenarioPrefix.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComboBoxScenarioPrefix.FormattingEnabled = true;
            this.ComboBoxScenarioPrefix.Items.AddRange(new object[] {
            "PB",
            "SL"});
            this.ComboBoxScenarioPrefix.Location = new System.Drawing.Point(422, 14);
            this.ComboBoxScenarioPrefix.Name = "ComboBoxScenarioPrefix";
            this.ComboBoxScenarioPrefix.Size = new System.Drawing.Size(44, 28);
            this.ComboBoxScenarioPrefix.TabIndex = 6;
            this.ComboBoxScenarioPrefix.Text = "PB";
            // 
            // ComboBoxScenarioSuffix
            // 
            this.ComboBoxScenarioSuffix.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComboBoxScenarioSuffix.FormattingEnabled = true;
            this.ComboBoxScenarioSuffix.Items.AddRange(new object[] {
            "-N",
            "-X",
            "-E"});
            this.ComboBoxScenarioSuffix.Location = new System.Drawing.Point(537, 14);
            this.ComboBoxScenarioSuffix.Name = "ComboBoxScenarioSuffix";
            this.ComboBoxScenarioSuffix.Size = new System.Drawing.Size(44, 28);
            this.ComboBoxScenarioSuffix.TabIndex = 7;
            this.ComboBoxScenarioSuffix.Text = "-N";
            // 
            // numericUpDownTwoDigits1
            // 
            this.numericUpDownTwoDigits1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDownTwoDigits1.Location = new System.Drawing.Point(482, 16);
            this.numericUpDownTwoDigits1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.numericUpDownTwoDigits1.Name = "numericUpDownTwoDigits1";
            this.numericUpDownTwoDigits1.Size = new System.Drawing.Size(41, 26);
            this.numericUpDownTwoDigits1.TabIndex = 9;
            this.numericUpDownTwoDigits1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.ButtonClearOutput);
            this.panel1.Controls.Add(this.ButtonProcessShipmentLoadTrailerID);
            this.panel1.Controls.Add(this.TextBoxShipmentLoadTrailerID);
            this.panel1.Controls.Add(this.ButtonProcessSkidBuildOrderID);
            this.panel1.Controls.Add(this.TextBoxSkidBuildOrderID);
            this.panel1.Controls.Add(this.CheckBoxExpendablePackagingException);
            this.panel1.Controls.Add(this.CheckBoxUseCameraScans);
            this.panel1.Controls.Add(this.numericUpDownTwoDigits1);
            this.panel1.Controls.Add(this.ComboBoxScenarioSuffix);
            this.panel1.Controls.Add(this.ComboBoxScenarioPrefix);
            this.panel1.Controls.Add(this.CheckBoxSEND);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.ButtonProcessManifestID);
            this.panel1.Controls.Add(this.TextBoxManifestID);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1130, 89);
            this.panel1.TabIndex = 5;
            // 
            // ButtonProcessShipmentLoadTrailerID
            // 
            this.ButtonProcessShipmentLoadTrailerID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonProcessShipmentLoadTrailerID.Location = new System.Drawing.Point(301, 48);
            this.ButtonProcessShipmentLoadTrailerID.Name = "ButtonProcessShipmentLoadTrailerID";
            this.ButtonProcessShipmentLoadTrailerID.Size = new System.Drawing.Size(236, 28);
            this.ButtonProcessShipmentLoadTrailerID.TabIndex = 15;
            this.ButtonProcessShipmentLoadTrailerID.Text = "Send ShipmentLoadTrailer ID:";
            this.ButtonProcessShipmentLoadTrailerID.UseVisualStyleBackColor = true;
            this.ButtonProcessShipmentLoadTrailerID.Click += new System.EventHandler(this.ButtonProcessShipmentLoadTrailerID_Click);
            // 
            // TextBoxShipmentLoadTrailerID
            // 
            this.TextBoxShipmentLoadTrailerID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxShipmentLoadTrailerID.Location = new System.Drawing.Point(543, 49);
            this.TextBoxShipmentLoadTrailerID.Name = "TextBoxShipmentLoadTrailerID";
            this.TextBoxShipmentLoadTrailerID.Size = new System.Drawing.Size(45, 26);
            this.TextBoxShipmentLoadTrailerID.TabIndex = 14;
            // 
            // ButtonProcessSkidBuildOrderID
            // 
            this.ButtonProcessSkidBuildOrderID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonProcessSkidBuildOrderID.Location = new System.Drawing.Point(8, 47);
            this.ButtonProcessSkidBuildOrderID.Name = "ButtonProcessSkidBuildOrderID";
            this.ButtonProcessSkidBuildOrderID.Size = new System.Drawing.Size(204, 28);
            this.ButtonProcessSkidBuildOrderID.TabIndex = 13;
            this.ButtonProcessSkidBuildOrderID.Text = "Send SkidBuildOrder ID:";
            this.ButtonProcessSkidBuildOrderID.UseVisualStyleBackColor = true;
            this.ButtonProcessSkidBuildOrderID.Click += new System.EventHandler(this.ButtonProcessSkidBuildOrderID_Click);
            // 
            // TextBoxSkidBuildOrderID
            // 
            this.TextBoxSkidBuildOrderID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxSkidBuildOrderID.Location = new System.Drawing.Point(218, 48);
            this.TextBoxSkidBuildOrderID.Name = "TextBoxSkidBuildOrderID";
            this.TextBoxSkidBuildOrderID.Size = new System.Drawing.Size(77, 26);
            this.TextBoxSkidBuildOrderID.TabIndex = 12;
            // 
            // CheckBoxExpendablePackagingException
            // 
            this.CheckBoxExpendablePackagingException.AutoSize = true;
            this.CheckBoxExpendablePackagingException.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CheckBoxExpendablePackagingException.Location = new System.Drawing.Point(612, 46);
            this.CheckBoxExpendablePackagingException.Name = "CheckBoxExpendablePackagingException";
            this.CheckBoxExpendablePackagingException.Size = new System.Drawing.Size(331, 24);
            this.CheckBoxExpendablePackagingException.TabIndex = 11;
            this.CheckBoxExpendablePackagingException.Text = "Expendable Packaging Exception (20)";
            this.CheckBoxExpendablePackagingException.UseVisualStyleBackColor = true;
            // 
            // CheckBoxUserCameraScans
            // 
            this.CheckBoxUseCameraScans.AutoSize = true;
            this.CheckBoxUseCameraScans.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CheckBoxUseCameraScans.Location = new System.Drawing.Point(732, 16);
            this.CheckBoxUseCameraScans.Name = "CheckBoxUserCameraScans";
            this.CheckBoxUseCameraScans.Size = new System.Drawing.Size(182, 24);
            this.CheckBoxUseCameraScans.TabIndex = 10;
            this.CheckBoxUseCameraScans.Text = "Use Camera Scans";
            this.CheckBoxUseCameraScans.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.TextBoxOutput);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 89);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1130, 568);
            this.panel2.TabIndex = 6;
            // 
            // ButtonClearOutput
            // 
            this.ButtonClearOutput.Location = new System.Drawing.Point(992, 18);
            this.ButtonClearOutput.Name = "ButtonClearOutput";
            this.ButtonClearOutput.Size = new System.Drawing.Size(98, 41);
            this.ButtonClearOutput.TabIndex = 16;
            this.ButtonClearOutput.Text = "Clear Output";
            this.ButtonClearOutput.UseVisualStyleBackColor = true;
            this.ButtonClearOutput.Click += new System.EventHandler(this.ButtonClearOutput_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1130, 657);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "MainForm";
            this.Text = "MainForm";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownTwoDigits1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox TextBoxManifestID;
        private System.Windows.Forms.Button ButtonProcessManifestID;
        private System.Windows.Forms.TextBox TextBoxOutput;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox CheckBoxSEND;
        private System.Windows.Forms.ComboBox ComboBoxScenarioPrefix;
        private System.Windows.Forms.ComboBox ComboBoxScenarioSuffix;
        private NumericUpDownTwoDigits numericUpDownTwoDigits1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.CheckBox CheckBoxUseCameraScans;
        private System.Windows.Forms.CheckBox CheckBoxExpendablePackagingException;
        private System.Windows.Forms.Button ButtonProcessSkidBuildOrderID;
        private System.Windows.Forms.TextBox TextBoxSkidBuildOrderID;
        private System.Windows.Forms.Button ButtonProcessShipmentLoadTrailerID;
        private System.Windows.Forms.TextBox TextBoxShipmentLoadTrailerID;
        private System.Windows.Forms.Button ButtonClearOutput;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ToyotaSCS_API_Certification
{
    public partial class NumericUpDownTwoDigits : NumericUpDown
    {
        public NumericUpDownTwoDigits()
        {
            InitializeComponent();
        }

        protected override void UpdateEditText()
        {
            
            if( this.Text.Length > 2)
            {
                this.Text = "00";
            }
            else
            {
                this.Text = Value.ToString("00");
            }
            // base.UpdateEditText();
        }

    }
}

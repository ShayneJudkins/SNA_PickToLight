﻿using PickToLightData;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using System.Net;
using System.Net.Sockets;
using System.Collections;
using System.Reflection;
using System.IO;
using System.Globalization;

namespace ToyotaSCS_API_Certification
{
    public partial class MainForm : Form
    {

        public static TextBox _TextBoxOutput; // = MainForm.TextBoxOutput;

        string fileNameScenarioPrefix = "";

        public MainForm()
        {
            InitializeComponent();
            _TextBoxOutput = this.TextBoxOutput;
            if(ComboBoxScenarioPrefix.SelectedIndex < 0)
            {
                ComboBoxScenarioPrefix.SelectedIndex = 0;
            }
            if (ComboBoxScenarioSuffix.SelectedIndex < 0)
            {
                ComboBoxScenarioSuffix.SelectedIndex = 0;
            }
        }

        private void ButtonProcessManifestID_Click(object sender, EventArgs e)
        {
            fileNameScenarioPrefix = "D:\\TSCS_API_CERTIFICATION\\" + ComboBoxScenarioPrefix.Text + numericUpDownTwoDigits1.Text + ComboBoxScenarioSuffix.Text;
            //TextBoxOutput.AppendText(fileNameScenarioPrefix);
            //TextBoxOutput.AppendText(Environment.NewLine);

            ScanManifest scanManifest = PickToLightData.ScanManifest.GetScanEntry(Int32.Parse(TextBoxManifestID.Text));
            if (scanManifest != null) //Make sure we can read the row for the ID
            {
                if (CheckBoxUseCameraScans.Checked)
                {
                    ToyotaSkidBuildRequest(scanManifest, false);
                }
                else
                {
                    ToyotaSkidBuildRequest(scanManifest, true);
                }
            }
            //CheckBoxSEND.Checked = false;
        }

        private void ToyotaSkidBuildRequest(ScanManifest scanManifest, bool pickerScansOnly)
        {
            ///
            //Determine what all PartNumber/PANSREQ been been "Picked" by looking in "ScanOWK" where "CreatedBy=PickToLightClient".
            //Store Each PartNumber and PANSREQ  as "Ordered" (or "Planned").
            //Store Each PartNumber and Number of Unique/Distinct (Barcode) Scans as "Picked" (or "Pulled" or "Shipped").
            //(Maybe I should create a Class or Struct with "PartNumber", "PansOrdered", "PansPicked".)
            ///
            //var list = new[] { new { sn = "a1", sd = "b1" } }.ToList(); // declaring structure
            //list.Clear();                                               // clearing dummy element
            //list.Add(new { sn = "a", sd = "b" });                       // adding real element
            //foreach (var leaf in list) if (leaf.sn == "a") break;       // using it
            var partsOrdered = new Dictionary<string, int>();
            var partsPulled = new Dictionary<string, int>();
            var partsPulledDuplicate = new Dictionary<string, int>();

            bool DEBUG = true; // true;   // false;

            List<ScanOWK> pickerScansForAllPartsIncludingDuplicates = new List<ScanOWK>();
            List<ToyotaShipment> toyotaOrderShipments = new List<ToyotaShipment>();

            ////(As a "backup", if we can get PalletizationCode from CMS and at least one part for each Palletization has been scanned, but the order isn't complete, we should send email notifiation!

            //First, we need to determine if a SkidBuildRequest is necessary.
            //Determine if this is the only Manifest / Skid for the order:
            using (var ctx = new PickToLightEntities())
            {
                //  Use the NAMC (NAMCDestination) and SupplierCode from the Manifest to get the TRPT that corresponds to the NAMC in ToyotaShipments
                NAMC_TRPT_CrossRef namcTRPTcrossRef;
                namcTRPTcrossRef = (from n in ctx.NAMC_TRPT_CrossRef
                                    where scanManifest.NAMC == n.NAMCDestination && scanManifest.SupplierCode == n.SupplierCode
                                    select n).SingleOrDefault<NAMC_TRPT_CrossRef>();
                if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaSkidBuildRequest()----- NAMC_TRPT_CrossRef.TRPT = " + namcTRPTcrossRef.TRPT + "  (where scanManifest.NAMC (" + scanManifest.NAMC.ToString() + ") == n.NAMCDestination && scanManifest.SupplierCode (" + scanManifest.SupplierCode.ToString() + ") == n.SupplierCode)");

                //  Using OrderNumber, NAMC, Supplier Code and Dock Code, get Rows from ToyotaShipments where COMPLETED = FALSE (0)!!!
                //  (The NAMC in ToyotaShipments is a combination of the NAMC and Supplier Code!)
                toyotaOrderShipments = (from s in ctx.ToyotaShipments
                                        where namcTRPTcrossRef.TRPT == s.NAMC
                                        && scanManifest.OrderNumber == s.ORDERNUM
                                        && scanManifest.DockCode == s.DOCKCODE
                                        && s.Completed == false
                                        select s).ToList(); //Do a "ToList()" here??
                if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaSkidBuildRequest()----- Found " + toyotaOrderShipments.Count().ToString() + " toyotaOrderShipments, where namcTRPTcrossRef.TRPT (" + namcTRPTcrossRef.TRPT.ToString() + ") == s.NAMC && scanManifest.OrderNumber (" + scanManifest.OrderNumber.ToString() + ") == s.ORDERNUM && scanManifest.DockCode (" + scanManifest.DockCode.ToString() + ") == s.DOCKCODE");
                //RIGHT HERE, IF THERE AREN'T ANY SHIPMENTS (not Completed), WE NEED TO STOP AND SEND A MESSAGE!!! Normally, this shouldn't happen!!!!)
                if (toyotaOrderShipments.Count() == 0)
                {
                    //Console.WriteLine("NOTE: The most common reason for this Exception is when the spImportToyotaShipments (SQL Stored Procedure called via a SQL Job) has NOT been executed or had problems importing this Order. -----ToyotaSkidBuildRequest()----- NO ToyotaShipments (not marked as COMPLETED) exist for scanManifest.OrderNumber = " + scanManifest.OrderNumber + " AND scanManifest.DockCode = " + scanManifest.DockCode + " AND NAMC_TRPT_CrossRef.TRPT = " + namcTRPTcrossRef.TRPT + "  (where scanManifest.NAMC (" + scanManifest.NAMC.ToString() + ") == n.NAMCDestination && scanManifest.SupplierCode (" + scanManifest.SupplierCode.ToString() + ") == n.SupplierCode)");
                    SendEMailNotificationAndLogException("NOTE: The most common reason for this Exception is when the spImportToyotaShipments (SQL Stored Procedure called via a SQL Job) has NOT been executed or had problems importing this Order. -----ToyotaSkidBuildRequest()----- NO ToyotaShipments (not marked as COMPLETED) exist for scanManifest.OrderNumber = " + scanManifest.OrderNumber + " AND scanManifest.DockCode = " + scanManifest.DockCode + " AND NAMC_TRPT_CrossRef.TRPT = " + namcTRPTcrossRef.TRPT + "  (where scanManifest.NAMC (" + scanManifest.NAMC.ToString() + ") == n.NAMCDestination && scanManifest.SupplierCode (" + scanManifest.SupplierCode.ToString() + ") == n.SupplierCode)");
                    return;
                }
                //  There will be one Row per Part…get all the Parts with ORDERQTY, PANQTY and PANSREQ…
                foreach (var shipment in toyotaOrderShipments)
                {
                    if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaSkidBuildRequest()----- Shipment for SNAPARTNUM:" + shipment.SNAPARTNUM + " PANSREQ:" + shipment.PANSREQ + " ORDERQTY:" + shipment.ORDERQTY + " PANQTY:" + shipment.PANQTY + "   (ORDERNUM:" + shipment.ORDERNUM + " NAMC:" + shipment.NAMC + " DOCKCODE:" + shipment.DOCKCODE + " SUBROUTE:" + shipment.SUBROUTE + "  SHIPDATE:" + shipment.SHIPDATE + " SHIPTIME:" + shipment.SHIPTIME + " CUSTPARTNUM:" + shipment.CUSTPARTNUM + ")");
                    if (partsOrdered.ContainsKey(shipment.CUSTPARTNUM))
                    {
                        partsOrdered[shipment.CUSTPARTNUM] = partsOrdered[shipment.CUSTPARTNUM] + Int32.Parse(shipment.PANSREQ.ToString());
                    }
                    else
                    {
                        partsOrdered.Add(shipment.CUSTPARTNUM, Int32.Parse(shipment.PANSREQ.ToString()));
                        //Also "seed" partsPulled and partsPulledDuplicate with 0 values....
                        partsPulled.Add(shipment.CUSTPARTNUM, 0);
                        partsPulledDuplicate.Add(shipment.CUSTPARTNUM, 0);
                    }

                    //     Get all the matching ScanOWK entries for Pickers (PickToLightClient).
                    //          Each "unique" ROW (NAMC, SupplierCode, OrderNumber,DockCode,PartNumber,Box...) is one PAN (PANREQ)
                    //var pickerScans = (from p in ctx.ScanOWKs //Define this outsite the "using", so it can be accessed below to send to DoSkidBuildTransaction()
                    List<ScanOWK> pickerScans = new List<ScanOWK>();
                    if(pickerScansOnly)
                    {
                        //     Get all the matching ScanOWK entries for Pickers (PickToLightClient).
                        //          Each "unique" ROW (NAMC, SupplierCode, OrderNumber,DockCode,PartNumber,Box...) is one PAN (PANREQ)
                        //List<ScanOWK> pickerScans = (from p in ctx.ScanOWKs
                        pickerScans = (from p in ctx.ScanOWKs
                                        where scanManifest.NAMC == p.NAMCDestination  //Use the NAMC from the Manifest!
                                        && scanManifest.SupplierCode == p.SupplierCode
                                        && scanManifest.OrderNumber == p.OrderNumber
                                        && scanManifest.DockCode == p.DockCode
                                        && p.Decoded == true
                                        && shipment.CUSTPARTNUM == p.PartNumber
                                        && p.CreatedBy.Equals("PickToLightClient")
                                        && p.Created < scanManifest.Created //We should only process the Scans that happened BEFORE this "B Manifest"....
                                        orderby p.Created
                                        select p).ToList();
                    }
                    else
                    {
                        pickerScans = (from p in ctx.ScanOWKs
                                        where scanManifest.NAMC == p.NAMCDestination  //Use the NAMC from the Manifest!
                                        && scanManifest.SupplierCode == p.SupplierCode
                                        && scanManifest.OrderNumber == p.OrderNumber
                                        && scanManifest.DockCode == p.DockCode
                                        && p.Decoded == true
                                        && shipment.CUSTPARTNUM == p.PartNumber
                                        //
                                        //If pickerScansOnly == FALSE, include ALL Scans... Pickers, Transfer, Bander1, Bander2.
                                        //This is used when called in situations other than "P2L_COMMAND_ScanManifestEnd"
                                        //
                                        //&& p.CreatedBy.Equals("PickToLightClient")
                                        //&& p.Created < scanManifest.Created //We should only process the Scans that happened BEFORE this "B Manifest"....
                                        orderby p.Created
                                        select p).ToList();
                    }

                    //Iterate through and log info just for debug.
                    foreach (var scan in pickerScans)
                    {
                        //[SupplierCode]
                        //,[DockCode]
                        //,[KanbanNumber]
                        //,[PartNumber]
                        //,[SupplierTextLine1]   //SNA Part #
                        //FROM [PickToLightDev].[dbo].[OWKSupplierText]
                        var kanban = (from k in ctx.OWKSupplierTexts
                                      where scan.SupplierCode == k.SupplierCode
                                      && scan.DockCode == k.DockCode
                                      && scan.PartNumber == k.PartNumber
                                      select k).FirstOrDefault<OWKSupplierText>();
                        if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaSkidBuildRequest()----- PickerScans -- Palletization:" + scan.PalletizationCode + " LineSideAddress:" + scan.LineSideAddress + " PartNumber:" + scan.PartNumber + " SNAPartNumber:" + kanban.SupplierTextLine1 + " Kanban:" + scan.KanbanNumber + " LotSize:" + scan.LotSize + " BoxNumber:" + scan.BoxNumber + " BoxTotal:" + scan.BoxTotal + "   (OrderNumber:" + scan.OrderNumber + " NAMCDestination:" + scan.NAMCDestination + " DockCode:" + scan.DockCode + " SubRoute:" + scan.SubRoute + "  ShipDate:" + scan.ShipDate + " ShipTime:" + scan.ShipTime + " CreatedBy:" + scan.CreatedBy + " ScannedBy:" + scan.ScannedBy + " Created:" + scan.Created.ToString() + ")");
                        //Let's add these parts to "pickerScansForAllPartsIncludingDuplicates" so they can be passed to the method that sends them to Toyota...
                        scan.SupplierInformation = kanban.SupplierTextLine1; //Save the SNAPartNumber as "SupplierInformation.
                        pickerScansForAllPartsIncludingDuplicates.Add(scan);
                    }
                    //          Actually, can use the "Barcode" to Group By or get "Distinct", to omit any duplicate Scans!
                    int numPartsPulled = pickerScans.Count(); //This includes Duplicate Scans!!
                    int numUniquePartsPulled = pickerScans.Select(barcode => barcode.Barcode).Distinct().Count(); //This omits any duplicates!
                    if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaSkidBuildRequest()----- PickerScans (" + numPartsPulled.ToString() + ") with distinct/unique barcode:" + numUniquePartsPulled.ToString());
                    if (partsPulled.ContainsKey(shipment.CUSTPARTNUM))
                    {
                        partsPulled[shipment.CUSTPARTNUM] = partsPulled[shipment.CUSTPARTNUM] + numUniquePartsPulled;
                    }
                    else //This normally shouldn't happen, becasue all "partsPulled" are seeded with a 0 above.....but just in case they pulled the wrong part!
                    {
                        partsPulled.Add(shipment.CUSTPARTNUM, numUniquePartsPulled);
                    }
                    //Store the duplicate scans too, just so the notification can be tailored!
                    if (numPartsPulled != numUniquePartsPulled)
                    {
                        if (partsPulledDuplicate.ContainsKey(shipment.CUSTPARTNUM))
                        {
                            partsPulledDuplicate[shipment.CUSTPARTNUM] = partsPulledDuplicate[shipment.CUSTPARTNUM] + numPartsPulled;
                        }
                        else //This normally shouldn't happen, becasue all "partsPulledDuplicate" are seeded with a 0 above.....but just in case they pulled the wrong part!
                        {
                            partsPulledDuplicate.Add(shipment.CUSTPARTNUM, numPartsPulled);
                        }
                    }
                }
            }

            if (DEBUG)
            {
                foreach (var pair in partsPulled)
                {
                    //Console.WriteLine("Pulled = {0}, {1}", pair.Key, pair.Value);
                    _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaSkidBuildRequest()----- Part# " + pair.Key + " Pulled: " + pair.Value + " Ordered:" + partsOrdered[pair.Key]);
                }
                foreach (var pair in partsOrdered)
                {
                    //Console.WriteLine("Pulled = {0}, {1}", pair.Key, pair.Value);
                    _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaSkidBuildRequest()----- Part# " + pair.Key + " Ordered: " + pair.Value + "  Pulled:" + partsPulled[pair.Key]);
                }
            }

            //     If the Order is complete, send it off for confirmation.
            //     Otherwise, "log" it and continue on.

            //if partsOrdered = partsPulled, order is 100% complete, SEND it!
            //if partsOrdered has at least 1 part pulled in partsPulled, then send Email notification and warn of possible intervention.
            //Otherwise, (one of the PartNumbers doesn't have ANY parts pulled for it) lets just assume another Manifest is coming and we will pick up the entire order then!

            bool EachPartHasAtLeastOneScan = true;
            bool AllPartsHaveBeenCompleted = true;
            bool AllPartsHaveBeenCompletedWithDuplicates = false;

            foreach (var pair in partsOrdered)
            {
                if (partsPulled[pair.Key] == 0)
                {
                    EachPartHasAtLeastOneScan = false;
                    if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaSkidBuildRequest()----- Part# " + pair.Key + " had ZERO parts Pulled. (DON'T DO ANYTHING??? WAIT FOR ANOTHER MANIFEST???)");
                }
                else if (partsPulled[pair.Key] >= pair.Value)
                {
                    if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaSkidBuildRequest()----- Part# " + pair.Key + " was FULLY Pulled. (IF ALL PARTS ARE FULLY PULLED, SEND SkidBuild!)");
                }
                else
                {
                    AllPartsHaveBeenCompleted = false;
                    if (partsPulledDuplicate[pair.Key] >= pair.Value)
                    {
                        AllPartsHaveBeenCompletedWithDuplicates = true;
                        if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaSkidBuildRequest()----- Part# " + pair.Key + " was NOT FULLY Pulled because the same barcode/boxnumber was scanned multiple times! (SEND A NOTIFICATION THAT ONLY XXX were PULLED FOR PART#, UNLESS ONE OF THE PARTS PULLED ARE ZERO, THEN IGNORE!)");
                    }
                    else
                    {
                        AllPartsHaveBeenCompletedWithDuplicates = false;
                        if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaSkidBuildRequest()----- Part# " + pair.Key + " was NOT FULLY Pulled. (SEND A NOTIFICATION THAT ONLY XXX were PULLED FOR PART#, UNLESS ONE OF THE PARTS PULLED ARE ZERO, THEN IGNORE!)");
                    }
                }
            }

            if (EachPartHasAtLeastOneScan)
            {
                if (AllPartsHaveBeenCompleted)
                {
                    DoSkidBuildTransaction(scanManifest, pickerScansForAllPartsIncludingDuplicates, toyotaOrderShipments, pickerScansOnly); //NOTE, pickerScans parameter may not be unique, hence the name!
                    _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "INFO", "-----ToyotaSkidBuildRequest()----- Sent to Toyota SCS API for Approval!");
                }
                else
                {
                    if (AllPartsHaveBeenCompletedWithDuplicates)
                    {
                        SendNotificationEmail_OrderNotComplete(scanManifest, true, "");
                        _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "ERROR", "-----ToyotaSkidBuildRequest()----- EMAIL Notifcation Sent! (AllPartsHaveBeenCompletedWithDuplicates = " + (AllPartsHaveBeenCompletedWithDuplicates ? "TRUE" : "FALSE"));
                    }
                    else
                    {
                        SendNotificationEmail_OrderNotComplete(scanManifest, false, "");
                        _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "INFO", "-----ToyotaSkidBuildRequest()----- EMAIL Notifcation Sent! (AllPartsHaveBeenCompletedWithDuplicates = " + (AllPartsHaveBeenCompletedWithDuplicates ? "TRUE" : "FALSE"));
                    }
                }
            }
            else
            {
                //MOST of the time, this means there is still another Manifest to Pull, so just wait.
                _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "INFO", "-----ToyotaSkidBuildRequest()----- One of the PartNumbers doesn't have ANY parts pulled, so don't send to TSCS API, also NO Email Notification!");
            }
        }

        private void DoSkidBuildTransaction(ScanManifest scanManifest, List<ScanOWK> nonUniquePickerScans, List<ToyotaShipment> toyotaOrderShipments, bool pickerScansOnly)
        {
            bool DEBUG = true; // false;   // true;
            bool TestException = false; //true
            TestException = CheckBoxExpendablePackagingException.Checked;

            // TODO - FINISH!
            if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- scanManifest.ID:" + scanManifest.ID.ToString() + " scanManifest.NAMC:" + scanManifest.NAMC.ToString() + " scanManifest.SupplierCode:" + scanManifest.SupplierCode.ToString() + " scanManifest.DockCode:" + scanManifest.DockCode.ToString() + " scanManifest.OrderNumber:" + scanManifest.OrderNumber.ToString() + " scanManifest.OrderSequence:" + scanManifest.OrderSequence.ToString());
            //int numUniquePartsPulled = pickerScans.Select(barcode => barcode.Barcode).Distinct().Count(); //This omits any duplicates!
            int parsedInt;
            List<ScanOWK> uniquePickerScans = (from ps in nonUniquePickerScans
                                               where ps.CreatedBy == "PickToLightClient" //Only get the actual PickerScans here!
                                               group ps by ps.Barcode  //There can be duplicates, so group on Barcode and take the last Scan.
                                                   into grp
                                                   select new ScanOWK     //Or, I could make the list of Kanban's here!
                                                   {
                                                       Barcode = grp.Key,
                                                       ID = grp.Select(ex => ex.ID).LastOrDefault(), //There can be duplicates, so group on Barcode and take the last Scan.
                                                       SupplierCode = grp.Select(ex => ex.SupplierCode).LastOrDefault(),
                                                       DockCode = grp.Select(ex => ex.DockCode).LastOrDefault(),
                                                       KanbanNumber = grp.Select(ex => ex.KanbanNumber).LastOrDefault(),
                                                       PartNumber = grp.Select(ex => ex.PartNumber).LastOrDefault(),
                                                       LineSideAddress = grp.Select(ex => ex.LineSideAddress).LastOrDefault(),
                                                       StoreAddress = grp.Select(ex => ex.StoreAddress).LastOrDefault(),
                                                       LotSize = grp.Select(ex => ex.LotSize).LastOrDefault(),
                                                       SupplierName = grp.Select(ex => ex.SupplierName).LastOrDefault(),
                                                       MainRoute = grp.Select(ex => ex.MainRoute).LastOrDefault(),
                                                       SubRoute = grp.Select(ex => ex.SubRoute).LastOrDefault(),
                                                       UnloadDate = grp.Select(ex => ex.UnloadDate).LastOrDefault(),
                                                       ShipDate = grp.Select(ex => ex.ShipDate).LastOrDefault(),
                                                       ShipTime = grp.Select(ex => ex.ShipTime).LastOrDefault(),
                                                       OrderNumber = grp.Select(ex => ex.OrderNumber).LastOrDefault(),
                                                       BoxNumber = grp.Select(ex => ex.BoxNumber).LastOrDefault(),
                                                       BoxTotal = grp.Select(ex => ex.BoxTotal).LastOrDefault(),
                                                       NAMCDestination = grp.Select(ex => ex.NAMCDestination).LastOrDefault(),
                                                       PalletizationCode = grp.Select(ex => ex.PalletizationCode).LastOrDefault(),
                                                       DeviceName = grp.Select(ex => ex.DeviceName).LastOrDefault(),
                                                       DeviceIdentifier = grp.Select(ex => ex.DeviceIdentifier).LastOrDefault(),
                                                       ScannedBy = grp.Select(ex => ex.ScannedBy).LastOrDefault(),
                                                       Created = grp.Select(ex => ex.Created).LastOrDefault(),
                                                       CreatedBy = grp.Select(ex => ex.CreatedBy).LastOrDefault(),
                                                       Filler = "" //Later on, we will "stuff" the SkidId into this field, since we aren't using it for building the Kanbans...
                                                   }).ToList();

            List<ScanOWK> cameraScansMissingFromPickerScans = new List<ScanOWK>();
            if (pickerScansOnly == false)
            {
                //Add the missing Camera Scans!!!
                //
                //First, get the uniqueCameraScans
                List<ScanOWK>  uniqueCameraScans = (from ps in nonUniquePickerScans
                                                    where ps.CreatedBy != "PickToLightClient" //Only get the actual PickerScans here!
                                                    group ps by ps.Barcode  //There can be duplicates, so group on Barcode and take the last Scan.
                                                        into grp
                                                        select new ScanOWK     //Or, I could make the list of Kanban's here!
                                                        {
                                                            Barcode = grp.Key,
                                                            ID = grp.Select(ex => ex.ID).LastOrDefault(), //There can be duplicates, so group on Barcode and take the last Scan.
                                                            SupplierCode = grp.Select(ex => ex.SupplierCode).LastOrDefault(),
                                                            DockCode = grp.Select(ex => ex.DockCode).LastOrDefault(),
                                                            KanbanNumber = grp.Select(ex => ex.KanbanNumber).LastOrDefault(),
                                                            PartNumber = grp.Select(ex => ex.PartNumber).LastOrDefault(),
                                                            LineSideAddress = grp.Select(ex => ex.LineSideAddress).LastOrDefault(),
                                                            StoreAddress = grp.Select(ex => ex.StoreAddress).LastOrDefault(),
                                                            LotSize = grp.Select(ex => ex.LotSize).LastOrDefault(),
                                                            SupplierName = grp.Select(ex => ex.SupplierName).LastOrDefault(),
                                                            MainRoute = grp.Select(ex => ex.MainRoute).LastOrDefault(),
                                                            SubRoute = grp.Select(ex => ex.SubRoute).LastOrDefault(),
                                                            UnloadDate = grp.Select(ex => ex.UnloadDate).LastOrDefault(),
                                                            ShipDate = grp.Select(ex => ex.ShipDate).LastOrDefault(),
                                                            ShipTime = grp.Select(ex => ex.ShipTime).LastOrDefault(),
                                                            OrderNumber = grp.Select(ex => ex.OrderNumber).LastOrDefault(),
                                                            BoxNumber = grp.Select(ex => ex.BoxNumber).LastOrDefault(),
                                                            BoxTotal = grp.Select(ex => ex.BoxTotal).LastOrDefault(),
                                                            NAMCDestination = grp.Select(ex => ex.NAMCDestination).LastOrDefault(),
                                                            PalletizationCode = grp.Select(ex => ex.PalletizationCode).LastOrDefault(),
                                                            DeviceName = grp.Select(ex => ex.DeviceName).LastOrDefault(),
                                                            DeviceIdentifier = grp.Select(ex => ex.DeviceIdentifier).LastOrDefault(),
                                                            ScannedBy = grp.Select(ex => ex.ScannedBy).LastOrDefault(),
                                                            Created = grp.Select(ex => ex.Created).LastOrDefault(),
                                                            CreatedBy = grp.Select(ex => ex.CreatedBy).LastOrDefault(),
                                                            Filler = "" //Later on, we will "stuff" the SkidId into this field, since we aren't using it for building the Kanbans...
                                                        }).ToList();
                
                //Now get the barcodes that were only scanned by a Camera
                cameraScansMissingFromPickerScans = uniqueCameraScans.Where(uCS => !uniquePickerScans.Any(uPS => uPS.Barcode == uCS.Barcode)).ToList();
            }

            foreach (var scan in cameraScansMissingFromPickerScans)
            {
                //if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- Camera Scans missing from Picker Scans:" + );
                if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- Camera Scans missing from Picker Scans: OrderNumber:" + scan.OrderNumber + " NAMCDestination:" + scan.NAMCDestination + " DockCode:" + scan.DockCode + " Palletization:" + scan.PalletizationCode + " Created:" + scan.Created.ToString() + " PartNumber:" + scan.PartNumber + " SNAPartNumber:" + scan.SupplierInformation + " Kanban:" + scan.KanbanNumber + " BoxNumber:" + scan.BoxNumber + " BoxTotal:" + scan.BoxTotal + " CreatedBy:" + scan.CreatedBy + " ScannedBy:" + scan.ScannedBy);
            }

            //RequestSkidBuild reqSkidBuild = new RequestSkidBuild("ExampleFromGarry");
            RequestSkidBuild reqSkidBuild = new RequestSkidBuild();

            ////////////////////////////////////////Build the RequestSkidBuild!!!!!////////////////////////////////////////

            ///I could do all this in a constructor for "RequestSkidBuild" and pass scanManifest and kanbans...

            reqSkidBuild.order = scanManifest.OrderNumber;
            reqSkidBuild.supplier = scanManifest.SupplierCode;
            reqSkidBuild.plant = scanManifest.NAMC;
            reqSkidBuild.dock = scanManifest.DockCode;


            //
            //Skid Build – Order Level
            //Shipment Load – Skid Level
            //Shipment Load – Trailer Level
            //
            //
            //We will need a SkidBuild (actually now SkidBuild), Exception Code table to choose the Codes from.
            //     (SkidBuildOrderLevelExceptionCodes, Columns = "Code,NVARCHAR(2)" and "Description,NVARCHAR(100)"....)
            //
            //Also, one for "Shipment Load - Skid Level" and "Shipment Load = Trailer Level"...
            //
            //We will need a ShipmentLoad - SkidLevel, Exception Code table to choose the Codes from.
            //     (ShipmentLoadSkidLevelExceptionCodes, Columns = "Code,NVARCHAR(2)" and "Description,NVARCHAR(100)"....)
            //We will need a ShipmentLoad = TrailerLevel, Exception Code table to choose the Codes from.
            //     (ShipmentLoadTrailerLevelExceptionCodes, Columns = "Code,NVARCHAR(2)" and "Description,NVARCHAR(100)"....)
            //
            //Add an Exception for Code 20
            //
            //It appears if there aren't any Exceptions, we don't have to add any!!!
            //BUT.... the method that builds the JSON adds a "null" exception... so lets add an empty one for now so the Request format is correct!)
            //
            //++++++++++
            //UPDATED 11/25/18!
            //++++++++++
            //Now, we can set this to null and have it omitted from the Request, because we can:
            //Tell the Serializer to ignore this by adding the Json Attribute: [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
            //to the "exceptions" property in the RequestSkidBuild class.
            //-----
            //reqSkidBuild.exceptions = new List<APIexception>();
            //APIexception exceptionItem1 = new APIexception();
            //exceptionItem1.exceptionCode = (TestException ? "20" : "");
            //exceptionItem1.comments = (TestException ? "Expendable Packaging" : "");
            //reqSkidBuild.exceptions.Add(exceptionItem1);
            ////////APIexception exceptionItem2 = new APIexception();
            ////////exceptionItem2.exceptionCode = "";
            ////////exceptionItem2.comments = "";
            ////////reqSkidBuild.exceptions.Add(exceptionItem2);
            //-----
            //++++++++++
            if (TestException)
            {
                reqSkidBuild.exceptions = new List<APIexception>();
                APIexception exceptionItem1 = new APIexception();
                exceptionItem1.exceptionCode = "20";
                exceptionItem1.comments = "Expendable Packaging";
                reqSkidBuild.exceptions.Add(exceptionItem1);
            }
            else
            {
                reqSkidBuild.exceptions = null;
            }

            //First, let's get all the Manifests that have been scanned for this Order...
            //(OrderNumber, SupplierCode, NAMC and DockCode)
            //(But only this one (that we are processing) AND the ones "older" than this one.)
            //This can be done by "ID", since we have the ScanManifest and are only querying ScanManifest.
            List<ScanManifest> manifestScans = new List<ScanManifest>();
            using (var ctx = new PickToLightEntities())
            {
                if (pickerScansOnly)
                {
                    manifestScans = (from m in ctx.ScanManifests
                                         where scanManifest.OrderNumber == m.OrderNumber
                                         && scanManifest.SupplierCode == m.SupplierCode
                                         && scanManifest.NAMC == m.NAMC
                                         && scanManifest.DockCode == m.DockCode
                                         && m.Decoded == true
                                         && m.CreatedBy.Equals("PickToLightClient")
                                         && scanManifest.ID > m.ID //Let's just use the "ID", since its faster, because its the Primary Key and Indexed.
                                         //&& m.Created < scanManifest.Created //We should only process the Scans that happened BEFORE this "B Manifest"....
                                         orderby m.Created
                                         select m).ToList();
                }
                else //1-25-19 - Load ALL Scan Manifests if we are using ALL Scans.
                {
                    manifestScans = (from m in ctx.ScanManifests
                                     where scanManifest.OrderNumber == m.OrderNumber
                                     && scanManifest.SupplierCode == m.SupplierCode
                                     && scanManifest.NAMC == m.NAMC
                                     && scanManifest.DockCode == m.DockCode
                                     && m.Decoded == true
                                     //&& m.CreatedBy.Equals("PickToLightClient")
                                     //&& scanManifest.ID > m.ID //Let's just use the "ID", since its faster, because its the Primary Key and Indexed.
                                     //&& m.Created < scanManifest.Created //We should only process the Scans that happened BEFORE this "B Manifest"....
                                     orderby m.Created
                                     select m).ToList();
                }
            }

            //Now, lets go through all the OWK Scans, Sorted by Palletization Code, then Created (Date/Time) (...NO, Just use "ID"!).
            //For each one, lets just use the Manifest that was Scanned "most recent".
            //In other words, only use the Manifests that Match the Palletization Code...
            //  sorted by Created (Date/Time) (or just ID)...
            //  and get the "Last" (newest) one that came before (less than) the OWK Scan we are processing.
            //Lets store the SkidID in a field that we aren't going to use, like "Filler"..
            //1-25-19 - We need to match the ScannedBy and/or DeviceName. I'm going to try both, that should be accurate..
            //foreach (var scan in uniquePickerScans.OrderBy(p => p.PalletizationCode).OrderBy(p => p.ID))
            //Also changed second OrderBy to ThenBy!!!! 
            //(Handle cameraScansMissingFromPickerScans differently than uniquePickerScans, try to determine the Manifest using one of the similar uniquePickerScans.
            string manifestNotFoundMessage = "";
            foreach (var scan in uniquePickerScans.OrderBy(p => p.PalletizationCode).ThenBy(p => p.ID))
            {
                if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- uniquePickerScans.OrderBy(PalletizationCode).ThenBy(ID) -- Palletization:" + scan.PalletizationCode + " Created:" + scan.Created.ToString() + " LineSideAddress:" + scan.LineSideAddress + " PartNumber:" + scan.PartNumber + " SNAPartNumber:" + scan.SupplierInformation + " Kanban:" + scan.KanbanNumber + " LotSize:" + scan.LotSize + " BoxNumber:" + scan.BoxNumber + " BoxTotal:" + scan.BoxTotal + "   (OrderNumber:" + scan.OrderNumber + " NAMCDestination:" + scan.NAMCDestination + " DockCode:" + scan.DockCode + " SubRoute:" + scan.SubRoute + "  ShipDate:" + scan.ShipDate + " ShipTime:" + scan.ShipTime + " CreatedBy:" + scan.CreatedBy + " ScannedBy:" + scan.ScannedBy + ")");
                ScanManifest manifestScan = (from m in manifestScans
                                             where scan.PalletizationCode == m.PalletizationCode
                                             && scan.Created > m.Created //Only get the Manifests that were scanned BEFORE this one...
                                             //
                                             //1-25-19 - We need to match the ScannedBy and/or DeviceName. I'm going to try both, that should be accurate.
                                             //This is to handle when:
                                             //     A picker has started one SkidId (Manifest) such as 001.
                                             //     Another picker starts a different SkidId (Manifest) such as 002
                                             //     The first picker finishes
                                             //
                                             //NO!!! NOT FOR this "Test" program anyway.
                                             //I had an instance where a picker scanned the Manifest then NONE of the Scans (only the camera).
                                             //UGH!!
                                             //&& scan.ScannedBy.Equals(m.ScannedBy) && scan.DeviceName.Equals(m.DeviceName)
                                             orderby m.ID
                                             select m).LastOrDefault();
                //Now, lets save the SkidId this OWK belongs to, in the "Filler" column (if we can find a Manifest/SkidId!!)
                if (manifestScan != null)
                {
                    if (string.IsNullOrEmpty(manifestScan.OrderSequence) == false)
                    {
                        int orderSequenceLength = manifestScan.OrderSequence.Length;
                        if (orderSequenceLength > 3) //The Skid
                        {
                            //The SkidId+AorBcode is the last 4 characters: XX001A, 14001B, 11002A, 1A002B, etc......
                            //But, we don't need the last character (AorBcode), we only need the 3 character "SkidId" 001, 002, 003, etc.
                            scan.Filler = manifestScan.OrderSequence.Substring(orderSequenceLength - 4, 3);
                        }
                    }
                }
                if (string.IsNullOrEmpty(scan.Filler))
                {
                    if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- Unable to find a matching manifest to use for uniquePickerScan -- Palletization:" + scan.PalletizationCode + " Created:" + scan.Created.ToString() + " PartNumber:" + scan.PartNumber + " SNAPartNumber:" + scan.SupplierInformation + " Kanban:" + scan.KanbanNumber + " LotSize:" + scan.LotSize + " BoxNumber:" + scan.BoxNumber + " BoxTotal:" + scan.BoxTotal + "   (OrderNumber:" + scan.OrderNumber + " NAMCDestination:" + scan.NAMCDestination + " DockCode:" + scan.DockCode + " SubRoute:" + scan.SubRoute + "  ShipDate:" + scan.ShipDate + " ShipTime:" + scan.ShipTime + " CreatedBy:" + scan.CreatedBy + " ScannedBy:" + scan.ScannedBy + ")");
                    if (string.IsNullOrEmpty(manifestNotFoundMessage))
                    {
                        manifestNotFoundMessage = "Unable to find a matching Manifest Scan for the following Picker Scanned OWKs:";
                    }
                    manifestNotFoundMessage += "SNAPart# " + scan.SupplierInformation + "<br>-----> Kanban# " + scan.KanbanNumber + " Box# " + scan.BoxNumber + " ScannedBy " + scan.ScannedBy + " Scanned " + scan.Created.ToString();
                }
            }
            //
            //1-25-19 - Move to loop above!!
            //
            ////If we didn't find a matching Manifest for any of the OWK Scans, we need to send an EmailNotification and just return...
            ////(Do that here, or in the "foreach" above????)
            ////Actually...the logic in this "foreach" and the next "foreach" could all be combined in the one above!!!
            //string manifestNotFoundMessage = "";
            ////1-25-19 - Changed second OrderBy to ThenBy!!!! 
            //foreach (var scan in uniquePickerScans.OrderBy(p => p.PalletizationCode).ThenBy(p => p.ID))
            //{
            //    if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- uniquePickerScans.OrderBy(PalletizationCode).ThenBy(ID) -- Palletization:" + scan.PalletizationCode + " Filler (SkidId):" + scan.Filler.ToString() + " Created:" + scan.Created.ToString() + " LineSideAddress:" + scan.LineSideAddress + " PartNumber:" + scan.PartNumber + " Kanban:" + scan.KanbanNumber + " LotSize:" + scan.LotSize + " BoxNumber:" + scan.BoxNumber + " BoxTotal:" + scan.BoxTotal + "   (OrderNumber:" + scan.OrderNumber + " NAMCDestination:" + scan.NAMCDestination + " DockCode:" + scan.DockCode + " SubRoute:" + scan.SubRoute + "  ShipDate:" + scan.ShipDate + " ShipTime:" + scan.ShipTime + " CreatedBy:" + scan.CreatedBy + " ScannedBy:" + scan.ScannedBy + ")");
            //    if (string.IsNullOrEmpty(scan.Filler))
            //    {
            //        if (string.IsNullOrEmpty(manifestNotFoundMessage))
            //        {
            //            manifestNotFoundMessage = "Unable to find a matching Manifest Scan for the following Picker Scanned OWKs:";
            //        }
            //        manifestNotFoundMessage += SNAPart# " + scan.SupplierInformation + "<br>-----> Kanban# " + scan.KanbanNumber + " Box# " + scan.BoxNumber + " ScannedBy " + scan.ScannedBy + " Scanned " + scan.Created.ToString();
            //    }
            //}

            //1-25-19 - Now, lets see if there are any cameraScansMissingFromPickerScans (not null)?
            //Handle cameraScansMissingFromPickerScans differently than uniquePickerScans:
            //try to determine the Manifest using one of the similar uniquePickerScans.
            bool firstMatch = true;
            foreach (var scan in cameraScansMissingFromPickerScans.OrderBy(p => p.PalletizationCode).ThenBy(p => p.ID))
            {
                if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- Determine which SkidId to use for cameraScansMissingFromPickerScans.OrderBy(PalletizationCode).ThenBy(ID) -- Palletization:" + scan.PalletizationCode + " Created:" + scan.Created.ToString() + " PartNumber:" + scan.PartNumber + " SNAPartNumber:" + scan.SupplierInformation + " Kanban:" + scan.KanbanNumber + " LotSize:" + scan.LotSize + " BoxNumber:" + scan.BoxNumber + " BoxTotal:" + scan.BoxTotal + "   (OrderNumber:" + scan.OrderNumber + " NAMCDestination:" + scan.NAMCDestination + " DockCode:" + scan.DockCode + " SubRoute:" + scan.SubRoute + "  ShipDate:" + scan.ShipDate + " ShipTime:" + scan.ShipTime + " CreatedBy:" + scan.CreatedBy + " ScannedBy:" + scan.ScannedBy + ")");
                ScanOWK similarPickerScan = null;
                //First, lets see if there is a scan in uniquePickerScans that matches the Palletization Code and Kanban
                similarPickerScan = (from ps in uniquePickerScans
                                     where scan.PalletizationCode == ps.PalletizationCode && scan.KanbanNumber == ps.KanbanNumber
                                     orderby ps.ID
                                     select ps).LastOrDefault();
                //If we found a match, use the SkidId (Filler)
                if (similarPickerScan != null)
                {
                    scan.Filler = similarPickerScan.Filler;
                    if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- Used SkidId for Camera Scan from uniquePickerScans matching Palletization Code and Kanban. Palletization:" + similarPickerScan.PalletizationCode + " Created:" + similarPickerScan.Created.ToString() + " PartNumber:" + similarPickerScan.PartNumber + " SNAPartNumber:" + similarPickerScan.SupplierInformation + " Kanban:" + similarPickerScan.KanbanNumber + " LotSize:" + similarPickerScan.LotSize + " BoxNumber:" + similarPickerScan.BoxNumber + " BoxTotal:" + similarPickerScan.BoxTotal + "   (OrderNumber:" + similarPickerScan.OrderNumber + " NAMCDestination:" + similarPickerScan.NAMCDestination + " DockCode:" + similarPickerScan.DockCode + " SubRoute:" + similarPickerScan.SubRoute + "  ShipDate:" + similarPickerScan.ShipDate + " ShipTime:" + similarPickerScan.ShipTime + " CreatedBy:" + similarPickerScan.CreatedBy + " ScannedBy:" + similarPickerScan.ScannedBy + ")");
                }
                else //Otherwise, just use the "last" one matching the Palletization Code.
                {
                    //We could get fancy here and add more logic when there are more than one Skid for this Palletization Code.
                    //But, considering how rare it is that we are ever going to his this code anyway, this is good enough!!!
                    similarPickerScan = (from ps in uniquePickerScans
                                         where scan.PalletizationCode == ps.PalletizationCode // && scan.KanbanNumber == ps.KanbanNumber
                                         orderby ps.ID
                                         select ps).LastOrDefault();
                    if (similarPickerScan != null)
                    {
                        scan.Filler = similarPickerScan.Filler;
                        if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- Used SkidId for Camera Scan from uniquePickerScans matching Palletization Code. (No matching Kanban found, this could prevent Confirmation!) Palletization:" + similarPickerScan.PalletizationCode + " Created:" + similarPickerScan.Created.ToString() + " PartNumber:" + similarPickerScan.PartNumber + " SNAPartNumber:" + similarPickerScan.SupplierInformation + " Kanban:" + similarPickerScan.KanbanNumber + " LotSize:" + similarPickerScan.LotSize + " BoxNumber:" + similarPickerScan.BoxNumber + " BoxTotal:" + similarPickerScan.BoxTotal + "   (OrderNumber:" + similarPickerScan.OrderNumber + " NAMCDestination:" + similarPickerScan.NAMCDestination + " DockCode:" + similarPickerScan.DockCode + " SubRoute:" + similarPickerScan.SubRoute + "  ShipDate:" + similarPickerScan.ShipDate + " ShipTime:" + similarPickerScan.ShipTime + " CreatedBy:" + similarPickerScan.CreatedBy + " ScannedBy:" + similarPickerScan.ScannedBy + ")");
                    }
                    else
                    {
                        if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- Unable to determine a SkidId to use for cameraScansMissingFromPickerScans -- Palletization:" + scan.PalletizationCode + " Created:" + scan.Created.ToString() + " PartNumber:" + scan.PartNumber + " SNAPartNumber:" + scan.SupplierInformation + " Kanban:" + scan.KanbanNumber + " LotSize:" + scan.LotSize + " BoxNumber:" + scan.BoxNumber + " BoxTotal:" + scan.BoxTotal + "   (OrderNumber:" + scan.OrderNumber + " NAMCDestination:" + scan.NAMCDestination + " DockCode:" + scan.DockCode + " SubRoute:" + scan.SubRoute + "  ShipDate:" + scan.ShipDate + " ShipTime:" + scan.ShipTime + " CreatedBy:" + scan.CreatedBy + " ScannedBy:" + scan.ScannedBy + ")");
                        if (firstMatch)
                        {
                            firstMatch = false;
                            manifestNotFoundMessage += "<br><br>Unable to find a matching Picker Scan for the following Camera Scanned OWKs:";
                        }
                        manifestNotFoundMessage += "SNAPart# " + scan.SupplierInformation + "<br>-----> Kanban# " + scan.KanbanNumber + " Box# " + scan.BoxNumber + " ScannedBy " + scan.ScannedBy + " Scanned " + scan.Created.ToString();
                    }
                }
            }
            //
            //Move to loop above!
            //
            //bool firstMatch = true;
            //foreach (var scan in cameraScansMissingFromPickerScans.OrderBy(p => p.PalletizationCode).ThenBy(p => p.ID))
            //{
            //    if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- uniquePickerScans.OrderBy(PalletizationCode).ThenBy(ID) -- Palletization:" + scan.PalletizationCode + " Filler (SkidId):" + scan.Filler.ToString() + " Created:" + scan.Created.ToString() + " LineSideAddress:" + scan.LineSideAddress + " PartNumber:" + scan.PartNumber + " Kanban:" + scan.KanbanNumber + " LotSize:" + scan.LotSize + " BoxNumber:" + scan.BoxNumber + " BoxTotal:" + scan.BoxTotal + "   (OrderNumber:" + scan.OrderNumber + " NAMCDestination:" + scan.NAMCDestination + " DockCode:" + scan.DockCode + " SubRoute:" + scan.SubRoute + "  ShipDate:" + scan.ShipDate + " ShipTime:" + scan.ShipTime + " CreatedBy:" + scan.CreatedBy + " ScannedBy:" + scan.ScannedBy + ")");
            //    if (string.IsNullOrEmpty(scan.Filler))
            //    {
            //        if (firstMatch)
            //        {
            //            firstMatch = false;
            //            manifestNotFoundMessage += "<br><br>Unable to find a matching Picker Scan for the following Camera Scanned OWKs:";
            //        }
            //        manifestNotFoundMessage += "SNAPart# " + scan.SupplierInformation + "<br>-----> Kanban# " + scan.KanbanNumber + " Box# " + scan.BoxNumber + " ScannedBy " + scan.ScannedBy + " Scanned " + scan.Created.ToString();
            //        }
            //    }
            //}

            //If we didn't find a matching Manifest for any of the OWK Scans, we need to send an EmailNotification and just return...
            if (string.IsNullOrEmpty(manifestNotFoundMessage) == false)//If one of the Manifests wasn't found, send the notification and return!
            {
                SendNotificationEmail_OrderNotComplete(scanManifest, false, manifestNotFoundMessage);
                if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "ERROR", "-----DoSkidBuildTransaction()----- SendNotificationEmail_OrderNotComplete, manifestNotFoundMessage = " + manifestNotFoundMessage);
                return;
            }


            //
            //1-25-19 - Build uniqueScans from uniquePickerScans and cameraScansMissingFromPickerScans!
            //
            //
            //List<ScanOWK> uniqueScans = new List<ScanOWK>();
            //uniqueScans.AddRange(uniquePickerScans);
            //uniqueScans.AddRange(cameraScansMissingFromPickerScans);
            //(Both of these methods work, but the one below is a little better/quicker, I think.)
            List<ScanOWK> uniqueScans = uniquePickerScans;
            uniqueScans.AddRange(cameraScansMissingFromPickerScans);


            //Now, lets build the Skids and Kanbans!
            //Actually...the logic in this "foreach" and the "foreach" above could all be combined in the first one!!!
            string lastPalletizationCode = "";
            string lastSkidId = "";
            reqSkidBuild.skids = new List<Skid>();
            Skid skidItem = null;
            Kanban kanbanItem = null;
            //
            //1-25-19 - We need to include the SkidId ("Filler") in the OrderBy, after the Palletication Code!!!
            //foreach (var scan in uniquePickerScans.OrderBy(p => p.PalletizationCode).OrderBy(p => p.ID))
            if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- *****Creating the Skids and Kanbans***** ");
            //Also changed second OrderBy to ThenBy!!!! 
            foreach (var scan in uniqueScans.OrderBy(p => p.PalletizationCode).ThenBy(p => p.Filler).ThenBy(p => p.ID))
            {
                if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- : lastPalletizationCode:" + lastPalletizationCode + " scan:" + scan.PalletizationCode + "    lastSkidId:" + lastSkidId + " Filler (SkidId):" + scan.Filler.ToString() + "  Created:" + scan.Created.ToString() +  "  Kanban:" + scan.KanbanNumber + " BoxNumber:" + scan.BoxNumber + "  CreatedBy:" + scan.CreatedBy + "  ScannedBy:" + scan.ScannedBy);
                //First, let's see if we have a new "Skid", if so, add one, then we all all the KanBans for that Skid.
                if (lastPalletizationCode != scan.PalletizationCode || lastSkidId != scan.Filler)
                {
                    if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- : ***NEW Skid***");
                    lastPalletizationCode = scan.PalletizationCode;
                    lastSkidId = scan.Filler;
                    if (skidItem != null)
                    {
                        if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- : ***Add Skid to Order***");
                        //
                        //Not implemented yet, since it may change, just comment out for now!!
                        //
                        ////It appears we don't have to add the rfidDetails!!!
                        ////BUT.... the method that builds the JSON adds a "null" rfidDetails... so lets add an empty one for now so the Request format is correct!)
                        //skidItem.rfidDetails = new List<RfidDetail>();

                        //RfidDetail rfidItem1 = new RfidDetail();
                        //rfidItem1.rfId = null; //rfId = "";
                        //rfidItem1.type = "";
                        //skidItem.rfidDetails.Add(rfidItem1);
                        ////RfidDetail rfidItem2 = new RfidDetail();
                        ////rfidItem2.rfId = null; //rfId = "";
                        ////rfidItem2.type = "";
                        ////skidItem.rfidDetails.Add(rfidItem2);

                        reqSkidBuild.skids.Add(skidItem); //Add the first SkidItem (when there is more than one)!
                    }
                    skidItem = new Skid();
                    skidItem.palletization = scan.PalletizationCode;
                    skidItem.skidId = scan.Filler;
                    skidItem.kanbans = new List<Kanban>();
                }
                kanbanItem = new Kanban();
                kanbanItem.lineSideAddress = scan.LineSideAddress;
                kanbanItem.partNumber = scan.PartNumber;
                kanbanItem.kanban = scan.KanbanNumber;
                kanbanItem.qpc = (Int32.TryParse(scan.LotSize, out parsedInt) ? parsedInt : 0);
                kanbanItem.boxNumber = (Int32.TryParse(scan.BoxNumber, out parsedInt) ? parsedInt : 0);
                kanbanItem.manifestNumber = null; //manifestNumber = "";
                kanbanItem.rfId = null; //rfId = "";
                skidItem.kanbans.Add(kanbanItem);
            }
            if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- *****DONE Creating the Skids and Kanbans***** ");
            //
            //Not implemented yet, since it may change, just comment out for now!!
            //
            ////It appears we don't have to add the rfidDetails!!!
            ////BUT.... the method that builds the JSON adds a "null" rfidDetails... so lets add an empty one for now so the Request format is correct!)
            //skidItem.rfidDetails = new List<RfidDetail>();

            //RfidDetail rfidItem = new RfidDetail();
            //rfidItem.rfId = null; //rfId = "";
            //rfidItem.type = "";
            //skidItem.rfidDetails.Add(rfidItem);
            ////RfidDetail rfidItem2 = new RfidDetail();
            ////rfidItem2.rfId = null; //rfId = "";
            ////rfidItem2.type = "";
            ////skidItem.rfidDetails.Add(rfidItem2);

            reqSkidBuild.skids.Add(skidItem); //Add the last SkidItem.

            //Lets order the Skids by SkidId (001,002,Etc) and the Kanbans by Part#, then Box#.
            //It makes the Request String/Json/SQL all easier to evaluate/debug/look at!
            reqSkidBuild.skids.Sort((a, b) => a.skidId.CompareTo(b.skidId));
            foreach (var skid in reqSkidBuild.skids)
            {
                //skid.kanbans.Sort((a, b) => a.partNumber.CompareTo(b.partNumber));
                skid.kanbans = skid.kanbans.OrderBy(o => o.partNumber).ThenBy(o => o.boxNumber).ToList();
            }

            SkidBuildOrder newSkidBuildOrder = CreateSkidBuildSQLEntry(reqSkidBuild, scanManifest.ScannedBy);
            if (newSkidBuildOrder == null)
            {
                _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "EXCEPTION", "-----DoSkidBuildTransaction()==== Problem creating SkidBuild SQL Rows for scanManifest.ID: " + scanManifest.ID + ", scanManifest.NAMC:" + scanManifest.NAMC.ToString() + ", scanManifest.SupplierCode:" + scanManifest.SupplierCode.ToString() + " scanManifest.DockCode:" + scanManifest.DockCode);
            }

            ////////////////////////////////////////Build the RequestSkidBuild!!!!!////////////////////////////////////////

            String Username = "24d058ee-4775-4426-9ae0-6d3e612b5e10";  //AppID
            String Password = "W8aD2pM3qO7fS8xC3wE7bD1kX1nN8fG3gS8iN1kE8gH2iF3aX0";  //AppSecret

            String SkidURL = "https://api.toyota.com/tmna/prod/Logistics/v/SupplierOrderInformation/skid";
            String TrailerURL = "https://api.toyota.com/tmna/prod/Logistics/v/SupplierOrderInformation/trailer";

            //if (DEBUG) _logger.Log("-----DoSkidBuildTransaction()-----++++++++++New Skid Build Request++++++++++");
            //if (DEBUG) _logger.Log("-----DoSkidBuildTransaction()SkidURL: " + SkidURL);
            //if (DEBUG) _logger.Log("-----DoSkidBuildTransaction()Request (ObjectDumper): " + ObjectDumper.Dump(reqSkidBuild));
            //if (DEBUG) _logger.Log("-----DoSkidBuildTransaction()Request (JSON): " + JsonConvert.SerializeObject(reqSkidBuild));

            ToyotaSCSWebAPI tscsWebAPI = new ToyotaSCSWebAPI(Username, Password, SkidURL, TrailerURL);

            APIresponse response = null;

            //Testing API Communication!
            //response = tscsWebAPI.SendRequest<APIresponse>(SkidURL, "[{\"order\":\"2018090501SA\"}]");
            //if (DEBUG) _logger.Log("-----DoSkidBuildTransaction()==========(Only Sending Order, for test...) Response: " + Misc.ClassToString(response));

            List<RequestSkidBuild> orders = new List<RequestSkidBuild>();
            orders.Add(reqSkidBuild);
            string jsonRequest = JsonConvert.SerializeObject(orders);
            if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()=======Request (JSON): " + jsonRequest);
            File.WriteAllText(fileNameScenarioPrefix + "_Request.txt", jsonRequest);
            if (CheckBoxSEND.Checked)
            {
                string stringResponse;
                response = tscsWebAPI.SendRequest<APIresponse>(SkidURL, jsonRequest, out stringResponse);
                //Console.WriteLine("-----DoSkidBuildTransaction()==========Response: " + Misc.ClassToString(response));
                //Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                //Console.WriteLine("-----DoSkidBuildTransaction()==========Response (ObjectDumper): " + ObjectDumper.Dump(response));
                //Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                //if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()==========Response: " + Misc.ClassToString(response));
                if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()==========Response (ObjectDumper): " + ObjectDumper.Dump(response));

                File.WriteAllText(fileNameScenarioPrefix + "_Response.txt", stringResponse);

                //
                //HandleAPIResponse() creates the SQL Rows for APIResponse, APIResonseMessage and SkidBuildOrderResponse (Maybe ShipmentLoadTrailerResponse in future???)
                //      It also "parses" the response and determines what to do? Like update ToyotaShipments or SkidBuildOrder Tables, or send an EMAIL Notification to "Managers" or "Developers"????
                //      RIGHT??? Make sure it does do all that!
                //
                HandleAPIResponse(response, newSkidBuildOrder, toyotaOrderShipments, scanManifest.ScannedBy);
            }
            else
            {
                MainForm._TextBoxOutput.AppendText(Environment.NewLine);
                MainForm._TextBoxOutput.AppendText("Created SkidBuildOrderID: " + newSkidBuildOrder.ID.ToString());
                MainForm._TextBoxOutput.AppendText(Environment.NewLine);
            }

            #region SimulateMoreTestResponses

            //////
            //////Simulate more responses, just to test Methods and proper SQL creation!
            //////
            //////Bad UserName
            ////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            ////Console.WriteLine("");
            ////Console.WriteLine("");
            ////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            ////Console.WriteLine("Press any Key and I will Send A BAD UserName!");
            ////Console.ReadKey(true);
            ////tscsWebAPI.UserName = "BAD";
            ////response = tscsWebAPI.SendRequest<APIresponse>(SkidURL, jsonRequest);
            //////Console.WriteLine("-----DoSkidBuildTransaction()==========Response: " + Misc.ClassToString(response));
            //////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            //////Console.WriteLine("-----DoSkidBuildTransaction()==========Response (ObjectDumper): " + ObjectDumper.Dump(response));
            //////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            ////HandleAPIResponse(response, newSkidBuildOrder, toyotaOrderShipments, scanManifest.ScannedBy);

            //////Wrong URL "method"
            ////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            ////Console.WriteLine("");
            ////Console.WriteLine("");
            ////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            ////Console.WriteLine("Press any Key and I will Send the wrong URL/WebMethod!");
            ////tscsWebAPI.UserName = Username;
            ////Console.ReadKey(true);
            ////response = tscsWebAPI.SendRequest<APIresponse>("https://api.toyota.com/tmna/prod/Logistics/v/SupplierOrderInformation/skidBAD", jsonRequest);
            //////Console.WriteLine("-----DoSkidBuildTransaction()==========Response: " + Misc.ClassToString(response));
            //////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            //////Console.WriteLine("-----DoSkidBuildTransaction()==========Response (ObjectDumper): " + ObjectDumper.Dump(response));
            //////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            ////HandleAPIResponse(response, newSkidBuildOrder, toyotaOrderShipments, scanManifest.ScannedBy);

            //////Sending to HTTP URL
            ////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            ////Console.WriteLine("");
            ////Console.WriteLine("");
            ////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            ////Console.WriteLine("Press any Key and I will Send to HTTP URL!");
            ////Console.ReadKey(true);
            ////response = tscsWebAPI.SendRequest<APIresponse>("http://api.toyota.com/tmna/prod/Logistics/v/SupplierOrderInformation/skid", jsonRequest);
            //////Console.WriteLine("-----DoSkidBuildTransaction()==========Response: " + Misc.ClassToString(response));
            //////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            //////Console.WriteLine("-----DoSkidBuildTransaction()==========Response (ObjectDumper): " + ObjectDumper.Dump(response));
            //////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            ////HandleAPIResponse(response, newSkidBuildOrder, toyotaOrderShipments, scanManifest.ScannedBy);

            //////Wrong URL...
            ////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            ////Console.WriteLine("");
            ////Console.WriteLine("");
            ////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            ////Console.WriteLine("Press any Key and I will Send the wrong URL... No Method!");
            ////Console.ReadKey(true);
            ////response = tscsWebAPI.SendRequest<APIresponse>("https://api.toyota.com/tmna/prod/Logistics/v/SupplierOrderInformation/", jsonRequest);
            //////Console.WriteLine("-----DoSkidBuildTransaction()==========Response: " + Misc.ClassToString(response));
            //////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            //////Console.WriteLine("-----DoSkidBuildTransaction()==========Response (ObjectDumper): " + ObjectDumper.Dump(response));
            //////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            ////HandleAPIResponse(response, newSkidBuildOrder, toyotaOrderShipments, scanManifest.ScannedBy);

            //////Sending only an Order #
            ////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            ////Console.WriteLine("");
            ////Console.WriteLine("");
            ////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            ////Console.WriteLine("Press any Key and I will Send only an Order Num!");
            ////Console.ReadKey(true);
            ////response = tscsWebAPI.SendRequest<APIresponse>(SkidURL, "[{\"order\":\"2018090501SA\"}]");
            //////Console.WriteLine("-----DoSkidBuildTransaction()==========Response: " + Misc.ClassToString(response));
            //////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            //////Console.WriteLine("-----DoSkidBuildTransaction()==========Response (ObjectDumper): " + ObjectDumper.Dump(response));
            //////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            ////HandleAPIResponse(response, newSkidBuildOrder, toyotaOrderShipments, scanManifest.ScannedBy);

            //////Sending only an Order #, but with multiple APIMessages!!
            ////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            ////Console.WriteLine("");
            ////Console.WriteLine("");
            ////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            ////Console.WriteLine("Press any Key and I will Send only an Order Num, but testing Multi APIResponseMessage SQL!!!");
            ////Console.ReadKey(true);
            ////response = tscsWebAPI.SendRequest<APIresponse>(SkidURL, "[{\"order\":\"2018090501SA\"}]");
            //////Console.WriteLine("-----DoSkidBuildTransaction()==========Response: " + Misc.ClassToString(response));
            //////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            //////Console.WriteLine("-----DoSkidBuildTransaction()==========Response (ObjectDumper): " + ObjectDumper.Dump(response));
            //////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            //////RIGHT HERE, LETS TEST:
            //////NOTE: There can be multiple APIResponseMessages received, and within each of those there can be multiple Messages!
            //////Test multiple APIResponseMessages, some with ONE Message and some with more than one!!
            ////Message tempTesting = new Message();
            ////tempTesting.message = new List<string>();
            ////tempTesting.keyObject = "Extra APIMessage for testing SQL. (One Message.)";
            ////tempTesting.message.Add("This is the only Message in this Test.");
            ////response.messages.Add(tempTesting);
            ////tempTesting = new Message();
            ////tempTesting.message = new List<string>();
            ////tempTesting.keyObject = response.messages[0].keyObject;
            ////tempTesting.message.Add("Extra APIMessage for testing SQL. (First of two Messages.).");
            ////tempTesting.message.Add("Added another Message for Testing, Message 2");
            ////response.messages.Add(tempTesting);
            ////HandleAPIResponse(response, newSkidBuildOrder, toyotaOrderShipments, scanManifest.ScannedBy);
            //////
            //////Simulate more responses (above), just to test Methods and proper SQL creation!
            //////

            #endregion //SimulateMoreTestResponses
        }

        private void SendNotificationEmail_OrderNotComplete(ScanManifest scanManifest, bool CompletedWithDuplicates, string manifestNotFoundMessage)
        {
            String emailSendTo = "";
            using (var ctx = new PickToLightEntities())
            {
                AppSetting email = (from s in ctx.AppSettings
                                    where s.Name == "TSCS_EmailNotification"
                                    select s).SingleOrDefault<AppSetting>();
                if (email != null)
                {
                    emailSendTo = email.Value;
                }
            }
            if (string.IsNullOrEmpty(emailSendTo))
            {
                emailSendTo = "sjudkins@shiroki-na.com";
            }

            _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "INFO", "-----SendNotificationEmail_OrderNotComplete()----- to " + emailSendTo);

            // TODO - FINISH!
            string body = "<br>This Manifest was just pulled, but the system is unable to send it to the \"Toyota SCS\" for Approval.<br>" +
                        "The details of this Order are available on the SNA Toyota Shipping Confirmation System site.<br>" +
                        "Please corect and submit to Toyota for Approval, ASAP!<br>" +
                        "<br>" +
                //"             ID: " + scanManifest.ID.ToString() + "<br>" +
                //"    OrderNumber:" + scanManifest.OrderNumber.ToString() + "<br>" +
                //"  OrderSequence:" + scanManifest.OrderSequence.ToString() + "<br>" +
                //"   SupplierCode:" + scanManifest.SupplierCode.ToString() + "<br>" +
                //"           NAMC: " + scanManifest.NAMC.ToString() + "<br>" +
                //"       DockCode:" + scanManifest.DockCode.ToString() + "<br>" +
                        "<table>" +
                        "<tr><td>ID:</td><td>" + scanManifest.ID.ToString() + "</td></tr>" +
                        "<tr><td>OrderNumber:</td><td>" + scanManifest.OrderNumber.ToString() + "</td></tr>" +
                        "<tr><td>OrderSequence:</td><td>" + scanManifest.OrderSequence.ToString() + "</td></tr>" +
                        "<tr><td>SupplierCode:</td><td>" + scanManifest.SupplierCode.ToString() + "</td></tr>" +
                        "<tr><td>NAMC:</td><td>" + scanManifest.NAMC.ToString() + "</td></tr>" +
                        "<tr><td>DockCode:</td><td>" + scanManifest.DockCode.ToString() + "</td></tr>" +
                        "</table><br>" +
                        "(Provide Link to SHIROKInet for this _Manifest/ToyotaShipment_.)<br>";
            if (CompletedWithDuplicates) //I'm going to eliminate most (or ALL) of these by changing the PickToLightClient software!
            {
                body = body + "<br><span style=\"font-size:120%;font-weight:bold\">(Note: There were \"Duplicate Scans\" (the same OWK Label was scanned multiple times) in the system for this Manifest!!)</span>";
                _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "ERROR", "-----SendNotificationEmail_OrderNotComplete()----- The same Barcode/BoxNumber was scanned Multiple times! scanManifest.ID:" + scanManifest.ID.ToString() + " scanManifest.NAMC:" + scanManifest.NAMC.ToString() + " scanManifest.SupplierCode:" + scanManifest.SupplierCode.ToString() + " scanManifest.DockCode:" + scanManifest.DockCode.ToString() + " scanManifest.OrderNumber:" + scanManifest.OrderNumber.ToString() + " scanManifest.OrderSequence:" + scanManifest.OrderSequence.ToString());
            }
            else
            {
                _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "INFO", "-----SendNotificationEmail_OrderNotComplete()----- scanManifest.ID:" + scanManifest.ID.ToString() + " scanManifest.NAMC:" + scanManifest.NAMC.ToString() + " scanManifest.SupplierCode:" + scanManifest.SupplierCode.ToString() + " scanManifest.DockCode:" + scanManifest.DockCode.ToString() + " scanManifest.OrderNumber:" + scanManifest.OrderNumber.ToString() + " scanManifest.OrderSequence:" + scanManifest.OrderSequence.ToString());
            }
            if (string.IsNullOrEmpty(manifestNotFoundMessage) == false) //Right now, this is used to include the OWKs that couldn't be matched up with a Manifest...
            {
                body = body + "<br><span style=\"font-size:120%;font-weight:bold\">" + manifestNotFoundMessage + "</span>";
                _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "ERROR", "-----SendNotificationEmail_OrderNotComplete()----- Unable to figure out the matching Manifest for some of the OWKs! scanManifest.ID:" + scanManifest.ID.ToString() + " scanManifest.NAMC:" + scanManifest.NAMC.ToString() + " scanManifest.SupplierCode:" + scanManifest.SupplierCode.ToString() + " scanManifest.DockCode:" + scanManifest.DockCode.ToString() + " scanManifest.OrderNumber:" + scanManifest.OrderNumber.ToString() + " scanManifest.OrderSequence:" + scanManifest.OrderSequence.ToString());
                _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "ERROR", "-----SendNotificationEmail_OrderNotComplete()----- manifestNotFoundMessage: " + manifestNotFoundMessage);
            }

            Misc.SendEmail("PickToLightServer@shiroki-na.com", emailSendTo, "Toyota SCS SkidBuild Issue - ATTENTION REQUIRED!", body);
        }

        private static void SendEMailNotificationAndLogException(string exceptionMessage)
        //private void SendEMailNotificationAndLogException(string exceptionMessage)
        {
            _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "EXCEPTION", "-----SendEMailNotificationAndLogException()----- Message:" + exceptionMessage);

            String emailSendTo = "";
            using (var ctx = new PickToLightEntities())
            {
                AppSetting email = (from s in ctx.AppSettings
                                    where s.Name == "TSCS_ApplicationException_EmailNotification"
                                    select s).SingleOrDefault<AppSetting>();
                if (email != null)
                {
                    emailSendTo = email.Value;
                }
            }
            if (string.IsNullOrEmpty(emailSendTo))  // If no Email in AppSettings for "TSCS_ApplicationException_EmailNotification", try "TSCS_EmailNotification" 
            {
                using (var ctx = new PickToLightEntities())
                {
                    AppSetting email = (from s in ctx.AppSettings
                                        where s.Name == "TSCS_EmailNotification"
                                        select s).SingleOrDefault<AppSetting>();
                    if (email != null)
                    {
                        emailSendTo = email.Value;
                    }
                }
            }
            if (string.IsNullOrEmpty(emailSendTo))
            {
                emailSendTo = "sjudkins@shiroki-na.com";
            }

            _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "INFO", "-----SendEMailNotificationAndLogException()----- to " + emailSendTo);

            // TODO - FINISH!
            string body = "<br><span style=\"font-size:120%;font-weight:bold;color:red;\">There is a SERIOUS problem in the PickToLightServer program. Please investigate!!!</span><br>" +
                        "<br> Exception Message: " + exceptionMessage;
            //"<br> This occured after receiving a Pick To Light Command (P2L_COMMAND_ScanManifestEnd) for this Manifest:<br>"
            //"<table>" +
            //"<tr><td>ID:</td><td>" + scanManifest.ID.ToString() + "</td></tr>" +
            //"<tr><td>OrderNumber:</td><td>" + scanManifest.OrderNumber.ToString() + "</td></tr>" +
            //"<tr><td>OrderSequence:</td><td>" + scanManifest.OrderSequence.ToString() + "</td></tr>" +
            //"<tr><td>SupplierCode:</td><td>" + scanManifest.SupplierCode.ToString() + "</td></tr>" +
            //"<tr><td>NAMC:</td><td>" + scanManifest.NAMC.ToString() + "</td></tr>" +
            //"<tr><td>DockCode:</td><td>" + scanManifest.DockCode.ToString() + "</td></tr>" +
            //"</table><br>" +
            //"(Provide Link to SHIROKInet for this _Manifest/ToyotaShipment_.)<br>";

            Misc.SendEmail("PickToLightServer@shiroki-na.com", emailSendTo, "Toyota SCS - Application Exception!!!!", body);
        }

        private static void SendEMailNotificationToFixValidationErrors(SkidBuildOrder skidBuildOrder,string emailMessage)
        //private void SendEMailNotificationToFixValidationErrors(SkidBuildOrder skidBuildOrder, string emailMessage)
        {
            _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "ERROR", "-----SendEMailNotificationToFixValidationErrors()----- Message:" + emailMessage);

            String emailSendTo = "";
            using (var ctx = new PickToLightEntities())
            {
                AppSetting email = (from s in ctx.AppSettings
                                    where s.Name == "TSCS_EmailNotification"
                                    select s).SingleOrDefault<AppSetting>();
                if (email != null)
                {
                    emailSendTo = email.Value;
                }
            }
            if (string.IsNullOrEmpty(emailSendTo))
            {
                emailSendTo = "sjudkins@shiroki-na.com";
            }

            _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "INFO", "-----SendEMailNotificationToFixValidationErrors()----- to " + emailSendTo);

            // TODO - FINISH!
            string body = emailMessage +
            "<br> This occured while processing a \"Pick To Light Command\" (P2L_COMMAND_ScanManifestEnd), for this Manifest:<br>" +
            "<table style=\"margin-left: 10px;\">" +
            "<tr><td>ID:</td><td>" + skidBuildOrder.ID.ToString() + "</td></tr>" +
            "<tr><td>OrderNumber:</td><td>" + skidBuildOrder.OrderNumber.ToString() + "</td></tr>" +
            "<tr><td>SupplierCode:</td><td>" + skidBuildOrder.SupplierCode.ToString() + "</td></tr>" +
            "<tr><td>Plant (NAMC):</td><td>" + skidBuildOrder.Plant.ToString() + "</td></tr>" +
            "<tr><td>DockCode:</td><td>" + skidBuildOrder.DockCode.ToString() + "</td></tr>" +
            "</table><br>" +
            "(Provide Link to SHIROKInet for this SkidBuildOrder.)<br>";

            Misc.SendEmail("PickToLightServer@shiroki-na.com", emailSendTo, "Toyota SCS - Validation Errors!!!!", body);
        }

        private static void SendEMailNotificationToFixValidationErrors(ShipmentLoadTrailer shipmentLoadTrailer, string emailMessage)
        //private void SendEMailNotificationToFixValidationErrors(ShipmentLoadTrailer shipmentLoadTrailer, string emailMessage)
        {
            _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "ERROR", "-----SendEMailNotificationToFixValidationErrors()----- Message:" + emailMessage);

            String emailSendTo = "";
            using (var ctx = new PickToLightEntities())
            {
                AppSetting email = (from s in ctx.AppSettings
                                    where s.Name == "TSCS_ShipmentLoadTrailer_EmailNotification"
                                    select s).SingleOrDefault<AppSetting>();
                if (email != null)
                {
                    emailSendTo = email.Value;
                }
            }
            if (string.IsNullOrEmpty(emailSendTo))
            {
                emailSendTo = "sjudkins@shiroki-na.com";
            }

            _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "INFO", "-----SendEMailNotificationToFixValidationErrors()----- to " + emailSendTo);

            // TODO - FINISH!
            string body = emailMessage +
            "<br> This occured while sending a ShipmentLoadTrailerRequest, for this ShipmentLoadTrailer:<br>" +
            "<table style=\"margin-left: 10px;\">" +
            "<tr><td>ID:</td><td>" + shipmentLoadTrailer.ID.ToString() + "</td></tr>" +
            "<tr><td>SupplierCode:</td><td>" + shipmentLoadTrailer.SupplierCode.ToString() + "</td></tr>" +
            "<tr><td>Route:</td><td>" + shipmentLoadTrailer.Route.ToString() + "</td></tr>" +
            "<tr><td>Run:</td><td>" + shipmentLoadTrailer.Run.ToString() + "</td></tr>" +
            "<tr><td>TrailerNumber:</td><td>" + shipmentLoadTrailer.TrailerNumber.ToString() + "</td></tr>" +
            "</table><br>" +
            "(Provide Link to SHIROKInet for this ShipmentLoadTrailer.)<br>";

            Misc.SendEmail("PickToLightServer@shiroki-na.com", emailSendTo, "Toyota SCS - Validation Errors!!!!", body);
        }

        private static SkidBuildOrder CreateSkidBuildSQLEntry(RequestSkidBuild reqSkidBuild, string pickerName)
        //private SkidBuildOrder CreateSkidBuildSQLEntry(RequestSkidBuild reqSkidBuild, string pickerName)
        {
            SkidBuildOrder newPalletBuildOrder = null; // new SkidBuildOrder();

            //
            //public partial class SkidBuildOrder()
            //{
            //public int ID { get; set; }
            //public string OrderNumber { get; set; }
            //public string SupplierCode { get; set; }
            //public string Plant { get; set; }
            //public string DockCode { get; set; }
            //public string ConfirmationNumber { get; set; }
            //public System.DateTime Created { get; set; }
            //public string CreatedBy { get; set; }
            //public System.DateTime Modified { get; set; }
            //public string ModifiedBy { get; set; }
            //this.SkidBuildOrderExceptions = new HashSet<SkidBuildOrderException>();
            //this.SkidBuildOrderResponses = new HashSet<SkidBuildOrderResponse>();
            //this.SkidBuildSkids = new HashSet<SkidBuildSkid>();
            //}

            var SkidBuildOrder = new SkidBuildOrder();

            SkidBuildOrder.OrderNumber = reqSkidBuild.order;
            SkidBuildOrder.SupplierCode = reqSkidBuild.supplier;
            SkidBuildOrder.Plant = reqSkidBuild.plant;
            SkidBuildOrder.DockCode = reqSkidBuild.dock;
            //SkidBuildOrder.Created = DateTime.Now; SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
            SkidBuildOrder.CreatedBy = pickerName;
            //SkidBuildOrder.Modified = DateTime.Now;  SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
            SkidBuildOrder.ModifiedBy = pickerName; //= ""; //Empty or NULL, until actually Modified?? Or, store the CreatedBy user??

            //
            //Now add the Skids...
            //
            //
            //public partial class SkidBuildSkid
            //{
            //public int ID { get; set; }
            //public int SkidBuildOrderID { get; set; }
            //public string SkidId { get; set; }
            //public string PalletizationCode { get; set; }
            //public string RFId { get; set; }
            //public System.DateTime Created { get; set; }
            //public string CreatedBy { get; set; }
            //public System.DateTime Modified { get; set; }
            //public string ModifiedBy { get; set; }
            //this.SkidBuildKanbans = new HashSet<SkidBuildKanban>();
            //}
            //Use Foreign Key and add the Skids
            if (reqSkidBuild.skids != null)
            {
                if (reqSkidBuild.skids.Count > 0)
                {
                    SkidBuildSkid SkidBuildSkid;
                    foreach (var skid in reqSkidBuild.skids)
                    {
                        SkidBuildSkid = new SkidBuildSkid();
                        //SkidBuildSkid.SkidBuildOrderID = //ID of SkidBuildOrder, but it hasn't been created yet!! May need to change the ordering here...
                        SkidBuildSkid.SkidId = skid.skidId.PadLeft(3, '0');
                        SkidBuildSkid.PalletizationCode = skid.palletization;
                        //SkidBuildSkid.Created = DateTime.Now;  SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
                        SkidBuildSkid.CreatedBy = pickerName;
                        //SkidBuildSkid.Modified = DateTime.Now;  SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
                        SkidBuildSkid.ModifiedBy = pickerName; //= ""; //Empty or NULL, until actually Modified?? Or, store the CreatedBy user??
                        //WAIT, Add this AFTER the kanbans!! -- SkidBuildOrder.SkidBuildSkids.Add(SkidBuildSkid);
                        //
                        //Now add the Kanbans, for this Skid!!
                        //
                        //
                        //public partial class SkidBuildKanban
                        //{
                        //public int ID { get; set; }
                        //public int SkidBuildSkidID { get; set; }
                        //public string PartNumber { get; set; }
                        //public string KanbanNumber { get; set; }
                        //public Nullable<int> QPC { get; set; }
                        //public Nullable<int> BoxNumber { get; set; }
                        //public string LineSideAddress { get; set; }
                        //public string RFId { get; set; }
                        //public string ManifestNumber { get; set; }
                        //public System.DateTime Created { get; set; }
                        //public string CreatedBy { get; set; }
                        //public System.DateTime Modified { get; set; }
                        //public string ModifiedBy { get; set; }
                        //}
                        if (skid.kanbans != null)
                        {
                            if (skid.kanbans.Count > 0)
                            {
                                SkidBuildKanban SkidBuildKanban;
                                foreach (var kanban in skid.kanbans)
                                {
                                    SkidBuildKanban = new SkidBuildKanban();

                                    //SkidBuildSkid.SkidBuildSkidID = //ID of SkidBuildSkid, but it hasn't been created yet!! May need to change the ordering here...
                                    SkidBuildKanban.PartNumber = kanban.partNumber;
                                    SkidBuildKanban.KanbanNumber = kanban.kanban;
                                    SkidBuildKanban.QPC = kanban.qpc;
                                    SkidBuildKanban.BoxNumber = kanban.boxNumber;
                                    SkidBuildKanban.LineSideAddress = kanban.lineSideAddress;
                                    SkidBuildKanban.RFId = kanban.rfId; //Will be Empty or NULL, not doing RFID right now!
                                    SkidBuildKanban.ManifestNumber = null;  //Not doing ManifestNumbers right now...
                                    //SkidBuildKanban.Created = DateTime.Now;  SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
                                    SkidBuildKanban.CreatedBy = pickerName;
                                    //SkidBuildKanban.Modified = DateTime.Now;  SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
                                    SkidBuildKanban.ModifiedBy = pickerName; //= ""; //Empty or NULL, until actually Modified?? Or, store the CreatedBy user??
                                    SkidBuildSkid.SkidBuildKanbans.Add(SkidBuildKanban);
                                }
                            }
                        }
                        SkidBuildOrder.SkidBuildSkids.Add(SkidBuildSkid);
                    }
                }
            }

            //
            //public partial class SkidBuildOrderException
            //{
            //public int ID { get; set; }
            //public int SkidBuildOrderID { get; set; }
            //public string Code { get; set; }
            //public string Comments { get; set; }
            //public System.DateTime Created { get; set; }
            //public string CreatedBy { get; set; }
            //public System.DateTime Modified { get; set; }
            //public string ModifiedBy { get; set; }
            //}
            //
            //Use Foreign Key and add the Exceptions
            if (reqSkidBuild.exceptions != null)
            {
                if (reqSkidBuild.exceptions.Count > 0)
                {
                    SkidBuildOrderException SkidBuildOrderException;
                    foreach (var exception in reqSkidBuild.exceptions)
                    {
                        SkidBuildOrderException = new SkidBuildOrderException();
                        //SkidBuildSkid.SkidBuildOrderID = //ID of SkidBuildOrder, but it hasn't been created yet!! May need to change the ordering here...
                        SkidBuildOrderException.Code = exception.exceptionCode;
                        SkidBuildOrderException.Comments = exception.comments;
                        //SkidBuildOrderException.Created = DateTime.Now;  SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
                        SkidBuildOrderException.CreatedBy = pickerName;
                        //SkidBuildOrderException.Modified = DateTime.Now;  SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
                        SkidBuildOrderException.ModifiedBy = pickerName; //= ""; //Empty or NULL, until actually Modified?? Or, store the CreatedBy user??
                        SkidBuildOrder.SkidBuildOrderExceptions.Add(SkidBuildOrderException);
                    }
                }
            }

            using (PickToLightEntities context = new PickToLightEntities())
            {
                context.SkidBuildOrders.Add(SkidBuildOrder);
                context.SaveChanges();
                //return (SkidBuildOrder.ID); //return the newly created ID!
                //Console.WriteLine("New SkidBuildOrder ID: " + SkidBuildOrder.ID.ToString());
                newPalletBuildOrder = SkidBuildOrder;
            }
            return (newPalletBuildOrder);
        }

        private static APIResponse CreateAPIResponseSQLEntry(int idForPalletBuildOrShipmentLoad, APIresponse response, string pickerName)
        //private APIResponse CreateAPIResponseSQLEntry(int idForPalletBuildOrShipmentLoad, APIresponse response, string pickerName)
        {
            bool DEBUG = false;

            //
            //public partial class APIResponse()
            //{
            //public int ID { get; set; }
            //public string Exception { get; set; }
            //public Nullable<int> Code { get; set; }
            //public string ConfirmationNumber { get; set; }
            //public string ConfirmedOrderNumber { get; set; }
            //public string ConfirmedOrderSupplierCode { get; set; }
            //public string ConfirmedOrderPlant { get; set; }
            //public string ConfirmedOrderDockCode { get; set; }
            //public string ConfirmedTrailerSupplierCode { get; set; }
            //public string ConfirmedTrailerRoute { get; set; }
            //public string ConfirmedTrailerRun { get; set; }
            //public string ConfirmedTrailerNumber { get; set; }
            //public Nullable<System.DateTime> ConfirmedTrailerPickUp { get; set; }
            //public string HTTPCode { get; set; }
            //public string HTTPMessage { get; set; }
            //public string HTTPMoreInformation { get; set; }
            //public System.DateTime Created { get; set; }
            //public string CreatedBy { get; set; }
            //this.APIResponseMessages = new HashSet<APIResponseMessage>();
            //this.SkidBuildOrderResponses = new HashSet<SkidBuildOrderResponse>();
            //}

            APIResponse aPIResponse = new APIResponse();

            //aPIResponse.Exception = "Parse dotNetException Object, HERE OR END OF Method????";
            aPIResponse.Code = response.code;
            aPIResponse.ConfirmationNumber = string.IsNullOrEmpty(response.confirmationNumber) ? "" : response.confirmationNumber;
            if (response.confirmedOrders != null)
            {
                if (response.confirmedOrders.Count > 1) //We don't send "batch orders", only one order at a time!!!
                {
                    //Console.WriteLine("TODO - //Called From - CreateAPIResponseSQLEntry() - SendEMailNotificationAndLogException");
                    //Console.WriteLine("Application ERROR! More than one confirmedOrder received in API Response!!!");
                    SendEMailNotificationAndLogException("Application ERROR! More than one confirmedOrder received in API Response!!!");
                }
                if (response.confirmedOrders.Count > 0)
                {
                    aPIResponse.ConfirmedOrderNumber = string.IsNullOrEmpty(response.confirmedOrders[0].order) ? "" : response.confirmedOrders[0].order; //response.confirmedOrders[0].order;
                    aPIResponse.ConfirmedOrderSupplierCode = string.IsNullOrEmpty(response.confirmedOrders[0].supplier) ? "" : response.confirmedOrders[0].supplier; //response.confirmedOrders[0].supplier;
                    aPIResponse.ConfirmedOrderPlant = string.IsNullOrEmpty(response.confirmedOrders[0].plant) ? "" : response.confirmedOrders[0].plant; //response.confirmedOrders[0].plant;
                    aPIResponse.ConfirmedOrderDockCode = string.IsNullOrEmpty(response.confirmedOrders[0].dock) ? "" : response.confirmedOrders[0].dock; //response.confirmedOrders[0].dock;
                }

                //This is a Many-To-Many Table, or "Mapping" table....we need the ID of one of the ForeignKeys, possibly both....
                //If we are going to do this here, we AT LEAST need the ID of the "SkidBuildOrder" for "SkidBuildOrderID"...
                //Now add SkidBuildOrderResponse.
                //
                //
                //public partial class SkidBuildOrderResponse
                //{
                //    public int ID { get; set; }
                //    public int APIResponseID { get; set; }
                //    public int SkidBuildOrderID { get; set; }
                //    public System.DateTime Created { get; set; }
                //    public string CreatedBy { get; set; }

                //    public virtual APIResponse APIResponse { get; set; }
                //    public virtual SkidBuildOrder SkidBuildOrder { get; set; }
                //}
                if (idForPalletBuildOrShipmentLoad > 0)
                {
                    SkidBuildOrderResponse SkidBuildOrderResponse = new SkidBuildOrderResponse();
                    //SkidBuildOrderResponse.APIResponseID = //ID of APIResponse, but it hasn't been created yet!! May need to change the ordering here...
                    //SkidBuildOrderResponse.SkidBuildOrderID = //ID of SkidBuildOrder, but it hasn't been created yet!! May need to change the ordering here...
                    //SkidBuildOrderResponse.SkidBuildOrderID = 21; //Hard Code the ID for this first Test Run!
                    SkidBuildOrderResponse.SkidBuildOrderID = idForPalletBuildOrShipmentLoad;
                    //SkidBuildOrderResponse.Created = DateTime.Now;  SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
                    SkidBuildOrderResponse.CreatedBy = pickerName;
                    aPIResponse.SkidBuildOrderResponses.Add(SkidBuildOrderResponse);
                }
                else
                {
                    //Console.WriteLine("TODO - //Called From - CreateAPIResponseSQLEntry() - SendEMailNotificationAndLogException (newPalletBuildOrderID <= 0!!!!)");
                    SendEMailNotificationAndLogException("Application ERROR! CreateAPIResponseSQLEntry() was called with idForPalletBuildOrShipmentLoad <= 0!!!!");
                }

            }
            //This isn't called for a ShipLoad, or IS IT????
            if (response.confirmedTrailer != null)
            {
                aPIResponse.ConfirmedTrailerSupplierCode = string.IsNullOrEmpty(response.confirmedTrailer.supplier) ? "" : response.confirmedTrailer.supplier; //response.confirmedTrailer.supplier;
                aPIResponse.ConfirmedTrailerRoute = string.IsNullOrEmpty(response.confirmedTrailer.route) ? "" : response.confirmedTrailer.route; //response.confirmedTrailer.route;
                aPIResponse.ConfirmedTrailerRun = string.IsNullOrEmpty(response.confirmedTrailer.run) ? "" : response.confirmedTrailer.run; //response.confirmedTrailer.run;
                aPIResponse.ConfirmedTrailerNumber = string.IsNullOrEmpty(response.confirmedTrailer.trailerNumber) ? "" : response.confirmedTrailer.trailerNumber; //response.confirmedTrailer.trailerNumber;

                //
                //This date is in the format of: 2018-11-15T13:50 (11/15/2018 13:50) yyyy-MM-ddTHH:mm As defined by datetime - RFC3339
                //To parse it, replace the "T" between the Date and Time with a "space".
                DateTime dateTime;
                //if (DateTime.TryParse(response.confirmedTrailer.pickUp, out dateTime) == false)
                //CultureInfo enUS = new CultureInfo("en-US");
                //if( DateTime.TryParseExact(response.confirmedTrailer.pickUp, "o", CultureInfo.InvariantCulture, DateTimeStyles.None, out dateTime) == false)
                //if (DateTime.TryParse(response.confirmedTrailer.pickUp.Replace('T', ' '), out dateTime) == false)
                if (DateTime.TryParseExact(response.confirmedTrailer.pickUp, "yyyy-MM-ddTHH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out dateTime) == false)
                {
                    aPIResponse.ConfirmedTrailerPickUp = null;
                    //Console.WriteLine("TODO - //Called From - CreateAPIResponseSQLEntry() - SendEMailNotificationAndLogException");
                    //Console.WriteLine("Application ERROR! Unable to parse the confirmed trailer Pickup Date/Time in API Response!!!");
                    SendEMailNotificationAndLogException("Application ERROR! Unable to parse the confirmed trailer Pickup Date/Time in API Response!!!");
                }
                else
                {
                    aPIResponse.ConfirmedTrailerPickUp = dateTime;
                }

                //This is a Many-To-Many Table, or "Mapping" table....we need the ID of one of the ForeignKeys, possibly both....
                //If we are going to do this here, we AT LEAST need the ID of the "ShipmentLoadTrailer" for "ShipmentLoadTrailerID"...
                //Now add ShipmentLoadTrailerResponse.
                //
                //
                //public partial class ShipmentLoadTrailerResponse
                //{
                //    public int ID { get; set; }
                //    public int APIResponseID { get; set; }
                //    public int ShipmentLoadTrailerID { get; set; }
                //    public System.DateTime Created { get; set; }
                //    public string CreatedBy { get; set; }
                //
                //    public virtual APIResponse APIResponse { get; set; }
                //    public virtual ShipmentLoadTrailer ShipmentLoadTrailer { get; set; }
                //}
                if (idForPalletBuildOrShipmentLoad > 0)
                {
_TextBoxOutput.AppendText(Environment.NewLine);
_TextBoxOutput.AppendText("idForPalletBuildOrShipmentLoad = " + idForPalletBuildOrShipmentLoad.ToString());
                    ShipmentLoadTrailerResponse shipmentLoadTrailerResponse = new ShipmentLoadTrailerResponse();
                    //ShipmentLoadTrailerResponse.APIResponseID = //ID of APIResponse, but it hasn't been created yet!! May need to change the ordering here...
                    //ShipmentLoadTrailerResponse.ShipmentLoadTrailerID = //ID of ShipmentLoadTrailer, but it hasn't been created yet!! May need to change the ordering here...
                    //ShipmentLoadTrailerResponse.ShipmentLoadTrailerID = 21; //Hard Code the ID for this first Test Run!
                    shipmentLoadTrailerResponse.ShipmentLoadTrailerID = idForPalletBuildOrShipmentLoad;
                    //ShipmentLoadTrailerResponse.Created = DateTime.Now;  SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
                    shipmentLoadTrailerResponse.CreatedBy = pickerName;
                    aPIResponse.ShipmentLoadTrailerResponses.Add(shipmentLoadTrailerResponse);
_TextBoxOutput.AppendText("pickerName = " + pickerName);
_TextBoxOutput.AppendText(Environment.NewLine);

                }
                else
                {
                    //Console.WriteLine("TODO - //Called From - CreateAPIResponseSQLEntry() - SendEMailNotificationAndLogException (newPalletBuildOrderID <= 0!!!!)");
                    SendEMailNotificationAndLogException("Application ERROR! CreateAPIResponseSQLEntry() was called with newPalletBuildOrderID <= 0!!!!");
                }
            }

            aPIResponse.HTTPCode = string.IsNullOrEmpty(response.httpCode) ? "" : response.httpCode; //response.httpCode;
            aPIResponse.HTTPMessage = string.IsNullOrEmpty(response.httpMessage) ? "" : response.httpMessage; //response.httpMessage;
            aPIResponse.HTTPMoreInformation = string.IsNullOrEmpty(response.moreInformation) ? "" : response.moreInformation; //response.moreInformation;
            //aPIResonse.Created = DateTime.Now;  SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
            aPIResponse.CreatedBy = pickerName;

            //Now add APIResponseMessages
            if (response.messages != null)
            {
                if (response.messages.Count > 0)
                {
_TextBoxOutput.AppendText(Environment.NewLine);
_TextBoxOutput.AppendText("Adding Validation Message!!! = " + pickerName);
_TextBoxOutput.AppendText(Environment.NewLine);

                    //
                    //public partial class APIResponseMessage
                    //{
                    //    public int ID { get; set; }
                    //    public int APIResponseID { get; set; }
                    //    public string KeyObject { get; set; }
                    //    public string Message { get; set; }
                    //    public System.DateTime Created { get; set; }
                    //    public string CreatedBy { get; set; }
                    //
                    //    public virtual APIResponse APIResponse { get; set; }
                    //}
                    //NOTE: There can be multiple APIResponseMessages received, and within each of those there can be multiple Messages!
                    APIResponseMessage aPIResponseMessage;
                    foreach (var message in response.messages)
                    {
                        if (message.message != null)
                        {
                            if (message.message.Count == 1)
                            {
                                aPIResponseMessage = new APIResponseMessage();
                                //aPIResponseMessage.APIResponseID = //ID of APIResponse, but it hasn't been created yet!! May need to change the ordering here...
                                aPIResponseMessage.KeyObject = string.IsNullOrEmpty(message.keyObject) ? "" : message.keyObject; //message.keyObject;
                                aPIResponseMessage.Message = string.IsNullOrEmpty(message.message[0]) ? "" : message.message[0]; //message.message[0];
                                //aPIResponseMessage.Created = DateTime.Now;  SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
                                aPIResponseMessage.CreatedBy = pickerName;
                                aPIResponse.APIResponseMessages.Add(aPIResponseMessage);
                            }
                            else if (message.message.Count > 1) //If more than one message for this "APIResponseMessage", add additional Rows!
                            {
                                //NOTE: This handles multiple "messages" inside an "APIResponseMessage"!
                                foreach (var innerMessage in message.message)
                                {
                                    aPIResponseMessage = new APIResponseMessage();
                                    //aPIResponseMessage.APIResponseID = //ID of APIResponse, but it hasn't been created yet!! May need to change the ordering here...
                                    aPIResponseMessage.KeyObject = string.IsNullOrEmpty(message.keyObject) ? "" : message.keyObject; //message.keyObject;
                                    aPIResponseMessage.Message = string.IsNullOrEmpty(innerMessage) ? "" : innerMessage; //innerMessage; //message.message[0];
                                    //aPIResponseMessage.Created = DateTime.Now;  SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
                                    aPIResponseMessage.CreatedBy = pickerName;
                                    aPIResponse.APIResponseMessages.Add(aPIResponseMessage);
                                }
                            }
                        }
                    }
                }
            }

            aPIResponse.Exception = ""; // "Parse dotNetException Object, HERE OR BEGIN of Method????";

            if (response.dotNetException != null)
            {
_TextBoxOutput.AppendText(Environment.NewLine);
_TextBoxOutput.AppendText("dotNetException!!! = " + pickerName);
_TextBoxOutput.AppendText(Environment.NewLine);

                aPIResponse.Exception = "Exception Type (" + response.dotNetException.GetType().Name + ")  ";
                //All status codes are standard HTTP status codes. The below ones are used in this API.
                //2XX - Success of some kind
                //4XX - Error occurred in client’s part
                //5XX - Error occurred in server’s part
                //--
                //200 OK, Created, Accepted, Validation errors
                //400 Bad request
                //401 Authentication failure
                //403 Forbidden
                //404 Resource not found
                //405 Method Not Allowed
                //409 Conflict
                //412 Precondition Failed
                //413 Request Entity Too Large
                //500 Internal Server Error
                //501 Not Implemented
                //503 Service Unavailable

                //class System.Exception();
                //
                //public Exception(string message);
                //[SecuritySafeCritical]
                //protected Exception(SerializationInfo info, StreamingContext context);
                //public Exception(string message, Exception innerException);

                //public virtual IDictionary Data { get; }
                //public virtual string HelpLink { get; set; }
                //public int HResult { get; protected set; }
                //public Exception InnerException { get; }
                //public virtual string Message { get; }
                //public virtual string Source { get; set; }
                //public virtual string StackTrace { get; }
                //public MethodBase TargetSite { get; }
                //
                //public virtual Exception GetBaseException();

                if (response.dotNetException.GetType().Name.Equals("WebException"))
                {
                    //All status codes are standard HTTP status codes. The below ones are used in this API.
                    //2XX - Success of some kind
                    //4XX - Error occurred in client’s part
                    //5XX - Error occurred in server’s part

                    //public int ID { get; set; }
                    //public string Exception { get; set; }
                    //public Nullable<int> Code { get; set; }
                    //
                    //public string HTTPCode { get; set; }
                    //public string HTTPMessage { get; set; }
                    //public string HTTPMoreInformation { get; set; }

                    //Console.WriteLine("A WebException has been caught.");
                    System.Net.WebException webException = (System.Net.WebException)response.dotNetException;
                    //
                    //public class WebException : InvalidOperationException, ISerializable
                    //
                    //public WebException();
                    //public WebException(string message);
                    //protected WebException(SerializationInfo serializationInfo, StreamingContext streamingContext);
                    //public WebException(string message, Exception innerException);
                    //public WebException(string message, WebExceptionStatus status);
                    //public WebException(string message, Exception innerException, WebExceptionStatus status, WebResponse response);
                    //
                    //public WebResponse Response { get; }
                    //public WebExceptionStatus Status { get; }
                    //

                    //WebResponse webResponse;
                    //WebExceptionStatus webExceptionStatus;

                    if (webException.Response != null)
                    {
                        HttpWebResponse httpResponse = (HttpWebResponse)webException.Response;
                        aPIResponse.Exception = aPIResponse.Exception + "Response Status Code (" + httpResponse.StatusCode.ToString() + ")  ";
                        if (string.IsNullOrEmpty(aPIResponse.HTTPCode))
                        {
                            //Console.WriteLine((int)httpResponse.StatusCode + " - " + httpResponse.StatusCode);
                            //aPIResponse.HTTPCode = httpResponse.StatusCode.ToString(); //NO! This can be longer than three???
                            aPIResponse.HTTPCode = ((int)httpResponse.StatusCode).ToString(); //Use the int value!
                        }
                    }

                    // Write out the WebException message.  
                    //Console.WriteLine(webException.ToString());
                    aPIResponse.Exception = aPIResponse.Exception + webException.ToString();
                    // Get the WebException status code.  
                    WebExceptionStatus status = webException.Status;
                    //Console.WriteLine(status.ToString());
                    aPIResponse.Exception = aPIResponse.Exception + "WebException Status Code (" + status.ToString() + ")  ";
                    if (string.IsNullOrEmpty(aPIResponse.HTTPCode))
                    {
                        //Console.WriteLine((int)httpResponse.StatusCode + " - " + httpResponse.StatusCode);
                        //aPIResponse.HTTPCode = status.ToString(); //NO! This can be longer than three???
                        aPIResponse.HTTPCode = ((int)status).ToString(); //Use the int value!
                    }
                    //// If status is WebExceptionStatus.ProtocolError,   
                    ////   there has been a protocol error and a WebResponse   
                    ////   should exist. Display the protocol error.  
                    //if (status == WebExceptionStatus.ProtocolError)
                    //{
                    //    Console.WriteLine("The server returned protocol error ");
                    //    //// Get HttpWebResponse so that you can check the HTTP status code.  
                    //    //HttpWebResponse httpResponse = (HttpWebResponse)webException.Response;
                    //    //Console.WriteLine((int)httpResponse.StatusCode + " - " + httpResponse.StatusCode);
                    //}  
                }
                else  //An exception that isn't a WebException!
                {
                    //Console.WriteLine("A WebException has been caught.");

                    //aPIResponse.Exception = "Exception Type (" + response.dotNetException.GetType().Name + ")";

                    //genericClass.GetType().GetProperty("webException").SetValue(genericClass, ex);
                    //genericClass.GetType().GetProperty("dotNetException").SetValue(genericClass, ex);

                    aPIResponse.Exception = aPIResponse.Exception + "Message (" + response.dotNetException.Message + ")  ";

                    if (response.dotNetException.InnerException != null && response.dotNetException.InnerException.Message.Length > 0)
                    {
                        aPIResponse.Exception = aPIResponse.Exception + "Inner (" + response.dotNetException.InnerException.Message + ")  ";
                    }
                }
            }

            if (aPIResponse.Exception.Length > 4000)
            {
                string trimmedIndicator = " *TRIMMED*";
                aPIResponse.Exception = aPIResponse.Exception.Substring(0, 4000 - trimmedIndicator.Length) + trimmedIndicator;
            }

            using (PickToLightEntities context = new PickToLightEntities())
            {
_TextBoxOutput.AppendText(Environment.NewLine);
_TextBoxOutput.AppendText("Adding APIResponse!!!");
                context.APIResponses.Add(aPIResponse);
                try
                {
_TextBoxOutput.AppendText("Saving...");

                    context.SaveChanges();

_TextBoxOutput.AppendText("Saved!!!");
_TextBoxOutput.AppendText(Environment.NewLine);
                }
                catch (Exception ex)
                {
                    //Console.WriteLine("Exception Saving API Response: " + ex.Message);
                    //foreach(var err in context.GetValidationErrors())
                    //{
                    //    Console.WriteLine(  "Validation Error -- Valid? " + (err.IsValid ? "YES" : "NO"));
                    //        //" Entity: " + err.Entry.Entity.ToString() + " CurrentValues: " + err.Entry.CurrentValues.ToString() + " State: " + err.Entry.State.ToString());
                    //    foreach (var valErr in err.ValidationErrors)
                    //    {
                    //        Console.WriteLine("    ValidationErrors - PropertyName: " + valErr.PropertyName + " ErrorMessage: " + valErr.ErrorMessage);
                    //    }
                    //}
                    StringBuilder exceptionMessage = new StringBuilder();
                    exceptionMessage.Append("Application Exception in CreateAPIResponseSQLEntry(), saving API Response: " + ex.Message);
                    if (ex.InnerException != null && ex.InnerException.Message.Length > 0)
                    {
                        exceptionMessage.Append(" Inner (" + ex.InnerException.Message + ")  ");
                    }
                    foreach (var err in context.GetValidationErrors())
                    {
                        exceptionMessage.Append("<br>Validation Error -- Valid? " + (err.IsValid ? "YES" : "NO"));
                        foreach (var valErr in err.ValidationErrors)
                        {
                            exceptionMessage.Append("  PropertyName: " + valErr.PropertyName + " ErrorMessage: " + valErr.ErrorMessage);
                        }
                    }
                    SendEMailNotificationAndLogException(exceptionMessage.ToString());
                }
                //return (aPIResponse.ID); //return the newly created ID!
                //Console.WriteLine("New APIResponse ID: " + aPIResponse.ID.ToString());
            }
            return (aPIResponse);
        }

        private static void HandleAPIResponse(APIresponse response, SkidBuildOrder newPalletBuildOrder, List<ToyotaShipment> toyotaOrderShipments, string pickerName)
        //private void HandleAPIResponse(APIresponse response, SkidBuildOrder newPalletBuildOrder, List<ToyotaShipment> toyotaOrderShipments, string pickerName)
        {
            APIResponse aPIResponse = CreateAPIResponseSQLEntry(newPalletBuildOrder.ID, response, pickerName);

            //**************************************************************************************************
            //****NEW!!!! We need to be updating the Completed and Confirmation Number even if this FAILS!
            //**** ConfirmationNumber should be "cleared" when it fails and Completed set to FALSE!!!
            //**************************************************************************************************
            PickToLightData.SkidBuildOrder.UpdateConfirmationNumber(newPalletBuildOrder.ID, aPIResponse.ConfirmationNumber);
            PickToLightData.ToyotaShipment.UpdateToyotaShipmentsCompleted(toyotaOrderShipments, aPIResponse.ConfirmationNumber);

            //if (string.IsNullOrEmpty(aPIResponse.Exception) == false || response.dotNetException != null)
            if (string.IsNullOrEmpty(aPIResponse.Exception) == false)
            {
                //Console.WriteLine("TODO - In HandleAPIResponse() - There was an Exception when sending the SkidBuild! Exception was (" + aPIResponse.Exception + ")");
                SendEMailNotificationAndLogException("In HandleAPIResponse() - There was an Exception when sending the SkidBuild! Exception was (" + aPIResponse.Exception + ")");
            }
            else if (response.code.ToString().StartsWith("2"))
            {
                //Store the ConfirmationNumber in the SkidBuildOrder table for this Order!
                //Mark SkidBuildOrder "Success"...
                //Indicate the ToyotaShipments used for the Order are "Shipped", done, completed, etc.
                //**************************************************************************************************
                //****NEW!!!! We need to be updating the Completed and Confirmation Number even if this FAILS!
                //**** ConfirmationNumber should be "cleared" when it fails and Completed set to FALSE!!!
                //**************************************************************************************************
                //if (aPIResponse.ConfirmationNumber != null && aPIResponse.ConfirmationNumber.Length > 0)
                //{
                //    //Console.WriteLine("+++++++++++++++++++Order was Successfully sent and Approved!!!, The Confirmation Number was " + aPIResponse.ConfirmationNumber + "+++++++++++++++++++");
                //    //Console.WriteLine("");
                //    //Console.WriteLine("//In HandleAPIResponse() - Updating ConfirmationNumber in SkidBuildOrderID:" + newPalletBuildOrder.ID.ToString());
                //    PickToLightData.SkidBuildOrder.UpdateSkidBuildOrderConfirmationNumber(newPalletBuildOrder.ID, aPIResponse.ConfirmationNumber);

                //    //Console.WriteLine("TODO - //In HandleAPIResponse() - Mark ToyotaShipments used for the Order as \"Completed\"...");
                //    PickToLightData.ToyotaShipment.UpdateToyotaShipmentsCompleted(toyotaOrderShipments, aPIResponse.ConfirmationNumber);
                //}
                //else
                if ( string.IsNullOrEmpty(aPIResponse.ConfirmationNumber))
                {
                    //Console.WriteLine("+++++++++++++++++++Order was Successfully sent, but not Approved, due to one or more Validation Errors:");
                    StringBuilder emailMessage = new StringBuilder();
                    emailMessage.Append("<br><span style=\"font-size:120%;font-weight:bold\">Skid Build Order was <u><span style=\"color:red;\">NOT APPROVED</span></u>, due to one or more Validation Errors:</span>");
                    foreach (var message in aPIResponse.APIResponseMessages)
                    {
                        //Console.WriteLine("                   KeyObject: " + message.KeyObject);
                        //Console.WriteLine("                   Message: " + message.Message);
                        //emailMessage.Append("<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;KeyObject: " + message.KeyObject);
                        //emailMessage.Append("<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Message: " + message.Message);
                        emailMessage.Append("<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Message: " + message.Message + "  (KeyObject: " + message.KeyObject + ")");
                        emailMessage.Append("<br>");
                    }
                    //EMAIL the above information to the "Managers"...
                    SendEMailNotificationToFixValidationErrors(newPalletBuildOrder, emailMessage.ToString());
                }
            }
            else
            {
//TODO!   Right here, don't I need to REMOVE any Confirmation Numbers from previous successes????
//NO! I am doing it at beginning of method now!!
                //Console.WriteLine("In HandleAPIResponse() - There wasn't an Exception, but the transaction failed, because the response code was " + response.code.ToString());
                SendEMailNotificationAndLogException("In HandleAPIResponse() - There wasn't an Exception, but the transaction failed, because the response code was " + response.code.ToString());
            }
        }

        private static void HandleAPIResponse(APIresponse response, ShipmentLoadTrailer newShipmentLoadTrailer, string userName)
        //private void HandleAPIResponse(APIresponse response, ShipmentLoadTrailer newShipmentLoadTrailer, string userName)
        {
            APIResponse aPIResponse = CreateAPIResponseSQLEntry(newShipmentLoadTrailer.ID, response, userName);

            //**************************************************************************************************
            //****NEW!!!! We need to be updating the Completed and Confirmation Number even if this FAILS!
            //**** ConfirmationNumber should be "cleared" when it fails and Completed set to FALSE!!!
            //**************************************************************************************************
            //PickToLightData.SkidBuildOrder.UpdateConfirmationNumber(newPalletBuildOrder.ID, aPIResponse.ConfirmationNumber);
            PickToLightData.ShipmentLoadTrailer.UpdateConfirmationNumber(newShipmentLoadTrailer.ID, aPIResponse.ConfirmationNumber);
            //Only for SkidBuildOrder, in the "other" HandleAPIResponse method...
            //PickToLightData.ToyotaShipment.UpdateToyotaShipmentsCompleted(toyotaOrderShipments, aPIResponse.ConfirmationNumber);

            //if (string.IsNullOrEmpty(aPIResponse.Exception) == false || response.dotNetException != null)
            if (string.IsNullOrEmpty(aPIResponse.Exception) == false)
            {
                //Console.WriteLine("TODO - In HandleAPIResponse() - There was an Exception when sending the ShipmentLoad! Exception was (" + aPIResponse.Exception + ")");
                SendEMailNotificationAndLogException("In HandleAPIResponse() - There was an Exception when sending the ShipmentLoad! Exception was (" + aPIResponse.Exception + ")");
            }
            else if (response.code.ToString().StartsWith("2"))
            {
                if (string.IsNullOrEmpty(aPIResponse.ConfirmationNumber))
                {
                    //Console.WriteLine("+++++++++++++++++++Order was Successfully sent, but not Approved, due to one or more Validation Errors:");
                    StringBuilder emailMessage = new StringBuilder();
                    emailMessage.Append("<br><span style=\"font-size:120%;font-weight:bold\">Skid Build Order was <u><span style=\"color:red;\">NOT APPROVED</span></u>, due to one or more Validation Errors:</span>");
                    foreach (var message in aPIResponse.APIResponseMessages)
                    {
                        //Console.WriteLine("                   KeyObject: " + message.KeyObject);
                        //Console.WriteLine("                   Message: " + message.Message);
                        //emailMessage.Append("<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;KeyObject: " + message.KeyObject);
                        //emailMessage.Append("<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Message: " + message.Message);
                        emailMessage.Append("<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Message: " + message.Message + "  (KeyObject: " + message.KeyObject + ")");
                        emailMessage.Append("<br>");
                    }
                    //EMAIL the above information to the "Managers"...
                    SendEMailNotificationToFixValidationErrors(newShipmentLoadTrailer, emailMessage.ToString());
                }
            }
            else
            {
                //TODO!   Right here, don't I need to REMOVE any Confirmation Numbers from previous successes????
                //NO! I am doing it at beginning of method now!!
                //Console.WriteLine("In HandleAPIResponse() - There wasn't an Exception, but the transaction failed, because the response code was " + response.code.ToString());
                SendEMailNotificationAndLogException("In HandleAPIResponse() - There wasn't an Exception, but the transaction failed, because the response code was " + response.code.ToString());
            }
        }

        private void ButtonProcessSkidBuildOrderID_Click(object sender, EventArgs e)
        {
            bool DEBUG = true;

            fileNameScenarioPrefix = "D:\\TSCS_API_CERTIFICATION\\" + ComboBoxScenarioPrefix.Text + numericUpDownTwoDigits1.Text + ComboBoxScenarioSuffix.Text;
            //TextBoxOutput.AppendText(fileNameScenarioPrefix);
            //TextBoxOutput.AppendText(Environment.NewLine);

            //TextBoxOutput.AppendText(Environment.NewLine);
            //TextBoxOutput.AppendText("NOT IMPLEMENTED YET!!!");
            //TextBoxOutput.AppendText(Environment.NewLine);

            SkidBuildOrder skidBuildOrder = PickToLightData.SkidBuildOrder.GetSkidBuildOrder(Int32.Parse(TextBoxSkidBuildOrderID.Text));
            if (skidBuildOrder == null) //Make sure we can read the row for the ID
            {
                TextBoxOutput.AppendText(Environment.NewLine);
                TextBoxOutput.AppendText("Can't find row for SkidBuildOrder ID: " + TextBoxSkidBuildOrderID.Text);
                TextBoxOutput.AppendText(Environment.NewLine);
                return;
            }

            //Copied from DoSkidBuildTransaction()!!!
            //Copied from DoSkidBuildTransaction()!!!
            //Copied from DoSkidBuildTransaction()!!!
            //Copied from DoSkidBuildTransaction()!!!
            //Copied from DoSkidBuildTransaction()!!!

            RequestSkidBuild reqSkidBuild = new RequestSkidBuild();

            ////////////////////////////////////////Build the RequestSkidBuild!!!!!////////////////////////////////////////

            ///I could do all this in a constructor for "RequestSkidBuild" and pass scanManifest and kanbans...

            reqSkidBuild.order = skidBuildOrder.OrderNumber;
            reqSkidBuild.supplier = skidBuildOrder.SupplierCode;
            reqSkidBuild.plant = skidBuildOrder.Plant;
            reqSkidBuild.dock = skidBuildOrder.DockCode;

            reqSkidBuild.exceptions = null;
            if (skidBuildOrder.SkidBuildOrderExceptions != null)
            {
                if (skidBuildOrder.SkidBuildOrderExceptions.Count > 0)
                {
                    reqSkidBuild.exceptions = new List<APIexception>();
                    foreach (var exception in skidBuildOrder.SkidBuildOrderExceptions)
                    {
                        APIexception exceptionItem = new APIexception();
                        exceptionItem.exceptionCode = exception.Code;
                        exceptionItem.comments = exception.Comments;
                        reqSkidBuild.exceptions.Add(exceptionItem);
                    }
                }
            }


            reqSkidBuild.skids = null;
            if (skidBuildOrder.SkidBuildSkids != null)
            {
                if (skidBuildOrder.SkidBuildSkids.Count > 0)
                {
                    reqSkidBuild.skids = new List<Skid>();
                    foreach (var skid in skidBuildOrder.SkidBuildSkids)
                    {
                        Skid skidItem = new Skid();
                        skidItem.skidId = skid.SkidId;
                        skidItem.palletization = skid.PalletizationCode;
                        skidItem.kanbans = new List<Kanban>();
                        foreach (var kanban in skid.SkidBuildKanbans)
                        {
                            Kanban kanbanItem = new Kanban();
                            kanbanItem.lineSideAddress = kanban.LineSideAddress;
                            kanbanItem.partNumber = kanban.PartNumber;
                            kanbanItem.kanban = kanban.KanbanNumber;
                            kanbanItem.qpc = kanban.QPC.Value;
                            kanbanItem.boxNumber = kanban.BoxNumber.Value;
                            kanbanItem.manifestNumber = kanban.ManifestNumber; //null; //manifestNumber = "";
                            kanbanItem.rfId = kanban.RFId; //null; //rfId = "";
                            skidItem.kanbans.Add(kanbanItem);
                        }
                        //
                        //Not implemented yet, since it may change, just comment out for now!!
                        //
                        ////It appears we don't have to add the rfidDetails!!!
                        ////BUT.... the method that builds the JSON adds a "null" rfidDetails... so lets add an empty one for now so the Request format is correct!)
                        //skidItem.rfidDetails = new List<RfidDetail>();
                        //skidItem.rfidDetails = null;
                        //
                        //RfidDetail rfidItem = new RfidDetail();
                        //rfidItem.rfId = null; //rfId = "";
                        //rfidItem.type = "";
                        //skidItem.rfidDetails.Add(rfidItem);
                        ////RfidDetail rfidItem2 = new RfidDetail();
                        ////rfidItem2.rfId = null; //rfId = "";
                        ////rfidItem2.type = "";
                        ////skidItem.rfidDetails.Add(rfidItem2);

                        reqSkidBuild.skids.Add(skidItem);
                    }
                }
            }


            //
            //Shouldn't be necessary, but lets go ahead and SORT..
            //
            //Lets order the Skids by SkidId (001,002,Etc) and the Kanbans by Part#, then Box#.
            //It makes the Request String/Json/SQL all easier to evaluate/debug/look at!
            reqSkidBuild.skids.Sort((a, b) => a.skidId.CompareTo(b.skidId));
            foreach (var skid in reqSkidBuild.skids)
            {
                //skid.kanbans.Sort((a, b) => a.partNumber.CompareTo(b.partNumber));
                skid.kanbans = skid.kanbans.OrderBy(o => o.partNumber).ThenBy(o => o.boxNumber).ToList();
            }

            //SkidBuildOrder newSkidBuildOrder = CreateSkidBuildSQLEntry(reqSkidBuild, scanManifest.ScannedBy);
            //if (newSkidBuildOrder == null)
            //{
            //    _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "EXCEPTION", "-----DoSkidBuildTransaction()==== Problem creating SkidBuild SQL Rows for scanManifest.ID: " + scanManifest.ID + ", scanManifest.NAMC:" + scanManifest.NAMC.ToString() + ", scanManifest.SupplierCode:" + scanManifest.SupplierCode.ToString() + " scanManifest.DockCode:" + scanManifest.DockCode);
            //}

            ////////////////////////////////////////Build the RequestSkidBuild!!!!!////////////////////////////////////////

            String Username = "24d058ee-4775-4426-9ae0-6d3e612b5e10";  //AppID
            String Password = "W8aD2pM3qO7fS8xC3wE7bD1kX1nN8fG3gS8iN1kE8gH2iF3aX0";  //AppSecret

            String SkidURL = "https://api.toyota.com/tmna/prod/Logistics/v/SupplierOrderInformation/skid";
            String TrailerURL = "https://api.toyota.com/tmna/prod/Logistics/v/SupplierOrderInformation/trailer";

            //if (DEBUG) _logger.Log("-----DoSkidBuildTransaction()-----++++++++++New Skid Build Request++++++++++");
            //if (DEBUG) _logger.Log("-----DoSkidBuildTransaction()SkidURL: " + SkidURL);
            //if (DEBUG) _logger.Log("-----DoSkidBuildTransaction()Request (ObjectDumper): " + ObjectDumper.Dump(reqSkidBuild));
            //if (DEBUG) _logger.Log("-----DoSkidBuildTransaction()Request (JSON): " + JsonConvert.SerializeObject(reqSkidBuild));

            ToyotaSCSWebAPI tscsWebAPI = new ToyotaSCSWebAPI(Username, Password, SkidURL, TrailerURL);

            APIresponse response = null;

            //Testing API Communication!
            //response = tscsWebAPI.SendRequest<APIresponse>(SkidURL, "[{\"order\":\"2018090501SA\"}]");
            //if (DEBUG) _logger.Log("-----DoSkidBuildTransaction()==========(Only Sending Order, for test...) Response: " + Misc.ClassToString(response));

            List<RequestSkidBuild> orders = new List<RequestSkidBuild>();
            orders.Add(reqSkidBuild);
            string jsonRequest = JsonConvert.SerializeObject(orders);
            if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()=======Request (JSON): " + jsonRequest);
            File.WriteAllText(fileNameScenarioPrefix + "_Request.txt", jsonRequest);
            if (CheckBoxSEND.Checked)
            {
                string stringResponse;
                response = tscsWebAPI.SendRequest<APIresponse>(SkidURL, jsonRequest, out stringResponse);
                //Console.WriteLine("-----DoSkidBuildTransaction()==========Response: " + Misc.ClassToString(response));
                //Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                //Console.WriteLine("-----DoSkidBuildTransaction()==========Response (ObjectDumper): " + ObjectDumper.Dump(response));
                //Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                //if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()==========Response: " + Misc.ClassToString(response));
                if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()==========Response (ObjectDumper): " + ObjectDumper.Dump(response));

                File.WriteAllText(fileNameScenarioPrefix + "_Response.txt", stringResponse);

                //
                //HandleAPIResponse() creates the SQL Rows for APIResponse, APIResonseMessage and SkidBuildOrderResponse (Maybe ShipmentLoadTrailerResponse in future???)
                //      It also "parses" the response and determines what to do? Like update ToyotaShipments or SkidBuildOrder Tables, or send an EMAIL Notification to "Managers" or "Developers"????
                //      RIGHT??? Make sure it does do all that!
                //
                //HandleAPIResponse(response, newSkidBuildOrder, toyotaOrderShipments, scanManifest.ScannedBy);
                List<ToyotaShipment> toyotaOrderShipments = new List<ToyotaShipment>();
                using (var ctx = new PickToLightEntities())
                {
                    //  Use the NAMC (NAMCDestination) and SupplierCode from the Manifest to get the TRPT that corresponds to the NAMC in ToyotaShipments
                    NAMC_TRPT_CrossRef namcTRPTcrossRef;
                    namcTRPTcrossRef = (from n in ctx.NAMC_TRPT_CrossRef
                                        where skidBuildOrder.Plant == n.NAMCDestination && skidBuildOrder.SupplierCode == n.SupplierCode
                                        select n).SingleOrDefault<NAMC_TRPT_CrossRef>();
                    //  Using OrderNumber, NAMC, Supplier Code and Dock Code, get Rows from ToyotaShipments where COMPLETED = FALSE (0)!!!
                    //  (The NAMC in ToyotaShipments is a combination of the NAMC and Supplier Code!)
                    toyotaOrderShipments = (from s in ctx.ToyotaShipments
                                            where namcTRPTcrossRef.TRPT == s.NAMC
                                            && skidBuildOrder.OrderNumber == s.ORDERNUM
                                            && skidBuildOrder.DockCode == s.DOCKCODE
                                            //We want them, even if they are "Completed", because we are Updating the Confirmation Number!!!
                                            //                                      && s.Completed == false
                                            select s).ToList(); //Do a "ToList()" here??
                    //RIGHT HERE, IF THERE AREN'T ANY SHIPMENTS (not Completed), WE NEED TO STOP AND SEND A MESSAGE!!! Normally, this shouldn't happen!!!!)
                    if (toyotaOrderShipments.Count() == 0)
                    {
                        TextBoxOutput.AppendText(" ERROR!!! Couldn't find ToyotaShipments to update!!!  skidBuildOrder.OrderNumber = " + skidBuildOrder.OrderNumber + " AND scanManifest.DockCode = " + skidBuildOrder.DockCode + " AND NAMC_TRPT_CrossRef.TRPT = " + namcTRPTcrossRef.TRPT + "  (where skidBuildOrder.Plant (" + skidBuildOrder.Plant + ") == n.NAMCDestination && skidBuildOrder.SupplierCode (" + skidBuildOrder.SupplierCode + ") == n.SupplierCode)");
                        return;
                    }
                }
                MainForm._TextBoxOutput.AppendText(Environment.NewLine);
                MainForm._TextBoxOutput.AppendText("Need to update ToyotaOrderShipments Confirmation #, no matter what... Fix this, when used in PRODUCTION (on the website/dashboard)!!!!");
                MainForm._TextBoxOutput.AppendText(Environment.NewLine);
                HandleAPIResponse(response, skidBuildOrder, toyotaOrderShipments, skidBuildOrder.CreatedBy);
            }
            else
            {
                MainForm._TextBoxOutput.AppendText(Environment.NewLine);
                MainForm._TextBoxOutput.AppendText("The SkidBuild Request was NOT sent (\"SEND IT!\" was NOT checked), but the Request file was created for SkidBuildOrderID: " + skidBuildOrder.ID.ToString());
                MainForm._TextBoxOutput.AppendText(Environment.NewLine);
            }

            CheckBoxSEND.Checked = false;
        }

        private void ButtonProcessShipmentLoadTrailerID_Click(object sender, EventArgs e)
        {
            bool DEBUG = true;

            fileNameScenarioPrefix = "D:\\TSCS_API_CERTIFICATION\\" + ComboBoxScenarioPrefix.Text + numericUpDownTwoDigits1.Text + ComboBoxScenarioSuffix.Text;
            //TextBoxOutput.AppendText(fileNameScenarioPrefix);
            //TextBoxOutput.AppendText(Environment.NewLine);

            ShipmentLoadTrailer shipmentLoadTrailer = PickToLightData.ShipmentLoadTrailer.GetShipmentLoadTrailer(Int32.Parse(TextBoxShipmentLoadTrailerID.Text));
            if (shipmentLoadTrailer == null) //Make sure we can read the row for the ID
            {
                TextBoxOutput.AppendText(Environment.NewLine);
                TextBoxOutput.AppendText("Can't find row for ShipmentLoadTrailer ID: " + TextBoxShipmentLoadTrailerID.Text);
                TextBoxOutput.AppendText(Environment.NewLine);
                return;
            }

            //Need to create DoShipmentLoadTransaction()!!!
            //Need to create DoShipmentLoadTransaction()!!!
            //Need to create DoShipmentLoadTransaction()!!!

            RequestShipmentLoad reqShipmentLoad = new RequestShipmentLoad();

            ////////////////////////////////////////Build the RequestShipmentLoad!!!!!////////////////////////////////////////

            ///I could do all this in a constructor for "RequestShipmentLoad" and pass all the properties...

            //public class RequestShipmentLoad
            //{
            //    public string supplier { get; set; }
            //    public string route { get; set; }
            //    public string run { get; set; }
            //    public string trailerNumber { get; set; }
            //    public bool dropHook { get; set; }
            //    public string sealNumber { get; set; }
            //    public string supplierTeamFirstName { get; set; }
            //    public string supplierTeamLastName { get; set; }
            //    public string lpCode { get; set; }
            //    public string driverTeamFirstName { get; set; }
            //    public string driverTeamLastName { get; set; }
            //    public List<APIexception> exceptions { get; set; }
            //    public List<Order> orders { get; set; }
            //}

            //ShipmentLoadTrailer
            //this.ShipmentLoadTrailerExceptions
            //this.ShipmentLoadOrders
            //this.ShipmentLoadOrders.ShipmentLoadOrderExceptions // TODO... I think this can be removed. Ask Garry!!!
            //this.ShipmentLoadOrders.ShipmentLoadSkids 
            //this.ShipmentLoadOrders.ShipmentLoadSkids.ShipmentLoadSkidExceptions
            //this.ShipmentLoadTrailerResponses
            //this.ShipmentLoadTrailerResponses.APIResponse
            //this.ShipmentLoadTrailerResponses.APIResponse.APIResponseMessages

            reqShipmentLoad.supplier = shipmentLoadTrailer.SupplierCode;
            reqShipmentLoad.route = shipmentLoadTrailer.Route;
            reqShipmentLoad.run = shipmentLoadTrailer.Run;
            reqShipmentLoad.trailerNumber = shipmentLoadTrailer.TrailerNumber;
            reqShipmentLoad.dropHook = shipmentLoadTrailer.DropHook.Value;
            reqShipmentLoad.sealNumber = shipmentLoadTrailer.SealNumber;
            reqShipmentLoad.supplierTeamFirstName = shipmentLoadTrailer.SupplierTeamFirstName;
            reqShipmentLoad.supplierTeamLastName = shipmentLoadTrailer.SupplierTeamLastName;
            reqShipmentLoad.lpCode = shipmentLoadTrailer.LPCode;
            reqShipmentLoad.driverTeamFirstName = shipmentLoadTrailer.DriverTeamFirstName;
            reqShipmentLoad.driverTeamLastName = shipmentLoadTrailer.DriverTeamLastName;
            
            //    public List<APIexception> exceptions { get; set; }
            //this.ShipmentLoadTrailerExceptions

            //public class APIexception //If rename this to "scsException" or something else, will "Newtonsoft.Json" still work?? 
            //{
            //    public string exceptionCode { get; set; }
            //    public string comments { get; set; }
            //}

            reqShipmentLoad.exceptions = null;
            if (shipmentLoadTrailer.ShipmentLoadTrailerExceptions != null)
            {
                if (shipmentLoadTrailer.ShipmentLoadTrailerExceptions.Count > 0)
                {
                    reqShipmentLoad.exceptions = new List<APIexception>();
                    foreach (var exception in shipmentLoadTrailer.ShipmentLoadTrailerExceptions)
                    {
                        APIexception exceptionItem = new APIexception();
                        exceptionItem.exceptionCode = exception.Code;
                        exceptionItem.comments = exception.Comments;
                        reqShipmentLoad.exceptions.Add(exceptionItem);
                    }
                }
            }

            //    public List<Order> orders { get; set; }
            //public class Order
            //{
            //    public string order { get; set; }
            //    public string supplier { get; set; }
            //    public string plant { get; set; }
            //    public string dock { get; set; }
            //    public string pickUp { get; set; }
            //    public List<ShipmentSkid> skids { get; set; }
            //}

            //public class ShipmentSkid
            //{
            //    public string palletization { get; set; }
            //    public string skidId { get; set; }
            //    [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
            //    public List<APIexception> exceptions { get; set; }
            //}

            //this.ShipmentLoadOrders
            //this.ShipmentLoadOrders.ShipmentLoadOrderExceptions  // TODO... I think this can be removed. Ask Garry!!!
            //this.ShipmentLoadOrders.ShipmentLoadSkids 
            //this.ShipmentLoadOrders.ShipmentLoadSkids.ShipmentLoadSkidExceptions

            reqShipmentLoad.orders = null;
            if (shipmentLoadTrailer.ShipmentLoadOrders != null)
            {
                if (shipmentLoadTrailer.ShipmentLoadOrders.Count > 0)
                {
                    reqShipmentLoad.orders = new List<Order>();
                    foreach (var order in shipmentLoadTrailer.ShipmentLoadOrders)
                    {

                        //public class Order
                        //{
                        //    public string order { get; set; }
                        //    public string supplier { get; set; }
                        //    public string plant { get; set; }
                        //    public string dock { get; set; }
                        //    public string pickUp { get; set; }
                        //    public List<ShipmentSkid> skids { get; set; }
                        //}

                        Order orderItem = new Order();
                        orderItem.order = order.OrderNumber;
                        orderItem.supplier = order.SupplierCode;
                        orderItem.plant = order.Plant;
                        orderItem.dock = order.DockCode;
                        //Don't need "K"??
                        //orderItem.pickUp = order.PickUp.Value.ToString("yyyy-MM-ddTHH:mmK"); //RFC3339, but only Date, Hours, Min (with a "T" between them)
                        //Don't need "K"???
                        orderItem.pickUp = order.PickUp.Value.ToString("yyyy-MM-ddTHH:mm"); //RFC3339, but only Date, Hours, Min (with a "T" between them)

                        //TODO... I don't think we need this... Ask Garry!!!
                        //If we need this, I will need to add "Exceptions" object to the JSON "Order" class (which is only used by ShipmentLoad!)
                        //orderItem.exceptions = null;
                        //if (order.ShipmentLoadOrderExceptions != null)
                        //{
                        //    if (order.ShipmentLoadOrderExceptions.Count > 0)
                        //    {
                        //        orderItem.exceptions = new List<APIexception>();
                        //        foreach (var exception in order.ShipmentLoadOrderExceptions)
                        //        {
                        //            APIexception exceptionItem = new APIexception();
                        //            exceptionItem.exceptionCode = exception.Code;
                        //            exceptionItem.comments = exception.Comments;
                        //            orderItem.exceptions.Add(exceptionItem);
                        //        }
                        //    }
                        //}

                        //public class ShipmentSkid
                        //{
                        //    public string palletization { get; set; }
                        //    public string skidId { get; set; }
                        //    [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
                        //    public List<APIexception> exceptions { get; set; }
                        //}

                        orderItem.skids = null;
                        if (order.ShipmentLoadSkids != null)
                        {
                            if (order.ShipmentLoadSkids.Count > 0)
                            {
                                orderItem.skids = new List<ShipmentSkid>();
                                foreach (var skid in order.ShipmentLoadSkids)
                                {
                                    ShipmentSkid skidItem = new ShipmentSkid();
                                    skidItem.palletization = skid.PalletizationCode;
                                    skidItem.skidId = skid.SkidId;

                                    skidItem.exceptions = null;
                                    if (skid.ShipmentLoadSkidExceptions != null)
                                    {
                                        if (skid.ShipmentLoadSkidExceptions.Count > 0)
                                        {
                                            skidItem.exceptions = new List<APIexception>();
                                            foreach (var exception in skid.ShipmentLoadSkidExceptions)
                                            {
                                                APIexception exceptionItem = new APIexception();
                                                exceptionItem.exceptionCode = exception.Code;
                                                exceptionItem.comments = exception.Comments;
                                                skidItem.exceptions.Add(exceptionItem);
                                            }
                                        }
                                    }

                                    orderItem.skids.Add(skidItem);
                                }
                            }
                        }
                        reqShipmentLoad.orders.Add(orderItem);
                    }
                }
            }

            //WE DONT NEED TO LOAD THESE FOR THIS!!!!
            //WE DONT NEED TO LOAD THESE FOR THIS!!!!
            //WE DONT NEED TO LOAD THESE FOR THIS!!!!
            //WE DONT NEED TO LOAD THESE FOR THIS!!!!

            //this.ShipmentLoadTrailerResponses
            //this.ShipmentLoadTrailerResponses.APIResponse
            //this.ShipmentLoadTrailerResponses.APIResponse.APIResponseMessages

            //
            //Shouldn't be necessary, but lets go ahead and SORT..
            //
            //Lets order the Skids by SkidId (001,002,Etc) and the Kanbans by Part#, then Box#.
            //It makes the Request String/Json/SQL all easier to evaluate/debug/look at!
            //
            //This seems to create some duplicates!!!???
            //s
            //reqShipmentLoad.orders.Sort((a, b) => a.order.CompareTo(b.order));
            //foreach (var order in reqShipmentLoad.orders)
            //{
            //    order.skids.Sort((a, b) => a.skidId.CompareTo(b.skidId));
            //    //order.skids = order.skids.OrderBy(o => o.skidId).ThenBy(o => o.ANOTHERFIELD).ToList();
            //}

            //ShipmentLoadTrailer newShipmentLoadTrailer = CreateShipmentLoadTrailerSQLEntry(reqShipmentLoad, shipmentLoadTrailer.ScannedBy);
            //if (newShipmentLoadTrailer == null)
            //{
            //    _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "EXCEPTION", "-----DoSkidBuildTransaction()==== Problem creating ShipmentLoadTrailer SQL Rows for shipmentLoadTrailer.ID: " + shipmentLoadTrailer.ID + ", shipmentLoadTrailer.NAMC:" + shipmentLoadTrailer.NAMC.ToString() + ", shipmentLoadTrailer.SupplierCode:" + shipmentLoadTrailer.SupplierCode.ToString() + " shipmentLoadTrailer.DockCode:" + shipmentLoadTrailer.DockCode);
            //}

            ////////////////////////////////////////Build the RequestSkidBuild!!!!!////////////////////////////////////////

            String Username = "24d058ee-4775-4426-9ae0-6d3e612b5e10";  //AppID
            String Password = "W8aD2pM3qO7fS8xC3wE7bD1kX1nN8fG3gS8iN1kE8gH2iF3aX0";  //AppSecret

            String SkidURL = "https://api.toyota.com/tmna/prod/Logistics/v/SupplierOrderInformation/skid";
            String TrailerURL = "https://api.toyota.com/tmna/prod/Logistics/v/SupplierOrderInformation/trailer";

            //if (DEBUG) _logger.Log("-----DoSkidBuildTransaction()-----++++++++++New Skid Build Request++++++++++");
            //if (DEBUG) _logger.Log("-----DoSkidBuildTransaction()SkidURL: " + SkidURL);
            //if (DEBUG) _logger.Log("-----DoSkidBuildTransaction()Request (ObjectDumper): " + ObjectDumper.Dump(reqSkidBuild));
            //if (DEBUG) _logger.Log("-----DoSkidBuildTransaction()Request (JSON): " + JsonConvert.SerializeObject(reqSkidBuild));

            ToyotaSCSWebAPI tscsWebAPI = new ToyotaSCSWebAPI(Username, Password, SkidURL, TrailerURL);

            APIresponse response = null;

            //Testing API Communication!
            //response = tscsWebAPI.SendRequest<APIresponse>(SkidURL, "[{\"order\":\"2018090501SA\"}]");
            //if (DEBUG) _logger.Log("-----DoSkidBuildTransaction()==========(Only Sending Order, for test...) Response: " + Misc.ClassToString(response));

            //ShipmentLoad isn't an ARRAY, like SkidBuild!!!
            //List<RequestShipmentLoad> shipmentLoad = new List<RequestShipmentLoad>();
            //shipmentLoad.Add(reqShipmentLoad);
            //string jsonRequest = JsonConvert.SerializeObject(shipmentLoad);
            string jsonRequest = JsonConvert.SerializeObject(reqShipmentLoad);
            if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoShipmentLoadTransaction()=======Request (JSON): " + jsonRequest);
            File.WriteAllText(fileNameScenarioPrefix + "_Request.txt", jsonRequest);
            if (CheckBoxSEND.Checked)
            {
                string stringResponse;
                response = tscsWebAPI.SendRequest<APIresponse>(TrailerURL, jsonRequest, out stringResponse);
                //Console.WriteLine("-----DoShipmentLoadTransaction()==========Response: " + Misc.ClassToString(response));
                //Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                //Console.WriteLine("-----DoShipmentLoadTransaction()==========Response (ObjectDumper): " + ObjectDumper.Dump(response));
                //Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                //if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoShipmentLoadTransaction()==========Response: " + Misc.ClassToString(response));
                if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoShipmentLoadTransaction()==========Response (ObjectDumper): " + ObjectDumper.Dump(response));

                File.WriteAllText(fileNameScenarioPrefix + "_Response.txt", stringResponse);

                // Will need an "Overloaded" HandleAPIRepsonse for ShipmentLoad!!!
                //
                //HandleAPIResponse() creates the SQL Rows for APIResponse, APIResonseMessage and ShipmentLoadTrailerResponse
                //      It also "parses" the response and determines what to do? Like update ShipmentLoadTrailer Tables, or send an EMAIL Notification to "Managers" or "Developers"????
                //      RIGHT??? Make sure it does do all that!
                //
                HandleAPIResponse(response, shipmentLoadTrailer, shipmentLoadTrailer.ModifiedBy); // Will need an "Overloaded" HandleAPIRepsonse for ShipmentLoad.
            }
            else
            {
                MainForm._TextBoxOutput.AppendText(Environment.NewLine);
                MainForm._TextBoxOutput.AppendText("The ShipmentLoad Request was NOT sent (\"SEND IT!\" was NOT checked), but the Request file was created for ShipmentLoadTrailerID: " + shipmentLoadTrailer.ID.ToString());
                MainForm._TextBoxOutput.AppendText(Environment.NewLine);
            }

            CheckBoxSEND.Checked = false;
        }

        private void ButtonClearOutput_Click(object sender, EventArgs e)
        {
            TextBoxOutput.ResetText();
        }
    }

    public static class Misc
    {
        public static void SendEmail(string fromAddress, string sendToAddresses, string subject, string body)
        {
            MainForm._TextBoxOutput.AppendText("Email subject:  : " + subject + "  body: " + body);
            MainForm._TextBoxOutput.AppendText(Environment.NewLine);
        }

    }

    public static class _logger
    {
        //public static void LogToSQL_TSCS(string output)
        public static void LogToSQL_TSCS(string TSCSsource, string TSCStype, string stringToLog)
        {
            //MainForm._TextBoxOutput.AppendText("TSCSsource : " + TSCSsource + "  TSCStype: " + TSCStype + " stringToLog: " + stringToLog);
            MainForm._TextBoxOutput.AppendText(stringToLog);
            MainForm._TextBoxOutput.AppendText(Environment.NewLine);
        }

    }

    public class RequestSkidBuild
    {
        public string order { get; set; }
        public string supplier { get; set; }
        public string plant { get; set; }
        public string dock { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public List<APIexception> exceptions { get; set; }
        public List<Skid> skids { get; set; }
        public RequestSkidBuild()
        {
        }

        public RequestSkidBuild(string example)
        {
            if (example.Equals("ExampleFromGarry"))
            {
                //[
                //{"order":"2018090501SA", "supplier":"22602", "plant":"02TMI", "dock":"M8","exceptions":[{"exceptionCode":"","comments":""},{"exceptionCode":"","comments":""}],
                // "skids": 
                //	[{"palletization":"D8","skidId":"001","kanbans":

                //        [{"lineSideAddress":"K16-02-DTL","partNumber":"698100C07000","kanban":"MC34","qpc":4,"boxNumber":1,"manifestNumber":"","rfId":""}
                //		,{"lineSideAddress":"K16-02-DTL","partNumber":"698100C07000","kanban":"MC34","qpc":4,"boxNumber":2,"manifestNumber":"","rfId":""}
                //		,{"lineSideAddress":"K16-02-DTL","partNumber":"698100C07000","kanban":"MC34","qpc":4,"boxNumber":3,"manifestNumber":"","rfId":""}
                //		,{"lineSideAddress":"K16-02-DTL","partNumber":"698100C07000","kanban":"MC34","qpc":4,"boxNumber":4,"manifestNumber":"","rfId":""}
                //		,{"lineSideAddress":"K16-02-DTL","partNumber":"698100C07000","kanban":"MC34","qpc":4,"boxNumber":5,"manifestNumber":"","rfId":""}
                //		,{"lineSideAddress":"K16-02-DTL","partNumber":"698100C07000","kanban":"MC34","qpc":4,"boxNumber":6,"manifestNumber":"","rfId":""}
                //		,{"lineSideAddress":"K16-02-DTL","partNumber":"698100C07000","kanban":"MC34","qpc":4,"boxNumber":7,"manifestNumber":"","rfId":""}
                //		,{"lineSideAddress":"K16-02-DTL","partNumber":"698100C07000","kanban":"MC34","qpc":4,"boxNumber":8,"manifestNumber":"","rfId":""}
                //		,{"lineSideAddress":"K16-02-DTL","partNumber":"698100C07000","kanban":"MC34","qpc":4,"boxNumber":9,"manifestNumber":"","rfId":""}
                //		,{"lineSideAddress":"K16-02-DTL","partNumber":"698100C07000","kanban":"MC34","qpc":4,"boxNumber":10,"manifestNumber":"","rfId":""}
                //		,{"lineSideAddress":"K16-02-DTL","partNumber":"698100C07000","kanban":"MC34","qpc":4,"boxNumber":11,"manifestNumber":"","rfId":""}],
                //
                //Not implemented yet, since it may change, just comment out for now!!
                //
                //////		"rfidDetails":[{"rfid":"","type":""},{"rfid":"","type":"" }]}]}
                //]


                this.order = "2018090501SA";
                this.supplier = "22602";
                this.plant = "02TMI";
                this.dock = "M8";


                //Tell the Serializer to ignore this by adding the Json Attribute: [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
                //to the "exceptions" property in the RequestSkidBuild class.
                this.exceptions = null;
                //this.exceptions = new List<APIexception>();
                //APIexception exceptionItem1 = new APIexception();
                //exceptionItem1.exceptionCode = "";
                //exceptionItem1.comments = "";
                //this.exceptions.Add(exceptionItem1);
                //APIexception exceptionItem2 = new APIexception();
                //exceptionItem2.exceptionCode = "";
                //exceptionItem2.comments = "";
                //this.exceptions.Add(exceptionItem2);


                skids = new List<Skid>();

                Skid skidItem = new Skid();
                skidItem.palletization = "D8";
                skidItem.skidId = "001";

                skidItem.kanbans = new List<Kanban>();

                Kanban kanbanItem1 = new Kanban();
                kanbanItem1.lineSideAddress = "K16-02-DTL";
                kanbanItem1.partNumber = "698100C07000";
                kanbanItem1.kanban = "MC34";
                kanbanItem1.qpc = 4;
                kanbanItem1.boxNumber = 1;
                kanbanItem1.manifestNumber = null; //manifestNumber = "";
                kanbanItem1.rfId = null; //rfId = "";
                skidItem.kanbans.Add(kanbanItem1);
                Kanban kanbanItem2 = new Kanban();
                kanbanItem2.lineSideAddress = "K16-02-DTL";
                kanbanItem2.partNumber = "698100C07000";
                kanbanItem2.kanban = "MC34";
                kanbanItem2.qpc = 4;
                kanbanItem2.boxNumber = 2;
                kanbanItem2.manifestNumber = null; //manifestNumber = "";
                kanbanItem2.rfId = null; //rfId = "";
                skidItem.kanbans.Add(kanbanItem2);
                Kanban kanbanItem3 = new Kanban();
                kanbanItem3.lineSideAddress = "K16-02-DTL";
                kanbanItem3.partNumber = "698100C07000";
                kanbanItem3.kanban = "MC34";
                kanbanItem3.qpc = 4;
                kanbanItem3.boxNumber = 3;
                kanbanItem3.manifestNumber = null; //manifestNumber = "";
                kanbanItem3.rfId = null; //rfId = "";
                skidItem.kanbans.Add(kanbanItem3);
                Kanban kanbanItem4 = new Kanban();
                kanbanItem4.lineSideAddress = "K16-02-DTL";
                kanbanItem4.partNumber = "698100C07000";
                kanbanItem4.kanban = "MC34";
                kanbanItem4.qpc = 4;
                kanbanItem4.boxNumber = 4;
                kanbanItem4.manifestNumber = null; //manifestNumber = "";
                kanbanItem4.rfId = null; //rfId = "";
                skidItem.kanbans.Add(kanbanItem4);
                Kanban kanbanItem5 = new Kanban();
                kanbanItem5.lineSideAddress = "K16-02-DTL";
                kanbanItem5.partNumber = "698100C07000";
                kanbanItem5.kanban = "MC34";
                kanbanItem5.qpc = 4;
                kanbanItem5.boxNumber = 5;
                kanbanItem5.manifestNumber = null; //manifestNumber = "";
                kanbanItem5.rfId = null; //rfId = "";
                skidItem.kanbans.Add(kanbanItem5);
                Kanban kanbanItem6 = new Kanban();
                kanbanItem6.lineSideAddress = "K16-02-DTL";
                kanbanItem6.partNumber = "698100C07000";
                kanbanItem6.kanban = "MC34";
                kanbanItem6.qpc = 4;
                kanbanItem6.boxNumber = 6;
                kanbanItem6.manifestNumber = null; //manifestNumber = "";
                kanbanItem6.rfId = null; //rfId = "";
                skidItem.kanbans.Add(kanbanItem6);
                Kanban kanbanItem7 = new Kanban();
                kanbanItem7.lineSideAddress = "K16-02-DTL";
                kanbanItem7.partNumber = "698100C07000";
                kanbanItem7.kanban = "MC34";
                kanbanItem7.qpc = 4;
                kanbanItem7.boxNumber = 7;
                kanbanItem7.manifestNumber = null; //manifestNumber = "";
                kanbanItem7.rfId = null; //rfId = "";
                skidItem.kanbans.Add(kanbanItem7);
                Kanban kanbanItem8 = new Kanban();
                kanbanItem8.lineSideAddress = "K16-02-DTL";
                kanbanItem8.partNumber = "698100C07000";
                kanbanItem8.kanban = "MC34";
                kanbanItem8.qpc = 4;
                kanbanItem8.boxNumber = 8;
                kanbanItem8.manifestNumber = null; //manifestNumber = "";
                kanbanItem8.rfId = null; //rfId = "";
                skidItem.kanbans.Add(kanbanItem8);
                Kanban kanbanItem9 = new Kanban();
                kanbanItem9.lineSideAddress = "K16-02-DTL";
                kanbanItem9.partNumber = "698100C07000";
                kanbanItem9.kanban = "MC34";
                kanbanItem9.qpc = 4;
                kanbanItem9.boxNumber = 9;
                kanbanItem9.manifestNumber = null; //manifestNumber = "";
                kanbanItem9.rfId = null; //rfId = "";
                skidItem.kanbans.Add(kanbanItem9);
                Kanban kanbanItem10 = new Kanban();
                kanbanItem10.lineSideAddress = "K16-02-DTL";
                kanbanItem10.partNumber = "698100C07000";
                kanbanItem10.kanban = "MC34";
                kanbanItem10.qpc = 4;
                kanbanItem10.boxNumber = 10;
                kanbanItem10.manifestNumber = null; //manifestNumber = "";
                kanbanItem10.rfId = null; //rfId = "";
                skidItem.kanbans.Add(kanbanItem10);
                Kanban kanbanItem11 = new Kanban();
                kanbanItem11.lineSideAddress = "K16-02-DTL";
                kanbanItem11.partNumber = "698100C07000";
                kanbanItem11.kanban = "MC34";
                kanbanItem11.qpc = 4;
                kanbanItem11.boxNumber = 11;
                kanbanItem11.manifestNumber = null; //manifestNumber = "";
                kanbanItem11.rfId = null; //rfId = "";
                skidItem.kanbans.Add(kanbanItem11);

                //
                //Not implemented yet, since it may change, just comment out for now!!
                //
                //skidItem.rfidDetails = new List<RfidDetail>();

                //RfidDetail rfidItem1 = new RfidDetail();
                //rfidItem1.rfId = null; //rfId = "";
                //rfidItem1.type = "";
                //skidItem.rfidDetails.Add(rfidItem1);
                //RfidDetail rfidItem2 = new RfidDetail();
                //rfidItem2.rfId = null; //rfId = "";
                //rfidItem2.type = "";
                //skidItem.rfidDetails.Add(rfidItem2);

                this.skids.Add(skidItem);
            }
            else if (example.Equals("ExampleRevB"))
            {
                //"orders":[{"order":"2018032336","supplier":"99999" ,"plant":"01TMK","dock":"N1","pickUp":"2018-03-22T12:10","skids": [
                //{"palletization":"D","skidId":"007", "exceptions": [{"exceptionCode":"", "comments":""},{"exceptionCode":"", "comments":""}] }]}]}

                //Each Request will be an object containing the SKID details and list of Kanban
                //(array).
                //JSON example:
                //{
                //"order":"2018032336","supplier":"99999","plant":"01TMK","dock":"N1",
                //"exceptions": [{"exceptionCode":"10", "comments":""}, {"exceptionCode":"20", "comments":""}],
                //"skids": [
                //    {"palletization":"D","skidId":"007","kanbans": [
                //        {"lineSideAddress":"ENW-05","partNumber":"329060605000","kanban":"NQ49","qpc":12,"boxNumber":1,"manifestNumber":"", "rfId": ""},
                //        {"lineSideAddress":"ENW-05","partNumber":"329060605000","kanban":"NQ49","qpc":12,"boxNumber":2,"manifestNumber":"", "rfId": ""},
                //        {"lineSideAddress":"ENW-05","partNumber":"329060605000","kanban":"NQ49","qpc":12,"boxNumber":3,"manifestNumber":"", "rfId": ""},
                //        {"lineSideAddress":"ENW-05","partNumber":"329060605000","kanban":"NQ49","qpc":12,"boxNumber":4,"manifestNumber":"", "rfId": ""},
                //        {"lineSideAddress":"ENW-05","partNumber":"329060605000","kanban":"NQ49","qpc":12,"boxNumber":5,"manifestNumber":"", "rfId": ""},
                //        {"lineSideAddress":"ENW-05","partNumber":"329060605000","kanban":"NQ49","qpc":12,"boxNumber":6,"manifestNumber":"", "rfId": ""},
                //        {"lineSideAddress":"ENW-05","partNumber":"329060605000","kanban":"NQ49","qpc":12,"boxNumber":7,"manifestNumber":"", "rfId": ""},
                //        {"lineSideAddress":"ENW-05","partNumber":"329060602000","kanban":"NPX0","qpc":12,"boxNumber":1,"manifestNumber":"", "rfId": ""}],
                //
                //Not implemented yet, since it may change, just comment out for now!!
                //
                //////    "rfidDetails": [{"rfid": "", "type": ""}, {"rfid": "", "type": "" }]
                //    }]
                //}


                this.order = "2018032336";
                this.supplier = "99999";
                this.plant = "01TMC";
                this.dock = "N1";


                this.exceptions = new List<APIexception>();

                APIexception exceptionItem1 = new APIexception();
                exceptionItem1.exceptionCode = "10";
                exceptionItem1.comments = "";
                this.exceptions.Add(exceptionItem1);
                APIexception exceptionItem2 = new APIexception();
                exceptionItem2.exceptionCode = "20";
                exceptionItem2.comments = "";
                this.exceptions.Add(exceptionItem2);


                skids = new List<Skid>();

                Skid skidItem = new Skid();
                skidItem.palletization = "D";
                skidItem.skidId = "007";

                skidItem.kanbans = new List<Kanban>();

                Kanban kanbanItem1 = new Kanban();
                kanbanItem1.lineSideAddress = "ENW-05";
                kanbanItem1.partNumber = "329060605000";
                kanbanItem1.kanban = "NQ49";
                kanbanItem1.qpc = 12;
                kanbanItem1.boxNumber = 1;
                kanbanItem1.manifestNumber = null; //manifestNumber = "";
                kanbanItem1.rfId = null; //rfId = "";
                skidItem.kanbans.Add(kanbanItem1);
                Kanban kanbanItem2 = new Kanban();
                kanbanItem2.lineSideAddress = "ENW-05";
                kanbanItem2.partNumber = "329060605000";
                kanbanItem2.kanban = "NQ49";
                kanbanItem2.qpc = 12;
                kanbanItem2.boxNumber = 2;
                kanbanItem2.manifestNumber = null; //manifestNumber = "";
                kanbanItem2.rfId = null; //rfId = "";
                skidItem.kanbans.Add(kanbanItem2);
                Kanban kanbanItem3 = new Kanban();
                kanbanItem3.lineSideAddress = "ENW-05";
                kanbanItem3.partNumber = "329060605000";
                kanbanItem3.kanban = "NQ49";
                kanbanItem3.qpc = 12;
                kanbanItem3.boxNumber = 3;
                kanbanItem3.manifestNumber = null; //manifestNumber = "";
                kanbanItem3.rfId = null; //rfId = "";
                skidItem.kanbans.Add(kanbanItem3);
                Kanban kanbanItem4 = new Kanban();
                kanbanItem4.lineSideAddress = "ENW-05";
                kanbanItem4.partNumber = "329060605000";
                kanbanItem4.kanban = "NQ49";
                kanbanItem4.qpc = 12;
                kanbanItem4.boxNumber = 4;
                kanbanItem4.manifestNumber = null; //manifestNumber = "";
                kanbanItem4.rfId = null; //rfId = "";
                skidItem.kanbans.Add(kanbanItem4);
                Kanban kanbanItem5 = new Kanban();
                kanbanItem5.lineSideAddress = "ENW-05";
                kanbanItem5.partNumber = "329060605000";
                kanbanItem5.kanban = "NQ49";
                kanbanItem5.qpc = 12;
                kanbanItem5.boxNumber = 5;
                kanbanItem5.manifestNumber = null; //manifestNumber = "";
                kanbanItem5.rfId = null; //rfId = "";
                skidItem.kanbans.Add(kanbanItem5);
                Kanban kanbanItem6 = new Kanban();
                kanbanItem6.lineSideAddress = "ENW-05";
                kanbanItem6.partNumber = "329060605000";
                kanbanItem6.kanban = "NQ49";
                kanbanItem6.qpc = 12;
                kanbanItem6.boxNumber = 6;
                kanbanItem6.manifestNumber = null; //manifestNumber = "";
                kanbanItem6.rfId = null; //rfId = "";
                skidItem.kanbans.Add(kanbanItem6);
                Kanban kanbanItem7 = new Kanban();
                kanbanItem7.lineSideAddress = "ENW-05";
                kanbanItem7.partNumber = "329060605000";
                kanbanItem7.kanban = "NQ49";
                kanbanItem7.qpc = 12;
                kanbanItem7.boxNumber = 7;
                kanbanItem7.manifestNumber = null; //manifestNumber = "";
                kanbanItem7.rfId = null; //rfId = "";
                skidItem.kanbans.Add(kanbanItem7);
                Kanban kanbanItem8 = new Kanban();
                kanbanItem8.lineSideAddress = "ENW-05";
                kanbanItem8.partNumber = "329060602000";
                kanbanItem8.kanban = "NPX0";
                kanbanItem8.qpc = 12;
                kanbanItem8.boxNumber = 1;
                kanbanItem8.manifestNumber = null; //manifestNumber = "";
                kanbanItem8.rfId = null; //rfId = "";
                skidItem.kanbans.Add(kanbanItem8);

                //
                //Not implemented yet, since it may change, just comment out for now!!
                //
                //skidItem.rfidDetails = new List<RfidDetail>();

                //RfidDetail rfidItem1 = new RfidDetail();
                //rfidItem1.rfId = null; //rfId = "";
                //rfidItem1.type = "";
                //skidItem.rfidDetails.Add(rfidItem1);
                //RfidDetail rfidItem2 = new RfidDetail();
                //rfidItem2.rfId = null; //rfId = "";
                //rfidItem2.type = "";
                //skidItem.rfidDetails.Add(rfidItem2);

                this.skids.Add(skidItem);
            }
        }
    }

    public class APIexception //If rename this to "scsException" or something else, will "Newtonsoft.Json" still work?? 
    {
        public string exceptionCode { get; set; }
        public string comments { get; set; }
    }

    public class Skid
    {
        public string palletization { get; set; }
        public string skidId { get; set; }
        public List<Kanban> kanbans { get; set; }
        //
        //Not implemented yet, since it may change, just comment out for now!!
        //
        //public List<RfidDetail> rfidDetails { get; set; }
    }

    public class Kanban
    {
        public string lineSideAddress { get; set; }
        public string partNumber { get; set; }
        public string kanban { get; set; }
        public int qpc { get; set; }
        public int boxNumber { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)] //This allows us to set manifestNumber to null and have it omitted from the JSON Request!
        public string manifestNumber { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)] //This allows us to set rfId to null and have it omitted from the JSON Request!
        public string rfId { get; set; }
    }

    //
    //Not implemented yet, since it may change, just comment out for now!!
    //
    //public class RfidDetail
    //{
    //    public string rfid { get; set; }
    //    public string type { get; set; }
    //}

    public class RequestShipmentLoad
    {
        public string supplier { get; set; }
        public string route { get; set; }
        public string run { get; set; }
        public string trailerNumber { get; set; }
        public bool dropHook { get; set; }
        public string sealNumber { get; set; }
        public string supplierTeamFirstName { get; set; }
        public string supplierTeamLastName { get; set; }
        public string lpCode { get; set; }
        public string driverTeamFirstName { get; set; }
        public string driverTeamLastName { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public List<APIexception> exceptions { get; set; }
        public List<Order> orders { get; set; }
    }

    public class ShipmentSkid
    {
        public string palletization { get; set; }
        public string skidId { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public List<APIexception> exceptions { get; set; }
    }

    public class Order
    {
        public string order { get; set; }
        public string supplier { get; set; }
        public string plant { get; set; }
        public string dock { get; set; }
        public string pickUp { get; set; }
        public List<ShipmentSkid> skids { get; set; }
    }

    public class APIresponse
    {
        //public System.Net.WebException webException { get; set; }
        public System.Exception dotNetException { get; set; }

        public int code { get; set; }
        public List<Message> messages { get; set; }
        public string confirmationNumber { get; set; }
        public List<ConfirmedOrder> confirmedOrders { get; set; }
        public ConfirmedTrailer confirmedTrailer { get; set; }

        public string httpCode { get; set; }
        public string httpMessage { get; set; }
        public string moreInformation { get; set; }
    }

    public class Message
    {
        public string keyObject { get; set; }
        public List<string> message { get; set; }
        public object type { get; set; }  //NULL in every example I have!
    }

    public class ConfirmedOrder
    {
        public string order { get; set; }
        public string supplier { get; set; }
        public string plant { get; set; }
        public string dock { get; set; }
    }

    public class ConfirmedTrailer
    {
        public string supplier { get; set; }
        public string route { get; set; }
        public string run { get; set; }
        public string trailerNumber { get; set; }
        public string pickUp { get; set; }
    }

    public class ToyotaSCSWebAPI
    {
        public String UserName { get; set; } //AppID
        public String Password { get; set; } //AppSecret
        public String SkidURL { get; set; }
        public String TrailerURL { get; set; }

        //public static String Username = "24d058ee-4775-4426-9ae0-6d3e612b5e10";  //AppID
        //public static String Password = "W8aD2pM3qO7fS8xC3wE7bD1kX1nN8fG3gS8iN1kE8gH2iF3aX0";  //AppSecret
        //
        //public static String SkidURL = "https://api.toyota.com/tmna/prod/Logistics/v/SupplierOrderInformation/skid";
        //public static String TrailerURL = "https://api.toyota.com/tmna/prod/Logistics/v/SupplierOrderInformation/trailer";
        public ToyotaSCSWebAPI(string userName, string password, string skidURL, string trailerUrl)
        {
            UserName = userName;
            Password = password;
            SkidURL = skidURL;
            TrailerURL = trailerUrl;
        }

        //Authentication:
        //• Type: Basic authentication(AppID/AppSecret)
        //• Username: AppID
        //• Password: AppSecret
        //For every request below are the required:
        //• Use HTTPS only
        //• Header: Add Content type in http header(Content-Type: application/json)
        //• Authentication: Basic Auth
        //• Body: Skid Build Array/Shipment Load Object

        //public T WebClientSkidBuild<T>(RequestSkidBuild reqSkidBuild) where T : new()
        //{
        //    List<RequestSkidBuild> orders = new List<RequestSkidBuild>();
        //    orders.Add(reqSkidBuild);

        //    //string jsonRequest = JsonConvert.SerializeObject(reqSkidBuild);
        //    string jsonRequest = JsonConvert.SerializeObject(orders);
        //    //return WebClientSkidBuild<T>(jsonRequest);
        //    return SendRequest<T>(this.SkidURL, jsonRequest);
        //}

        //public T WebClientSkidBuild<T>(string jsonRequest) where T : new()
        //{
        //    using (var w = new WebClient())
        //    {
        //        var json_data = string.Empty;
        //        // attempt to download JSON data as a string
        //        try
        //        {
        //            //Set Contet-Type to JSON
        //            w.Headers.Add(HttpRequestHeader.ContentType, "application/json");

        //            //ALL These seem to work!!
        //            //w.Headers[HttpRequestHeader.Authorization] = "Basic " + Convert.ToBase64String(Encoding.ASCII.GetBytes(this.UserName + ":" + this.Password));
        //            //w.Headers.Add("Authorization", "Basic " + Convert.ToBase64String(Encoding.Default.GetBytes(this.UserName + ":" + this.Password)));
        //            //w.Headers.Add("Authorization", "Basic " + Convert.ToBase64String(Encoding.ASCII.GetBytes(this.UserName + ":" + this.Password)));
        //            //w.Headers.Add(HttpRequestHeader.Authorization, "Basic " + Convert.ToBase64String(Encoding.ASCII.GetBytes(this.UserName + ":" + this.Password)));
        //            //w.Headers[HttpRequestHeader.Authorization] = "Basic " + Convert.ToBase64String(Encoding.UTF8.GetBytes(this.UserName + ":" + this.Password));
        //            //w.Headers.Add(HttpRequestHeader.Authorization, "Basic " + Convert.ToBase64String(Encoding.UTF8.GetBytes(this.UserName + ":" + this.Password)));

        //            //NOT NEEDED
        //            //w.Headers.Add(HttpRequestHeader.UserAgent, "Mozilla / 5.0(Windows; U; MSIE 9.0; Windows NT 9.0; en - US)");
        //            //w.Headers.Add(HttpRequestHeader.UserAgent, "WebClient");

        //            //w.Headers[HttpRequestHeader.Authorization] = "Basic " + credentials;

        //            //Needed?
        //            w.Encoding = System.Text.Encoding.UTF8;

        //            //JsonConvert.DeserializeObject<T>(json_data)
        //            //string jsonRequestObject = JsonConvert.SerializeObject(reqSkidBuild);
        //            json_data = w.UploadString(this.SkidURL, jsonRequest);
        //        }
        //        //catch (System.Net.WebException webEx)
        //        //{
        //        //    T genericClass = new T();
        //        //    genericClass.GetType().GetProperty("webException").SetValue(genericClass, webEx);
        //        //    return genericClass;
        //        //}
        //        catch (System.Exception ex)
        //        {
        //            //Also add an "Exception" variable to the Class??
        //            //And populate it like WebException above??

        //            T genericClass = new T();
        //            //if (ex.GetType().Name.Equals("WebException"))
        //            //{
        //                //Need this, with the Catch block above??
        //                //genericClass.GetType().GetProperty("webException").SetValue(genericClass, ex);
        //                genericClass.GetType().GetProperty("dotNetException").SetValue(genericClass, ex);
        //            //}
        //            return genericClass;
        //        }
        //        // if string with JSON data is not empty, deserialize it to class and return its instance 
        //        return !string.IsNullOrEmpty(json_data) ? JsonConvert.DeserializeObject<T>(json_data) : new T();
        //    }
        //}

        //public T WebClientShipmentBuild<T>(RequestShipmentLoad reqShipmentLoad) where T : new()
        //{
        //    List<RequestShipmentLoad> shipments = new List<RequestShipmentLoad>();
        //    shipments.Add(reqShipmentLoad);

        //    //string jsonRequest = JsonConvert.SerializeObject(reqSkidBuild);
        //    string jsonRequest = JsonConvert.SerializeObject(shipments);
        //    return SendRequest<T>(this.TrailerURL, jsonRequest);
        //}

        public T SendRequest<T>(string url, string jsonRequest, out string stringResponse) where T : new()
        {
            stringResponse = "";

            //This is required for .Net versions < 4.6 (or at least it's required for 4.5, not sure about 4.5.1, etc...)
            //Otherwise, the following Exception will be received:
            //    Exception Type (WebException)  System.Net.WebException: The underlying connection was closed: An unexpected error occurred on a send.
            //    System.IO.IOException: Authentication failed because the remote party has closed the transport stream.
            //    WebException Status Code (SendFailure)
            //
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;

            using (var w = new WebClient())
            {
                var json_data = string.Empty;
                // attempt to download JSON data as a string
                try
                {
                    //Set Contet-Type to JSON
                    w.Headers.Add(HttpRequestHeader.ContentType, "application/json");

                    //ALL These seem to work!!
                    //w.Headers[HttpRequestHeader.Authorization] = "Basic " + Convert.ToBase64String(Encoding.ASCII.GetBytes(this.UserName + ":" + this.Password));
                    //w.Headers.Add("Authorization", "Basic " + Convert.ToBase64String(Encoding.Default.GetBytes(this.UserName + ":" + this.Password)));
                    //w.Headers.Add("Authorization", "Basic " + Convert.ToBase64String(Encoding.ASCII.GetBytes(this.UserName + ":" + this.Password)));
                    //w.Headers.Add(HttpRequestHeader.Authorization, "Basic " + Convert.ToBase64String(Encoding.ASCII.GetBytes(this.UserName + ":" + this.Password)));
                    //w.Headers[HttpRequestHeader.Authorization] = "Basic " + Convert.ToBase64String(Encoding.UTF8.GetBytes(this.UserName + ":" + this.Password));
                    w.Headers.Add(HttpRequestHeader.Authorization, "Basic " + Convert.ToBase64String(Encoding.UTF8.GetBytes(this.UserName + ":" + this.Password)));

                    //NOT NEEDED
                    //w.Headers.Add(HttpRequestHeader.UserAgent, "Mozilla / 5.0(Windows; U; MSIE 9.0; Windows NT 9.0; en - US)");
                    //w.Headers.Add(HttpRequestHeader.UserAgent, "WebClient");

                    //w.Headers[HttpRequestHeader.Authorization] = "Basic " + credentials;

                    //Needed?
                    w.Encoding = System.Text.Encoding.UTF8;

                    //JsonConvert.DeserializeObject<T>(json_data)
                    //string jsonRequestObject = JsonConvert.SerializeObject(reqSkidBuild);
                    //json_data = w.UploadString(this.SkidURL, jsonRequest);
                    json_data = w.UploadString(url, jsonRequest);
                    stringResponse = json_data;
                }
                //catch (System.Net.WebException webEx)
                //{
                //    T genericClass = new T();
                //    genericClass.GetType().GetProperty("webException").SetValue(genericClass, webEx);
                //    return genericClass;
                //}
                catch (System.Exception ex)
                {
                    //Also add an "Exception" variable to the Class??
                    //And populate it like WebException above??

                    T genericClass = new T();
                    //if (ex.GetType().Name.Equals("WebException"))
                    //{
                    //Need this, with the Catch block above??
                    //genericClass.GetType().GetProperty("webException").SetValue(genericClass, ex);
                    genericClass.GetType().GetProperty("dotNetException").SetValue(genericClass, ex);
                    //}
                    return genericClass;
                }
                // if string with JSON data is not empty, deserialize it to class and return its instance 
                return !string.IsNullOrEmpty(json_data) ? JsonConvert.DeserializeObject<T>(json_data) : new T();
            }
        }

    }

    public class ObjectDumper
    {
        private int _currentIndent;
        private readonly int _indentSize;
        private readonly StringBuilder _stringBuilder;
        private readonly Dictionary<object, int> _hashListOfFoundElements;
        private readonly char _indentChar;
        private readonly int _depth;
        private int _currentLine;

        private ObjectDumper(int depth, int indentSize, char indentChar)
        {
            _depth = depth;
            _indentSize = indentSize;
            _indentChar = indentChar;
            _stringBuilder = new StringBuilder();
            _hashListOfFoundElements = new Dictionary<object, int>();
        }

        public static string Dump(object element, int depth = 4, int indentSize = 2, char indentChar = ' ')
        {
            var instance = new ObjectDumper(depth, indentSize, indentChar);
            return instance.DumpElement(element, true);
        }

        private string DumpElement(object element, bool isTopOfTree = false)
        {
            if (_currentIndent > _depth) { return null; }
            if (element == null || element is string)
            {
                Write(FormatValue(element));
            }
            else if (element is ValueType)
            {
                Type objectType = element.GetType();
                bool isWritten = false;
                if (objectType.IsGenericType)
                {
                    Type baseType = objectType.GetGenericTypeDefinition();
                    if (baseType == typeof(KeyValuePair<,>))
                    {
                        isWritten = true;
                        Write("Key:");
                        _currentIndent++;
                        DumpElement(objectType.GetProperty("Key").GetValue(element, null));
                        _currentIndent--;
                        Write("Value:");
                        _currentIndent++;
                        DumpElement(objectType.GetProperty("Value").GetValue(element, null));
                        _currentIndent--;
                    }
                }
                if (!isWritten)
                {
                    Write(FormatValue(element));
                }
            }
            else
            {
                //if (element is IEnumerable enumerableElement)
                if (element is IEnumerable)
                {
                    //foreach (object item in enumerableElement)
                    foreach (object item in (IEnumerable)element)
                    {
                        if (item is IEnumerable && !(item is string))
                        {
                            _currentIndent++;
                            DumpElement(item);
                            _currentIndent--;
                        }
                        else
                        {
                            DumpElement(item);
                        }
                    }
                }
                else
                {
                    Type objectType = element.GetType();
                    Write("{{{0}(HashCode:{1})}}", objectType.FullName, element.GetHashCode());
                    if (!AlreadyDumped(element))
                    {
                        _currentIndent++;
                        MemberInfo[] members = objectType.GetMembers(BindingFlags.Public | BindingFlags.Instance);
                        foreach (var memberInfo in members)
                        {
                            var fieldInfo = memberInfo as FieldInfo;
                            var propertyInfo = memberInfo as PropertyInfo;

                            if (fieldInfo == null && (propertyInfo == null || !propertyInfo.CanRead || propertyInfo.GetIndexParameters().Length > 0))
                                continue;

                            var type = fieldInfo != null ? fieldInfo.FieldType : propertyInfo.PropertyType;
                            object value;
                            try
                            {
                                value = fieldInfo != null
                                                   ? fieldInfo.GetValue(element)
                                                   : propertyInfo.GetValue(element, null);
                            }
                            catch (System.Exception e)
                            {
                                Write("{0} failed with:{1}", memberInfo.Name, (e.GetBaseException() ?? e).Message);
                                continue;
                            }

                            if (type.IsValueType || type == typeof(string))
                            {
                                Write("{0}: {1}", memberInfo.Name, FormatValue(value));
                            }
                            else
                            {
                                var isEnumerable = typeof(IEnumerable).IsAssignableFrom(type);
                                Write("{0}: {1}", memberInfo.Name, isEnumerable ? "..." : "{ }");

                                _currentIndent++;
                                DumpElement(value);
                                _currentIndent--;
                            }
                        }
                        _currentIndent--;
                    }
                }
            }

            return isTopOfTree ? _stringBuilder.ToString() : null;
        }

        private bool AlreadyDumped(object value)
        {
            int lineNo;
            if (value == null)
                return false;
            if (_hashListOfFoundElements.TryGetValue(value, out lineNo))
            {
                Write("(reference already dumped - line:{0})", lineNo);
                return true;
            }
            _hashListOfFoundElements.Add(value, _currentLine);
            return false;
        }

        private void Write(string value, params object[] args)
        {
            var space = new string(_indentChar, _currentIndent * _indentSize);

            if (args != null)
                value = string.Format(value, args);

            _stringBuilder.AppendLine(space + value);
            _currentLine++;
        }

        private string FormatValue(object o)
        {
            if (o == null)
                return ("null");

            if (o is DateTime)
                return (((DateTime)o).ToShortDateString());

            if (o is string)
                return "\"" + (string)o + "\"";

            if (o is char)
            {
                if (o.Equals('\0'))
                {
                    return "''";
                }
                else
                {
                    return "'" + (char)o + "'";
                }
            }

            if (o is ValueType)
                return (o.ToString());

            if (o is IEnumerable)
                return ("...");

            return ("{ }");
        }
    }
}
﻿using Cognex.DataMan.SDK;
using Cognex.DataMan.SDK.Utils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;
using System.Net;
using PickToLightData;

namespace SNA.WinService.PickToLightServer
{
    public partial class PickToLightServer_Bander : ServiceBase
    {
        private static Logger _logger;

        private bool stopping;
        private ManualResetEvent stoppedEvent; 

        //Scanner Related
        //Need to reference the assembly!
        private ResultCollector _scannerResults;
        private DataManSystem _scanner = null;
        private ISystemConnector _connector = null;
        //private string _pickToLightServerIP = "";
        IPAddress _pickToLightServerIP = null;
        private string _scannerName = "";
        private string _scannerIP = "";
        private string _scannerPassword = "";
        private string _scannerImages = "";
        private string _scannerImagesUNC = "";
        private string _pickToLightBanderDisplayHost = "";
        IPAddress _pickToLightBanderDisplayIP = null;
        private bool _scannerKeepAlive = true;
        private int _scannerKeepAliveTimeout = 3000;
        private int _scannerKeepAliveInterval = 1000;
        private bool _autoconnectScanner = false;
        private object _currentResultInfoSyncLock = new object();

        //TODO: READ THIS AS AN "app.config" setting!!!
        //The port number for the remote device.  
        //private int _pickToLightServerPort = 11000; //11000 is the port for the "old" Code and 31001 I sometimes use, too. The BanderDisplay uses 12000
        //Not used... uses default in class!
        //private int _pickToLightServerPort = 11100;   //11000 is the port for the "old" Code and 31001 I sometimes use, too. The BanderDisplay uses 12000
        private int _pickToLightBanderDisplayPort = 12000;

        public PickToLightServer_Bander()
        {
            InitializeComponent();

            //Optionally set the ServiceName from the config fie.
            string appSetting = GetSetting("ServiceName");
            if (appSetting.Length != 0)
            {
                this.ServiceName = appSetting;
            }

            this.stopping = false;
            this.stoppedEvent = new ManualResetEvent(false);
        }

        protected override void OnStart(string[] args)
        {
            Thread.CurrentThread.Name = "OnStart Thread";

            _logger = new Logger(this.ServiceName);

            // Log a service start message to the Application log.
            //Even though LoadSettings() hasn't been called, the LogMode defaults to NoLogging.
            //So, this will work as expected!
            _logger.LogMainEvent(this.ServiceName + " is Starting.");

            //Load the Service Settings from the Config File!
            LoadSettings();

            //
            //StartBanderScanner();
            //Or start like this?
            //
            // Queue the bander scanner communication for execution in a worker thread. 
            // (A Service has to return, the "work" should be done with Threads.)

            // TODO: Since this is the MAIN, long running thread, I believe I should be using "NewThread" (or new Thread()??) instead of the "ThreadPool".
            ThreadPool.QueueUserWorkItem(new WaitCallback(BanderScannerConnectThread)); 

            //return 0; 
        }

        protected override void OnStop()
        {
            Thread.CurrentThread.Name = "OnStop Thread";

            // Log a service stop message to the Application log.
            _logger.LogMainEvent(this.ServiceName + " is Stopping.");

            // Indicate that the service is stopping and wait for the finish
            // of the main service function (ServiceWorkerThread).
            this.stopping = true;
        }

        public void LoadSettings()
        {
            string appSetting;

            try
            {
                //Read in the LogMode (NoLogging, FileLog, EventLog, SQLLog)
                appSetting = GetSetting("LogMode");
                //if(String.IsNullOrEmpty(appSetting))
                if (appSetting.Length == 0)
                {
                    _logger.LogMode = Logger.LogModes.NoLogging;
                    _logger.LogFolder = "LogMode=NoLogging";
                }
                else
                {
                    if (appSetting.ToUpper().Equals("NOLOGGING"))
                    {
                        _logger.LogMode = Logger.LogModes.NoLogging;
                        _logger.LogFolder = "LogMode=NoLogging";
                    }
                    else if (appSetting.ToUpper().Equals("FILELOG"))
                    {
                        _logger.LogMode = Logger.LogModes.FileLog;
                        //Read in the LogFolder (Used when LogMode = FileLog)
                        appSetting = GetSetting("LogFolder");
                        //if(String.IsNullOrEmpty(appSetting))
                        if (appSetting.Length > 0)
                        {
                            if (Directory.Exists(appSetting))
                            {
                                _logger.LogFolder = appSetting;
                            }
                            else
                            {
                                _logger.LogError("LogFolder (" + _logger.LogFolder + ") does not exist!");
                            }
                        }
                    }
                    else if (appSetting.ToUpper().Equals("EVENTLOG"))
                    {
                        _logger.LogMode = Logger.LogModes.EventLog;
                        _logger.LogFolder = "LogMode=EventLog";
                    }
                    else if (appSetting.ToUpper().Equals("SQLLOG"))
                    {
                        _logger.LogMode = Logger.LogModes.SQLLog;
                        _logger.LogFolder = "LogMode=SQLLog";
                    }
                    else // Unrecognized, so lets do EventLog!
                    {
                        _logger.LogMode = Logger.LogModes.EventLog;
                        _logger.LogFolder = "LogMode=EventLog";
                    }
                }

                //<add key="PickToLightServerIP" value="10.2.9.23" />
                //Read in the PickToLightServerIP
                appSetting = GetSetting("PickToLightServerIP");
                //if(String.IsNullOrEmpty(appSetting))
                if (appSetting.Length == 0)
                {
                    //_pickToLightServerIP = "";
                    _pickToLightServerIP = null;
                    throw new ConfigurationErrorsException("PickToLightServerIP is missing or empty!");
                    //We won't get here since its called in a main thread (not on an Asynch Callback)
                    // Use this since we are a console app
                    //System.Environment.Exit(1);
                }
                else
                {
                    //_pickToLightServerIP = appSetting;
                    if (System.Net.IPAddress.TryParse(appSetting, out _pickToLightServerIP) == false)
                    {
                        throw new ConfigurationErrorsException("PickToLightServerIP can't be parsed into a valid IP!");
                    }
                }

                //<add key="ScannerName" value="Bander1" />
                //Read in the ScannerName
                appSetting = GetSetting("ScannerName");
                //if(String.IsNullOrEmpty(appSetting))
                if (appSetting.Length == 0)
                {
                    _scannerName = "";
                    throw new ConfigurationErrorsException("ScannerName is missing or empty!");
                    //We won't get here since its called in a main thread (not on an Asynch Callback)
                    // Use this since we are a console app
                    //System.Environment.Exit(1);
                }
                else
                {
                    _scannerName = appSetting;
                }

                //<add key="ScannerIP" value="10.22.10.102" />
                //Read in the ScannerIP
                appSetting = GetSetting("ScannerIP");
                //if(String.IsNullOrEmpty(appSetting))
                if (appSetting.Length == 0)
                {
                    _scannerIP = "";
                    throw new ConfigurationErrorsException("ScannerIP is missing or empty!");
                    //We won't get here since its called in a main thread (not on an Asynch Callback)
                    // Use this since we are a console app
                    //System.Environment.Exit(1);
                }
                else
                {
                    _scannerIP = appSetting;
                }

                //<add key="ScannerPassword" value="" />
                //Read in the ScannerPassword
                appSetting = GetSetting("ScannerPassword");
                //if(String.IsNullOrEmpty(appSetting))
                if (appSetting.Length == 0)
                {
                    _scannerPassword = "";
                }
                else
                {
                    _scannerPassword = appSetting;
                }

                //<add key="ScannerImages" value="D:\PickToLightScans\Bander1" />
                //Read in the ScannerImages (Folder)
                appSetting = GetSetting("ScannerImages");
                //if(String.IsNullOrEmpty(appSetting))
                if (appSetting.Length == 0)
                {
                    _scannerImages = "";
                    throw new ConfigurationErrorsException("ScannerImages (Folder) is missing or empty!");
                    //We won't get here since its called in a main thread (not on an Asynch Callback)
                    // Use this since we are a console app
                    //System.Environment.Exit(3); //ERROR_PATH_NOT_FOUND
                }
                else
                {
                    if (Directory.Exists(appSetting))
                    {
                        _scannerImages = appSetting;
                    }
                    else
                    {
                        _scannerImages = "";
                        _logger.LogError("ScannerImages (Folder) (" + _scannerImages + ") does not exist!");
                        throw new ConfigurationErrorsException("ScannerImages (Folder) (" + _scannerImages + ") does not exist!");
                        //We won't get here since its called in a main thread (not on an Asynch Callback)
                        // Use this since we are a console app
                        //System.Environment.Exit(3); //ERROR_PATH_NOT_FOUND
                    }
                }

                //<add key="ScannerImagesUNC" value="\\HQ-MEDIA\Public\PickToLightScans\Bander1" />
                //Read in the ScannerImagesUNC (UNC Path)
                appSetting = GetSetting("ScannerImagesUNC");
                //if(String.IsNullOrEmpty(appSetting))
                if (appSetting.Length == 0)
                {
                    _scannerImagesUNC = "";
                    throw new ConfigurationErrorsException("ScannerImagesUNC (UNC Path) is missing or empty!");
                    //We won't get here since its called in a main thread (not on an Asynch Callback)
                    // Use this since we are a console app
                    //System.Environment.Exit(3); //ERROR_PATH_NOT_FOUND
                }
                else
                {
                    if (Directory.Exists(appSetting))
                    {
                        _scannerImagesUNC = appSetting;
                    }
                    else
                    {
                        _scannerImagesUNC = "";
                        _logger.LogError("ScannerImagesUNC (UNC Path) (" + _scannerImagesUNC + ") does not exist!");
                        throw new ConfigurationErrorsException("ScannerImagesUNC (UNC Path) (" + _scannerImagesUNC + ") does not exist!");
                        //We won't get here since its called in a main thread (not on an Asynch Callback)
                        // Use this since we are a console app
                        //System.Environment.Exit(3); //ERROR_PATH_NOT_FOUND
                    }
                }

                //<add key="PickToLightBanderDisplayHost" value="10.2.9.23" />
                //Read in the PickToLightBanderDisplayHost
                appSetting = GetSetting("PickToLightBanderDisplayHost");
                //if(String.IsNullOrEmpty(appSetting))
                if (appSetting.Length == 0)
                {
                    //_pickToLightBanderDisplayIP = "";
                    _pickToLightBanderDisplayIP = null;
                    throw new ConfigurationErrorsException("PickToLightBanderDisplayHost is missing or empty!");
                    //We won't get here since its called in a main thread (not on an Asynch Callback)
                    // Use this since we are a console app
                    //System.Environment.Exit(1);
                }
                else
                {
                    _pickToLightBanderDisplayHost = appSetting.ToUpper();
                    if (_pickToLightBanderDisplayHost == "DISABLED")
                    {
                        _pickToLightBanderDisplayIP = null;
                    }
                    else
                    {
                        //Lookup the IP address
                        //IPAddress[] ipAddress = Dns.GetHostAddresses(_pickToLightBanderDisplayHost);
                        //if (ipAddress.Count() == 0)
                        //{
                        //    //_pickToLightBanderDisplayIP = "";
                        //    _pickToLightBanderDisplayIP = null;
                        //    _logger.LogError("Unable to get IP for PickToLightBanderDisplayHost(" + _pickToLightBanderDisplayHost + ")!");
                        //    throw new ConfigurationErrorsException("Unable to get IP for PickToLightBanderDisplayHost (" + _pickToLightBanderDisplayHost + ")!");
                        //}
                        ////else if (System.Net.IPAddress.TryParse(ipAddress[0].ToString(), out _pickToLightBanderDisplayIP) == false)
                        //else
                        //{
                        //    IPAddress ip = null;
                        //    if (GetResolvedConnecionIPAddress(_pickToLightBanderDisplayHost, out _pickToLightBanderDisplayIP)) //Use this method, becasue "GetHostAddresses" returns IPV6, IPV4, etc.
                        //    {
                        //        ///Your Code
                        //    }

                        //    throw new ConfigurationErrorsException("PickToLightBanderDisplayHost can't be parsed into a valid IP!");
                        //}

                        if (Misc.GetResolvedConnectionIPAddress(_pickToLightBanderDisplayHost, out _pickToLightBanderDisplayIP) == false) //Use this method, becasue "GetHostAddresses" returns IPV6, IPV4, etc.
                        {
                            _logger.LogError("Unable to resolve IP for PickToLightBanderDisplayHost(" + _pickToLightBanderDisplayHost + ")!");
                            throw new ConfigurationErrorsException("Unable to resolve IP for PickToLightBanderDisplayHost (" + _pickToLightBanderDisplayHost + ")!");
                        }

                    }
                }

                //Log all the Settings loaded to the EventLog
                //_logger.LogMainEvent("LogMode = (" + _logger.LogMode.ToString() + "), LogFolder = (" + _logger.LogFolder + "), PickToLightServerIP = (" + _pickToLightServerIP + "), ScannerName = (" + _scannerName + "), ScannerIP = (" + _scannerIP + "), ScannerPassword = (" + _scannerPassword + "), ScannerImages (Folder) = (" + _scannerImages + "), ScannerImagesUNC (UNC Path) = (" + _scannerImagesUNC + "), PickToLightBanderDisplayHost = (" + _pickToLightBanderDisplayHost + " IP=" + _pickToLightBanderDisplayIP + ")");
                _logger.LogMainEvent("LogMode = (" + _logger.LogMode.ToString() + "), LogFolder = (" + _logger.LogFolder + "), PickToLightServerIP = (" + _pickToLightServerIP + "), ScannerName = (" + _scannerName + "), ScannerIP = (" + _scannerIP + "), ScannerPassword = (" + _scannerPassword + "), ScannerImages (Folder) = (" + _scannerImages + "), ScannerImagesUNC (UNC Path) = (" + _scannerImagesUNC + "), PickToLightBanderDisplayHost = (" + _pickToLightBanderDisplayHost + (_pickToLightBanderDisplayIP == null ? "" : " Resolved to IP: " + _pickToLightBanderDisplayIP.ToString()) + ")"); //+ " IP=" + _pickToLightBanderDisplayIP + ")");
            }
            catch (Exception e)
            {
                _logger.LogError("Exception in LoadSettings: " + e.Message);
                throw new ConfigurationErrorsException("Exception in LoadSettings: " + e.Message);
                //We won't get here since its called in a main thread (not on an Asynch Callback)
                // Use this since we are a console app
                //System.Environment.Exit(1);
            }
        }

        private static string GetSetting(string appSetting)
        {
            
            if( ConfigurationManager.AppSettings == null)
            {
                return "";
            }
            if (ConfigurationManager.AppSettings.Get(appSetting) == null)
            {
                return "";
            }

            return ConfigurationManager.AppSettings.Get(appSetting);
        }

        //public static bool GetResolvedConnectionIPAddress(string serverNameOrURL, out IPAddress resolvedIPAddress)
        //{
        //    bool isResolved = false;
        //    IPHostEntry hostEntry = null;
        //    IPAddress resolvIP = null;
        //    try
        //    {
        //        if (!IPAddress.TryParse(serverNameOrURL, out resolvIP))
        //        {
        //            hostEntry = Dns.GetHostEntry(serverNameOrURL);

        //            if (hostEntry != null && hostEntry.AddressList != null && hostEntry.AddressList.Length > 0)
        //            {
        //                if (hostEntry.AddressList.Length == 1)
        //                {
        //                    resolvIP = hostEntry.AddressList[0];
        //                    isResolved = true;
        //                }
        //                else
        //                {
        //                    foreach (IPAddress var in hostEntry.AddressList)
        //                    {
        //                        if (var.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork) //This is for IPV4!!
        //                        {
        //                            resolvIP = var;
        //                            isResolved = true;
        //                            break;
        //                        }
        //                    }
        //                }
        //            }
        //        }
        //        else
        //        {
        //            isResolved = true;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        isResolved = false;
        //        resolvIP=null;
        //    }
        //    finally
        //    {
        //        resolvedIPAddress = resolvIP;
        //    }

        //    return isResolved;
        //}

        #region Scanner

        //Start Bander Scanner this way?
        private void BanderScannerConnectThread(object state)
        {
            Thread.CurrentThread.Name = "BanderScannerConnectThread";
            _logger.LogMainEvent("The Bander Scanner Connection Thread has started.");

            if (_scannerIP.Length > 10 && _scannerIP.Split('.').Length == 4) //At least 11 characters (10.10.10.10) and 3 periods/dots.
            {
                StartBanderScanner(_scannerIP);
            }
            else
            {
                //_logger.LogToEventLog("The ScannerIP setting has (" + _scannerIP.Split('.').Length.ToString() + ") periods!");
                _logger.LogError("The ScannerIP setting (" + _scannerIP + ") is invalid or not specified!");
                return;
            }

            DateTime lastLogTime = DateTime.Now.AddHours(-1.0D);  //Use this to prevent too many entries in the log!! Set to 1 Hour ago to force logging on first pass...

            // Periodically check if the service is stopping. 
            while (!this.stopping) //This can be a "spin-wait", which is very BAD. Need a "sleep" or "wait" in the block below to prevent that!.
            {
                //If we haven't "logged" anything in 10 minutes, lets write to the log to show its still running!
                TimeSpan timeElapsed = DateTime.Now.Subtract(lastLogTime);
                if (timeElapsed.TotalMinutes > 10.0D)
                {
                    lastLogTime = DateTime.Now;
                    _logger.Log("Heartbeat from BanderScannerConnectThread() at " + lastLogTime.ToString());
                }

                //        // Perform main service function here... 
                //        // BUT, only the Synchronous Actions!

                //        //Thread.Sleep(2000);  // Simulate some lengthy operations. 

                //Thread.Sleep(10); //Give the processor some down time so this thread doesn't use 100%. This prevents the while loop above from being a "spin-wait".
                //System.Threading.EventWaitHandle eventWaitHandle = new EventWaitHandle();
                //eventWaitHandle.WaitOne(10);
                if (this.stoppedEvent.WaitOne(10)) //returns false if the wait ended because of a timeout
                {
                    _logger.LogMainEvent("WaitOne ended due to signalling, not due to a timeOut! (stopping = " + stopping.ToString() + ") in  BanderScannerConnectThread() at " + DateTime.Now.ToString());
                }
            }

            _logger.Log("Left while loop (stopping = " + stopping.ToString() + ") in BanderScannerConnectThread() at " + DateTime.Now.ToString());

            //Prevent ReConnecting to Transfer Scanner!
            _autoconnectScanner = false;

            // Signal the stopped event. 
            this.stoppedEvent.Set();

            _logger.LogMainEvent("Leaving BanderScannerConnectThread() (stopping = " + stopping.ToString() + ") at " + DateTime.Now.ToString());
        }

        public void StartBanderScanner(string scannerIP) //Based off "ConnectToIP()" from PickToLightServer (WinForm, GUI App)
        {
            try
            {
                System.Net.IPAddress ipAddress = System.Net.IPAddress.Parse(scannerIP);
                EthSystemConnector conn = new EthSystemConnector(ipAddress);

                conn.UserName = "admin";
                conn.Password = _scannerPassword;

                _connector = conn;

                _scanner = new DataManSystem(_connector);
                _scanner.DefaultTimeout = 5000;

                // Subscribe to events that are signalled when the system is connected / disconnected.
                _scanner.SystemConnected += new SystemConnectedHandler(OnSystemConnected);
                _scanner.SystemDisconnected += new SystemDisconnectedHandler(OnSystemDisconnected);
                _scanner.SystemWentOnline += new SystemWentOnlineHandler(OnSystemWentOnline); //This is for Handhelds, shouldn't occur here.
                _scanner.SystemWentOffline += new SystemWentOfflineHandler(OnSystemWentOffline); //This is for Handhelds, shouldn't occur here.
                _scanner.KeepAliveResponseMissed += new KeepAliveResponseMissedHandler(OnKeepAliveResponseMissed);
                _scanner.BinaryDataTransferProgress += new BinaryDataTransferProgressHandler(OnBinaryDataTransferProgress);
                _scanner.OffProtocolByteReceived += new OffProtocolByteReceivedHandler(OffProtocolByteReceived);
                _scanner.AutomaticResponseArrived += new AutomaticResponseArrivedHandler(AutomaticResponseArrived);

                // Subscribe to events that are signalled when the device sends auto-responses.
                //ResultTypes requested_result_types = ResultTypes.ReadXml | ResultTypes.Image | ResultTypes.ImageGraphics;
                ResultTypes requested_result_types = ResultTypes.ReadXml | ResultTypes.Image;
                _scannerResults = new ResultCollector(_scanner, requested_result_types);
                _scannerResults.ComplexResultCompleted += Results_ComplexResultCompleted;
                _scannerResults.SimpleResultDropped += Results_SimpleResultDropped;

                //_scanner.SetKeepAliveOptions(cbEnableKeepAlive.Checked, 3000, 1000);
                _scanner.SetKeepAliveOptions(_scannerKeepAlive, _scannerKeepAliveTimeout,  _scannerKeepAliveInterval);  //Probably should use "app.config" properties for these.

                _scanner.Connect();

                try
                {
                    _scanner.SetResultTypes(requested_result_types);
                }
                catch
                { }
            }
            catch (Exception ex)
            {
                CleanupConnection();

                _logger.LogError("Exception ERROR in StartBanderScanner(). Unable to connect to Scanner!");
            }
        }

        public void ReconnectBanderScanner() //Created from StartBanderScanner
        {
            //Created from StartTransferScanner
            try
            {
                //System.Net.IPAddress ipAddress = System.Net.IPAddress.Parse(scannerIP);
                //EthSystemConnector conn = new EthSystemConnector(ipAddress);

                //conn.UserName = "admin";
                //conn.Password = _scannerPassword;

                //_connector = conn;

                //_scanner = new DataManSystem(_connector);
                //_scanner.DefaultTimeout = 5000;

                //// Subscribe to events that are signalled when the system is connected / disconnected.
                //_scanner.SystemConnected += new SystemConnectedHandler(OnSystemConnected);
                //_scanner.SystemDisconnected += new SystemDisconnectedHandler(OnSystemDisconnected);
                //_scanner.SystemWentOnline += new SystemWentOnlineHandler(OnSystemWentOnline); //This is for Handhelds, shouldn't occur here.
                //_scanner.SystemWentOffline += new SystemWentOfflineHandler(OnSystemWentOffline); //This is for Handhelds, shouldn't occur here.
                //_scanner.KeepAliveResponseMissed += new KeepAliveResponseMissedHandler(OnKeepAliveResponseMissed);
                //_scanner.BinaryDataTransferProgress += new BinaryDataTransferProgressHandler(OnBinaryDataTransferProgress);
                //_scanner.OffProtocolByteReceived += new OffProtocolByteReceivedHandler(OffProtocolByteReceived);
                //_scanner.AutomaticResponseArrived += new AutomaticResponseArrivedHandler(AutomaticResponseArrived);

                //// Subscribe to events that are signalled when the device sends auto-responses.
                ////ResultTypes requested_result_types = ResultTypes.ReadXml | ResultTypes.Image | ResultTypes.ImageGraphics;
                ResultTypes requested_result_types = ResultTypes.ReadXml | ResultTypes.Image;
                _scannerResults = new ResultCollector(_scanner, requested_result_types);
                _scannerResults.ComplexResultCompleted += Results_ComplexResultCompleted;
                _scannerResults.SimpleResultDropped += Results_SimpleResultDropped;

                ////_scanner.SetKeepAliveOptions(cbEnableKeepAlive.Checked, 3000, 1000);
                //_scanner.SetKeepAliveOptions(_scannerKeepAlive, _scannerKeepAliveTimeout, _scannerKeepAliveInterval);  //Probably should use "app.config" properties for these.

                DateTime lastLogTime = DateTime.Now.AddHours(-1.0D);  //Use this to prevent too many entries in the log!! Set to 1 Hour ago to force logging on first pass...

                //Check "this.stopping", so this blocking call can be stopped when the Service is stopped!!
                while (!this.stopping && _scanner != null && _scanner.State != Cognex.DataMan.SDK.ConnectionState.Connected)
                {
                    try
                    {
                        //If we haven't "logged" anything in 10 minutes, lets write to the log to show its still running!
                        TimeSpan timeElapsed = DateTime.Now.Subtract(lastLogTime);
                        if (timeElapsed.TotalMinutes > 10.0D)
                        {
                            lastLogTime = DateTime.Now;
                            _logger.LogMainEvent("Trying to Re-Connect to Scanner at " + lastLogTime.ToString());
                        }
                        _scanner.Connect(3000); //Try to connect for up to 3000 milliseconds (3 seconds)
                        try
                        {
                            _scanner.SetResultTypes(requested_result_types);
                        }
                        catch
                        { }
                    }
                    catch
                    {
                        if (this.stoppedEvent.WaitOne(2000)) //Wait up to 2000 milliseconds (2 seconds) before trying to Connect() again, returns false if the wait ended because of a timeout
                        {
                            _logger.LogMainEvent("WaitOne ended due to signalling, not due to a timeOut! (stopping = " + stopping.ToString() + ") in  ReconnectBanderScanner() at " + DateTime.Now.ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                CleanupConnection();

                _logger.LogError("Exception ERROR in ReconnectBanderScanner(). Unable to Re-Connect to Scanner!");
            }
        }

        //Let's not ReConnect using a new Thread, we can use the regular "BanderScannerConnectThread"!
        //private void BanderScannerReConnectThread(object state)
        //{
        //    //TODO: Look at the info from Cognex Tech Support. Does this need to be changed to work like they described?

        //    Thread.CurrentThread.Name = "BanderScannerReConnectThread";
        //    _logger.LogMainEvent("The Bander Scanner Re-Connection Thread has started!");

        //    DateTime lastLogTime = DateTime.Now;

        //    // Periodically check if the service is stopping. 
        //    while (!this.stopping) //This can be a "spin-wait", which is very BAD. Need a "sleep" or "wait" in the block below to prevent that!.
        //    {
        //        //If we haven't "logged" anything in 10 minutes, lets write to the log to show its still running!
        //        TimeSpan timeElapsed = DateTime.Now.Subtract(lastLogTime);
        //        if (timeElapsed.TotalMinutes > 10.0D)
        //        {
        //            lastLogTime = DateTime.Now;
        //            _logger.Log("Heartbeat from BanderScannerReConnectThread() at " + lastLogTime.ToString());
        //        }
        //        try
        //        {
        //            _logger.LogMainEvent("Attempting to Re-Connect in \"BanderScannerReConnectThread\"...");
        //            _scanner.Connect();
        //        }
        //        catch
        //        {
        //            //TODO: Is this entire catch block correct? Test by unplugging the Scanner... this should keep trying, then stop the service.. did it all work correctly? Did it keep trying to connect?
        //            _logger.LogError("Unable to Re-Connect in \"BanderScannerReConnectThread\", trying again in half a second...");
        //            //Thread.Sleep(500);
        //            if (this.stoppedEvent.WaitOne(500)) //returns false if the wait ended because of a timeout
        //            {
        //                _logger.Log("WaitOne ended due to signalling, not due to a timeOut! (stopping = " + stopping.ToString() + ") in  BanderScannerReConnectThread() at " + DateTime.Now.ToString());
        //            }
        //            continue;
        //        }
        //        break; //TODO: Does this break belong here???
        //    }

        //    //Prevent ReConnecting to Scanner!
        //    _autoconnectScanner = false;

        //    // Signal the stopped event. 
        //    this.stoppedEvent.Set();
        //}

        //This should probably only be called if we decide to handle "Disconnect" in the "OnKeepAliveResponseMissed" handler!
        //private void DisconnectConnection()
        //{
        //    try
        //    {
        //        if (_scanner == null || _scanner.State != Cognex.DataMan.SDK.ConnectionState.Connected)
        //        {
        //            return;
        //        }

        //        //_autoconnectScanner = false;
        //        _scanner.Disconnect();

        //        CleanupConnection();

        //        _scannerResults.ClearCachedResults();
        //        _scannerResults = null;
        //    }
        //    finally
        //    {
        //        //RefreshGui();
        //    }
        //}

        private void CleanupConnection()
        {
            if (null != _scanner)
            {
                _scanner.SystemConnected -= OnSystemConnected;
                _scanner.SystemDisconnected -= OnSystemDisconnected;
                _scanner.SystemWentOnline -= OnSystemWentOnline; //This is for Handhelds, shouldn't occur here.
                _scanner.SystemWentOffline -= OnSystemWentOffline; //This is for Handhelds, shouldn't occur here.
                _scanner.KeepAliveResponseMissed -= OnKeepAliveResponseMissed;
                _scanner.BinaryDataTransferProgress -= OnBinaryDataTransferProgress;
                _scanner.OffProtocolByteReceived -= OffProtocolByteReceived;
                _scanner.AutomaticResponseArrived -= AutomaticResponseArrived;
            }

            _connector = null;
            _scanner = null;
        }

        #region Scanner Results

        private void Results_ComplexResultCompleted(object sender, ComplexResult e)
        {
            _logger.Log("Scanner Results Event: \"ComplexResultCompleted\"!");
            ProcessResult(e);
        }

        private void Results_SimpleResultDropped(object sender, SimpleResult e)
        {
            _logger.LogError("Scanner Results Event: \"SimpleResultDropped\": " + string.Format("Partial result dropped: {0}, id={1}", e.Id.Type.ToString(), e.Id.Id));
        }

        private void ProcessResult(ComplexResult complexResult)
        {
            List<Image> images = new List<Image>();
            List<string> image_graphics = new List<string>();
            string read_result = null;
            int result_id = -1;
            ResultTypes collected_results = ResultTypes.None;

            // Take a reference or copy values from the locked result info object.
            // This is done so that the lock is used only for a short period of time.
            lock (_currentResultInfoSyncLock)
            {
                foreach (var simple_result in complexResult.SimpleResults)
                {
                    collected_results |= simple_result.Id.Type;

                    switch (simple_result.Id.Type)
                    {
                        case ResultTypes.Image:
                            Image image = ImageArrivedEventArgs.GetImageFromImageBytes(simple_result.Data);
                            if (image != null)
                                images.Add(image);
                            break;

                        case ResultTypes.ImageGraphics:
                            image_graphics.Add(simple_result.GetDataAsString());
                            break;

                        case ResultTypes.ReadXml:
                            read_result = GetReadStringFromResultXml(simple_result.GetDataAsString());
                            result_id = simple_result.Id.Id;
                            break;

                        case ResultTypes.ReadString:
                            read_result = simple_result.GetDataAsString();
                            result_id = simple_result.Id.Id;
                            break;
                    }
                }
            }

            _logger.Log(string.Format("Complex result arrived: resultId = {0}, read result = {1}, images {2}", result_id, read_result, images.Count.ToString()));
            _logger.Log(string.Format("Complex result contains: {0}", collected_results.ToString()));

            string resultImageFolderPath = "";

            if (images.Count > 0)
            {
                //Create a folder to store all the images from this Result!
                //resultImageFolderPath = _scannerImages + (_scannerImages.EndsWith("\\") ? "" : "\\");
                //Directory.CreateDirectory(resultImageFolderPath);
                //resultImageFolderPath = resultImageFolderPath + DateTime.Now.Year.ToString("0000") + DateTime.Now.Month.ToString("00") + DateTime.Now.Day.ToString("00") + "\\";
                //DirectoryInfo di = Directory.CreateDirectory(resultImageFolderPath);
                //resultImageFolderPath = resultImageFolderPath + result_id.ToString() + "\\";
                //Directory.CreateDirectory(resultImageFolderPath);
                //resultImageFolderPath = String.Format("{0}{1}{2}{3}{4}{5}{6}{7}", _scannerImages, (_scannerImages.EndsWith("\\") ? "" : "\\"),
                //            DateTime.Now.Year.ToString("0000"), DateTime.Now.Month.ToString("00"), DateTime.Now.Day.ToString("00"), "\\",
                //            result_id.ToString(), "\\");
                resultImageFolderPath = _scannerImages + (_scannerImages.EndsWith("\\") ? "" : "\\") +
                                DateTime.Now.Year.ToString("0000") + DateTime.Now.Month.ToString("00") + DateTime.Now.Day.ToString("00") + "\\" +
                                result_id.ToString() + "\\";
                try
                { 
                    DirectoryInfo di = Directory.CreateDirectory(resultImageFolderPath); //This will create ALL directories in the full path.
                    if (di.Exists == false)
                    {
                        _logger.LogError("Error creating directory to store images: " + resultImageFolderPath + "!!!");
                        //throw new ConfigurationErrorsException("Error creating directory: " + resultImageFolderPath + "!!!");
                        //Instead of throwing an Exception, need to EXIT, because this is called as an Asynch handler (not on the main thread)!
                        // Use this since we are a console app
                        //--11-9-17 - Wait! This shouldn't cause an actual EXIT!!! Just keep on going....
                        //System.Environment.Exit(82); //ERROR_CANNOT_MAKE
                    }
                    else
                    {
                        int i = 0;
                        foreach (var image in images)
                        {
                            //_logger.Log(string.Format("Complex result, saving image {0}", i.ToString()));
                            image.Save(resultImageFolderPath + i.ToString() + ".jpg", System.Drawing.Imaging.ImageFormat.Jpeg);
                            i++;
                        }
                        //Using too much space in database! Just Log the total, not each image.
                        _logger.Log(string.Format("Complex result, saved {0} images", i.ToString()));
                        //Replace image path with the UNC SHARE name!
                        //Lets get a UNC, for example "ScannerImagesUNC". (Will need an app.config setting!)
                        //resultImageFolderPath = resultImageFolderPath.Replace("D:\\", "\\\\HQ-SPTEST01");
                        resultImageFolderPath = resultImageFolderPath.Replace(_scannerImages, _scannerImagesUNC);
                    }
                }
                catch (Exception ex)
                {
                    if (ex.InnerException != null)
                    {
                        _logger.LogError("Exception creating the directory (" + resultImageFolderPath + ") to store the images: " + ex.Message + " (Inner Exception: " + ex.InnerException + ")");
                    }
                    else
                    {
                        _logger.LogError("Exception creating the directory (" + resultImageFolderPath + ") to store the images: " + ex.Message);
                    }
                    //throw new ConfigurationErrorsException("Error creating directory to store the images: " + resultImageFolderPath + "!!!");
                    //Instead of throwing an Exception, need to EXIT, because this is called as an Asynch handler (not on the main thread)!
                    // Use this since we are a console app
                    //--11-9-17 - Wait! This shouldn't cause an actual EXIT!!! Just keep on going....
                    //System.Environment.Exit(82); //ERROR_CANNOT_MAKE
                }
            }

            try
            {
                _logger.Log("Creating Scan Entry for resultId " + result_id);
                ProcessScan(result_id, read_result, resultImageFolderPath);
                //if (read_result != null)
                //{
                //    //Use the right values/settings!!
                //    PickToLightData.ScanOWK.CreateScanEntry(_scannerName, _scannerName, _scannerName, result_id.ToString(), read_result, resultImageFolderPath);
                //}
                //else
                //{
                //    //Use the right values/settings!!
                //    PickToLightData.ScanOWK.CreateScanEntry(_scannerName, _scannerName, _scannerName, result_id.ToString(), "NO Barcode in Result, possibly due to network communication timing, device error or system error.", resultImageFolderPath);
                //}
            }
            catch (Exception ex)
            {
                if (ex.InnerException != null)
                {
                    _logger.LogError("Exception creating the Scan Entry: " + ex.Message + " (Inner Exception: " + ex.InnerException + ")");
                }
                else
                {
                    _logger.LogError("Exception creating the Scan Entry: " + ex.Message);
                }
            }
        }

        private void ProcessScan(int resultID, string barcode, string imagePath)
        {
            //Do all of this, or even each of these in a seperate thread???
            //
            //Create a Scan Entry in the SQL table.
            //Send the "BanderDisplayCommand" to the PickToLightBanderDisplay.
            //

            //ThreadPool.QueueUserWorkItem(new WaitCallback(TransferScannerReConnectThread));

            //if (barcode != null)
            //{
            //    int entryID = PickToLightData.ScanOWK.CreateScanEntry(_scannerName, _scannerName, _scannerName, resultID.ToString(), barcode, imagePath);
            //    //if (barcode.StartsWith("C") && barcode.Length >= 250)  //A valid read will start with a "C" and will be 250 characters.
            //    //{
            //    //    SendBanderDisplayCommand(true, entryID); //Actually, we know if the scan was successful using the boolean column "decoded" in the SQL table...
            //    //}
            //    //else
            //    //{
            //    //    SendBanderDisplayCommand(false, entryID); //Actually, we know if the scan was successful using the boolean column "decoded" in the SQL table...
            //    //}
            //    //if (_pickToLightBanderDisplayHost.ToUpper() != "DISABLED") //The _pickToLightBanderDisplayIP will be NULL and SendBanderDisplayCommand will handle this....
            //    //{
            //        SendBanderDisplayCommand(entryID); //Actually, we know if the scan was successful using the boolean column "decoded" in the SQL table...
            //    //}
            //}
            //else
            //{
            //    //I don't think this needs to be communicated to the PickToLightBanderDisplay...
            //    //Create Entry in SQL...
            //    PickToLightData.ScanOWK.CreateScanEntry(_scannerName, _scannerName, _scannerName, resultID.ToString(), "NO Barcode in Result, possibly due to network communication timing, device error or system error.", imagePath);
            //}

            try
            {
                if (barcode != null)
                {
                    //Create Entry in SQL...
                    int entryID = PickToLightData.ScanOWK.CreateScanEntry(_scannerName, _scannerName, _scannerName, resultID.ToString(), barcode, imagePath);
                    SendBanderDisplayCommand(entryID); //Actually, we know if the scan was successful using the boolean column "decoded" in the SQL table...
                }
                else
                {
                    //I don't think this needs to be communicated to the PickToLightBanderDisplay...
                    //Create Entry in SQL...
                    PickToLightData.ScanOWK.CreateScanEntry(_scannerName, _scannerName, _scannerName, resultID.ToString(), "NO Barcode in Result, possibly due to network communication timing, device error or system error.", imagePath);
                }
            }
            catch (Exception ex)
            {
                if (ex.InnerException != null)
                {
                    //_logger.LogError("Exception in ProcessScan()" + (barcode == null ? " (No Barcode in Result!) " : "") + "_scannerName (" + _scannerName + "), resultID (" + resultID.ToString() + (barcode == null ? ")." : "), imagePath (" + imagePath + ").") +  " Exception: " + ex.Message + " (Inner Exception: " + ex.InnerException + ")");
                    _logger.LogError("Exception in ProcessScan()" + (barcode == null ? " (No Barcode in Result!) " : "") + "_scannerName (" + _scannerName + "), resultID (" + resultID.ToString() + "), imagePath (" + imagePath + "). Exception: " + ex.Message + " (Inner Exception: " + ex.InnerException + ")");
                }
                else
                {
                    //_logger.LogError("Exception in ProcessScan()" + (barcode == null ? " (No Barcode in Result!) " : "") + "_scannerName (" + _scannerName + "), resultID (" + resultID.ToString() + (barcode == null ? ")." : "), imagePath (" + imagePath + ").") +  " Exception: " + ex.Message);
                    _logger.LogError("Exception in ProcessScan()" + (barcode == null ? " (No Barcode in Result!) " : "") + "_scannerName (" + _scannerName + "), resultID (" + resultID.ToString() + "), imagePath (" + imagePath + "). Exception: " + ex.Message);
                }
            }
        }

        private void SendBanderDisplayCommand(int entryID)
        {
            //if (_pickToLightServerIP.Length > 10 && _pickToLightServerIP.Split('.').Length == 4) //At least 11 characters (10.10.10.10) and 3 periods/dots.
            if (_pickToLightBanderDisplayIP != null)
            {
                string commandToSend = "";
                commandToSend = PickToLightCommands.PopulateBanderDisplayCommand(entryID);

                TCPClient tcpClient = new TCPClient(_logger, _pickToLightBanderDisplayIP, _pickToLightBanderDisplayPort);
                StringBuilder commandResponse = new StringBuilder();
                tcpClient.SendCommand(commandToSend, commandResponse);
            }
            //else
            //{
            //    _logger.LogError("The PickToLightBanderDisplayIP setting is invalid or not specified! (This shouldn't get this far, it should be caught when Loading the settings during startup!)");
            //    return;
            //}
        }

        private string GetReadStringFromResultXml(string resultXml)
        {
            try
            {
                XmlDocument doc = new XmlDocument();

                doc.LoadXml(resultXml);

                XmlNode full_string_node = doc.SelectSingleNode("result/general/full_string");

                if (full_string_node != null && _scanner != null && _scanner.State == Cognex.DataMan.SDK.ConnectionState.Connected)
                {
                    XmlAttribute encoding = full_string_node.Attributes["encoding"];
                    if (encoding != null && encoding.InnerText == "base64")
                    {
                        if (!string.IsNullOrEmpty(full_string_node.InnerText))
                        {
                            byte[] code = Convert.FromBase64String(full_string_node.InnerText);
                            return _scanner.Encoding.GetString(code, 0, code.Length);
                        }
                        else
                        {
                            return "";
                        }
                    }

                    return full_string_node.InnerText;
                }
            }
            catch
            {
            }

            return "";
        }

        #endregion //Scanner Results

        #region Scanner Events

        private void OnSystemConnected(object sender, EventArgs args)
        {
            //Enable ReConnecting to Bander Scanner!
            _autoconnectScanner = true;

            _logger.LogMainEvent("BanderScanner Event: \"SystemConnected\"!");

            _logger.Log("Setting scanner to get all the images!");
            _scanner.SendCommand("SET CAMERA.BURST-TRANSFER-ALL ON");
        }

        private void OnSystemDisconnected(object sender, EventArgs args)
        {
            Thread.CurrentThread.Name = "ReconnectBanderScanner";
            //_logger.LogMainEvent("BanderScanner Event: \"SystemDisconnected\"!");
                        //No, lets log this as an ERROR!
            //The "System Center Operations Manager" will email an alert!
            _logger.LogError("BanderScanner Event: \"SystemDisconnected\"!");

            if (_autoconnectScanner) //Make sure the Service wasn't stopped on purpose....
            {
                //Start up a Reconnect Thread (BanderScannerReConnectThread) and try to reconnect every half second (500 milliseconds)
                //
                //NO!!! I don't think we need a new Thread! Let's just keep using this Tread and try to ReConnect!!
                //
                //ThreadPool.QueueUserWorkItem(new WaitCallback(BanderScannerReConnectThread));
                ReconnectBanderScanner();
            }
            else
            {
                _logger.LogMainEvent("NOT reconnecting, the service must be stopping...");
            }

        }

        private void OnKeepAliveResponseMissed(object sender, EventArgs args)
        {
            _logger.LogMainEvent("BanderScanner Event: \"KeepAliveResponseMissed\"!");

            //Should we go ahead and Disconnect/Connect, since we aren't getting a Keep Alive Acknowledgement.

            //First, see if we need to Disconnect.

            //Then (if not Connected??), try Re-Connecting!

            //TODO: KeepAliveResponseMissed, from Cognex Tech Support!
            //
            //“What is the proper way to handle this event?”
                //The safest way to handle this event it so call the Disconnect function and destroy the DatamanSystem object.
                //After this object is created, you will need to call connect and call setResultTypes.
            //Before calling “Disconnect()” and/or “Connect()”, do I need to check the “State” property to see if the system is “Connected”?
            //What if it IS?
            //What if it ISN’T?
                //Yes you should check the state of the system any time you try to connect to it. This function call is blocking, by the way.
            //Do I need to check for “SystemDisconnected” and/or “SystemWentOffline”? (Or, will the “State” property be changed to “Disconnected” if one of those has occurred?)
                //The state will change but it is best to handle the event as well. Either throw an exception or try reconnecting.
            //What is the difference between the events,  “SystemWentOffline” and “SystemDisconnected”?
                //SystemWentOffline is specifically for our handheld readers when they leave the range of the base station or lose connection with the base.
                //SystemDisconnected is used for our fixed mount readers and the base stations for handhelds. SystemDisconnected is the one you should be paying attention to.
            //Also, considering this event was thrown over and over, is it possible the device was no longer “Connected”? (Since clicking Disconnect and Connect “fixed” the problem.)
                //You are correct, this is exactly what happened.
            //Finally, what if I didn’t turn on “Keep Alive”? (What events/scenarios do I need to “handle”?)
                //If keep alive wasn't turned on, you would only receive the systemDisconnected event.
                //You would handle this normally like described above.
                //Have keep alive turned on will try to keep the connection alive, and continually throw the Keep alive missed event if you are disconnected.
        }

        private void OnSystemWentOnline(object sender, EventArgs args)
        {
            //This is for Handhelds, shouldn't occur here.
            _logger.LogMainEvent("BanderScanner Event: \"SystemWentOnline\"!");
        }

        private void OnSystemWentOffline(object sender, EventArgs args)
        {
            //This is for Handhelds, shouldn't occur here.
            _logger.LogError("BanderScanner Event: \"SystemWentOffline\"!");
        }

        private void OnBinaryDataTransferProgress(object sender, BinaryDataTransferProgressEventArgs args)
        {
            _logger.Log("BanderScanner Event: \"BinaryDataTransferProgress\": " + string.Format("{0}: {1}% of {2} bytes (Type={3}, Id={4})", args.Direction == TransferDirection.Incoming ? "Receiving" : "Sending", args.TotalDataSize > 0 ? (int)(100 * (args.BytesTransferred / (double)args.TotalDataSize)) : -1, args.TotalDataSize, args.ResultType.ToString(), args.ResponseId));
        }

        private void OffProtocolByteReceived(object sender, OffProtocolByteReceivedEventArgs args)
        {
            _logger.LogError("BanderScanner Event: \"OffProtocolByteReceived\": " + (char)args.Byte);
        }

        private void AutomaticResponseArrived(object sender, AutomaticResponseArrivedEventArgs args)
        {
            _logger.Log("BanderScanner Event: \"AutomaticResponseArrived\": " + string.Format("Type={0}, Id={1}, Data={2} bytes", args.DataType.ToString(), args.ResponseId, args.Data != null ? args.Data.Length : 0));
        }

        #endregion //#region Scanner Events

        #endregion //#region Scanner
    }
}

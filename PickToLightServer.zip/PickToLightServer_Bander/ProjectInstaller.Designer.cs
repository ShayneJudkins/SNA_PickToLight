﻿using System.IO;
using System.Reflection;
using System.Xml;
namespace SNA.WinService.PickToLightServer
{
    partial class ProjectInstaller
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.serviceProcessInstaller1 = new System.ServiceProcess.ServiceProcessInstaller();
            this.serviceInstaller1 = new System.ServiceProcess.ServiceInstaller();
            // 
            // serviceProcessInstaller1
            // 
            this.serviceProcessInstaller1.Account = System.ServiceProcess.ServiceAccount.NetworkService;
            this.serviceProcessInstaller1.Password = null;
            this.serviceProcessInstaller1.Username = null;
            // 
            // serviceInstaller1
            // 
            this.serviceInstaller1.ServiceName = "PickToLightServer_Bander";
            this.serviceInstaller1.Description = "PickToLightServer Service that controls ONE of the scanners at the end of the conveyor, that verfies the part/tote is at the correct Banding Machine. One instance is installed for each Bander!";

            //Call SetServiceName() to use a custom ServiceName and DisplayName defined in the "config" file.
            //This will allow installing multiple copies of this Service (each copy will need its own directory).
            SetServiceName();

            // 
            // ProjectInstaller
            // 
            this.Installers.AddRange(new System.Configuration.Install.Installer[] {
            this.serviceProcessInstaller1,
            this.serviceInstaller1});

        }

        #endregion

        private void SetServiceName()
        {
            string configurationFilePath = Path.ChangeExtension(Assembly.GetExecutingAssembly().Location, "exe.config");
            XmlDocument doc = new XmlDocument();
            doc.Load(configurationFilePath);

            XmlNode serviceName = doc.SelectSingleNode("//appSettings//add[@key='ServiceName']");
            XmlNode displayName = doc.SelectSingleNode("//appSettings//add[@key='DisplayName']");


            if (serviceName != null && (serviceName.Attributes != null && (serviceName.Attributes["value"] != null)))
            {
                this.serviceInstaller1.ServiceName = serviceName.Attributes["value"].Value;
            }
            //else
            //{
            //    this.serviceInstaller1.ServiceName = "Custom.Service.Name";
            //}

            if (displayName != null && (displayName.Attributes != null && (displayName.Attributes["value"] != null)))
            {
                this.serviceInstaller1.DisplayName = displayName.Attributes["value"].Value;
            }
            //else
            //{
            //    this.serviceInstaller1.DisplayName = "Custom.Service.DisplayName";
            //}
        }


        private System.ServiceProcess.ServiceProcessInstaller serviceProcessInstaller1;
        private System.ServiceProcess.ServiceInstaller serviceInstaller1;
    }
}
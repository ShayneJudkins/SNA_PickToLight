﻿using PickToLightData;
using SNA.WinService.PickToLightServer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PickToLightServer_TestHarness
{
    public partial class MainForm : Form
    {

        private static Logger _logger;
        IPAddress _pickToLightServerIPAddress = null;
        //The port number for the remote device.  
        //private int _port = 11000;
        private int _port = 11100; //11000 is the port for the "old" Code and 31001 I sometimes use, too. The BanderDisplay uses 12000

        //Next two lines are for the Production Server
        //static string GT_PickToLight = "10.22.1.50";
        //static string _pickToLightServerIP = GT_PickToLight;
        //Next two lines are for the Development Server
        //static string hq_sptest01 = "10.2.9.23";
        static string hq_sptest01 = "10.128.244.18";
        static string _pickToLightServerIP = hq_sptest01;
        //

        char[] caGS = { (char)29 };

        public MainForm()
        {
            InitializeComponent();

            _pickToLightServerIPAddress = System.Net.IPAddress.Parse(_pickToLightServerIP);

            _logger = new Logger(this.Text);
            //_logger.LogMode = Logger.LogModes.SQLLog;
            _logger.LogMode = Logger.LogModes.SQLLog;

            RefreshDataGridLog();

            textBoxSupplierCode.Text = "22602";
            //textBoxSubRoute.Text = "SPCL02";
            //textBoxSubRoute.Text = "";
            textBoxSubRoute.Text = "IGNORED";
            textBoxShipDate.Text = "2018-12-10";
            textBoxShipTime.Text = "702"; //"702"  (or "697" - "707")
        }

        private void btnSendScanManifestEnd_Click(object sender, EventArgs e)
        {
            labelOutput.Text = "";
            if(String.IsNullOrEmpty(textBoxManifestID.Text))
            {
                labelOutput.Text = "ERROR: You must enter a Scan Manifest ID!";
                return;
            }
            int manifestID = 0;
            if(Int32.TryParse(textBoxManifestID.Text, out manifestID))
            {
                //TCPClient tcpClient = new TCPClient(_logger, _pickToLightServerIPAddress, _port);
                SendScanManifestEndCommand(manifestID);
            }
            RefreshDataGridLog();

        }
        private void SendScanManifestEndCommand(int manifestID)
        {

            string commandToSend = "";
            commandToSend = PickToLightCommands.PopulateScanManifestEndCommand(manifestID);
            TCPClient tcpClient = new TCPClient(_logger, _pickToLightServerIPAddress, _port);
            StringBuilder commandResponse = new StringBuilder();
            tcpClient.SendCommand(commandToSend, commandResponse);
            labelOutput.Text = "Response: " + commandResponse;
        }

        private void RefreshDataGridLog()
        {
            //Change date/time format for "Created" field.
            //(Moved it to the second column!)
            dgvLog.Columns[1].DefaultCellStyle.Format = "MM/dd/yyyy HH:mm:ss.fff";
            using(var ctx = new PickToLightEntities())
            {
                var log = (from l in ctx.Logs
                                 orderby l.ID descending
                                 select l).Take(200).ToList();
                logBindingSource.DataSource = log;
            }
            dgvLog.AutoResizeColumns();
            dgvLog.Refresh();
        }

        private void btnSendShipmentLoadBegin_Click(object sender, EventArgs e)
        {

            //string supplierCode = "22602";
            //string subRoute = "SPCL02";
            ////string subRoute = "";
            //string shipDate = "2018-12-10";
            //string shipTime = "702"; //"702"  (or "697" - "707")

            string commandToSend = "";
            //commandToSend = PickToLightCommands.PopulateShipmentLoadBeginCommand(textBoxSupplierCode.Text, textBoxSubRoute.Text, textBoxShipDate.Text, textBoxShipTime.Text);
            commandToSend = PickToLightCommands.PopulateShipmentLoadBeginCommand(textBoxSupplierCode.Text, textBoxShipDate.Text, textBoxShipTime.Text, textBoxSubRoute.Text);
            TCPClient tcpClient = new TCPClient(_logger, _pickToLightServerIPAddress, _port);
            StringBuilder commandResponse = new StringBuilder();
            tcpClient.SendCommand(commandToSend, commandResponse);

            string[] commandFields = commandResponse.ToString().Split(caGS);

            //labelOutput.Text = "Response Length: " + commandFields.Length.ToString() + "   ResponseCode: " + commandFields[1].ToString() + "   Data: " + commandFields[2].ToString();

            textBoxOutput.Text = "Response Length: " + commandFields.Length.ToString() + "   ResponseCode: " + commandFields[1].ToString() + "   Data: " + commandFields[2].ToString().Replace("<br>", Environment.NewLine).Replace("<BR>", Environment.NewLine); ;

            RefreshDataGridLog();

        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            RefreshDataGridLog();
        }
    }
}

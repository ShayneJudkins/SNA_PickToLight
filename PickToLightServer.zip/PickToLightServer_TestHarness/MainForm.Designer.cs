﻿namespace PickToLightServer_TestHarness
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if(disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.textBoxManifestID = new System.Windows.Forms.TextBox();
            this.lblManifestID = new System.Windows.Forms.Label();
            this.btnSendScanManifestEnd = new System.Windows.Forms.Button();
            this.labelOutput = new System.Windows.Forms.Label();
            this.dgvLog = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnSendShipmentLoadBegin = new System.Windows.Forms.Button();
            this.textBoxSupplierCode = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxSubRoute = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxShipDate = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxShipTime = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.textBoxOutput = new System.Windows.Forms.TextBox();
            this.logBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.createdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sourceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.threadNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.threadIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLog)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // textBoxManifestID
            // 
            this.textBoxManifestID.Location = new System.Drawing.Point(78, 16);
            this.textBoxManifestID.Name = "textBoxManifestID";
            this.textBoxManifestID.Size = new System.Drawing.Size(75, 20);
            this.textBoxManifestID.TabIndex = 0;
            // 
            // lblManifestID
            // 
            this.lblManifestID.AutoSize = true;
            this.lblManifestID.Location = new System.Drawing.Point(8, 19);
            this.lblManifestID.Name = "lblManifestID";
            this.lblManifestID.Size = new System.Drawing.Size(64, 13);
            this.lblManifestID.TabIndex = 1;
            this.lblManifestID.Text = "Manifest ID:";
            // 
            // btnSendScanManifestEnd
            // 
            this.btnSendScanManifestEnd.Location = new System.Drawing.Point(171, 3);
            this.btnSendScanManifestEnd.Name = "btnSendScanManifestEnd";
            this.btnSendScanManifestEnd.Size = new System.Drawing.Size(142, 44);
            this.btnSendScanManifestEnd.TabIndex = 2;
            this.btnSendScanManifestEnd.Text = "Send ScanManifestEnd to (Dev) PickToLightServer";
            this.btnSendScanManifestEnd.UseVisualStyleBackColor = true;
            this.btnSendScanManifestEnd.Click += new System.EventHandler(this.btnSendScanManifestEnd_Click);
            // 
            // labelOutput
            // 
            this.labelOutput.AutoSize = true;
            this.labelOutput.Location = new System.Drawing.Point(12, 55);
            this.labelOutput.Name = "labelOutput";
            this.labelOutput.Size = new System.Drawing.Size(0, 13);
            this.labelOutput.TabIndex = 3;
            // 
            // dgvLog
            // 
            this.dgvLog.AllowUserToAddRows = false;
            this.dgvLog.AllowUserToDeleteRows = false;
            this.dgvLog.AllowUserToOrderColumns = true;
            this.dgvLog.AutoGenerateColumns = false;
            this.dgvLog.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLog.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.createdDataGridViewTextBoxColumn,
            this.sourceDataGridViewTextBoxColumn,
            this.threadNameDataGridViewTextBoxColumn,
            this.threadIDDataGridViewTextBoxColumn,
            this.dataDataGridViewTextBoxColumn});
            this.dgvLog.DataSource = this.logBindingSource;
            this.dgvLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvLog.Location = new System.Drawing.Point(0, 0);
            this.dgvLog.Name = "dgvLog";
            this.dgvLog.ReadOnly = true;
            this.dgvLog.Size = new System.Drawing.Size(1063, 453);
            this.dgvLog.TabIndex = 4;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.textBoxOutput);
            this.panel1.Controls.Add(this.btnRefresh);
            this.panel1.Controls.Add(this.textBoxShipTime);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.textBoxShipDate);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.textBoxSubRoute);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.textBoxSupplierCode);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.btnSendShipmentLoadBegin);
            this.panel1.Controls.Add(this.btnSendScanManifestEnd);
            this.panel1.Controls.Add(this.textBoxManifestID);
            this.panel1.Controls.Add(this.labelOutput);
            this.panel1.Controls.Add(this.lblManifestID);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1063, 204);
            this.panel1.TabIndex = 5;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.dgvLog);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 204);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1063, 453);
            this.panel2.TabIndex = 6;
            // 
            // btnSendShipmentLoadBegin
            // 
            this.btnSendShipmentLoadBegin.Location = new System.Drawing.Point(518, 3);
            this.btnSendShipmentLoadBegin.Name = "btnSendShipmentLoadBegin";
            this.btnSendShipmentLoadBegin.Size = new System.Drawing.Size(176, 47);
            this.btnSendShipmentLoadBegin.TabIndex = 4;
            this.btnSendShipmentLoadBegin.Text = "Send ShipmentLoadBegin to (Dev) PickToLightServer";
            this.btnSendShipmentLoadBegin.UseVisualStyleBackColor = true;
            this.btnSendShipmentLoadBegin.Click += new System.EventHandler(this.btnSendShipmentLoadBegin_Click);
            // 
            // textBoxSupplierCode
            // 
            this.textBoxSupplierCode.Location = new System.Drawing.Point(432, 6);
            this.textBoxSupplierCode.Name = "textBoxSupplierCode";
            this.textBoxSupplierCode.Size = new System.Drawing.Size(75, 20);
            this.textBoxSupplierCode.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(355, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Supplier Code:";
            // 
            // textBoxSubRoute
            // 
            this.textBoxSubRoute.Location = new System.Drawing.Point(432, 31);
            this.textBoxSubRoute.Name = "textBoxSubRoute";
            this.textBoxSubRoute.Size = new System.Drawing.Size(75, 20);
            this.textBoxSubRoute.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(355, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Sub Route:";
            // 
            // textBoxShipDate
            // 
            this.textBoxShipDate.Location = new System.Drawing.Point(777, 6);
            this.textBoxShipDate.Name = "textBoxShipDate";
            this.textBoxShipDate.Size = new System.Drawing.Size(75, 20);
            this.textBoxShipDate.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(700, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Ship Date:";
            // 
            // textBoxShipTime
            // 
            this.textBoxShipTime.Location = new System.Drawing.Point(777, 32);
            this.textBoxShipTime.Name = "textBoxShipTime";
            this.textBoxShipTime.Size = new System.Drawing.Size(75, 20);
            this.textBoxShipTime.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(700, 35);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Ship Time:";
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(964, 6);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(96, 30);
            this.btnRefresh.TabIndex = 13;
            this.btnRefresh.Text = "REFRESH";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.buttonRefresh_Click);
            // 
            // textBoxOutput
            // 
            this.textBoxOutput.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxOutput.Location = new System.Drawing.Point(3, 84);
            this.textBoxOutput.Multiline = true;
            this.textBoxOutput.Name = "textBoxOutput";
            this.textBoxOutput.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxOutput.Size = new System.Drawing.Size(1057, 114);
            this.textBoxOutput.TabIndex = 14;
            // 
            // logBindingSource
            // 
            this.logBindingSource.DataSource = typeof(PickToLightData.Log);
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            this.iDDataGridViewTextBoxColumn.ReadOnly = true;
            this.iDDataGridViewTextBoxColumn.Width = 41;
            // 
            // createdDataGridViewTextBoxColumn
            // 
            this.createdDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.createdDataGridViewTextBoxColumn.DataPropertyName = "Created";
            this.createdDataGridViewTextBoxColumn.HeaderText = "Created";
            this.createdDataGridViewTextBoxColumn.Name = "createdDataGridViewTextBoxColumn";
            this.createdDataGridViewTextBoxColumn.ReadOnly = true;
            this.createdDataGridViewTextBoxColumn.Width = 67;
            // 
            // sourceDataGridViewTextBoxColumn
            // 
            this.sourceDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.sourceDataGridViewTextBoxColumn.DataPropertyName = "Source";
            this.sourceDataGridViewTextBoxColumn.HeaderText = "Source";
            this.sourceDataGridViewTextBoxColumn.Name = "sourceDataGridViewTextBoxColumn";
            this.sourceDataGridViewTextBoxColumn.ReadOnly = true;
            this.sourceDataGridViewTextBoxColumn.Width = 64;
            // 
            // threadNameDataGridViewTextBoxColumn
            // 
            this.threadNameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.threadNameDataGridViewTextBoxColumn.DataPropertyName = "ThreadName";
            this.threadNameDataGridViewTextBoxColumn.HeaderText = "ThreadName";
            this.threadNameDataGridViewTextBoxColumn.Name = "threadNameDataGridViewTextBoxColumn";
            this.threadNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.threadNameDataGridViewTextBoxColumn.Width = 92;
            // 
            // threadIDDataGridViewTextBoxColumn
            // 
            this.threadIDDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.threadIDDataGridViewTextBoxColumn.DataPropertyName = "ThreadID";
            this.threadIDDataGridViewTextBoxColumn.HeaderText = "ThreadID";
            this.threadIDDataGridViewTextBoxColumn.Name = "threadIDDataGridViewTextBoxColumn";
            this.threadIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.threadIDDataGridViewTextBoxColumn.Width = 75;
            // 
            // dataDataGridViewTextBoxColumn
            // 
            this.dataDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataDataGridViewTextBoxColumn.DataPropertyName = "Data";
            this.dataDataGridViewTextBoxColumn.HeaderText = "Data";
            this.dataDataGridViewTextBoxColumn.Name = "dataDataGridViewTextBoxColumn";
            this.dataDataGridViewTextBoxColumn.ReadOnly = true;
            this.dataDataGridViewTextBoxColumn.Width = 53;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1063, 657);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "MainForm";
            this.Text = "Test Harnes for PickToLightServer";
            ((System.ComponentModel.ISupportInitialize)(this.dgvLog)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.logBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxManifestID;
        private System.Windows.Forms.Label lblManifestID;
        private System.Windows.Forms.Button btnSendScanManifestEnd;
        private System.Windows.Forms.Label labelOutput;
        private System.Windows.Forms.DataGridView dgvLog;
        private System.Windows.Forms.BindingSource logBindingSource;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnSendShipmentLoadBegin;
        private System.Windows.Forms.TextBox textBoxShipTime;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxShipDate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxSubRoute;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxSupplierCode;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.TextBox textBoxOutput;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn createdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sourceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn threadNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn threadIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataDataGridViewTextBoxColumn;
    }
}


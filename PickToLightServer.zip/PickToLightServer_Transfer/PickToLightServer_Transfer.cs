﻿using Cognex.DataMan.SDK;
using Cognex.DataMan.SDK.Utils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;
using System.Net;
using PickToLightData;

namespace SNA.WinService.PickToLightServer
{
    public partial class PickToLightServer_Transfer : ServiceBase
    {
        private static Logger _logger;

        private bool stopping;
        private ManualResetEvent stoppedEvent; 

        //Scanner Related
        //Need to reference the assembly!
        private ResultCollector _transferScannerResults;
        private DataManSystem _transferScanner = null;
        private ISystemConnector _transferConnector = null;
        //private string _pickToLightServerIP = "";
        IPAddress _pickToLightServerIP = null;
        private string _transferScannerIP = "";
        private string _transferScannerPassword = "";
        private string _transferScannerImages = "";
        private string _transferScannerImagesUNC = "";
        private bool _transferScannerKeepAlive = true;
        private int _transferScannerKeepAliveTimeout = 3000;
        private int _transferScannerKeepAliveInterval = 1000;
        private bool _autoconnectTransferScanner = false;
        private object _currentResultInfoSyncLock = new object();

        //TODO: READ THIS AS AN "app.config" setting!!!
        //The port number for the remote device.  
        //private int _port = 11000;
        private int _port = 11100; //11000 is the port for the "old" Code and 31001 I sometimes use, too. The BanderDisplay uses 12000

        public PickToLightServer_Transfer()
        {
            InitializeComponent();

            this.stopping = false;
            this.stoppedEvent = new ManualResetEvent(false);
        }

        protected override void OnStart(string[] args)
        {
            Thread.CurrentThread.Name = "OnStart Thread";

            _logger = new Logger(this.ServiceName);

            // Log a service start message to the Application log.
            //Even though LoadSettings() hasn't been called, the LogMode defaults to NoLogging.
            //So, this will work as expected!
            _logger.LogMainEvent(this.ServiceName + " is Starting.");

            //Load the Service Settings from the Config File!
            LoadSettings();

            //
            //StartTransferScanner();
            //Or start like this?
            //
            // Queue the transfer scanner communication for execution in a worker thread. 
            // (A Service has to return, the "work" should be done with Threads.)
            ThreadPool.QueueUserWorkItem(new WaitCallback(TransferScannerConnectThread)); 

            //return 0; 
        }

        protected override void OnStop()
        {
            Thread.CurrentThread.Name = "OnStop Thread";

            // Log a service stop message to the Application log.
            _logger.LogMainEvent(this.ServiceName + " is Stopping.");

            // Indicate that the service is stopping and wait for the finish
            // of the main service function (ServiceWorkerThread).
            this.stopping = true;
        }

        public void LoadSettings()
        {
            string appSetting;

            try
            {
                //Read in the LogMode (NoLogging, FileLog, EventLog, SQLLog)
                appSetting = GetSetting("LogMode");
                //if(String.IsNullOrEmpty(appSetting))
                if (appSetting.Length == 0)
                {
                    _logger.LogMode = Logger.LogModes.NoLogging;
                    _logger.LogFolder = "LogMode=NoLogging";
                }
                else
                {
                    if (appSetting.ToUpper().Equals("NOLOGGING"))
                    {
                        _logger.LogMode = Logger.LogModes.NoLogging;
                        _logger.LogFolder = "LogMode=NoLogging";
                    }
                    else if (appSetting.ToUpper().Equals("FILELOG"))
                    {
                        _logger.LogMode = Logger.LogModes.FileLog;
                        //Read in the LogFolder (Used when LogMode = FileLog)
                        appSetting = GetSetting("LogFolder");
                        //if(String.IsNullOrEmpty(appSetting))
                        if (appSetting.Length > 0)
                        {
                            if (Directory.Exists(appSetting))
                            {
                                _logger.LogFolder = appSetting;
                            }
                            else
                            {
                                _logger.LogError("LogFolder (" + _logger.LogFolder + ") does not exist!");
                            }
                        }
                    }
                    else if (appSetting.ToUpper().Equals("EVENTLOG"))
                    {
                        _logger.LogMode = Logger.LogModes.EventLog;
                        _logger.LogFolder = "LogMode=EventLog";
                    }
                    else if (appSetting.ToUpper().Equals("SQLLOG"))
                    {
                        _logger.LogMode = Logger.LogModes.SQLLog;
                        _logger.LogFolder = "LogMode=SQLLog";
                    }
                    else // Unrecognized, so lets do EventLog!
                    {
                        _logger.LogMode = Logger.LogModes.EventLog;
                        _logger.LogFolder = "LogMode=EventLog";
                    }
                }

                //<add key="PickToLightServerIP" value="10.2.9.23" />
                //Read in the PickToLightServerIP
                appSetting = GetSetting("PickToLightServerIP");
                //if(String.IsNullOrEmpty(appSetting))
                if (appSetting.Length == 0)
                {
                    //_pickToLightServerIP = "";
                    _pickToLightServerIP = null;
                    throw new ConfigurationErrorsException("PickToLightServerIP is missing or empty!");
                    //We won't get here since its called in a main thread (not on an Asynch Callback)
                    // Use this since we are a console app
                    //System.Environment.Exit(1);
                }
                else
                {
                    //_pickToLightServerIP = appSetting;
                    if (System.Net.IPAddress.TryParse(appSetting, out _pickToLightServerIP) == false)
                    {
                        throw new ConfigurationErrorsException("PickToLightServerIP can't be parsed into a valid IP!");
                    }
                }
                
                //<add key="TransferScannerIP" value="10.22.10.101" />
                //Read in the ScannerIP
                appSetting = GetSetting("TransferScannerIP");
                //if(String.IsNullOrEmpty(appSetting))
                if (appSetting.Length == 0)
                {
                    _transferScannerIP = "";
                    throw new ConfigurationErrorsException("TransferScannerIP is missing or empty!");
                    //We won't get here since its called in a main thread (not on an Asynch Callback)
                    // Use this since we are a console app
                    //System.Environment.Exit(1);
                }
                else
                {
                    _transferScannerIP = appSetting;
                }

                //<add key="TransferScannerPassword" value="" />
                //Read in the ScannerPassword
                appSetting = GetSetting("TransferScannerPassword");
                //if(String.IsNullOrEmpty(appSetting))
                if (appSetting.Length == 0)
                {
                    _transferScannerPassword = "";
                }
                else
                {
                    _transferScannerPassword = appSetting;
                }

                //<add key="TransferScannerImages" value="D:\PickToLightScans\Transfer" />
                //Read in the TransferScannerImages (Folder)
                appSetting = GetSetting("TransferScannerImages");
                //if(String.IsNullOrEmpty(appSetting))
                if (appSetting.Length == 0)
                {
                    _transferScannerImages = "";
                    throw new ConfigurationErrorsException("TransferScannerImages (Folder) is missing or empty!");
                    //We won't get here since its called in a main thread (not on an Asynch Callback)
                    // Use this since we are a console app
                    //System.Environment.Exit(3); //ERROR_PATH_NOT_FOUND
                }
                else
                {
                    if (Directory.Exists(appSetting))
                    {
                        _transferScannerImages = appSetting;
                    }
                    else
                    {
                        _transferScannerImages = "";
                        _logger.LogError("TransferScannerImages (Folder) (" + _transferScannerImages + ") does not exist!");
                        throw new ConfigurationErrorsException("TransferScannerImages (Folder) (" + _transferScannerImages + ") does not exist!");
                        //We won't get here since its called in a main thread (not on an Asynch Callback)
                        // Use this since we are a console app
                        //System.Environment.Exit(3); //ERROR_PATH_NOT_FOUND
                    }
                }

                //<add key="TransferScannerImagesUNC" value="\\HQ-SPTEST01\PickToLightScans\Transfer" />
                //Read in the TransferScannerImagesUNC (UNC Path)
                appSetting = GetSetting("TransferScannerImagesUNC");
                //if(String.IsNullOrEmpty(appSetting))
                if (appSetting.Length == 0)
                {
                    _transferScannerImagesUNC = "";
                    throw new ConfigurationErrorsException("TransferScannerImagesUNC (UNC Path) is missing or empty!");
                    //We won't get here since its called in a main thread (not on an Asynch Callback)
                    // Use this since we are a console app
                    //System.Environment.Exit(3); //ERROR_PATH_NOT_FOUND
                }
                else
                {
                    if (Directory.Exists(appSetting))
                    {
                        _transferScannerImagesUNC = appSetting;
                    }
                    else
                    {
                        _transferScannerImagesUNC = "";
                        _logger.LogError("TransferScannerImagesUNC (UNC Path) (" + _transferScannerImagesUNC + ") does not exist!");
                        throw new ConfigurationErrorsException("TransferScannerImagesUNC (UNC Path) (" + _transferScannerImagesUNC + ") does not exist!");
                        //We won't get here since its called in a main thread (not on an Asynch Callback)
                        // Use this since we are a console app
                        //System.Environment.Exit(3); //ERROR_PATH_NOT_FOUND
                    }
                }

                //Log all the Settings loaded to the EventLog
                _logger.LogMainEvent("LogMode = (" + _logger.LogMode.ToString() + "), LogFolder = (" + _logger.LogFolder + "), PickToLightServerIP = (" + _pickToLightServerIP + "), TransferScannerIP = (" + _transferScannerIP + "), TransferScannerPassword = (" + _transferScannerPassword + "), TransferScannerImages (Folder) = (" + _transferScannerImages + "), TransferScannerImagesUNC (UNC Path) = (" + _transferScannerImagesUNC + ")");
            }
            catch (Exception e)
            {
                _logger.LogError("Exception in LoadSettings: " + e.Message);
                throw new ConfigurationErrorsException("Exception in LoadSettings: " + e.Message);
                //We won't get here since its called in a main thread (not on an Asynch Callback)
                // Use this since we are a console app
                //System.Environment.Exit(1);
            }
        }

        private static string GetSetting(string appSetting)
        {
            
            if( ConfigurationManager.AppSettings == null)
            {
                return "";
            }
            if (ConfigurationManager.AppSettings.Get(appSetting) == null)
            {
                return "";
            }

            return ConfigurationManager.AppSettings.Get(appSetting);
        }

        #region Scanner

        //Start Transfer Scanner this way?
        private void TransferScannerConnectThread(object state)
        {
            Thread.CurrentThread.Name = "TransferScannerConnectThread";
            _logger.LogMainEvent("The Transfer Scanner Connection Thread has started.");

            if (_transferScannerIP.Length > 10 && _transferScannerIP.Split('.').Length == 4) //At least 11 characters (10.10.10.10) and 3 periods/dots.
            {
                StartTransferScanner(_transferScannerIP);
            }
            else
            {
                //_logger.LogToEventLog("The TransferScannerIP setting has (" + _transferScannerIP.Split('.').Length.ToString() + ") periods!");
                _logger.LogError("The TransferScannerIP setting (" + _transferScannerIP + ") is invalid or not specified!");
                return;
            }

            DateTime lastLogTime = DateTime.Now.AddHours(-1.0D);  //Use this to prevent too many entries in the log!! Set to 1 Hour ago to force logging on first pass...

            // Periodically check if the service is stopping. 
            while (!this.stopping) //This can be a "spin-wait", which is very BAD. Need a "sleep" or "wait" in the block below to prevent that!.
            {
                //If we haven't "logged" anything in 10 minutes, lets write to the log to show its still running!
                TimeSpan timeElapsed = DateTime.Now.Subtract(lastLogTime);
                if (timeElapsed.TotalMinutes > 10.0D)
                {
                    lastLogTime = DateTime.Now;
                    _logger.Log("Heartbeat from TransferScannerConnectThread() at " + lastLogTime.ToString());
                }

                //        // Perform main service function here... 
                //        // BUT, only the Synchronous Actions!

                //        //Thread.Sleep(2000);  // Simulate some lengthy operations. 

                //Thread.Sleep(10); //Give the processor some down time so this thread doesn't use 100%. This prevents the while loop above from being a "spin-wait".
                //System.Threading.EventWaitHandle eventWaitHandle = new EventWaitHandle();
                //eventWaitHandle.WaitOne(10);
                if (this.stoppedEvent.WaitOne(10)) //returns false if the wait ended because of a timeout
                {
                    _logger.LogMainEvent("WaitOne ended due to signalling, not due to a timeOut! (stopping = " + stopping.ToString() + ") in  TransferScannerConnectThread() at " + DateTime.Now.ToString());
                }

            }

            _logger.Log("Left while loop (stopping = " + stopping.ToString() + ") in TransferScannerConnectThread() at " + DateTime.Now.ToString());

            //Prevent ReConnecting to Transfer Scanner!
            _autoconnectTransferScanner = false;

            // Signal the stopped event. 
            this.stoppedEvent.Set();

            _logger.LogMainEvent("Leaving TransferScannerConnectThread() (stopping = " + stopping.ToString() + ") at " + DateTime.Now.ToString());
        }

        public void StartTransferScanner(string transferScannerIP) //Based off "ConnectToIP()" from PickToLightServer (WinForm, GUI App)
        {
            try
            {
                System.Net.IPAddress ipAddress = System.Net.IPAddress.Parse(transferScannerIP);
                EthSystemConnector conn = new EthSystemConnector(ipAddress);

                conn.UserName = "admin";
                conn.Password = _transferScannerPassword;

                _transferConnector = conn;

                _transferScanner = new DataManSystem(_transferConnector);
                _transferScanner.DefaultTimeout = 5000;

                // Subscribe to events that are signalled when the system is connected / disconnected.
                _transferScanner.SystemConnected += new SystemConnectedHandler(OnSystemConnected);
                _transferScanner.SystemDisconnected += new SystemDisconnectedHandler(OnSystemDisconnected);
                _transferScanner.SystemWentOnline += new SystemWentOnlineHandler(OnSystemWentOnline); //This is for Handhelds, shouldn't occur here.
                _transferScanner.SystemWentOffline += new SystemWentOfflineHandler(OnSystemWentOffline); //This is for Handhelds, shouldn't occur here.
                _transferScanner.KeepAliveResponseMissed += new KeepAliveResponseMissedHandler(OnKeepAliveResponseMissed);
                _transferScanner.BinaryDataTransferProgress += new BinaryDataTransferProgressHandler(OnBinaryDataTransferProgress);
                _transferScanner.OffProtocolByteReceived += new OffProtocolByteReceivedHandler(OffProtocolByteReceived);
                _transferScanner.AutomaticResponseArrived += new AutomaticResponseArrivedHandler(AutomaticResponseArrived);

                // Subscribe to events that are signalled when the device sends auto-responses.
                //ResultTypes requested_result_types = ResultTypes.ReadXml | ResultTypes.Image | ResultTypes.ImageGraphics;
                ResultTypes requested_result_types = ResultTypes.ReadXml | ResultTypes.Image;
                _transferScannerResults = new ResultCollector(_transferScanner, requested_result_types);
                _transferScannerResults.ComplexResultCompleted += Results_ComplexResultCompleted;
                _transferScannerResults.SimpleResultDropped += Results_SimpleResultDropped;

                //_transferScanner.SetKeepAliveOptions(cbEnableKeepAlive.Checked, 3000, 1000);
                _transferScanner.SetKeepAliveOptions(   _transferScannerKeepAlive,
                                                        _transferScannerKeepAliveTimeout,
                                                        _transferScannerKeepAliveInterval);  //Probably should use "app.config" properties for these.

                _transferScanner.Connect();

                try
                {
                    _transferScanner.SetResultTypes(requested_result_types);
                }
                catch
                { }
            }
            catch (Exception ex)
            {
                CleanupConnection();

                _logger.LogError("Exception ERROR in StartTransferScanner(). Unable to connect to Transfer Scanner!");
            }
        }

        public void ReconnectTransferScanner() //Created from StartTransferScanner
        {
            //Created from StartTransferScanner
            try
            {
                //System.Net.IPAddress ipAddress = System.Net.IPAddress.Parse(transferScannerIP);
                //EthSystemConnector conn = new EthSystemConnector(ipAddress);

                //conn.UserName = "admin";
                //conn.Password = _transferScannerPassword;

                //_transferConnector = conn;

                //_transferScanner = new DataManSystem(_transferConnector);
                //_transferScanner.DefaultTimeout = 5000;

                //// Subscribe to events that are signalled when the system is connected / disconnected.
                //_transferScanner.SystemConnected += new SystemConnectedHandler(OnSystemConnected);
                //_transferScanner.SystemDisconnected += new SystemDisconnectedHandler(OnSystemDisconnected);
                //_transferScanner.SystemWentOnline += new SystemWentOnlineHandler(OnSystemWentOnline); //This is for Handhelds, shouldn't occur here.
                //_transferScanner.SystemWentOffline += new SystemWentOfflineHandler(OnSystemWentOffline); //This is for Handhelds, shouldn't occur here.
                //_transferScanner.KeepAliveResponseMissed += new KeepAliveResponseMissedHandler(OnKeepAliveResponseMissed);
                //_transferScanner.BinaryDataTransferProgress += new BinaryDataTransferProgressHandler(OnBinaryDataTransferProgress);
                //_transferScanner.OffProtocolByteReceived += new OffProtocolByteReceivedHandler(OffProtocolByteReceived);
                //_transferScanner.AutomaticResponseArrived += new AutomaticResponseArrivedHandler(AutomaticResponseArrived);

                // Subscribe to events that are signalled when the device sends auto-responses.
                //ResultTypes requested_result_types = ResultTypes.ReadXml | ResultTypes.Image | ResultTypes.ImageGraphics;
                ResultTypes requested_result_types = ResultTypes.ReadXml | ResultTypes.Image;
                _transferScannerResults = new ResultCollector(_transferScanner, requested_result_types);
                _transferScannerResults.ComplexResultCompleted += Results_ComplexResultCompleted;
                _transferScannerResults.SimpleResultDropped += Results_SimpleResultDropped;

                ////_transferScanner.SetKeepAliveOptions(cbEnableKeepAlive.Checked, 3000, 1000);
                //_transferScanner.SetKeepAliveOptions(_transferScannerKeepAlive,
                //                                        _transferScannerKeepAliveTimeout,
                //                                        _transferScannerKeepAliveInterval);  //Probably should use "app.config" properties for these.

                DateTime lastLogTime = DateTime.Now.AddHours(-1.0D);  //Use this to prevent too many entries in the log!! Set to 1 Hour ago to force logging on first pass...
                
                //Check "this.stopping", so this blocking call can be stopped when the Service is stopped!!
                while (!this.stopping && _transferScanner != null && _transferScanner.State != Cognex.DataMan.SDK.ConnectionState.Connected)
                {
                    try
                    {
                        //If we haven't "logged" anything in 10 minutes, lets write to the log to show its still running!
                        TimeSpan timeElapsed = DateTime.Now.Subtract(lastLogTime);
                        if (timeElapsed.TotalMinutes > 10.0D)
                        {
                            lastLogTime = DateTime.Now;
                            _logger.LogMainEvent("Trying to Re-Connect to Scanner at " + lastLogTime.ToString());
                        }
                        _transferScanner.Connect(3000); //Try to connect for up to 3000 milliseconds (3 seconds)
                        try
                        {
                            _transferScanner.SetResultTypes(requested_result_types);
                        }
                        catch
                        { }
                    }
                    catch
                    {
                        if (this.stoppedEvent.WaitOne(2000)) //Wait up to 2000 milliseconds (2 seconds) before trying to Connect() again, returns false if the wait ended because of a timeout
                        {
                            _logger.LogMainEvent("WaitOne ended due to signalling, not due to a timeOut! (stopping = " + stopping.ToString() + ") in  ReconnectTransferScanner() at " + DateTime.Now.ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                CleanupConnection();

                _logger.LogError("Exception ERROR in ReconnectTransferScanner(). Unable to Re-Connect to Transfer Scanner!");
            }
        }

        //Let's not ReConnect using a new Thread, we can use the regular "TransferScannerConnectThread"!
        //private void TransferScannerReConnectThread(object state)
        //{
        //    Thread.CurrentThread.Name = "TransferScannerReConnectThread";
        //    _logger.LogMainEvent("The Transfer Scanner Re-Connection Thread has started!");

        //    DateTime lastLogTime = DateTime.Now;

        //    // Periodically check if the service is stopping. 
        //    while (!this.stopping) //This can be a "spin-wait", which is very BAD. Need a "sleep" or "wait" in the block below to prevent that!.
        //    {
        //        //If we haven't "logged" anything in 10 minute, lets write to the log to show its still running!
        //        TimeSpan timeElapsed = DateTime.Now.Subtract(lastLogTime);
        //        if (timeElapsed.TotalMinutes > 10.0D)
        //        {
        //            lastLogTime = DateTime.Now;
        //            _logger.Log("Heartbeat from TransferScannerConnectThread() at " + lastLogTime.ToString());
        //        }
        //        try
        //        {
        //            _logger.LogMainEvent("Attempting to Re-Connect in \"TransferScannerReConnectThread\"...");
        //            _transferScanner.Connect();
        //        }
        //        catch
        //        {
        //            _logger.LogError("Unable to Re-Connect in \"TransferScannerReConnectThread\", trying again in half a second...");
        //            //Thread.Sleep(500);
        //            if (this.stoppedEvent.WaitOne(500)) //returns false if the wait ended because of a timeout
        //            {
        //                _logger.Log("WaitOne ended due to signalling, not due to a timeOut! (stopping = " + stopping.ToString() + ") in  TransferScannerReConnectThread() at " + DateTime.Now.ToString());
        //            }
        //            continue;
        //        }
        //        break;
        //    }

        //    //Prevent ReConnecting to Transfer Scanner!
        //    _autoconnectTransferScanner = false;

        //    // Signal the stopped event. 
        //    this.stoppedEvent.Set();
        //}

        //This should probably only be called if we decide to handle "Disconnect" in the "OnKeepAliveResponseMissed" handler!
        //private void DisconnectConnection()
        //{
        //    try
        //    {
        //        if (_transferScanner == null || _transferScanner.State != Cognex.DataMan.SDK.ConnectionState.Connected)
        //        {
        //            return;
        //        }

        //        //_autoconnectTransferScanner = false;
        //        _transferScanner.Disconnect();

        //        CleanupConnection();

        //        _transferScannerResults.ClearCachedResults();
        //        _transferScannerResults = null;
        //    }
        //    finally
        //    {
        //        //RefreshGui();
        //    }
        //}

        private void CleanupConnection()
        {
            if (null != _transferScanner)
            {
                _transferScanner.SystemConnected -= OnSystemConnected;
                _transferScanner.SystemDisconnected -= OnSystemDisconnected;
                _transferScanner.SystemWentOnline -= OnSystemWentOnline; //This is for Handhelds, shouldn't occur here.
                _transferScanner.SystemWentOffline -= OnSystemWentOffline; //This is for Handhelds, shouldn't occur here.
                _transferScanner.KeepAliveResponseMissed -= OnKeepAliveResponseMissed;
                _transferScanner.BinaryDataTransferProgress -= OnBinaryDataTransferProgress;
                _transferScanner.OffProtocolByteReceived -= OffProtocolByteReceived;
                _transferScanner.AutomaticResponseArrived -= AutomaticResponseArrived;
            }

            _transferConnector = null;
            _transferScanner = null;
        }

        #region Scanner Results

        private void Results_ComplexResultCompleted(object sender, ComplexResult e)
        {
            _logger.Log("TransferScanner Results Event: \"ComplexResultCompleted\"!");
            ProcessResult(e);
        }

        private void Results_SimpleResultDropped(object sender, SimpleResult e)
        {
            _logger.LogError("TransferScanner Results Event: \"SimpleResultDropped\": " + string.Format("Partial result dropped: {0}, id={1}", e.Id.Type.ToString(), e.Id.Id));
        }

        private void ProcessResult(ComplexResult complexResult)
        {
            List<Image> images = new List<Image>();
            List<string> image_graphics = new List<string>();
            string read_result = null;
            int result_id = -1;
            ResultTypes collected_results = ResultTypes.None;

            // Take a reference or copy values from the locked result info object.
            // This is done so that the lock is used only for a short period of time.
            lock (_currentResultInfoSyncLock)
            {
                foreach (var simple_result in complexResult.SimpleResults)
                {
                    collected_results |= simple_result.Id.Type;

                    switch (simple_result.Id.Type)
                    {
                        case ResultTypes.Image:
                            Image image = ImageArrivedEventArgs.GetImageFromImageBytes(simple_result.Data);
                            if (image != null)
                                images.Add(image);
                            break;

                        case ResultTypes.ImageGraphics:
                            image_graphics.Add(simple_result.GetDataAsString());
                            break;

                        case ResultTypes.ReadXml:
                            read_result = GetReadStringFromResultXml(simple_result.GetDataAsString());
                            result_id = simple_result.Id.Id;
                            break;

                        case ResultTypes.ReadString:
                            read_result = simple_result.GetDataAsString();
                            result_id = simple_result.Id.Id;
                            break;
                    }
                }
            }

            _logger.Log(string.Format("Complex result arrived: resultId = {0}, read result = {1}, images {2}", result_id, read_result, images.Count.ToString()));
            _logger.Log(string.Format("Complex result contains: {0}", collected_results.ToString()));

            string resultImageFolderPath = "";

            if (images.Count > 0)
            {
                //Create a folder to store all the images from this Result!
                //resultImageFolderPath = _transferScannerImages + (_transferScannerImages.EndsWith("\\") ? "" : "\\");
                //Directory.CreateDirectory(resultImageFolderPath);
                //resultImageFolderPath = resultImageFolderPath + DateTime.Now.Year.ToString("0000") + DateTime.Now.Month.ToString("00") + DateTime.Now.Day.ToString("00") + "\\";
                //DirectoryInfo di = Directory.CreateDirectory(resultImageFolderPath);
                //resultImageFolderPath = resultImageFolderPath + result_id.ToString() + "\\";
                //Directory.CreateDirectory(resultImageFolderPath);
                //resultImageFolderPath = String.Format("{0}{1}{2}{3}{4}{5}{6}{7}", _transferScannerImages, (_transferScannerImages.EndsWith("\\") ? "" : "\\"),
                //            DateTime.Now.Year.ToString("0000"), DateTime.Now.Month.ToString("00"), DateTime.Now.Day.ToString("00"), "\\",
                //            result_id.ToString(), "\\");
                resultImageFolderPath = _transferScannerImages + (_transferScannerImages.EndsWith("\\") ? "" : "\\") +
                                DateTime.Now.Year.ToString("0000") + DateTime.Now.Month.ToString("00") + DateTime.Now.Day.ToString("00") + "\\" +
                                result_id.ToString() + "\\";
                try
                { 
                    DirectoryInfo di = Directory.CreateDirectory(resultImageFolderPath); //This will create ALL directories in the full path.
                    if (di.Exists == false)
                    {
                        _logger.LogError("Error creating directory to store images: " + resultImageFolderPath + "!!!");
                        //throw new ConfigurationErrorsException("Error creating directory: " + resultImageFolderPath + "!!!");
                        //Instead of throwing an Exception, need to EXIT, because this is called as an Asynch handler (not on the main thread)!
                        // Use this since we are a console app
                        //--11-9-17 - Wait! This shouldn't cause an actual EXIT!!! Just keep on going....
                        //System.Environment.Exit(82); //ERROR_CANNOT_MAKE
                    }
                    else
                    {
                        int i = 0;
                        foreach (var image in images)
                        {
                            //_logger.Log(string.Format("Complex result, saving image {0}", i.ToString()));
                            image.Save(resultImageFolderPath + i.ToString() + ".jpg", System.Drawing.Imaging.ImageFormat.Jpeg);
                            i++;
                        }
                        //Using too much space in database! Just Log the total, not each image.
                        _logger.Log(string.Format("Complex result, saved {0} images", i.ToString()));
                        //Replace image path with the UNC SHARE name!
                        //Lets get a UNC, for example "TransferScannerImagesUNC". (Will need an app.config setting!)
                        //resultImageFolderPath = resultImageFolderPath.Replace("D:\\", "\\\\HQ-SPTEST01");
                        resultImageFolderPath = resultImageFolderPath.Replace(_transferScannerImages, _transferScannerImagesUNC);
                    }
                }
                catch (Exception ex)
                {
                    if (ex.InnerException != null)
                    {
                        _logger.LogError("Exception creating the directory (" + resultImageFolderPath + ") to store the images: " + ex.Message + " (Inner Exception: " + ex.InnerException + ")");
                    }
                    else
                    {
                        _logger.LogError("Exception creating the directory (" + resultImageFolderPath + ") to store the images: " + ex.Message);
                    }
                    //throw new ConfigurationErrorsException("Error creating directory to store the images: " + resultImageFolderPath + "!!!");
                    //Instead of throwing an Exception, need to EXIT, because this is called as an Asynch handler (not on the main thread)!
                    //Use this since we are a console app
                    //--11-9-17 - Wait! This shouldn't cause an actual EXIT!!! Just keep on going....
                    //System.Environment.Exit(82); //ERROR_CANNOT_MAKE
                }
            }

            try
            {
                _logger.Log("Creating Scan Entry for resultId " + result_id);
                ProcessTransferScan(result_id, read_result, resultImageFolderPath);
                //if (read_result != null)
                //{
                //    //Use the right values/settings!!
                //    PickToLightData.ScanOWK.CreateScanEntry("Transfer", "Transfer", "Transfer", result_id.ToString(), read_result, resultImageFolderPath);
                //}
                //else
                //{
                //    //Use the right values/settings!!
                //    PickToLightData.ScanOWK.CreateScanEntry("Transfer", "Transfer", "Transfer", result_id.ToString(), "NO Barcode in Result, possibly due to network communication timing, device error or system error.", resultImageFolderPath);
                //}
            }
            catch (Exception ex)
            {
                if (ex.InnerException != null)
                {
                    _logger.LogError("Exception creating the Scan Entry: " + ex.Message + " (Inner Exception: " + ex.InnerException + ")");
                }
                else
                {
                    _logger.LogError("Exception creating the Scan Entry: " + ex.Message);
                }
            }
        }

        private void ProcessTransferScan(int resultID, string barcode, string imagePath)
        {
            //Do all of this, or even each of these in a seperate thread???
            //
            //Create a Scan Entry in the SQL table.
            //Send the "ScanTransferCommand" to the PickToLightServer, so the proper command can be sent to the PLC to select the correct Banding Machine (Bander1 or Bander2).
            //

            //ThreadPool.QueueUserWorkItem(new WaitCallback(TransferScannerReConnectThread));

            try
            {
                if (barcode != null)
                {
                    int entryID = PickToLightData.ScanOWK.CreateScanEntry("Transfer", "Transfer", "Transfer", resultID.ToString(), barcode, imagePath);
                    if (barcode.StartsWith("C") && barcode.Length >= 250)  //A valid read will start with a "C" and will be 250 characters.
                    {
                        SendTransferCommand(true, entryID); //Actually, we know if the scan was successful using the boolean column "decoded" in the SQL table...
                    }
                    else
                    {
                        SendTransferCommand(false, entryID); //Actually, we know if the scan was successful using the boolean column "decoded" in the SQL table...
                    }
                }
                else
                {
                    PickToLightData.ScanOWK.CreateScanEntry("Transfer", "Transfer", "Transfer", resultID.ToString(), "NO Barcode in Result, possibly due to network communication timing, device error or system error.", imagePath);
                    //I don't think this needs to be communicated to the PickToLightServer...
                }
            }
            catch (Exception ex)
            {
                if (ex.InnerException != null)
                {
                    //_logger.LogError("Exception in ProcessTransferScan()" + (barcode == null ? " (No Barcode in Result!) " : "") + "resultID (" + resultID.ToString() + (barcode == null ? ")." : "), imagePath (" + imagePath + ").") +  " Exception: " + ex.Message + " (Inner Exception: " + ex.InnerException + ")");
                    _logger.LogError("Exception in ProcessTransferScan()" + (barcode == null ? " (No Barcode in Result!) " : "") + "resultID (" + resultID.ToString() + "), imagePath (" + imagePath + "). Exception: " + ex.Message + " (Inner Exception: " + ex.InnerException + ")");
                }
                else
                {
                    //_logger.LogError("Exception in ProcessTransferScan()" + (barcode == null ? " (No Barcode in Result!) " : "") + "resultID (" + resultID.ToString() + (barcode == null ? ")." : "), imagePath (" + imagePath + ").") +  " Exception: " + ex.Message);
                    _logger.LogError("Exception in ProcessTransferScan()" + (barcode == null ? " (No Barcode in Result!) " : "") + "resultID (" + resultID.ToString() + "), imagePath (" + imagePath + "). Exception: " + ex.Message);
                }
            }
        }

        private void SendTransferCommand(bool barcodeDecoded, int entryID)
        {
            
            //if (_pickToLightServerIP.Length > 10 && _pickToLightServerIP.Split('.').Length == 4) //At least 11 characters (10.10.10.10) and 3 periods/dots.
            if (_pickToLightServerIP != null)
            {
				string commandToSend = "";
	            commandToSend = PickToLightCommands.PopulateScanTransferCommand(barcodeDecoded, entryID);
                TCPClient tcpClient = new TCPClient(_logger, _pickToLightServerIP, _port);
                StringBuilder commandResponse = new StringBuilder();
                tcpClient.SendCommand(commandToSend, commandResponse);
            }
            else
            {
                //_logger.LogToEventLog("The TransferScannerIP setting has (" + _transferScannerIP.Split('.').Length.ToString() + ") periods!");
                _logger.LogError("The PickToLightServerIP setting is invalid or not specified! (This shouldn't get this far, it should be caught when Loading the settings during startup!)");
                return;
            }
        }

        private string GetReadStringFromResultXml(string resultXml)
        {
            try
            {
                XmlDocument doc = new XmlDocument();

                doc.LoadXml(resultXml);

                XmlNode full_string_node = doc.SelectSingleNode("result/general/full_string");

                if (full_string_node != null && _transferScanner != null && _transferScanner.State == Cognex.DataMan.SDK.ConnectionState.Connected)
                {
                    XmlAttribute encoding = full_string_node.Attributes["encoding"];
                    if (encoding != null && encoding.InnerText == "base64")
                    {
                        if (!string.IsNullOrEmpty(full_string_node.InnerText))
                        {
                            byte[] code = Convert.FromBase64String(full_string_node.InnerText);
                            return _transferScanner.Encoding.GetString(code, 0, code.Length);
                        }
                        else
                        {
                            return "";
                        }
                    }

                    return full_string_node.InnerText;
                }
            }
            catch
            {
            }

            return "";
        }

        #endregion //Scanner Results

        #region Scanner Events

        private void OnSystemConnected(object sender, EventArgs args)
        {
            //Enable ReConnecting to Transfer Scanner!
            _autoconnectTransferScanner = true;

            _logger.LogMainEvent("TransferScanner Event: \"SystemConnected\"!");

            _logger.Log("Setting scanner to get all the images!");
            _transferScanner.SendCommand("SET CAMERA.BURST-TRANSFER-ALL ON");
        }

        private void OnSystemDisconnected(object sender, EventArgs args)
        {
            Thread.CurrentThread.Name = "ReconnectTransferScanner";
            //_logger.LogMainEvent("TransferScanner Event: \"SystemDisconnected\"!");
            //No, lets log this as an ERROR!
            //The "System Center Operations Manager" will email an alert!
            _logger.LogError("TransferScanner Event: \"SystemDisconnected\"!");

            if (_autoconnectTransferScanner) //Make sure the Service wasn't stopped on purpose....
            {
                //Start up a Reconnect Thread (TransferScannerReConnectThread) and try to reconnect every half second (500 milliseconds)
                //
                //NO!!! I don't think we need a new Thread! Let's just keep using this Tread and try to ReConnect!!
                //
                //ThreadPool.QueueUserWorkItem(new WaitCallback(TransferScannerReConnectThread));
                ReconnectTransferScanner();
            }
            else
            {
                _logger.LogMainEvent("NOT reconnecting, the service must be stopping...");
            }

        }

        private void OnKeepAliveResponseMissed(object sender, EventArgs args)
        {
            _logger.LogMainEvent("TransferScanner Event: \"KeepAliveResponseMissed\"!");

            //Should we go ahead and Disconnect/Connect, since we aren't getting a Keep Alive Acknowledgement.

            //
            //NO! For now, lets see if we can just depend on the "SystemDisconnect" event!
            //

            //First, see if we need to Disconnect.

            //Then (if not Connected??), try Re-Connecting!
        }

        private void OnSystemWentOnline(object sender, EventArgs args)
        {
            //This is for Handhelds, shouldn't occur here.
            _logger.LogMainEvent("TransferScanner Event: \"SystemWentOnline\"!");
        }

        private void OnSystemWentOffline(object sender, EventArgs args)
        {
            //This is for Handhelds, shouldn't occur here.
            _logger.LogError("TransferScanner Event: \"SystemWentOffline\"!");
        }

        private void OnBinaryDataTransferProgress(object sender, BinaryDataTransferProgressEventArgs args)
        {
            _logger.Log("TransferScanner Event: \"BinaryDataTransferProgress\": " + string.Format("{0}: {1}% of {2} bytes (Type={3}, Id={4})", args.Direction == TransferDirection.Incoming ? "Receiving" : "Sending", args.TotalDataSize > 0 ? (int)(100 * (args.BytesTransferred / (double)args.TotalDataSize)) : -1, args.TotalDataSize, args.ResultType.ToString(), args.ResponseId));
        }

        private void OffProtocolByteReceived(object sender, OffProtocolByteReceivedEventArgs args)
        {
            _logger.LogError("TransferScanner Event: \"OffProtocolByteReceived\": " + (char)args.Byte);
        }

        private void AutomaticResponseArrived(object sender, AutomaticResponseArrivedEventArgs args)
        {
            _logger.Log("TransferScanner Event: \"AutomaticResponseArrived\": " + string.Format("Type={0}, Id={1}, Data={2} bytes", args.DataType.ToString(), args.ResponseId, args.Data != null ? args.Data.Length : 0));
        }

        #endregion //#region Scanner Events

        #endregion //#region Scanner
    }
}

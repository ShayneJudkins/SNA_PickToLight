﻿using PickToLightData;
using SNA.PLC.Mitsubishi.FX3U;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using Newtonsoft.Json;
using System.Globalization;

namespace SNA.WinService.PickToLightServer
{
    public partial class PickToLightServer : ServiceBase
    {
        string _serverVersion = System.Reflection.Assembly.GetCallingAssembly().GetName().Version.ToString();

        //string sSTX = "\u0002";
        //string sETX = "\u0003";
        ////char cSTX = (char)2;
        ////char cETX = (char)2;
        //byte cSTX = 0x02;
        //byte cETX = 0x03;

        const int iGS = 29; //ASCII Group Separator
        const char cGS = (char)29;
        const byte bGS = 0x1D;
        const string sGS = "\x1D";
        string[] saGS = { "\x1D" };
        char[] caGS = { (char)29 };

        ////Implementing new Networking Code...
        ////(Eventually, this "version" will go away!!)
        //private TCPServer _tcpServer = null;       //int port = 11000;
        //New Networking Code
        private TCPServerV2 _tcpServerV2 = null;   //int port = 11100; Start the new version of the Networking code on Port 11100...
        
        private string _plcIP = "";

        private static Logger _logger;

        private static PLCDevice _plcDevice;
        //const string P2L_COMMAND_ScanTransfer = "ST";

        //private static string _manifestNum1 = "";
        //private static string _manifestNum2 = "";
        //private static string _mainRoute1 = "";
        //private static string _mainRoute2 = "";
        //private static string _subRoute1 = "";
        //private static string _subRoute2 = "";
        //
        //private static DateTime _dateTimeDefault = new DateTime(2000, 1, 1); //Initialize to 1/1/00
        //private static DateTime _bander1Used = new DateTime(2000, 1, 1); //Initialize to 1/1/00
        //private static DateTime _bander2Used = new DateTime(2000, 1, 1); //Initialize to 1/1/00
        //
        //Instead of all these fields, create the class "BanderOrder"...
        //
        BanderOrder _bander1Order; //Used to track the Manifest that we are "Transferring" to Bander 1.
        BanderOrder _bander2Order; //Used to track the Manifest that we are "Transferring" to Bander 2.
        bool TransferDebug = true; //This can be turned off in AppSettings. For now, I am going to turn it on, since I just refactored much of the code.
        string TransferDebug_AppSettingName = "PickToLightServer_TransferDebug";

        //Using these to determine when to try another ToyotaConfirmation!
        //We can also use these and get rid of the 6 "global" properties above!
        TrackedManifest _manifest1 = null;
        TrackedManifest _manifest2 = null;

        private static List<SkidBuild> SkidBuilds = new List<SkidBuild>();

        public PickToLightServer()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            Thread.CurrentThread.Name = "OnStart Thread";

            _logger = new Logger(this.ServiceName);

            // Log a service start message to the Application log.
            //Even though LoadSettings() hasn't been called, the LogMode defaults to NoLogging.
            //So, this will work as expected!
            _logger.LogMainEvent(this.ServiceName + " version " + _serverVersion + " is Starting.");

            //Load the Service Settings from the Config File!
            LoadSettings();

            //Load "AppSettings" from the AppSettings SQL Table!
            LoadAppSettings();

            //Allow "_plc
            if (_plcIP.ToUpper().Equals("NONE"))
            {
                _logger.LogMainEvent(this.ServiceName + " is configured with PLCIP = \"NONE\". (This is usually to focus testing the Client/Server TCP Socket architecture.)");
            }
            else
            {
                //Connect to PLC Device (probably add setting to Config file and move this to "LoadSettings()"!
                _plcDevice = new PLCDevice(_logger); //Will use 0 as the default Logical Unit Number.
                _plcDevice.Open();
            }

            _bander1Order = new BanderOrder(_logger); //Used to track the Manifest that we are "Transferring" to Bander 1.
            _bander2Order = new BanderOrder(_logger); //Used to track the Manifest that we are "Transferring" to Bander 2.

            ////Implementing new Networking Code...
            ////(Eventually, this "version" will go away!!)
            ////
            //// Create the Server Object and Start it.
            //_tcpServer = new TCPServer(_logger); //We can pass a port here or use the Default of 11000
            //_tcpServer.CommandReceived += TCPServer_CommandReceived;
            //_tcpServer.StartServer();

            //New Networking Code
            _tcpServerV2 = new TCPServerV2(_logger, Dns.GetHostName()); //We can pass a port here or use the Default of 11100
            _tcpServerV2.CommandReceived += TCPServer_CommandReceived;
            _tcpServerV2.StartServer();

            //Scanner Related
            //
            //StartTransferScanner();
            //Or start like this?
            //
            // Queue the transfer scanner communication for execution in a worker thread. 
            // (A Service has to return, the "work" should be done with Threads.)
            //ThreadPool.QueueUserWorkItem(new WaitCallback(TransferScannerThread)); 

            InitSkidBuilds(); //Initialize them from AppSettings and other tables.
            //This isn't necessary, because the BanderDisplay's can only be told what Manifest is being "Built", by this program!
            //ValidateSkidBuilds(); //Make sure these Builds still apply. (Check the "ScanOWK" Bander Scans?? Take into account the "Modified" timestamp in the AppSettings row???)
            //Once again... this isn't necessary, because the BanderDisplay's will "query" the Skid Build when they startup (after a restart, crash, reboot, etc).
            //SendSkidBuildsToBanderDisplays();

            //return 0;   
        }

        void InitSkidBuilds()
        {

            //What is the best way to determine what is on each Bander, after this Service has been Started/ReStarted??
            //Read the scans from the ScanOWK Table?
            //It has to be the Manifest for the LAST OWK Scanned, or 

            //Read in the last values from AppSettings.
            //If they don't exist, create them with null/blanks.
            
            SkidBuild bander1 = new SkidBuild();
            bander1.Init("Bander1");
            bander1.Recover(); //Heck, I could probably refactor this and add it to "Init()". Although, the BanderDisplay also uses this Class, so enough changes for now...
            _logger.LogMainEvent("On Start Up - Bander1Skid (ObjectDumper): " + ObjectDumper.Dump(bander1));
            //_logger.LogMainEvent("On Start Up - Bander1Skid (ClassToString): " + Misc.ClassToString(bander1));
            //Recover() should just call Persist() to handle creating a new/empty AppSetting!
            //if(bander1.Recover() == false)
            //{
            //    bander1.Persist(); //Persist will create a new/blank one, if one wasn't found in "Recover()".
            //}
            SkidBuilds.Add(bander1);
            SkidBuild bander2 = new SkidBuild();
            bander2.Init("Bander2");
            bander2.Recover(); //Heck, I could probably refactor this and add it to "Init()". Although, the BanderDisplay also uses this Class, so enough changes for now...
            _logger.LogMainEvent("On Start Up - Bander2Skid (ObjectDumper): " + ObjectDumper.Dump(bander2));
            //_logger.LogMainEvent("On Start Up - Bander2Skid (ClassToString): " + Misc.ClassToString(bander2));
            SkidBuilds.Add(bander2);
        }

        void TCPServer_CommandReceived(object sender, PickToLightCommandEventArgsV2 e)
        {
            _logger.Log("(V2Networking) PickToLightServer CommandReceived Event, Command = (" + e.Command + ") Length = (" + e.Command.Length + ")");
            if (ProcessP2LCommand(e) == false) //Basically, this is only "false" if we want to retun the "default" response below.
            {
                // I suppose this is just to keep the communicatons going between Client/Server (and keep the Server running)...
                // Because, this usually indicates a badly formatted command (wrong number of "Fields" (<GS>) or an "Exception"....
                // So, it's basically up to the Client to decide how to handle this type of response.
                string commandResponse = String.Format("(V2Networking) Command Received and Processed: <{0}> Length: <{1}>", e.Command, e.Command.Length.ToString());
                e.SendWithProtocol(commandResponse);
            }
            //e.ClientSocket.Send(Encoding.ASCII.GetBytes(String.Format("Command Received and Processed: <{0}> Length: <{1}>", e.Command, e.Command.Length.ToString())));
        }

        //Return false if we didn't process it and just need to send the regular reply back.
        bool ProcessP2LCommand(PickToLightCommandEventArgsV2 e)
        {
            string[] commandFields = e.Command.Split(caGS);

            if(commandFields.Length < 1) //No GS found!
            {
                _logger.Log("*****ProcessP2LCommand()***** ERROR: No GS in command!");
                return (false);
            }

            switch (commandFields[0])
            {
                //commandToSend = P2L_COMMAND_SkidBuildQuery + sGS + banderNum;
                case PickToLightCommands.P2L_COMMAND_SkidBuildQuery:
                    if (commandFields.Length < 2)
                    {
                        _logger.Log("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_SkidBuildQuery command received, but no Bander Number!");
                        return (false);
                    }
                    int banderNum = -1;
                    if (int.TryParse(commandFields[1], out banderNum) == false)
                    {
                        _logger.Log("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_SkidBuildQuery command received, but is NOT an integer!");
                        return (false);
                    }
                    if (banderNum != 1 && banderNum != 2)
                    {
                        _logger.Log("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_SkidBuildQuery command received, but Bander Number is out of range (currently only 1 or 2)!");
                        return (false);
                    }

                    //Keep this??
                    _logger.Log("-----ProcessP2LCommand()----- P2L_COMMAND_SkidBuildQuery was received for Bander Number [" + banderNum.ToString() + "]...");

                    //TODO: Create a new SQL Table to track "P2L_COMMAND" received and add a new row here!
                    //      Or, just use the "Log" table, but create a SQL View!!!!

                    //Check the SkidBuilds for the Bander Number and return the ScanManifestID
                    try
                    {
                        int manifestID = -1;
                        if (SkidBuilds.Count >= banderNum)
                        {
                            SkidBuild skidBuild = SkidBuilds[banderNum - 1];
                            if (skidBuild.ScanManifestID > 0 && string.IsNullOrEmpty(skidBuild.OrderNumber) == false)
                            {
                                manifestID = skidBuild.ScanManifestID;
                            }
                        }

                        //***Send the Command Response...
                        //string commandResponse = PickToLightCommands.PopulateSkidBuildQueryCommandResponse(manifestID);
                        //e.SendWithProtocol(commandResponse);
                        e.SendWithProtocol(PickToLightCommands.PopulateSkidBuildQueryCommandResponse(manifestID));

                        return (true);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError("Exception processing P2L_COMMAND_SkidBuildQuery: " + ex.Message);
                        return (false);
                        throw;
                    }

                    return (false); //Should never get here.

                    break;

                //commandToSend = P2L_COMMAND_SkidBuildBegin + sGS + manifestID + sGS + banderNum;
                case PickToLightCommands.P2L_COMMAND_SkidBuildBegin:
                    if (commandFields.Length < 3)
                    {
                        _logger.Log("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_SkidBuildBegin command received, but no ScanManifest ID or Bander Number!");
                        return (false);
                    }
                    int idScanManifest = -1;
                    if (int.TryParse(commandFields[1], out idScanManifest) == false)
                    {
                        _logger.Log("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_SkidBuildBegin command received, but ScanManifest ID is NOT an integer!");
                        return (false);
                    }
                    banderNum = -1;
                    if (int.TryParse(commandFields[2], out banderNum) == false)
                    {
                        _logger.Log("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_SkidBuildBegin command received, but Bander Number is NOT an integer!");
                        return (false);
                    }
                    if (banderNum != 1 && banderNum != 2)
                    {
                        _logger.Log("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_SkidBuildBegin command received, but Bander Number is out of range (currently only 1 or 2)!");
                        return (false);
                    }

                    //Keep this??
                    _logger.Log("-----ProcessP2LCommand()----- P2L_COMMAND_SkidBuildBegin was received for ScanManifest ID [" + idScanManifest.ToString() + "] and Bander Number [" + banderNum.ToString() + "]...");

                    //TODO: Create a new SQL Table to track "P2L_COMMAND" received and add a new row here!
                    //      Or, just use the "Log" table, but create a SQL View!!!!

                    //Read in the ID from the Table and decide what to do.
                    try
                    {
                        ScanManifest scanManifest = PickToLightData.ScanManifest.GetScanEntry(idScanManifest);
                        if (scanManifest != null) //Make sure we can read the row for the idScanManifest
                        {
                            
                            //Determine if this Manifest is OK for the Bander
                            //The Bander Num can be determined using the "CreatedBy" field in the ScanManifest Table...
                            //BUT... I'm going to add it as a parameter to this command. That makes more sense to me...
                            //
                            //We also need to return some things such as NAMC (the long name), SubRoute, RFid (top and bottom) and Confirmation#
                            //NOTE: Do I need to just send back the "SkiduildOrder" (using the "plan"???)
                            //
                            //
                            //For now, we are pretty much going to rely on the "BanderDisplay" to be up and working, to provide feedback to the kitter on needed scans, etc.
                            //
                            //Determine the Manifest of the "Bander Display", using the (generic) "List" of "SkidBuilds" (and the scans in ScanOWK).
                            //     If the Bander is "waiting" for a Manifest, go ahead and use it.
                            //          (Let the Bander Display know to update its display by sending it the same command (SkidBuildBegin???).)
                            //     If it is in the process of a Build, only allow the Manifest if it is the SAME Manifest.
                            //     (This will cover instances where the handheld program had to restart, or the battery died, etc.)
                            //     Otherwise, DENY the build and inform the user what Skid is currently being built on that Bander.

                            string skidId = (scanManifest.OrderSequence.Length < 4 ? "ERR" : scanManifest.OrderSequence.Substring(scanManifest.OrderSequence.Length - 4, 4)); //The SkidId+AorBcode is the last 4 characters: XX001A, 14001B, 11002A, 1A002B, etc......

                            SkidBuild skidBuild = SkidBuilds[banderNum-1]; //Note this gets a "copy" of the item, to update the item, change value in that "copy", then assign the copy back to the List Item...
                            //If nothing is assigned to this Bander
                            //OR, if the manifest scanned is the SAME manifest (for instance, if battery died on the handheld and they have to resend the command)
                            //THEN we can allow this Manifest to use this Bander.
                            if (skidBuild.ScanManifestID < 0
                                || (skidBuild.SupplierCode == scanManifest.SupplierCode &&
                                    skidBuild.NAMC == scanManifest.NAMC &&
                                    skidBuild.DockCode == scanManifest.DockCode &&
                                    skidBuild.OrderNumber == scanManifest.OrderNumber &&
                                    skidBuild.PalletizationCode == scanManifest.PalletizationCode &&
                                    skidBuild.SkidId == skidId)
                                )
                            {
                                //***Update the SkidBuilds list

                                //This Bander doesn't have a SkidBuild
                                //OR the SkidBuild request is for the SAME Manifest (for instance, if the battery dies on the handheld and they had to resend it)
                                //So...we can go ahead and assign it!
                                //
                                skidBuild.ScanManifestID = idScanManifest;
                                skidBuild.SupplierCode = scanManifest.SupplierCode;
                                skidBuild.NAMC = scanManifest.NAMC;
                                skidBuild.DockCode = scanManifest.DockCode;
                                skidBuild.OrderNumber = scanManifest.OrderNumber;
                                skidBuild.PalletizationCode = scanManifest.PalletizationCode;
                                skidBuild.SkidId = skidId;
                                string errorMessage = "";
                                //Moved method to the SkidBuild Class.
                                if (skidBuild.PopulateExtraFields(out errorMessage) == false)
                                {
                                    //return (false);
                                    e.SendWithProtocol(PickToLightCommands.PopulateSkidBuildBeginCommandErrorResponse(errorMessage));
                                    return (true);
                                }

                                SkidBuilds[banderNum-1] = skidBuild; //Assign the updated "copy" back to the List item....

                                //***Send the Command Response...
                                //string commandResponse = PickToLightCommands.PopulateSkidBuildBeginCommandResponse(0, JsonConvert.SerializeObject(skidBuild));
                                //e.SendWithProtocol(commandResponse);
                                e.SendWithProtocol(PickToLightCommands.PopulateSkidBuildBeginCommandOKResponse(skidBuild.TradingPartner, skidBuild.SubRoute, skidBuild.RfIdBase, skidBuild.RfIdLid, skidBuild.ConfirmationNumber));

                                //***Update the SkidBuild in AppSettings
                                //using (var ctx = new PickToLightEntities())
                                //{
                                //    AppSetting banderSkidBuild = (from a in ctx.AppSettings
                                //                                  where a.Name.Equals(skidBuild.Bander)
                                //                                  select a).SingleOrDefault<AppSetting>();
                                //    if (banderSkidBuild == null) //This really shouuldn't happen, but the row in the table could be deleted or changed, I suppose...
                                //    {
                                //        string banderSkidName = "Bander" + banderNum.ToString() + "Skid";
                                //        ctx.AppSettings.Add(new AppSetting
                                //        {
                                //            Name = banderSkidName, Value = idScanManifest.ToString(),
                                //            CreatedBy = this.ServiceName, ModifiedBy = this.ServiceName,
                                //            Description = "Stores the ScanManifestID that is currently being built on Bander" + banderNum.ToString() + "."
                                //        });
                                //        ctx.SaveChanges();
                                //        _logger.LogError("While processing a successful SkidBuildBegin Command, the " + banderSkidName + " setting was missing in AppSettings! Adding it.....");
                                //    }
                                //    else
                                //    {
                                //        banderSkidBuild.Value = skidBuild.ScanManifestID.ToString();
                                //        ctx.SaveChanges();
                                //    }
                                //}
                                SkidBuilds[banderNum - 1].Persist();

                                //***Send the SkidBuildBegin command to the Bander Display
                                SendBanderDisplaySkidBuildBeginCommand(banderNum, scanManifest.ID);

                                return(true);
                            }

                            //If we get here, the user ("kitter") shouldn't be allowed to "build" this Skid on this Manifest

                            //string commandResponse = PickToLightCommands.PopulateSkidBuildBeginCommandResponse(1, "Please close out the previous Skid Build before scanning a new one!");
                            //e.SendWithProtocol(commandResponse);
                            e.SendWithProtocol(PickToLightCommands.PopulateSkidBuildBeginCommandErrorResponse("Please close out the previous Skid Build before scanning a new one!"));
                            return (true);
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError("Exception processing P2L_COMMAND_SkidBuildBegin: " + ex.Message);
                        return (false);
                        throw;
                    }

                    return (false); //Should never get here.

                    break;

                //commandToSend = P2L_COMMAND_SkidBuildEnd + sGS + manifestID + sGS + banderNum;
                case PickToLightCommands.P2L_COMMAND_SkidBuildEnd:
                    if (commandFields.Length < 3)
                    {
                        _logger.Log("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_SkidBuildEnd command received, but no ScanManifest ID or Bander Number!");
                        return (false);
                    }
                    idScanManifest = -1;
                    if (int.TryParse(commandFields[1], out idScanManifest) == false)
                    {
                        _logger.Log("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_SkidBuildEnd command received, but ScanManifest ID is NOT an integer!");
                        return (false);
                    }
                    banderNum = -1;
                    if (int.TryParse(commandFields[2], out banderNum) == false)
                    {
                        _logger.Log("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_SkidBuildEnd command received, but Bander Number is NOT an integer!");
                        return (false);
                    }
                    if (banderNum != 1 && banderNum != 2)
                    {
                        _logger.Log("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_SkidBuildEnd command received, but Bander Number is out of range (currently only 1 or 2)!");
                        return (false);
                    }

                    //Keep this??
                    _logger.Log("-----ProcessP2LCommand()----- P2L_COMMAND_SkidBuildEnd was received for ScanManifest ID [" + idScanManifest.ToString() + "] and Bander Number [" + banderNum.ToString() + "]...");

                    //TODO: Create a new SQL Table to track "P2L_COMMAND" received and add a new row here!
                    //      Or, just use the "Log" table, but create a SQL View!!!!

                    //Read in the ID from the Table and decide what to do.
                    try
                    {
                        ScanManifest scanManifest = PickToLightData.ScanManifest.GetScanEntry(idScanManifest);
                        if (scanManifest != null) //Make sure we can read the row for the idScanManifest
                        {

                            //Determine if this Manifest can "close out" the Skid Build on the Bander
                            //
                            //For now, we are pretty much going to rely on the "BanderDisplay" to be up and working, to provide feedback to the kitter on needed scans, etc.
                            //
                            //Determine the Manifest of the "Bander Display", using the (generic) "List" of "SkidBuilds" (and the scans in ScanOWK).

                            //Now, only check the first 3 digits of the SkidId, we will let them scan the same one twice...
                            string skidId = (scanManifest.OrderSequence.Length < 4 ? "ERR" : scanManifest.OrderSequence.Substring(scanManifest.OrderSequence.Length - 4, 3)); //The SkidId+AorBcode is the last 4 characters: XX001A, 14001B, 11002A, 1A002B, etc......

                            SkidBuild skidBuild = SkidBuilds[banderNum - 1]; //Note this gets a "copy" of the item, to update the item, change value in that "copy", then assign the copy back to the List Item...
                            if (skidBuild.ScanManifestID > 0
                                && (skidBuild.SupplierCode == scanManifest.SupplierCode &&
                                    skidBuild.NAMC == scanManifest.NAMC &&
                                    skidBuild.DockCode == scanManifest.DockCode &&
                                    skidBuild.OrderNumber == scanManifest.OrderNumber &&
                                    skidBuild.PalletizationCode == scanManifest.PalletizationCode &&
                                    skidBuild.SkidId.StartsWith(skidId)) //Only use the first 3 characters, when closing out, they can scan the same Skid Id. A/B doesn't matter!
                                )
                            {
                                //***Update the SkidBuilds list
                                //By clearing out the Manifest assigned.
                                //Soon, we want to do some validation here and make sure everthing has been scanned
                                //and also return a message telling the user if he needs to submit it, based on the Confirmation# (and all OWKs scanned).

                                string message = "";

                                skidBuild.Init(skidBuild.Bander);
                                SkidBuilds[banderNum - 1] = skidBuild; //Assign the updated "copy" back to the List item....

                                //***Send the Command Response...
                                //string commandResponse = PickToLightCommands.PopulateSkidBuildEndCommandResponse(0, JsonConvert.SerializeObject(skidBuild));
                                //e.SendWithProtocol(commandResponse);
                                e.SendWithProtocol(PickToLightCommands.PopulateSkidBuildEndCommandResponse(0,message));

                                //***Update the SkidBuild in AppSettings
                                SkidBuilds[banderNum - 1].Persist();

                                //***Send the SkidBuildEnd command to the Bander Display
                                SendBanderDisplaySkidBuildEndCommand(banderNum, scanManifest.ID);

                                return (true);
                            }

                            //If we get here, the user ("kitter") shouldn't be allowed to "build" this Skid on this Manifest

                            //string commandResponse = PickToLightCommands.PopulateSkidBuildEndCommandResponse(1, "Please close out the previous Skid Build before scanning a new one!");
                            //e.SendWithProtocol(commandResponse);
                            e.SendWithProtocol(PickToLightCommands.PopulateSkidBuildEndCommandResponse(1, "Please close out the previous Skid Build before scanning a new one!"));
                            return (true);
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError("Exception processing P2L_COMMAND_SkidBuildEnd: " + ex.Message);
                        return (false);
                        throw;
                    }

                    return (false); //Should never get here.

                    break;

                //commandToSend = P2L_COMMAND_ShipmentLoadBegin + sGS + supplierCode + sGS + shipDate + sGS + shipTime + sGS + subRoute;
                //(Ignoring  SubRoute for now, because it isn't sent from the Canadian NAMCs anyway.)
                case PickToLightCommands.P2L_COMMAND_ShipmentLoadBegin:
                    //if (commandFields.Length < 5)
                    if (commandFields.Length < 4)  //(Ignoring  SubRoute for now, because it isn't sent from the Canadian NAMCs anyway.)
                    {
                        _logger.Log("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_ShipmentLoadBegin command received, but has mising fields!");
                        return (false);
                    }
                    string supplierCode = commandFields[1];
                    string shipDate = commandFields[2];
                    string shipTime = commandFields[3];
                    //(Ignoring  SubRoute for now, because it isn't sent from the Canadian NAMCs anyway.)
                    //string subRoute = commandFields[4];

                    //Keep this??
                    //_logger.Log("-----ProcessP2LCommand()----- P2L_COMMAND_ShipmentLoadBegin was received for SupplierCode[" + supplierCode + "] SubRoute[" + subRoute + "] ShipDate[" + shipDate + "] ShipTime[" + shipTime + "]...");
                    //(Ignoring  SubRoute for now, because it isn't sent from the Canadian NAMCs anyway.)
                    _logger.Log("-----ProcessP2LCommand()----- P2L_COMMAND_ShipmentLoadBegin was received for SupplierCode[" + supplierCode + "] ShipDate[" + shipDate + "] ShipTime[" + shipTime + "]...");

                    //TODO: Create a new SQL Table to track "P2L_COMMAND" received and add a new row here!
                    //      Or, just use the "Log" table, but create a SQL View!!!!

                    try
                    {
                        //First, we need to see if there is already a ShipmentLoad for this SupplierCode + ShipDate + ShipTime (We are ignoring 
                        //When Searching for CMS/ToyotaShipments table (also ShipmentLoadOrder table for now):
                        //    Convert ShipTime to an INT and then search for a range within 5 minutes before and after the ShipTime!!!!!
                        //    This is necessary because sometimes the OWK and EDI ShipTime differ by a few seconds....
                        //ShipmentLoadTrailer shipmentLoadTrailer = ShipmentLoadTrailer.GetShipmentLoadTrailer(supplierCode, subRoute, shipDate, shipTime);
                        //(Ignoring  SubRoute for now, because it isn't sent from the Canadian NAMCs anyway.)
                        ShipmentLoadTrailer shipmentLoadTrailer = ShipmentLoadTrailer.GetShipmentLoadTrailer(supplierCode, shipDate, shipTime);
                        //GetShipmentLoadTrailer() Throws an Exception if there are more than one match, because there is a problem with the data that needs to be fixed!

                        //Now we need to create the ShipmentLoadTrailer "Plan".
                        //    First, lets Query all the ToyotaShipments for this Shipment Load and check for:
                        //      Missing ShipmentLoadTrailer "Plan" for supplied data (SupplierCode, ShipDate, ShipTime, SubRoute)
                        //          (Ignoring  SubRoute for now, because it isn't sent from the Canadian NAMCs anyway.)
                        //      One or more "ToyotaShipments NOT Completed" ERRORS! (Completed = False)
                        //      One or more "Missing SkidBuildOrder" ERRORS! (no SkidBuildOrderId)
                        //      One or more "Missing SkidBuildOrder Confirmation" ERRORS!
                        //          No ConfirmationNumber?
                        //          --OR--
                        //          Should I check for ConfirmationNumber NOT end with "P" or "L"???
                        //          NO!! Because SkidBuildOrder only ends in "P". (Unless we add something like "Order Changed Need Confirmation".)
                        //RequestShipmentLoad shipmentLoadTrailerPlan = ShipmentLoadTrailer.GetShipmentLoadTrailerPlan(supplierCode, subRoute, shipDate, shipTime);
                        //(Ignoring  SubRoute for now, because it isn't sent from the Canadian NAMCs anyway.)
                        RequestShipmentLoad shipmentLoadTrailerPlan = ShipmentLoadTrailer.GetShipmentLoadTrailerPlan(supplierCode, shipDate, shipTime);
                        //NO, this should return a ShipmentLoadTrailer (SQL Class, not the API Request Class, thats what we want to return to the Client!)
                        //ShipmentLoadTrailer shipmentLoadTrailerPlan = ShipmentLoadTrailer.GetShipmentLoadTrailerPlan(supplierCode, shipDate, shipTime);
                        //GetShipmentLoadTrailerPlan() Should just throw an Exception with the ERROR message to show the user!

                        int responseCode = 0; //No match found, so we return responseCode=0 and data is populated with the ShipmentLoadTrailer "Plan".
                        if(shipmentLoadTrailer != null) //Match found, so we return responseCode=ShipmentLoadTrailerID and data is populated with the ShipmentLoadTrailer "Plan" (in case the ShipmentLoad wasn't completed or the "Plan" has changed).
                        {
                            responseCode = shipmentLoadTrailer.ID;
                        }
                        string data = JsonConvert.SerializeObject(shipmentLoadTrailerPlan);
                        string commandResponse = PickToLightCommands.PopulateShipmentLoadBeginCommandResponse(responseCode, data);
                        e.SendWithProtocol(commandResponse);
                        return (true);
                    }
                    catch (ShipmentLoadCustomProgramException ex)
                    {
                        //Return Exception to Client Device and show it!!!!!!
                        //This Exception type could be thrown by GetShipmentLoadTrailer() or GetShipmentLoadTrailerPlan()
                        string commandResponse = PickToLightCommands.PopulateShipmentLoadBeginCommandResponse(-1, ex.Message);
                        e.SendWithProtocol(commandResponse);
                        _logger.LogError(ex.Message);

                        //return (false);
                        return (true); //NO, return true so the calling method doesn't send another (default) Response!!!
                    }
                    catch (Exception ex)
                    {
                        string exceptionError;
                        if (ex.InnerException != null)
                        {
                            exceptionError = "-----ProcessP2LCommand()----- P2L_COMMAND_ShipmentLoadBegin Exception: " + ex.Message + " (Inner Exception: " + ex.InnerException + ")";
                            _logger.LogError(exceptionError);
                        }
                        else
                        {
                            exceptionError = "-----ProcessP2LCommand()----- P2L_COMMAND_ShipmentLoadBegin Exception: " + ex.Message;
                            _logger.LogError(exceptionError);
                        }

                        //Return Exception to Client Device and show it!!!!!!
                        string commandResponse = PickToLightCommands.PopulateShipmentLoadBeginCommandResponse(-1, exceptionError);
                        e.SendWithProtocol(commandResponse);

                        //return (false);
                        return (true); //NO, return true so the calling method doesn't send another (default) Response!!!
                    }

                    return (false); //Should never get here.

                    break;

                ///// The ShipmentLoadSubmit command is sent by a client to Submit a ShipmentLoadTrailer Request to the Toyota SCS API for Approval/Confirmation.
                ///// The "Response" to this command consists of two "fields", the "responseCode" and "data". The possible values for each parameter are explained below...
                ///// <param name="approved">True (Was submitted and Approved.)
                /////                        False (Was not approved, the message parameter contains the reason.
                ///// <param name="message">When approved parameter is true (1), this contains the Confirmation # to show.</param>
                /////                       When approved parameter is false (0), this contains the message to show the user.</param>
                //static public string PopulateShipmentLoadSubmitCommandResponse(int approved, string message)
                case PickToLightCommands.P2L_COMMAND_ShipmentLoadSubmit:
                    if (commandFields.Length < 2)
                    {
                        _logger.Log("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_ShipmentLoadSubmit command received, but no ShipmentLoadTrailerID!");
                        return (false);
                    }
                    int shipmentLoadTrailerID = -1;
                    if (int.TryParse(commandFields[1], out shipmentLoadTrailerID) == false)
                    {
                        _logger.Log("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_ShipmentLoadSubmit command received, but ShipmentLoadTrailerID is NOT an integer!");
                        return (false);
                    }

                    //Keep this??
                    _logger.Log("-----ProcessP2LCommand()----- P2L_COMMAND_ShipmentLoadSubmit was received for ShipmentLoadTrailerID ID [" + shipmentLoadTrailerID.ToString() + "]...");

                    //TODO: Create a new SQL Table to track "P2L_COMMAND" received and add a new row here!
                    //      Or, just use the "Log" table, but create a SQL View!!!!

                    //Read in the ID from the Table and decide what to do.
                    try
                    {
                        ShipmentLoadTrailer shipmentLoadTrailer = ShipmentLoadTrailer.GetShipmentLoadTrailer(shipmentLoadTrailerID);
                        //GetShipmentLoadTrailer() Throws an Exception if there are more than one match, because there is a problem with the data that needs to be fixed!

                        if (shipmentLoadTrailer != null) //Make sure we can read the row for the shipmentLoadTrailerID
                        {
                            string message = "";
                            bool success = ToyotaShipmentLoadRequest(shipmentLoadTrailer, out message);
                            //We "couuld" throw an Exception in ToyotaShipmentLoadRequest() and it would be handled below in the "catch" and just be returned as another Error..... I'm just saying...

                            string commandResponse = PickToLightCommands.PopulateShipmentLoadSubmitCommandResponse(success, message);
                            e.SendWithProtocol(commandResponse);

                            return (true);
                        }
                        else
                        {
                            string error = "-----ProcessP2LCommand()----- P2L_COMMAND_ShipmentLoadSubmit No ShipmentLoadTrailer found for ID: " + shipmentLoadTrailerID.ToString();
                            string commandResponse = PickToLightCommands.PopulateShipmentLoadSubmitCommandResponse(false, error);
                            e.SendWithProtocol(commandResponse);
                            _logger.LogError(error);

                            return (true); //Return true so the calling method doesn't send another (default) Response!!!
                        }
                    }
                    catch (ShipmentLoadCustomProgramException ex)
                    {
                        //Return Exception to Client Device and show it!!!!!!
                        //This Exception type could be thrown by GetShipmentLoadTrailer()
                        string commandResponse = PickToLightCommands.PopulateShipmentLoadSubmitCommandResponse(false, ex.Message);
                        e.SendWithProtocol(commandResponse);
                        _logger.LogError(ex.Message);

                        //return (false);
                        return (true); //NO, return true so the calling method doesn't send another (default) Response!!!
                    }
                    catch (Exception ex)
                    {
                        string exceptionError;
                        if (ex.InnerException != null)
                        {
                            exceptionError = "-----ProcessP2LCommand()----- P2L_COMMAND_ShipmentLoadSubmit Exception: " + ex.Message + " (Inner Exception: " + ex.InnerException + ")";
                            _logger.LogError(exceptionError);
                        }
                        else
                        {
                            exceptionError = "-----ProcessP2LCommand()----- P2L_COMMAND_ShipmentLoadSubmit Exception: " + ex.Message;
                            _logger.LogError(exceptionError);
                        }

                        //Return Exception to Client Device and show it!!!!!!
                        string commandResponse = PickToLightCommands.PopulateShipmentLoadSubmitCommandResponse(false, exceptionError);
                        e.SendWithProtocol(commandResponse);

                        //return (false);
                        return (true); //NO, return true so the calling method doesn't send another (default) Response!!!
                    }

                    return (false); //Should never get here.

                    break;

                //commandToSend = P2L_COMMAND_RegisterClient + sGS + _deviceName + sGS + _appName + sGS + _clientVersion;
                case PickToLightCommands.P2L_COMMAND_RegisterClient:
                    if (commandFields.Length < 4)
                    {
                        _logger.Log("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_RegisterClient command received, but has mising fields!");
                        return (false);
                    }

                    //TODO: Create a new SQL Table to track "P2L_COMMAND" received and add a new row here!
                    //      Or, just use the "Log" table, but create a SQL View!!!!

                    try
                    {
                        //commandToSend = P2L_COMMAND_RegisterClient + sGS + _deviceName + sGS + _appName + sGS + _clientVersion;
                        string deviceName = commandFields[1];
                        string appName = commandFields[2];
                        string clientVersion = commandFields[3];

                        _logger.Log("-----ProcessP2LCommand()----- P2L_COMMAND_RegisterClient was received, Device [" + deviceName + "] is running Application [" + appName + "] Version [" + clientVersion + "]...");

                        string data = commandFields[1] + sGS + "This device has been registered and is approved for use!";
                        if (deviceName.ToUpper().StartsWith("DESKTOP"))
                        {
                            data = "This device isn't currently approved for use on the network. Please try another device (Honeywell Dolphin's are currently the only approved devices)";
                            _logger.Log("-----ProcessP2LCommand()----- P2L_COMMAND_RegisterClient was received, Client [" + deviceName + "] is not allowed to use the system, returning error message!");
                        }

                        string commandResponse = PickToLightCommands.PopulateRegisterClientCommandResponse(data);
                        e.SendWithProtocol(commandResponse);
                        return (true);
                    }
                    catch (Exception)
                    {
                        return (false);
                        throw;
                    }

                    return (false); //Should never get here.

                    break;

                case PickToLightCommands.P2L_COMMAND_Ping:
                    //
                    // 6-20-18 - Change the format of the "P2L_COMMAND_Ping" command.
                    //           Added another field (using <GS>) that (optionally) contains the client version.
                    //           If the client is running version 3, send back the new "SQL Server Connnection String" ("HQ-SQL02")!
                    //           Otherwise, send back the old "SQL Server Connnection String" ("GT-transACTION\SQLExpress")!
                    //           (All clients should be on Version 3 when this was put into production, this was just a "safety net".)
                    //           This should be administered/configured/handled in the future, using a "Config" SQL Table.
                    //           (This "Config" table should handle all configuration/customization/properties/etc for the ENTIRE PickToLight "system"!)
                    if (commandFields.Length < 2)
                    {
                        _logger.Log("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_Ping command received, but no data!");
                        return (false);
                    }
                    //string data = commandFields[1];

                    //Keep this??
                    _logger.Log("-----ProcessP2LCommand()----- P2L_COMMAND_Ping was received from Client [" + commandFields[1] + "]...");

                    //TODO: Create a new SQL Table to track "P2L_COMMAND" received and add a new row here!
                    //      Or, just use the "Log" table, but create a SQL View!!!!

                    //Otherwise, read in the ID from the Table and decide what to do.
                    try
                    {
                        //// commandToSend = P2L_COMMAND_Ping + sGS + DeviceID + sGS + ClientSoftwareVersion
                        string clientVersion3 = "3";
                        ////string deviceIDTesting1 = "ID15132J0058";
                        ////string deviceIDTesting2 = "BB4QL12";

                        //
                        //No longer return the SQL Connection String!
                        //
                        //string oldSqlConnectionString = @"Server=GT-transACTION\SQLExpress;Database=PickToLight; Uid=PickToLight; pwd=P1ckT0L1ght;";
                        //string newSqlConnectionString = @"Server=HQ-SQL02;Database=PickToLight; Uid=PickToLight; pwd=P1ckT0L1ght;";
                        //string sqlConnectionString = oldSqlConnectionString;
                        ////if (commandFields.Length > 2 && commandFields[2] == clientVersion3 && commandFields[1] == deviceIDTesting ) //3 fields = 2 GS characters.
                        if (commandFields.Length > 2) //3 fields = 2 GS characters.
                        {
                            _logger.Log("-----ProcessP2LCommand()----- P2L_COMMAND_Ping was received, Client is running Version [" + commandFields[2] + "]...");

                            //
                            //No longer return the SQL Connection String!
                            //
                            ////RIGHT NOW, FOR TESTING, WE ARE ONLY PASSING THE STRING to Version 3 clients!!!
                            //if (commandFields[2] == clientVersion3)
                            //{
                            //    ////RIGHT NOW, FOR TESTING, WE ARE ONLY PASSING THE STRING to the Honeywell Device in the IT office and my laptop!!!
                            //    //if (commandFields[1] == deviceIDTesting1 || commandFields[1] == deviceIDTesting2)
                            //    //{
                            //    //    //This is for testing, don't put this device in Production yet!
                            //    //    // responseToSend = P2L_COMMAND_Ping + sGS + DeviceID + sGS + SQLDBConnectionString
                            //    //    data = commandFields[1] + sGS + sqlConnectionString;
                            //    //}
                            //    sqlConnectionString = newSqlConnectionString;
                            //}
                        }
                        //                        string data = commandFields[1] + sGS + sqlConnectionString;

                        string data = commandFields[1] + sGS + "This device is Approved for use!";
                        //List<String> devicesDenied = ["DESKTOP-GQG6V38", "DESKTOP-ER09RIO"];
                        //if (commandFields[1].ToUpper().StartsWith("DESKTOP") || commandFields[1].ToUpper().Equals("B1FPNN2"))
                        if (commandFields[1].ToUpper().StartsWith("DESKTOP") )
                        {
                            data = "This device isn't currently approved for use on the network. Please try another device (Honeywell Dolphin's are currently the only approved devices)";
                            _logger.Log("-----ProcessP2LCommand()----- P2L_COMMAND_Ping was received, Client [" + commandFields[1] + "] is not allowed to use the system, returning error message!");
                        }

                        string commandResponse = PickToLightCommands.PopulatePingCommandResponse(data);
                        e.SendWithProtocol(commandResponse);
                        return (true);
                    }
                    catch (Exception)
                    {
                        return (false);
                        throw;
                    }

                    return (false); //Should never get here.

                    break;

                case PickToLightCommands.P2L_COMMAND_ScanTransfer:
                    if (commandFields.Length < 2)
                    {
                        _logger.Log("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_ScanTransfer command received, but no ScanOWK entryID!");
                        return (false);
                    }
                    int idScanOWK = -1;
                    if(int.TryParse(commandFields[1], out idScanOWK) == false)
                    {
                        _logger.Log("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_ScanTransfer command received, but ScanOWK entryID is NOT an integer!");
                        return (false);
                    }

                    //Keep this??
                    _logger.Log("-----ProcessP2LCommand()----- P2L_COMMAND_ScanTransfer was received for ScanOWK ID [" + idScanOWK.ToString() + "]...");

                    //TODO: Create a new SQL Table to track "P2L_COMMAND" received and add a new row here!
                    //      Or, just use the "Log" table, but create a SQL View!!!!

                    //if idScanOWK is a 0 (Zero), then the barcode scan failed....so just log it!
                    //TODO: Or, really should read in the Row from the table and check the "Decoded" boolean column!
                    if(idScanOWK == 0)
                    {
                        if (_plcDevice != null) _plcDevice.WriteNoRead();
                        string commandResponse = PickToLightCommands.PopulateScanTransferCommandResponse(idScanOWK, 0);
                        e.SendWithProtocol(commandResponse);
                        return (true);
                    }

                    //Otherwise, read in the ID from the Table and decide what to do.
                    try
                    {
                        ScanOWK scanOWK = PickToLightData.ScanOWK.GetScanEntry(idScanOWK);
                        if (scanOWK != null) //Is this even possible?
                        {
                            //TODO: Create a method that determines the Bander to use?
                            if (TransferDebug)
                            {
                                _logger.Log("-----ProcessP2LCommand()----- Critical ScanOWK values to use:"
                                    + " ID [" + idScanOWK.ToString() + "],"
                                    + " Order/Manifest # [" + scanOWK.OrderNumber + "],"
                                    + " SubRoute [" + scanOWK.SubRoute + "],"
                                    + " MainRoute [" + scanOWK.MainRoute + "],"
                                    );
                                _logger.Log("_bander1Order (ObjectDumper): " + ObjectDumper.Dump(_bander1Order));
                                _logger.Log("_bander2Order (ObjectDumper): " + ObjectDumper.Dump(_bander2Order));
                            }

                            //Read the current Manifest for each Bander from the PLC Register.
                            //This handles two situations, a "restart" of this Service and if the "Swap Builds" button is pressed on the HMI/TouchScreen.
                            if (_plcDevice != null)
                            {
                                string plcManifest = "";
                                _plcDevice.ReadBanderManifest(true, out plcManifest);
                                if (_bander1Order.PLCString != plcManifest) _bander1Order.ReplaceWith(plcManifest);
                                _plcDevice.ReadBanderManifest(false, out plcManifest);
                                if (_bander2Order.PLCString != plcManifest) _bander2Order.ReplaceWith(plcManifest);
                            }
                            //Determine which Banding Machine to use:
                            // First, check the Order Info (SupplierCode,NAMC,DockCode,OrderNumber).
                            // Then check the MainRoute and SubRoute
                            // Lastly, just use the bander that hasn't been used for the longest.
                            banderNum = DetermineBander(scanOWK);
                            //Update the Routes and TimeStamps... Used to determine Bander
                            //Make sure I really want to do this here, I think I do??
                            //Make sure I really want to do this here, I think I do??
                            //Make sure I really want to do this here, I think I do??
                            if(banderNum == 1)
                            {
                                _bander1Order.ReplaceWith(scanOWK);
                                if (_plcDevice != null) _plcDevice.WriteBanderManifest(true, _bander1Order.PLCString);
                                if (TransferDebug) _logger.Log("Bander 1 was chosen.");
                                //_mainRoute1 = scanOWK.MainRoute;
                                //_subRoute1 = scanOWK.SubRoute;
                                //_bander1Used = DateTime.Now;
                            }
                            else
                            {
                                _bander2Order.ReplaceWith(scanOWK);
                                if (_plcDevice != null) _plcDevice.WriteBanderManifest(false, _bander2Order.PLCString);
                                if (TransferDebug) _logger.Log("Bander 2 was chosen.");
                                //_mainRoute2 = scanOWK.MainRoute;
                                //_subRoute2 = scanOWK.SubRoute;
                                //_bander2Used = DateTime.Now;
                            }
                            //Tell the PLC which Banding Machnie to "Transfer" the current Tote/Part to.
                            //(By writing the proper value to the correct Register.)
                            if (_plcDevice != null) _plcDevice.WriteCommand("01" + banderNum.ToString("D2"));

                            string commandResponse = PickToLightCommands.PopulateScanTransferCommandResponse(idScanOWK, banderNum);
                            e.SendWithProtocol(commandResponse);

                            //
                            //See if we need to get a Toyota SkidBuildOrder Confirmation for the OWK just scanned.
                            //(Actually, NOT the one just scanned, but the one that is no longer going to be tracked/scanned.)
                            //(We know this because a new OWK/Order was just scanned that will cause it to no longer be tracked.)
                            //If we do, go ahead and send it for Confirmation!
                            //
                            VerifyToyotaSkidBuildOrderConfirmation(scanOWK);

                            return (true);
                        }
                    }
                    catch (Exception ex)
                    {
                        string exceptionError;
                        if (ex.InnerException != null)
                        {
                            exceptionError = "-----ProcessP2LCommand()----- P2L_COMMAND_ScanTransfer Exception: " + ex.Message + " (Inner Exception: " + ex.InnerException + ")";
                            _logger.LogError(exceptionError);
                        }
                        else
                        {
                            exceptionError = "-----ProcessP2LCommand()----- P2L_COMMAND_ScanTransfer Exception: " + ex.Message;
                            _logger.LogError(exceptionError);
                        }
                        return (false);
                    }

                    return (false); //Should never get here.

                    break;

                // commandToSend = P2L_COMMAND_Log + sGS + source + sGS + threadName + sGS + threadID.ToString() + sGS + data;
                case PickToLightCommands.P2L_COMMAND_Log:
                    if (commandFields.Length < 5) //5 fields = 4 GS characters.
                    {
                        _logger.Log("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_Log command received, but one of the four command parameters is missing!");
                        //return (false); //I don't like the way the calling code handles a FALSE return value. It probably needs to be changed.
                        string commandResponse = PickToLightCommands.PopulateLogCommandResponse(-1);
                        e.SendWithProtocol(commandResponse);
                        return (true);

                    }
                    int threadID = -1;
                    if (int.TryParse(commandFields[3], out threadID) == false)
                    {
                        _logger.Log("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_Log command received, but 'ThreadID' parameter is NOT an integer!");
                        //return (false); //I don't like the way the calling code handles a FALSE return value. It probably needs to be changed.
                        string commandResponse = PickToLightCommands.PopulateLogCommandResponse(-2);
                        e.SendWithProtocol(commandResponse);
                        return (true);
                    }

                    //Keep this??
                    _logger.Log("-----ProcessP2LCommand()----- P2L_COMMAND_Log was received...");

                    //TODO: Create a new SQL Table to track "P2L_COMMAND" received and add a new row here!
                    //      Or, just use the "Log" table, but create a SQL View!!!!

                    //Now, Add the Log entry to the Log Table.
                    try
                    {
                        PickToLightData.Log.CreateLogEntry(commandFields[1], commandFields[2], threadID, commandFields[4]);
                        string commandResponse = PickToLightCommands.PopulateLogCommandResponse(0);
                        e.SendWithProtocol(commandResponse);
                        return (true);
                    }
                    catch (Exception)
                    {
                        //return (false); //I don't like the way the calling code handles a FALSE return value. It probably needs to be changed.
                        string commandResponse = PickToLightCommands.PopulateLogCommandResponse(1);
                        e.SendWithProtocol(commandResponse);
                        return (true);
                    }

                    return (false); //Should never get here. //I don't like the way the calling code handles a FALSE return value. It probably needs to be changed.

                    break;

                // commandToSend = P2L_COMMAND_LinePart + sGS + LineName;
                // commandResponse = P2L_COMMAND_LinePart + sGS + LineName + sGS + snaPartNum;
                case PickToLightCommands.P2L_COMMAND_LinePart:
                    if (commandFields.Length < 2) //3 fields = 2 GS characters.
                    {
                        _logger.Log("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_LinePart command received, but one the LineName parameter is missing!");
                        return (false); //I don't like the way the calling code handles a FALSE return value. It probably needs to be changed.
                        //string commandResponse = PickToLightCommands.PopulateLinePartCommandResponse(-1);
                        //e.SendWithProtocol(commandResponse);
                        //return (true);

                    }

                    //Keep this??
                    _logger.Log("-----ProcessP2LCommand()----- P2L_COMMAND_LinePart was received...");

                    //TODO: Create a new SQL Table to track "P2L_COMMAND" received and add a new row here!
                    //      Or, just use the "Log" table, but create a SQL View!!!!

                    string lineName = commandFields[1];
                    string snaPartNum;

                    //Just for testing, lets hardcode two values:
                    // Client: < STX >LP< GS >AUTO3< ETX >
                    // Server:< STX >LP< GS >AUTO3<GS>1411-AL< ETX >
                    //
                    //  Client: < STX >LP< GS >AUTO2< ETX >
                    //  Server:< STX >LP< GS >AUTO2<GS>1412-AR< ETX >
                    if (lineName.Equals("AUTO2"))
                    {
                        snaPartNum = "1412-AR";
                    }
                    else if (lineName.Equals("AUTO3"))
                    {
                        snaPartNum = "1411-AL";
                    }
                    else
                    {
                        snaPartNum = "UNKNOWN";
                    }


                    try
                    {
                        //PickToLightData.Log.CreateLogEntry(commandFields[1], commandFields[2], threadID, commandFields[4]);
                        string commandResponse = PickToLightCommands.PopulateLinePartCommandResponse(lineName, snaPartNum);
                        e.SendWithProtocol(commandResponse);
                        return (true);
                    }
                    catch (Exception)
                    {
                        return (false); //I don't like the way the calling code handles a FALSE return value. It probably needs to be changed.
                        //string commandResponse = PickToLightCommands.PopulateLinePartCommandResponse(1);
                        //e.SendWithProtocol(commandResponse);
                        //return (true);
                    }

                    return (false); //Should never get here. //I don't like the way the calling code handles a FALSE return value. It probably needs to be changed.

                    break;

                //
                // 10-19-18 -   New code for Toyota SCS (Shipping Confirmation System).
                //              This command (P2L_COMMAND_ScanManifestEnd) will be sent by the PickToLightClient (Version 4) when the "Picker" scans the "B" Manifest.
                //              This is the "trigger" for this Server program to send the "SkidBuild" Request (for Toyota SCS).
                //              For now, we will just return a static message or "success".
                //              In the future, we could return the Status of the Request and the Confirmation #.
                //              It all depends on how much information we want to pass onto the "Picker".
                case PickToLightCommands.P2L_COMMAND_ScanManifestEnd:
                    if(commandFields.Length < 2)
                    {
                        _logger.Log("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_ScanManifestEnd command received, but no ScanManifest entryID!");
                        return (false);
                    }
                    //int idScanManifest = -1;
                    idScanManifest = -1;
                    if(int.TryParse(commandFields[1], out idScanManifest) == false)
                    {
                        _logger.Log("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_ScanManifestEnd command received, but ScanManifest entryID is NOT an integer!");
                        return (false);
                    }

                    //Keep this??
                    _logger.Log("-----ProcessP2LCommand()----- P2L_COMMAND_ScanManifestEnd was received for ScanManifest ID [" + idScanManifest.ToString() + "]...");

                    //TODO: Create a new SQL Table to track "P2L_COMMAND" received and add a new row here!
                    //      Or, just use the "Log" table, but create a SQL View!!!!

                    //Read in the ID from the Table and decide what to do.
                    try
                    {
                        ScanManifest scanManifest = PickToLightData.ScanManifest.GetScanEntry(idScanManifest);
                        if(scanManifest != null) //Make sure we can read the row for the idScanManifest
                        {
                            ////We could check the database, including the "ToyotaShipments", imported data/table and see if everything has been scanned for this Skid/Order.
                            ////Then, we could direct he Picker on what is left to scan!
                            ////Or, that could all be tracked on the client, by doing a looking during the "ManifestBegin" and returning what Kanbans are supposed to be pulled.
                            ////(Once again, using the "ToyotaShipments" table!
                            //ServerCommandResponse serverCommandResponse = new ServerCommandResponse();
                            //serverCommandResponse.NowScanThis = ServerCommandResponse.WhatToScan.ManifestBegin;
                            //serverCommandResponse.ShowErrorDialog = false;
                            //serverCommandResponse.UserInstructions = "Scan the Manifest to start a new kit.";
                            //serverCommandResponse.ErrorMessage = "";
                            ////TODO: serverCommandResponse.ProgramOutput = "Create a new Method() to be populate with Manifest Info that User is currently Pulling!";
                            //serverCommandResponse.ProgramOutput = "DONE pulling parts for Supplier Code " + scanManifest.SupplierCode + " Dock Code " + scanManifest.DockCode + " Order # " + scanManifest.OrderNumber;
                            //string commandResponse = PickToLightCommands.PopulateClientScanCommandResponse(PickToLightCommands.P2L_COMMAND_ScanManifestEnd, rowID, serverCommandResponse);
                            //e.SendWithProtocol(commandResponse);

                            //*****IMPORTANT*****
                            //*****IMPORTANT*****
                            //MOVE THIS TO REPLY BEFORE PROCESSING THE MANIFEST!!!
                            //IT'S CAUSING AN ERROR ON THE CLIENTS BECAUSE IT'S SO SLOW...
                            string commandResponse = PickToLightCommands.PopulateScanManifestEndCommandResponse(idScanManifest);
                            e.SendWithProtocol(commandResponse);
                            //*****IMPORTANT*****
                            //*****IMPORTANT*****

                            //Determine if we need to send a SkidBuild Request to TSCS.
                            //If there is more than one Skid, they all have to be sent on a single SkidBuild (Order) Request....
                            //
                            //(Note, don't put this logic in "ToyotaSkidBuildRequest",
                            //     because the "TransferScan" process has this logic and executes it BEFORE calling ToyotaSkidBuildRequest()!!)
                            //Before trying to create the SkidBuildOrder, lets see if there is one, if there is one, then we don't want to try to create another one!!
                            SkidBuildOrder skidBuildOrder = SkidBuildOrder.GetSkidBuildOrder(scanManifest.NAMC, scanManifest.SupplierCode, scanManifest.OrderNumber, scanManifest.DockCode);
                            //We really only care if there isn't a SkidBuildOrder.
                            //We don't really need to check for a Confirmation Number here (ScanManifestEnd).
                            //We may need a way to "append" to the order, or maybe that should only be a "manual" process??
                            if (skidBuildOrder == null)
                            {
                                ToyotaSkidBuildRequest(scanManifest, true);
                            }
                            //*****IMPORTANT*****
                            //*****IMPORTANT*****
                            //MOVE THIS TO REPLY BEFORE PROCESSING THE MANIFEST!!!
                            //IT'S CAUSING AN ERROR ON THE CLIENTS BECAUSE IT'S SO SLOW...
                            //string commandResponse = PickToLightCommands.PopulateScanManifestEndCommandResponse(idScanManifest);
                            //e.SendWithProtocol(commandResponse);
                            //*****IMPORTANT*****
                            //*****IMPORTANT*****

                            return (true);
                        }
                    }
                    catch(Exception)
                    {
                        return (false);
                        throw;
                    }

                    return (false); //Should never get here.

                    break;

                #region CodeCreatedWhenClientWasGoingToBeDumb

                /*  WAIT ON THIS!!!
                      case PickToLightCommands.P2L_COMMAND_ScanManifestBegin:   //Remove this SOON, too!
                      //if (commandFields.Length < 1) Is Checked before the "Switch" statement!
                      if (commandFields.Length < 2)
                      {
                          //_logger.Log("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_ScanManifest command received, but no ScanManifest entryID!");
                          _logger.LogError("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_ScanManifestBegin received, but the Response only contains one field/property!");
                          return (false);
                      }
                      int manifestRowID = -1;
                      if (int.TryParse(commandFields[1], out manifestRowID) == false)
                      {
                          _logger.LogError("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_ScanManifestBegin received, but the rowID (" + commandFields[1] + ") (for the SQL Table Row) is NOT an integer!"); 
                          return (false);
                      }

                      _logger.Log("-----ProcessP2LCommand()----- P2L_COMMAND_ScanManifestBegin was received for rowID (" + manifestRowID.ToString() + ")...");

                      //Read in the ID from the Table and decide what to do.
                      try
                      {
                          ScanManifest scanManifest = PickToLightData.ScanManifest.GetScanEntry(rowID);
                          if (scanManifest != null) //Is this even possible?
                          {
                              _logger.Log("-----ProcessP2LCommand()----- *****TEMP TESTING***** Received P2L_COMMAND_ScanManifestBegin, so lets send them to the InternalKanban!!!");
                              ServerCommandResponse serverCommandResponse = new ServerCommandResponse();
                              serverCommandResponse.NowScanThis = ServerCommandResponse.WhatToScan.InternalKanban;
                              serverCommandResponse.ShowErrorDialog = false;
                              serverCommandResponse.UserInstructions = "Please scan the barcode in the TOP, MIDDLE (under the Internal Part Number) on the Internal Kanban Label.";
                              serverCommandResponse.ErrorMessage = "";
                              //TODO: serverCommandResponse.ProgramOutput = "Create a new Method() to be populate with Manifest Info that User is currently Pulling!";
                              serverCommandResponse.ProgramOutput = "Scan and pull Parts for Supplier Code " + scanManifest.SupplierCode + " Dock Code " + scanManifest.DockCode + " Order # " + scanManifest.OrderNumber;
                              string commandResponse = PickToLightCommands.PopulateClientScanCommandResponse(PickToLightCommands.P2L_COMMAND_ScanManifestBegin, rowID, serverCommandResponse);
                              e.SendWithProtocol(commandResponse, e.ClientSocket);
                              return (true);
                          }
                      }
                      catch (Exception)
                      {
                          return (false);
                          throw;
                      }

                      return (false); //Should never get here.

                      break;

                  case PickToLightCommands.P2L_COMMAND_ScanManifestEnd:   //Remove this SOON, too!
                      //if (commandFields.Length < 1) Is Checked before the "Switch" statement!
                      if (commandFields.Length < 2)
                      {
                          //_logger.Log("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_ScanManifest command received, but no ScanManifest entryID!");
                          _logger.LogError("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_ScanManifestEnd received, but the Response only contains one field/property!");
                          return (false);
                      }
                      int manifestRowID = -1;
                      if (int.TryParse(commandFields[1], out manifestRowID) == false)
                      {
                          _logger.LogError("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_ScanManifestEnd received, but the rowID (" + commandFields[1] + ") (for the SQL Table Row) is NOT an integer!");
                          return (false);
                      }

                      _logger.Log("-----ProcessP2LCommand()----- P2L_COMMAND_ScanManifestEnd was received for rowID (" + manifestRowID.ToString() + ")...");

                      //Read in the ID from the Table and decide what to do.
                      try
                      {
                          ScanManifest scanManifest = PickToLightData.ScanManifest.GetScanEntry(manifestRowID);
                          if (scanManifest != null) //Is this even possible?
                          {
                              _logger.Log("-----ProcessP2LCommand()----- *****TEMP TESTING***** Received P2L_COMMAND_ScanManifestEnd, so lets send them to the ManifestEnd!!!");
                              ServerCommandResponse serverCommandResponse = new ServerCommandResponse();
                              serverCommandResponse.NowScanThis = ServerCommandResponse.WhatToScan.ManifestBegin;
                              serverCommandResponse.ShowErrorDialog = false;
                              serverCommandResponse.UserInstructions = "Scan the Manifest to start a new kit.";
                              serverCommandResponse.ErrorMessage = "";
                              //TODO: serverCommandResponse.ProgramOutput = "Create a new Method() to be populate with Manifest Info that User is currently Pulling!";
                              serverCommandResponse.ProgramOutput = "DONE pulling parts for Supplier Code " + scanManifest.SupplierCode + " Dock Code " + scanManifest.DockCode + " Order # " + scanManifest.OrderNumber;
                              string commandResponse = PickToLightCommands.PopulateClientScanCommandResponse(PickToLightCommands.P2L_COMMAND_ScanManifestEnd, rowID, serverCommandResponse);
                              e.SendWithProtocol(commandResponse, e.ClientSocket);
                              return (true);
                          }
                      }
                      catch (Exception)
                      {
                          return (false);
                          throw;
                      }

                      return (false); //Should never get here.

                      break;

                  case PickToLightCommands.P2L_COMMAND_ScanBarcode:
                  case PickToLightCommands.P2L_COMMAND_ScanInternalKanban:
                  case PickToLightCommands.P2L_COMMAND_ScanToyotaOWK:
                      //if (commandFields.Length < 1) Is Checked before the "Switch" statement!
                      if (commandFields.Length < 2)
                      {
                          //_logger.Log("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_ScanManifest command received, but no ScanManifest entryID!");
                          _logger.LogError("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND received, but the Response only contains one field/property!");
                          return (false);
                      }
                      int rowID = -1;
                      if (int.TryParse(commandFields[1], out rowID) == false)
                      {
                          _logger.LogError("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND received, but the rowID (" + commandFields[1] + ") (for the SQL Table Row) is NOT an integer!");
                          return (false);
                      }

                      string P2L_Command = "UNKNOWN (" + commandFields[0] + ")";
                      if (commandFields[0].Equals(PickToLightCommands.P2L_COMMAND_ScanManifest))
                      {
                          P2L_Command = "P2L_COMMAND_ScanManifest";
                      }
                      else if (commandFields[0].Equals(PickToLightCommands.P2L_COMMAND_ScanInternalKanban))
                      {
                          P2L_Command = "P2L_COMMAND_ScanInternalKanban";
                      }
                      else if (commandFields[0].Equals(PickToLightCommands.P2L_COMMAND_ScanToyotaOWK))
                      {
                          P2L_Command = "P2L_COMMAND_ScanToyotaOWK";
                      }
                      //Keep this??
                      _logger.Log("-----ProcessP2LCommand()----- P2L_COMMAND (" + P2L_Command + ") was received for rowID (" + rowID.ToString() + ")...");

                      //TODO: Create a new SQL Table to track "P2L_COMMAND" received and add a new row here???
                      //      Or, just use the "Log" table, but create a SQL View!!!!

                      //if idScanManifest is a 0 (Zero), then the barcode scan failed....so just log it!
                      //TODO: Or, really should read in the Row from the table and check the "Decoded" boolean column!
                      //TODO: I'm checking Decoded now (below), this can probably be removed!
                      //if (rowID == 0 && P2L_Command.Equals("P2L_COMMAND_ScanManifest"))
                      //{
                      //    _logger.Log("-----ProcessP2LCommand()----- P2L_COMMAND_ScanManifest entryID is 0, this indicates a bad read...");
                      //    ServerCommandResponse serverCommandResponse = new ServerCommandResponse();
                      //    serverCommandResponse.NowScanThis = ServerCommandResponse.WhatToScan.NoChange;
                      //    serverCommandResponse.ShowErrorDialog = true;
                      //    serverCommandResponse.UserInstructions = "";
                      //    serverCommandResponse.ErrorMessage = "ERROR FROM SERVER, BAD READ!";
                      //    //TODO: serverCommandResponse.ProgramOutput = "Create a new Method() to be populate with Manifest Info that User is currently Pulling!";
                      //    serverCommandResponse.ProgramOutput = "Create a new Method() to be populate with Manifest Info that User is currently Pulling!";
                      //    string commandResponse = PickToLightCommands.PopulateClientScanCommandResponse(PickToLightCommands.P2L_COMMAND_ScanManifest, rowID, serverCommandResponse);
                      //    e.SendWithProtocol(commandResponse, e.ClientSocket);
                      //}
                      if (P2L_Command.Equals("P2L_COMMAND_ScanManifest"))
                      {
                          _logger.Log("-----ProcessP2LCommand()----- *****TEMP TESTING***** Received P2L_COMMAND_ScanManifest, so lets send them to the InternalKanban!!!");
                          ServerCommandResponse serverCommandResponse = new ServerCommandResponse();
                          serverCommandResponse.NowScanThis = ServerCommandResponse.WhatToScan.InternalKanban;
                          serverCommandResponse.ShowErrorDialog = false;
                          serverCommandResponse.UserInstructions = "Please scan the barcode in the TOP, MIDDLE (under the Internal Part Number) on the Internal Kanban Label.";
                          serverCommandResponse.ErrorMessage = "";
                          //TODO: serverCommandResponse.ProgramOutput = "Create a new Method() to be populate with Manifest Info that User is currently Pulling!";
                          serverCommandResponse.ProgramOutput = "Create a new Method() to be populate with Manifest Info that User is currently Pulling!";
                          string commandResponse = PickToLightCommands.PopulateClientScanCommandResponse(PickToLightCommands.P2L_COMMAND_ScanManifest, rowID, serverCommandResponse);
                          e.SendWithProtocol(commandResponse, e.ClientSocket);
                          return (true);
                      }

                      //For Initial Temporary Testing, I am passing a Zero for "P2L_COMMAND_ScanInternalKanban" and "P2L_COMMAND_ScanToyotaOWK".
                      //TODO: Remove the Hard Coded "0" in the client and change/fix this here too!
                      //TODO: Or, really should read in the Row from the table and check the "Decoded" boolean column!
                      if (rowID == 0 && P2L_Command.Equals("P2L_COMMAND_ScanInternalKanban"))
                      {
                          _logger.Log("-----ProcessP2LCommand()----- *****TEMP TESTING***** Received P2L_COMMAND_ScanInternalKanban, so lets send them to the ToyotaOWK!!!");
                          ServerCommandResponse serverCommandResponse = new ServerCommandResponse();
                          serverCommandResponse.NowScanThis = ServerCommandResponse.WhatToScan.ToyotaOWK;
                          serverCommandResponse.ShowErrorDialog = false;
                          serverCommandResponse.UserInstructions = "Please scan the (big, \"2D\") barcode in the CENTER of the Toyota OWK Label";
                          serverCommandResponse.ErrorMessage = "";
                          //TODO: serverCommandResponse.ProgramOutput = "Create a new Method() to be populate with Manifest Info that User is currently Pulling!";
                          serverCommandResponse.ProgramOutput = "Create a new Method() to be populate with Manifest Info that User is currently Pulling!";
                          string commandResponse = PickToLightCommands.PopulateClientScanCommandResponse(PickToLightCommands.P2L_COMMAND_ScanInternalKanban, rowID, serverCommandResponse);
                          e.SendWithProtocol(commandResponse, e.ClientSocket);
                          return (true);
                      }

                      //For Initial Temporary Testing, I am passing a Zero for "P2L_COMMAND_ScanInternalKanban" and "P2L_COMMAND_ScanToyotaOWK".
                      //TODO: Remove the Hard Coded "0" in the client and change/fix this here too!
                      //TODO: Or, really should read in the Row from the table and check the "Decoded" boolean column!
                      if (rowID == 0 && P2L_Command.Equals("P2L_COMMAND_ScanToyotaOWK"))
                      {
                          _logger.Log("-----ProcessP2LCommand()----- *****TEMP TESTING***** Received P2L_COMMAND_ScanToyotaOWK, so lets send them to the InternalKanban!!!");
                          ServerCommandResponse serverCommandResponse = new ServerCommandResponse();
                          serverCommandResponse.NowScanThis = ServerCommandResponse.WhatToScan.InternalKanban;
                          serverCommandResponse.ShowErrorDialog = false;
                          serverCommandResponse.UserInstructions = "Please scan the barcode in the TOP, MIDDLE (under the Internal Part Number) on the Internal Kanban Label.";
                          serverCommandResponse.ErrorMessage = "";
                          //TODO: serverCommandResponse.ProgramOutput = "Create a new Method() to be populate with Manifest Info that User is currently Pulling!";
                          serverCommandResponse.ProgramOutput = "Create a new Method() to be populate with Manifest Info that User is currently Pulling!";
                          string commandResponse = PickToLightCommands.PopulateClientScanCommandResponse(PickToLightCommands.P2L_COMMAND_ScanToyotaOWK, rowID, serverCommandResponse);
                          e.SendWithProtocol(commandResponse, e.ClientSocket);
                          return (true);
                      }

                      //CONTINUE HERE!!!
                      //CONTINUE HERE!!!
                      //CONTINUE HERE!!!
                      //Uncomment the next block, comment the items above and implement the REAL logic!
                      //CONTINUE HERE!!!
                      //CONTINUE HERE!!!
                      //HandlePullerScan()

                      ////Otherwise, read in the ID from the Table and decide what to do.
                      //try
                      //{
                      //    ScanManifest scanManifest = PickToLightData.ScanManifest.GetScanEntry(rowID);
                      //    if (scanManifest != null) //Is this even possible?
                      //    {
                      //        ServerCommandResponse serverCommandResponse = new ServerCommandResponse();
                      //        if (scanManifest.Decoded == false)
                      //        {
                      //            _logger.Log("-----ProcessP2LCommand()----- P2L_COMMAND_ScanManifest wasn't decoded, this indicates a bad read...");
                      //            //ServerCommandResponse serverCommandResponse = new ServerCommandResponse();
                      //            serverCommandResponse.NowScanThis = ServerCommandResponse.WhatToScan.NoChange;
                      //            serverCommandResponse.ShowErrorDialog = true;
                      //            serverCommandResponse.UserInstructions = "";
                      //            serverCommandResponse.ErrorMessage = "ERROR FROM SERVER, BAD READ!";
                      //            //TODO: serverCommandResponse.ProgramOutput = "Create a new Method() to be populate with Manifest Info that User is currently Pulling!";
                      //            serverCommandResponse.ProgramOutput = "Create a new Method() to be populate with Manifest Info that User is currently Pulling!";
                      //            string commandResponse = PickToLightCommands.PopulateScanManifestCommandResponse(rowID, serverCommandResponse);
                      //            e.SendWithProtocol(commandResponse, e.ClientSocket);
                      //            return (true);
                      //        }

                      //        //TODO: Create a method that determines the proper ServerCommandResponse!!
                      //        _logger.Log("-----ProcessP2LCommand()----- Critical ScanManifest values to use:"
                      //            + " ID [" + rowID.ToString() + "],"
                      //            + " Order/Manifest # [" + scanManifest.OrderNumber + "],"
                      //            //+ " SubRoute [" + scanManifest. + "],"
                      //            //+ " MainRoute [" + scanManifest.MainRoute + "],"
                      //            );

                      //        //CONTINUE HERE!!!
                      //        //CONTINUE HERE!!!
                      //        //CONTINUE HERE!!!
                      //        //Create this method and do the logic outlined in the Design Document!!!!
                      //        //CONTINUE HERE!!!
                      //        //CONTINUE HERE!!!
                      //        //HandlePullerScan()

                      //        //ServerCommandResponse serverCommandResponse = new ServerCommandResponse();
                      //        serverCommandResponse.NowScanThis = ServerCommandResponse.WhatToScan.NoChange;
                      //        serverCommandResponse.ShowErrorDialog = false;
                      //        serverCommandResponse.UserInstructions = "Server Communication was valid!";
                      //        serverCommandResponse.ErrorMessage = "";
                      //        //TODO: serverCommandResponse.ProgramOutput = "Create a new Method() to be populate with Manifest Info that User is currently Pulling!";
                      //        serverCommandResponse.ProgramOutput = "Create a new Method() to be populate with Manifest Info that User is currently Pulling!";

                      //        string commandResponse = PickToLightCommands.PopulateScanManifestCommandResponse(idScanManifest, serverCommandResponse);
                      //        e.SendWithProtocol(commandResponse, e.ClientSocket);
                      //        return (true);
                      //    }
                      //}
                      //catch (Exception)
                      //{
                      //    return (false);
                      //    throw;
                      //}

                      return (false); //Should never get here.

                      break;

                



                  //case PickToLightCommands.P2L_COMMAND_ScanManifest:
                  //case PickToLightCommands.P2L_COMMAND_ScanInternalKanban:
                  //case PickToLightCommands.P2L_COMMAND_ScanToyotaOWK:
                  //    //if (commandFields.Length < 1) Is Checked before the "Switch" statement!
                  //    if (commandFields.Length < 2)
                  //    {
                  //        //_logger.Log("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND_ScanManifest command received, but no ScanManifest entryID!");
                  //        _logger.LogError("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND received, but the Response only contains one field/property!");
                  //        return (false);
                  //    }
                  //    int rowID = -1;
                  //    if (int.TryParse(commandFields[1], out rowID) == false)
                  //    {
                  //        _logger.LogError("*****ProcessP2LCommand()***** ERROR: P2L_COMMAND received, but the rowID (" + commandFields[1] + ") (for the SQL Table Row) is NOT an integer!");
                  //        return (false);
                  //    }

                  //    string P2L_Command = "UNKNOWN (" + commandFields[0] + ")";
                  //    if (commandFields[0].Equals(PickToLightCommands.P2L_COMMAND_ScanManifest))
                  //    {
                  //        P2L_Command = "P2L_COMMAND_ScanManifest";
                  //    }
                  //    else if (commandFields[0].Equals(PickToLightCommands.P2L_COMMAND_ScanInternalKanban))
                  //    {
                  //        P2L_Command = "P2L_COMMAND_ScanInternalKanban";
                  //    }
                  //    else if (commandFields[0].Equals(PickToLightCommands.P2L_COMMAND_ScanToyotaOWK))
                  //    {
                  //        P2L_Command = "P2L_COMMAND_ScanToyotaOWK";
                  //    }
                  //    //Keep this??
                  //    _logger.Log("-----ProcessP2LCommand()----- P2L_COMMAND (" + P2L_Command + ") was received for rowID (" + rowID.ToString() + ")...");

                  //    //TODO: Create a new SQL Table to track "P2L_COMMAND" received and add a new row here???
                  //    //      Or, just use the "Log" table, but create a SQL View!!!!

                  //    //if idScanManifest is a 0 (Zero), then the barcode scan failed....so just log it!
                  //    //TODO: Or, really should read in the Row from the table and check the "Decoded" boolean column!
                  //    //TODO: I'm checking Decoded now (below), this can probably be removed!
                  //    //if (rowID == 0 && P2L_Command.Equals("P2L_COMMAND_ScanManifest"))
                  //    //{
                  //    //    _logger.Log("-----ProcessP2LCommand()----- P2L_COMMAND_ScanManifest entryID is 0, this indicates a bad read...");
                  //    //    ServerCommandResponse serverCommandResponse = new ServerCommandResponse();
                  //    //    serverCommandResponse.NowScanThis = ServerCommandResponse.WhatToScan.NoChange;
                  //    //    serverCommandResponse.ShowErrorDialog = true;
                  //    //    serverCommandResponse.UserInstructions = "";
                  //    //    serverCommandResponse.ErrorMessage = "ERROR FROM SERVER, BAD READ!";
                  //    //    //TODO: serverCommandResponse.ProgramOutput = "Create a new Method() to be populate with Manifest Info that User is currently Pulling!";
                  //    //    serverCommandResponse.ProgramOutput = "Create a new Method() to be populate with Manifest Info that User is currently Pulling!";
                  //    //    string commandResponse = PickToLightCommands.PopulateClientScanCommandResponse(PickToLightCommands.P2L_COMMAND_ScanManifest, rowID, serverCommandResponse);
                  //    //    e.SendWithProtocol(commandResponse, e.ClientSocket);
                  //    //}
                  //    if (P2L_Command.Equals("P2L_COMMAND_ScanManifest"))
                  //    {
                  //        _logger.Log("-----ProcessP2LCommand()----- *****TEMP TESTING***** Received P2L_COMMAND_ScanManifest, so lets send them to the InternalKanban!!!");
                  //        ServerCommandResponse serverCommandResponse = new ServerCommandResponse();
                  //        serverCommandResponse.NowScanThis = ServerCommandResponse.WhatToScan.InternalKanban;
                  //        serverCommandResponse.ShowErrorDialog = false;
                  //        serverCommandResponse.UserInstructions = "Please scan the barcode in the TOP, MIDDLE (under the Internal Part Number) on the Internal Kanban Label.";
                  //        serverCommandResponse.ErrorMessage = "";
                  //        //TODO: serverCommandResponse.ProgramOutput = "Create a new Method() to be populate with Manifest Info that User is currently Pulling!";
                  //        serverCommandResponse.ProgramOutput = "Create a new Method() to be populate with Manifest Info that User is currently Pulling!";
                  //        string commandResponse = PickToLightCommands.PopulateClientScanCommandResponse(PickToLightCommands.P2L_COMMAND_ScanManifest, rowID, serverCommandResponse);
                  //        e.SendWithProtocol(commandResponse, e.ClientSocket);
                  //        return (true);
                  //    }

                  //    //For Initial Temporary Testing, I am passing a Zero for "P2L_COMMAND_ScanInternalKanban" and "P2L_COMMAND_ScanToyotaOWK".
                  //    //TODO: Remove the Hard Coded "0" in the client and change/fix this here too!
                  //    //TODO: Or, really should read in the Row from the table and check the "Decoded" boolean column!
                  //    if (rowID == 0 && P2L_Command.Equals("P2L_COMMAND_ScanInternalKanban"))
                  //    {
                  //        _logger.Log("-----ProcessP2LCommand()----- *****TEMP TESTING***** Received P2L_COMMAND_ScanInternalKanban, so lets send them to the ToyotaOWK!!!");
                  //        ServerCommandResponse serverCommandResponse = new ServerCommandResponse();
                  //        serverCommandResponse.NowScanThis = ServerCommandResponse.WhatToScan.ToyotaOWK;
                  //        serverCommandResponse.ShowErrorDialog = false;
                  //        serverCommandResponse.UserInstructions = "Please scan the (big, \"2D\") barcode in the CENTER of the Toyota OWK Label";
                  //        serverCommandResponse.ErrorMessage = "";
                  //        //TODO: serverCommandResponse.ProgramOutput = "Create a new Method() to be populate with Manifest Info that User is currently Pulling!";
                  //        serverCommandResponse.ProgramOutput = "Create a new Method() to be populate with Manifest Info that User is currently Pulling!";
                  //        string commandResponse = PickToLightCommands.PopulateClientScanCommandResponse(PickToLightCommands.P2L_COMMAND_ScanInternalKanban, rowID, serverCommandResponse);
                  //        e.SendWithProtocol(commandResponse, e.ClientSocket);
                  //        return (true);
                  //    }

                  //    //For Initial Temporary Testing, I am passing a Zero for "P2L_COMMAND_ScanInternalKanban" and "P2L_COMMAND_ScanToyotaOWK".
                  //    //TODO: Remove the Hard Coded "0" in the client and change/fix this here too!
                  //    //TODO: Or, really should read in the Row from the table and check the "Decoded" boolean column!
                  //    if (rowID == 0 && P2L_Command.Equals("P2L_COMMAND_ScanToyotaOWK"))
                  //    {
                  //        _logger.Log("-----ProcessP2LCommand()----- *****TEMP TESTING***** Received P2L_COMMAND_ScanToyotaOWK, so lets send them to the InternalKanban!!!");
                  //        ServerCommandResponse serverCommandResponse = new ServerCommandResponse();
                  //        serverCommandResponse.NowScanThis = ServerCommandResponse.WhatToScan.InternalKanban;
                  //        serverCommandResponse.ShowErrorDialog = false;
                  //        serverCommandResponse.UserInstructions = "Please scan the barcode in the TOP, MIDDLE (under the Internal Part Number) on the Internal Kanban Label.";
                  //        serverCommandResponse.ErrorMessage = "";
                  //        //TODO: serverCommandResponse.ProgramOutput = "Create a new Method() to be populate with Manifest Info that User is currently Pulling!";
                  //        serverCommandResponse.ProgramOutput = "Create a new Method() to be populate with Manifest Info that User is currently Pulling!";
                  //        string commandResponse = PickToLightCommands.PopulateClientScanCommandResponse(PickToLightCommands.P2L_COMMAND_ScanToyotaOWK, rowID, serverCommandResponse);
                  //        e.SendWithProtocol(commandResponse, e.ClientSocket);
                  //        return (true);
                  //    }

                  //    //CONTINUE HERE!!!
                  //    //CONTINUE HERE!!!
                  //    //CONTINUE HERE!!!
                  //    //Uncomment the next block, comment the items above and implement the REAL logic!
                  //    //CONTINUE HERE!!!
                  //    //CONTINUE HERE!!!
                  //    //HandlePullerScan()

                  //    ////Otherwise, read in the ID from the Table and decide what to do.
                  //    //try
                  //    //{
                  //    //    ScanManifest scanManifest = PickToLightData.ScanManifest.GetScanEntry(rowID);
                  //    //    if (scanManifest != null) //Is this even possible?
                  //    //    {
                  //    //        ServerCommandResponse serverCommandResponse = new ServerCommandResponse();
                  //    //        if (scanManifest.Decoded == false)
                  //    //        {
                  //    //            _logger.Log("-----ProcessP2LCommand()----- P2L_COMMAND_ScanManifest wasn't decoded, this indicates a bad read...");
                  //    //            //ServerCommandResponse serverCommandResponse = new ServerCommandResponse();
                  //    //            serverCommandResponse.NowScanThis = ServerCommandResponse.WhatToScan.NoChange;
                  //    //            serverCommandResponse.ShowErrorDialog = true;
                  //    //            serverCommandResponse.UserInstructions = "";
                  //    //            serverCommandResponse.ErrorMessage = "ERROR FROM SERVER, BAD READ!";
                  //    //            //TODO: serverCommandResponse.ProgramOutput = "Create a new Method() to be populate with Manifest Info that User is currently Pulling!";
                  //    //            serverCommandResponse.ProgramOutput = "Create a new Method() to be populate with Manifest Info that User is currently Pulling!";
                  //    //            string commandResponse = PickToLightCommands.PopulateScanManifestCommandResponse(rowID, serverCommandResponse);
                  //    //            e.SendWithProtocol(commandResponse, e.ClientSocket);
                  //    //            return (true);
                  //    //        }

                  //    //        //TODO: Create a method that determines the proper ServerCommandResponse!!
                  //    //        _logger.Log("-----ProcessP2LCommand()----- Critical ScanManifest values to use:"
                  //    //            + " ID [" + rowID.ToString() + "],"
                  //    //            + " Order/Manifest # [" + scanManifest.OrderNumber + "],"
                  //    //            //+ " SubRoute [" + scanManifest. + "],"
                  //    //            //+ " MainRoute [" + scanManifest.MainRoute + "],"
                  //    //            );

                  //    //        //CONTINUE HERE!!!
                  //    //        //CONTINUE HERE!!!
                  //    //        //CONTINUE HERE!!!
                  //    //        //Create this method and do the logic outlined in the Design Document!!!!
                  //    //        //CONTINUE HERE!!!
                  //    //        //CONTINUE HERE!!!
                  //    //        //HandlePullerScan()

                  //    //        //ServerCommandResponse serverCommandResponse = new ServerCommandResponse();
                  //    //        serverCommandResponse.NowScanThis = ServerCommandResponse.WhatToScan.NoChange;
                  //    //        serverCommandResponse.ShowErrorDialog = false;
                  //    //        serverCommandResponse.UserInstructions = "Server Communication was valid!";
                  //    //        serverCommandResponse.ErrorMessage = "";
                  //    //        //TODO: serverCommandResponse.ProgramOutput = "Create a new Method() to be populate with Manifest Info that User is currently Pulling!";
                  //    //        serverCommandResponse.ProgramOutput = "Create a new Method() to be populate with Manifest Info that User is currently Pulling!";

                  //    //        string commandResponse = PickToLightCommands.PopulateScanManifestCommandResponse(idScanManifest, serverCommandResponse);
                  //    //        e.SendWithProtocol(commandResponse, e.ClientSocket);
                  //    //        return (true);
                  //    //    }
                  //    //}
                  //    //catch (Exception)
                  //    //{
                  //    //    return (false);
                  //    //    throw;
                  //    //}

                  //    return (false); //Should never get here.

                  //    break;
              */

                #endregion CodeCreatedWhenClientWasGoingToBeDumb



                default:
                    break;
            }
            return (false);
        }

        private void SendBanderDisplaySkidBuildBeginCommand(int banderNum, int manifestID)
        {
            //Right now, banderNum is either 1 or 2
            string bander = "BanderDisplay" + (banderNum.ToString() == "2" ? "2" : "1");

            IPAddress banderDisplayIP = null;
            int banderDisplayPort = 12000; //NO!! Read this from AppSettings. Or heck, maybe we could default to 12000 and make it optional in the AppSettings...hmmmm...
            
            //Can we just read the PickToLightBanderDisplay from the AppSettings table?
            //We would just need to use the bander name ("BanderDisplay1" or "BanderDisplay2") for the "Setting"
            //And for the "Value", store the hostname and the port. (like this: "BANDER1-VIEW:12000" OR "BANDER1-VIEW,12000")
            //We should probably allow the setting to be "missing" or the value to be "empty" or maybe "disabled", in case the TV is ever "down"...
            //But, we should only read that in one time, when the App Starts... RIGHT?
            //NO, lets build that into the SendBanderDisplaySkidBuildBeginCommand and read it every time, so we can change it "dynamically".

            //Now, get the hostname and port from the AppSettings Table.
            string settingName = "BanderDisplay" + banderNum.ToString();
            using (var ctx = new PickToLightEntities())
            {
                AppSetting banderDisplay = (from b in ctx.AppSettings
                                            where b.Name.Equals(settingName)
                                            select b).SingleOrDefault<AppSetting>();
                if (banderDisplay == null)
                {
                    _logger.LogError(settingName + " is missing in AppSettings! It should at least be present Initializing an empty/blank/null SkidBuild for Bander1.");
                    return;
                }
                if (string.IsNullOrEmpty(banderDisplay.Value))
                {
                    _logger.LogError(settingName + " in AppSettings doesn't have a Value set. (To disable it, set the Value to DISABLE!)");
                    return;
                }
                if (banderDisplay.Value.ToUpper().Equals("DISABLE"))
                {
                    _logger.Log("Not sending the SkidBuildBegin command to " + settingName + ", because it is currently DISABLED in AppSettings.");
                    return;
                }
                char delimeter = ','; //Default the delimeter to a comma, but we can allow a colon, since hostname:port is often used.
                if (banderDisplay.Value.Contains(':')) delimeter = ':';
                string[] valueFields = banderDisplay.Value.Split(delimeter);
                if (valueFields.Length != 2)
                {
                    _logger.LogError(settingName + " in AppSettings doesn't have a valid Value (" + banderDisplay.Value + "). It should contain the hostname (or IP) then a comma or colon delimiter, then the port. (Example: BANDER1-VIEW:12000)");
                    return;
                }
                else
                {
                    if (valueFields[0].Contains('.')) //The value is an IP address
                    {
                        if (System.Net.IPAddress.TryParse(valueFields[0], out banderDisplayIP) == false)
                        {
                            _logger.LogError(settingName + " in AppSettings doesn't have a valid Value (" + banderDisplay.Value + "). Unable to parse the IP address specified! It should contain the hostname (or IP) then a comma or colon delimiter, then the port. (Example: BANDER1-VIEW:12000)");
                            return;
                        }
                    }
                    else //Assume the first value is the hostname.
                    {
                        if (Misc.GetResolvedConnectionIPAddress(valueFields[0], out banderDisplayIP) == false) //Use this method, becasue "GetHostAddresses" returns IPV6, IPV4, etc.
                        {
                            _logger.LogError(settingName + " in AppSettings doesn't have a valid Value (" + banderDisplay.Value + "). Unable to resolve the hostname to an IP address specified! It should contain the hostname (or IP) then a comma or colon delimiter, then the port. (Example: BANDER1-VIEW:12000)");
                            return;
                        }
                    }
                    if (int.TryParse(valueFields[1], out banderDisplayPort) == false)
                    {
                        _logger.LogError(settingName + " in AppSettings doesn't have a valid Value (" + banderDisplay.Value + "). The port number is not an integer! It should contain the hostname (or IP) then a comma or colon delimiter, then the port. (Example: BANDER1-VIEW:12000)");
                        return;
                    }
                }
            }

            if (banderDisplayIP != null)
            {
                string commandToSend = "";
                commandToSend = PickToLightCommands.PopulateSkidBuildBeginCommand(manifestID, banderNum);

                TCPClient tcpClient = new TCPClient(_logger, banderDisplayIP, banderDisplayPort);
                StringBuilder commandResponse = new StringBuilder();
                tcpClient.SendCommand(commandToSend, commandResponse); //Send it and receive a response in commandResponse, but we can probably just "fire and forget".....
            }
            //else
            //{
            //    _logger.LogError("The BanderDisplay setting is invalid or not specified! But, we really don't care, we are just "fire and forget" this command. If the BanderDisplay is down, so what???");
            //    return;
            //}
        }

        private void SendBanderDisplaySkidBuildEndCommand(int banderNum, int manifestID)
        {
            //Right now, banderNum is either 1 or 2
            string bander = "BanderDisplay" + (banderNum.ToString() == "2" ? "2" : "1");

            IPAddress banderDisplayIP = null;
            int banderDisplayPort = 12000; //NO!! Read this from AppSettings. Or heck, maybe we could default to 12000 and make it optional in the AppSettings...hmmmm...

            //Can we just read the PickToLightBanderDisplay from the AppSettings table?
            //We would just need to use the bander name ("BanderDisplay1" or "BanderDisplay2") for the "Setting"
            //And for the "Value", store the hostname and the port. (like this: "BANDER1-VIEW:12000" OR "BANDER1-VIEW,12000")
            //We should probably allow the setting to be "missing" or the value to be "empty" or maybe "disabled", in case the TV is ever "down"...
            //But, we should only read that in one time, when the App Starts... RIGHT?
            //NO, lets build that into the SendBanderDisplaySkidBuildEndCommand and read it every time, so we can change it "dynamically".

            //Now, get the hostname and port from the AppSettings Table.
            string settingName = "BanderDisplay" + banderNum.ToString();
            using (var ctx = new PickToLightEntities())
            {
                AppSetting banderDisplay = (from b in ctx.AppSettings
                                            where b.Name.Equals(settingName)
                                            select b).SingleOrDefault<AppSetting>();
                if (banderDisplay == null)
                {
                    _logger.LogError(settingName + " is missing in AppSettings! It should at least be present Initializing an empty/blank/null SkidBuild for Bander1.");
                    return;
                }
                if (string.IsNullOrEmpty(banderDisplay.Value))
                {
                    _logger.LogError(settingName + " in AppSettings doesn't have a Value set. (To disable it, set the Value to DISABLE!)");
                    return;
                }
                if (banderDisplay.Value.ToUpper().Equals("DISABLE"))
                {
                    _logger.Log("Not sending the SkidBuildEnd command to " + settingName + ", because it is currently DISABLED in AppSettings.");
                    return;
                }
                char delimeter = ','; //Default the delimeter to a comma, but we can allow a colon, since hostname:port is often used.
                if (banderDisplay.Value.Contains(':')) delimeter = ':';
                string[] valueFields = banderDisplay.Value.Split(delimeter);
                if (valueFields.Length != 2)
                {
                    _logger.LogError(settingName + " in AppSettings doesn't have a valid Value (" + banderDisplay.Value + "). It should contain the hostname (or IP) then a comma or colon delimiter, then the port. (Example: BANDER1-VIEW:12000)");
                    return;
                }
                else
                {
                    if (valueFields[0].Contains('.')) //The value is an IP address
                    {
                        if (System.Net.IPAddress.TryParse(valueFields[0], out banderDisplayIP) == false)
                        {
                            _logger.LogError(settingName + " in AppSettings doesn't have a valid Value (" + banderDisplay.Value + "). Unable to parse the IP address specified! It should contain the hostname (or IP) then a comma or colon delimiter, then the port. (Example: BANDER1-VIEW:12000)");
                            return;
                        }
                    }
                    else //Assume the first value is the hostname.
                    {
                        if (Misc.GetResolvedConnectionIPAddress(valueFields[0], out banderDisplayIP) == false) //Use this method, becasue "GetHostAddresses" returns IPV6, IPV4, etc.
                        {
                            _logger.LogError(settingName + " in AppSettings doesn't have a valid Value (" + banderDisplay.Value + "). Unable to resolve the hostname to an IP address specified! It should contain the hostname (or IP) then a comma or colon delimiter, then the port. (Example: BANDER1-VIEW:12000)");
                            return;
                        }
                    }
                    if (int.TryParse(valueFields[1], out banderDisplayPort) == false)
                    {
                        _logger.LogError(settingName + " in AppSettings doesn't have a valid Value (" + banderDisplay.Value + "). The port number is not an integer! It should contain the hostname (or IP) then a comma or colon delimiter, then the port. (Example: BANDER1-VIEW:12000)");
                        return;
                    }
                }
            }

            if (banderDisplayIP != null)
            {
                string commandToSend = "";
                commandToSend = PickToLightCommands.PopulateSkidBuildEndCommand(manifestID, banderNum);

                TCPClient tcpClient = new TCPClient(_logger, banderDisplayIP, banderDisplayPort);
                StringBuilder commandResponse = new StringBuilder();
                tcpClient.SendCommand(commandToSend, commandResponse); //Send it and receive a response in commandResponse, but we can probably just "fire and forget".....
            }
            //else
            //{
            //    _logger.LogError("The BanderDisplay setting is invalid or not specified! But, we really don't care, we are just "fire and forget" this command. If the BanderDisplay is down, so what???");
            //    return;
            //}
        }

        private bool ToyotaShipmentLoadRequest(ShipmentLoadTrailer shipmentLoadTrailer, out string message)
        {
            bool DEBUG = true;

            if (shipmentLoadTrailer == null) //Make sure we can read the row for the ID
            {
                //throw new ShipmentLoadCustomProgramException("No ERRORS found for ShipmentLoadPlan...continue developing the logic for GetShipmentLoadTrailerPlan!");
                message = "-----ToyotaShipmentLoadRequest()----- The ShipmentLoadTrailer parameter is NULL!";
                return false;
            }

            ////////////////////////////////////////Build the RequestShipmentLoad!!!!!////////////////////////////////////////

            RequestShipmentLoad reqShipmentLoad = new RequestShipmentLoad();

            ///I could do all this in a constructor for "RequestShipmentLoad" and pass all the properties...

            //public class RequestShipmentLoad
            //{
            //    public string supplier { get; set; }
            //    public string route { get; set; }
            //    public string run { get; set; }
            //    public string trailerNumber { get; set; }
            //    public bool dropHook { get; set; }
            //    public string sealNumber { get; set; }
            //    public string supplierTeamFirstName { get; set; }
            //    public string supplierTeamLastName { get; set; }
            //    public string lpCode { get; set; }
            //    public string driverTeamFirstName { get; set; }
            //    public string driverTeamLastName { get; set; }
            //    public List<APIexception> exceptions { get; set; }
            //    public List<Order> orders { get; set; }
            //}

            //ShipmentLoadTrailer
            //this.ShipmentLoadTrailerExceptions
            //this.ShipmentLoadOrders
            //this.ShipmentLoadOrders.ShipmentLoadSkids 
            //this.ShipmentLoadOrders.ShipmentLoadSkids.ShipmentLoadSkidExceptions
            //this.ShipmentLoadTrailerResponses
            //this.ShipmentLoadTrailerResponses.APIResponse
            //this.ShipmentLoadTrailerResponses.APIResponse.APIResponseMessages

            reqShipmentLoad.supplier = shipmentLoadTrailer.SupplierCode;
            reqShipmentLoad.route = shipmentLoadTrailer.Route;
            reqShipmentLoad.run = shipmentLoadTrailer.Run;
            reqShipmentLoad.trailerNumber = shipmentLoadTrailer.TrailerNumber;
            reqShipmentLoad.dropHook = shipmentLoadTrailer.DropHook.Value;
            reqShipmentLoad.sealNumber = shipmentLoadTrailer.SealNumber;
            reqShipmentLoad.supplierTeamFirstName = shipmentLoadTrailer.SupplierTeamFirstName;
            reqShipmentLoad.supplierTeamLastName = shipmentLoadTrailer.SupplierTeamLastName;
            reqShipmentLoad.lpCode = shipmentLoadTrailer.LPCode;
            reqShipmentLoad.driverTeamFirstName = shipmentLoadTrailer.DriverTeamFirstName;
            reqShipmentLoad.driverTeamLastName = shipmentLoadTrailer.DriverTeamLastName;

            //    public List<APIexception> exceptions { get; set; }
            //this.ShipmentLoadTrailerExceptions

            //public class APIexception //If rename this to "scsException" or something else, will "Newtonsoft.Json" still work?? 
            //{
            //    public string exceptionCode { get; set; }
            //    public string comments { get; set; }
            //}

            reqShipmentLoad.exceptions = null;
            if (shipmentLoadTrailer.ShipmentLoadTrailerExceptions != null)
            {
                if (shipmentLoadTrailer.ShipmentLoadTrailerExceptions.Count > 0)
                {
                    reqShipmentLoad.exceptions = new List<APIexception>();
                    foreach (var exception in shipmentLoadTrailer.ShipmentLoadTrailerExceptions)
                    {
                        APIexception exceptionItem = new APIexception();
                        exceptionItem.exceptionCode = exception.Code;
                        exceptionItem.comments = exception.Comments;
                        reqShipmentLoad.exceptions.Add(exceptionItem);
                    }
                }
            }

            //public class Order
            //{
            //    public string order { get; set; }
            //    public string supplier { get; set; }
            //    public string plant { get; set; }
            //    public string dock { get; set; }
            //    public string pickUp { get; set; }
            //    public List<ShipmentSkid> skids { get; set; }
            //}

            //public class ShipmentSkid
            //{
            //    public string palletization { get; set; }
            //    public string skidId { get; set; }
            //    [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
            //    public List<APIexception> exceptions { get; set; }
            //}

            //this.ShipmentLoadOrders
            //this.ShipmentLoadOrders.ShipmentLoadSkids 
            //this.ShipmentLoadOrders.ShipmentLoadSkids.ShipmentLoadSkidExceptions

            reqShipmentLoad.orders = null;
            if (shipmentLoadTrailer.ShipmentLoadOrders != null)
            {
                if (shipmentLoadTrailer.ShipmentLoadOrders.Count > 0)
                {
                    reqShipmentLoad.orders = new List<Order>();
                    //foreach (var order in shipmentLoadTrailer.ShipmentLoadOrders)
                    //Lets sort these before adding them...
                    //It will make the Request String/Json/SQL all easier to evaluate/debug/look at!
                    foreach (var order in shipmentLoadTrailer.ShipmentLoadOrders.OrderBy(o => o.OrderNumber).ThenBy(o => o.DockCode)) //.ToList())
                    {

                        //public class Order
                        //{
                        //    public string order { get; set; }
                        //    public string supplier { get; set; }
                        //    public string plant { get; set; }
                        //    public string dock { get; set; }
                        //    public string pickUp { get; set; }
                        //    public List<ShipmentSkid> skids { get; set; }
                        //}

                        Order orderItem = new Order();
                        orderItem.order = order.OrderNumber;
                        orderItem.supplier = order.SupplierCode;
                        orderItem.plant = order.Plant;
                        orderItem.dock = order.DockCode;
                        //orderItem.pickUp = order.PickUp.Value.ToString("yyyy-MM-ddTHH:mmK"); //RFC3339, but only Date, Hours, Min (with a "T" between them)
                        //Don't need "K"???
                        orderItem.pickUp = order.PickUp.Value.ToString("yyyy-MM-ddTHH:mm"); //RFC3339, but only Date, Hours, Min (with a "T" between them)

                        //public class ShipmentSkid
                        //{
                        //    public string palletization { get; set; }
                        //    public string skidId { get; set; }
                        //    [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
                        //    public List<APIexception> exceptions { get; set; }
                        //}

                        orderItem.skids = null;
                        if (order.ShipmentLoadSkids != null)
                        {
                            if (order.ShipmentLoadSkids.Count > 0)
                            {
                                orderItem.skids = new List<ShipmentSkid>();

                                //foreach (var skid in order.ShipmentLoadSkids)
                                //Lets sort these before adding them...
                                //It will make the Request String/Json/SQL all easier to evaluate/debug/look at!
                                foreach (var skid in order.ShipmentLoadSkids.OrderBy(s => s.SkidId)) //.ToList())
                                {
                                    ShipmentSkid skidItem = new ShipmentSkid();
                                    skidItem.palletization = skid.PalletizationCode;
                                    skidItem.skidId = skid.SkidId;

                                    skidItem.exceptions = null;
                                    if (skid.ShipmentLoadSkidExceptions != null)
                                    {
                                        if (skid.ShipmentLoadSkidExceptions.Count > 0)
                                        {
                                            skidItem.exceptions = new List<APIexception>();
                                            foreach (var exception in skid.ShipmentLoadSkidExceptions)
                                            {
                                                APIexception exceptionItem = new APIexception();
                                                exceptionItem.exceptionCode = exception.Code;
                                                exceptionItem.comments = exception.Comments;
                                                skidItem.exceptions.Add(exceptionItem);
                                            }
                                        }
                                    }

                                    orderItem.skids.Add(skidItem);
                                }
                            }
                        }
                        reqShipmentLoad.orders.Add(orderItem);
                    }
                }
            }

            //WE DONT NEED TO LOAD THESE FOR THIS!!!!
            //WE DONT NEED TO LOAD THESE FOR THIS!!!!
            //WE DONT NEED TO LOAD THESE FOR THIS!!!!
            //WE DONT NEED TO LOAD THESE FOR THIS!!!!

            //this.ShipmentLoadTrailerResponses
            //this.ShipmentLoadTrailerResponses.APIResponse
            //this.ShipmentLoadTrailerResponses.APIResponse.APIResponseMessages

            //
            //**********ACTUALLY, lets just do the sorting ABOVE as its added to the ShipmentLoadTrailer Request!!!!!**********
            //
            //Shouldn't be necessary, but lets go ahead and SORT..
            //
            //Lets order the Orders by OrderNumber (order) and DockCode (dock)
            //And the Skids by SkidId (001,002,Etc).
            //It makes the Request String/Json/SQL all easier to evaluate/debug/look at!
            //
            //reqShipmentLoad.orders = reqShipmentLoad.orders.OrderBy(o => o.order).ThenBy(o => o.dock).ToList();
            //foreach (var order in reqShipmentLoad.orders)
            //{
            //    order.skids = order.skids.OrderBy(s => s.skidId).ToList();
            //}


            ////////////////////////////////////////Build the RequestShipmentLoad!!!!!////////////////////////////////////////

            String Username = "24d058ee-4775-4426-9ae0-6d3e612b5e10";  //AppID
            String Password = "W8aD2pM3qO7fS8xC3wE7bD1kX1nN8fG3gS8iN1kE8gH2iF3aX0";  //AppSecret

            String SkidURL = "https://api.toyota.com/tmna/prod/Logistics/v/SupplierOrderInformation/skid";
            String TrailerURL = "https://api.toyota.com/tmna/prod/Logistics/v/SupplierOrderInformation/trailer";

            //if (DEBUG) _logger.   Log("-----ToyotaShipmentLoadRequest()-----++++++++++New Skid Build Request++++++++++");
            //if (DEBUG) _logger.Log("-----ToyotaShipmentLoadRequest()SkidURL: " + SkidURL);
            //if (DEBUG) _logger.Log("-----ToyotaShipmentLoadRequest()Request (ObjectDumper): " + ObjectDumper.Dump(reqSkidBuild));
            //if (DEBUG) _logger.Log("-----ToyotaShipmentLoadRequest()Request (JSON): " + JsonConvert.SerializeObject(reqSkidBuild));

            ToyotaSCSWebAPI tscsWebAPI = new ToyotaSCSWebAPI(Username, Password, SkidURL, TrailerURL);

            APIresponse response = null;

            //Testing API Communication!
            //response = tscsWebAPI.SendRequest<APIresponse>(SkidURL, "[{\"order\":\"2018090501SA\"}]");
            //if (DEBUG) _logger.Log("-----ToyotaShipmentLoadRequest()==========(Only Sending Order, for test...) Response: " + Misc.ClassToString(response));

            //ShipmentLoad isn't an ARRAY, like SkidBuild!!!
            //List<RequestShipmentLoad> shipmentLoad = new List<RequestShipmentLoad>();
            //shipmentLoad.Add(reqShipmentLoad);
            //string jsonRequest = JsonConvert.SerializeObject(shipmentLoad);
            string jsonRequest = JsonConvert.SerializeObject(reqShipmentLoad);
            if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaShipmentLoadRequest()=======Request (JSON): " + jsonRequest);
            //string stringResponse;
            response = tscsWebAPI.SendRequest<APIresponse>(TrailerURL, jsonRequest);

            if (response.dotNetException != null) //If there was an Exception...
            {
                if (response.dotNetException.GetType().Name.Equals("WebException")) //...and it was a "WebException"...
                {
                    APIResponse aPIResponse = CreateAPIResponseSQLEntry(false, shipmentLoadTrailer.ID, response, shipmentLoadTrailer.ModifiedBy);

                    //message = "In HandleAPIResponse() - There was an Exception when sending the SkidBuild! Exception was (" + aPIResponse.Exception + ")";
                    //SendEMailNotificationAndLogException(message);
                    _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "INFO", "-----ToyotaShipmentLoadRequest()----- 1st Send Failed with WebException, Retrying... Web Exception was:" + aPIResponse.Exception);
                    if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaShipmentLoadRequest()=======RETRY! Request (JSON): " + jsonRequest);
                    response = tscsWebAPI.SendRequest<APIresponse>(TrailerURL, jsonRequest);
                }
            }

            //Console.WriteLine("-----ToyotaShipmentLoadRequest()==========Response: " + Misc.ClassToString(response));
            //Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            //Console.WriteLine("-----ToyotaShipmentLoadRequest()==========Response (ObjectDumper): " + ObjectDumper.Dump(response));
            //Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            //if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaShipmentLoadRequest()==========Response: " + Misc.ClassToString(response));
            if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaShipmentLoadRequest()==========Response (ObjectDumper): " + ObjectDumper.Dump(response));

            // Will need an "Overloaded" HandleAPIRepsonse for ShipmentLoad!!!
            //
            //HandleAPIResponse() creates the SQL Rows for APIResponse, APIResonseMessage and ShipmentLoadTrailerResponse
            //      It also "parses" the response and determines what to do? Like update ShipmentLoadTrailer Tables, or send an EMAIL Notification to "Managers" or "Developers"????
            //      RIGHT??? Make sure it does do all that!
            //
            bool success = HandleAPIResponse(response, shipmentLoadTrailer, shipmentLoadTrailer.ModifiedBy, out message); // Will need an "Overloaded" HandleAPIRepsonse for ShipmentLoad.
            return success;
        }

        private bool HandleAPIResponse(APIresponse response, ShipmentLoadTrailer newShipmentLoadTrailer, string pickerName, out string message)
        {
            APIResponse aPIResponse = null;

            try
            {
                aPIResponse = CreateAPIResponseSQLEntry(false, newShipmentLoadTrailer.ID, response, pickerName);
            }
            catch (Exception ex)
            {
                //Return Exception to Client Device and show it!!!!!!
                if (ex.InnerException != null)
                {
                    message = "-----HandleAPIResponse()----- Calling CreateAPIResponseSQLEntry() Exception: " + ex.Message + " (Inner Exception: " + ex.InnerException + ")";
                }
                else
                {
                    message = "-----HandleAPIResponse()----- Calling CreateAPIResponseSQLEntry() Exception: " + ex.Message;
                }
                _logger.LogError(message);

                return (false);
            }

            //if (string.IsNullOrEmpty(aPIResponse.Exception) == false || response.dotNetException != null)
            if (string.IsNullOrEmpty(aPIResponse.Exception) == false)
            {
                //TODO!   Right here, don't I need to REMOVE the Confirmation Number from previous success????
                //Maybe NOT, but I DO need to REMOVE the Confirmation Number from previous success if the Request FAILED!!!!!

                //If the Exception was a "WebException", lets email a different error to indicate the problem is probably with the Toyota Servers.
                //(Since, as of 9/18/19, this has happened twice in the last couple of months!)
                bool isWebException = false;
                if (response.dotNetException != null) //If there was an Exception...
                {
                    if (response.dotNetException.GetType().Name.Equals("WebException")) //...and it was a "WebException"...
                    {
                        isWebException = true;
                    }
                }
                message = "In HandleAPIResponse() - There was an Exception when sending the SkidBuild! Exception was (" + aPIResponse.Exception + ")";
                SendEMailNotificationAndLogException(isWebException, message);
                return (false);
            }
            else if (response.code.ToString().StartsWith("2"))
            {
                //Store the ConfirmationNumber in the ShipmentLoadTrailer table for this Shipment!
                //Indicate the ToyotaShipments used for the Order are "Shipped", done, completed, etc.
                if (aPIResponse.ConfirmationNumber != null && aPIResponse.ConfirmationNumber.Length > 0)
                {
                    //Console.WriteLine("+++++++++++++++++++Order was Successfully sent and Approved!!!, The Confirmation Number was " + aPIResponse.ConfirmationNumber + "+++++++++++++++++++");
                    //Console.WriteLine("");
                    //Console.WriteLine("//In HandleAPIResponse() - Updating ConfirmationNumber in SkidBuildOrderID:" + newSkidBuildOrder.ID.ToString());
                    PickToLightData.ShipmentLoadTrailer.UpdateConfirmationNumber(newShipmentLoadTrailer.ID, aPIResponse.ConfirmationNumber);

                    //This is only done for the SkidBuild!!!
                    //Console.WriteLine("TODO - //In HandleAPIResponse() - Mark ToyotaShipments used for the Order as \"Completed\"...");
                    //PickToLightData.ToyotaShipment.UpdateToyotaShipmentsCompleted(toyotaOrderShipments, aPIResponse.ConfirmationNumber);
                    message = "Request was Approved, your Confirmation Number was: " + aPIResponse.ConfirmationNumber;
                    return (true);
                }
                else
                {
                    //NO!!!!!! Because ShipmentLoadTrailer Request are sent by a Client (Honeywell Dolphin), so just inform the user!
                    //(May need to return this????
                    StringBuilder emailMessage = new StringBuilder();
                    //If HTML, use this!
                    //emailMessage.Append("<br><span style=\"font-size:120%;font-weight:bold\">Shipment Load Trailer was <u><span style=\"color:red;\">NOT APPROVED</span></u>, due to one or more Validation Errors:</span>");
                    //foreach (var responseMessage in aPIResponse.APIResponseMessages)
                    //{
                    //    emailMessage.Append("<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Message: " + responseMessage.Message + "  (KeyObject: " + responseMessage.KeyObject + ")");
                    //    emailMessage.Append("<br>");
                    //}
                    emailMessage.Append("The Shipment Load Request had the following Validation Errors:" + Environment.NewLine);
                    foreach (var responseMessage in aPIResponse.APIResponseMessages)
                    {
                        //emailMessage.Append(Environment.NewLine + "     Message: " + responseMessage.Message + "  (KeyObject: " + responseMessage.KeyObject + ")");
                        emailMessage.Append(Environment.NewLine + "Message: " + responseMessage.Message);
                    }
                    //EMAIL the above information to the "Managers"...
                    //NO!!!!!! Because ShipmentLoadTrailer Request are sent by a Client (Honeywell Dolphin), so just inform the user!
                    //SendEMailNotificationToFixValidationErrors(newSkidBuildOrder, emailMessage.ToString());
                    message = emailMessage.ToString();
                    return (false);
                }
            }
            else
            {
                //TODO!   Right here, don't I need to REMOVE the Confirmation Number from previous success!!!!!
                //REMOVE ConfirmationNumber!!!!!
                //REMOVE ConfirmationNumber!!!!!
                //REMOVE ConfirmationNumber!!!!!
                //REMOVE ConfirmationNumber!!!!!
                message = "In HandleAPIResponse() - The transaction failed with response code " + response.code.ToString();
                _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", message);
                //SendEMailNotificationAndLogException("In HandleAPIResponse() - There wasn't an Exception, but the transaction failed, because the response code was " + response.code.ToString());
                //Do THIS???
                //PickToLightData.ShipmentLoadTrailer.UpdateConfirmationNumber(newShipmentLoadTrailer.ID, "");
                return (false);
            }

            return (true);
        }

        //
        //See if we need to get a Toyota SkidBuildOrder Confirmation for the OWK just scanned.
        //(Actually, NOT the one just scanned, but the one that is no longer going to be tracked/scanned.)
        //(We know this because a new OWK/Order was just scanned that will cause it to no longer be tracked.)
        //
        //If we do, go ahead and send it for Confirmation!
        //
        //VerifyToyotaSkidBuildOrderConfirmation();
        //DetermineGetToyotaSkidBuildOrderConfirmation();

        /// <summary>
        /// If there is already a "Confirmed" SkidBuildOrder for the OWK just scanned, the just "skip" it.
        /// Otherwise, if this is the final OWK for the Manifest being pulled, create a SkidBuildOrder (unless one exists) and send it for Conmfirmation.
        /// (Actually, NOT the one just scanned, but the one that is no longer going to be tracked/scanned.)
        /// (We know this because a new OWK/Order was just scanned that will cause it to no longer be tracked.)
        /// </summary>
        /// <param name="scanManifest"></param>
        private void VerifyToyotaSkidBuildOrderConfirmation(ScanOWK scanOWK)
        {

            //_logger.Log("-----In VerifyToyotaSkidBuildOrderConfirmation(): scanOWK.ID: " + scanOWK.ID.ToString());

            //
            //We need to avoid creating a new SkidBuildOrder, if one exists!
            //

            if(scanOWK.Decoded == false) return; //Is this even possible??

            if(_manifest1 == null ) //Program has just started, first OWK scan received, so create the first "TrackedManifest" and store the info.
            {
                //_logger.Log("-----In VerifyToyotaSkidBuildOrderConfirmation(): _manifest1 == null");
                _manifest1 = new TrackedManifest(_logger);
                //_logger.Log("-----In VerifyToyotaSkidBuildOrderConfirmation(): _manifest1 now Tracked");
                _manifest1.Populate(scanOWK);
                //_logger.Log("-----In VerifyToyotaSkidBuildOrderConfirmation(): _manifest1 Populated");
                return;
            }
            else //Not the first OWK scan, but lets see if its the SAME manifest/skid as the first TrackedManifest.
            {
                //_logger.Log("-----In VerifyToyotaSkidBuildOrderConfirmation(): _manifest1 NOT null");
                if(_manifest1.IsSameManifest(scanOWK))
                {
                    _manifest1.LastOWKScanned = DateTime.Now; //scanOWK.Created; //Store the DateTime, in case we need it when determining which one to replace.
                    return; //Not the first OWK scan, but it IS the SAME manifest/skid as the first TrackedManifest, so lets just return.
                }
            }

            if(_manifest2 == null ) //Not the first OWK scan, and NOT the SAME manifest/skid as the first TrackedManifest, so create the second TrackedManifest and store the info.
            {
                //_logger.Log("-----In VerifyToyotaSkidBuildOrderConfirmation(): _manifest2 == null");
                _manifest2 = new TrackedManifest(_logger);
                //_logger.Log("-----In VerifyToyotaSkidBuildOrderConfirmation(): _manifest2 now Tracked");
                _manifest2.Populate(scanOWK);
                //_logger.Log("-----In VerifyToyotaSkidBuildOrderConfirmation(): _manifest2 Populated");
                return;
            }
            else //Not the first OR second OWK scan (because both "TrackedManifest" have been allocated), but lets see if its the SAME manifest/skid as the second "Tracked Manifest".
            {
                //_logger.Log("-----In VerifyToyotaSkidBuildOrderConfirmation(): _manifest2 NOT null");
                if(_manifest2.IsSameManifest(scanOWK))
                {
                    _manifest2.LastOWKScanned = DateTime.Now; //scanOWK.Created; //Store the DateTime, in case we need it when determining which one to replace.
                    return; //This OWK scan IS the SAME manifest/skid as the second "TrackedManifest", so lets just return.
                }
            }

            //Getting here tells us we have scanned the OWKs for at least two different Manifests at the Transfer Scanner.
            //We also know this OWK scan doesn't match EITHER of the existing Manifests we have been tracking ("TrackedManifest").
            //Now we need to determine which of the two "TrackedManifest" this scan should replace.
            //Then, we need to determine if the manifest we are replacing needs to be submitted for Confirmation:
            //   If it already has a SkidBuildOrder (use Confirmation# property, it will either have a valid Confirmation# or "NEED CONFIRMATION!") then we don't need to send it.
            //   Otherwise, use the logic in "EndManifest" to determine if we need to send for Confirmation.
            //   ***Don't forget to store the current Scan in the "TrackedManifest" that we decided to replace!

            //First, let's see if this OWK is part of either of the two Orders the two "TrackedManifests" belong to.
            //(Basically, is this just another Skid/Manifest for one of the two "TrackedManifests".)
            //if(_manifest1.Plant == scanOWK.NAMCDestination
            //        && _manifest1.SupplierCode == scanOWK.SupplierCode
            //        && _manifest1.OrderNumber == scanOWK.OrderNumber
            //        && _manifest1.DockCode == scanOWK.DockCode)
            //        //A "SkidBuildOrder" consists of a Unique: Plant (NAMC), SupplierCode, OrderNumber and DockCode.
            //        //A "SkidBuildOrderSkid" consists of a Unique: Plant (NAMC), SupplierCode, OrderNumber, DockCode AND PalletizationCode.
            //        //The MainRoute and/or SubRoute don't change per "SkidBuildOrderSkid"
            //        //(There is only one MainRoute/SubRoute for the entire "SkidBuildOrder")
            //        //&& _manifest1.PalletizationCode == scanOWK.PalletizationCode
            //        //&& _manifest1.MainRoute == scanOWK.MainRoute
            //        //&& _manifest2.SubRoute == scanOWK.SubRoute)
            if(_manifest1.IsSameOrder(scanOWK))
            {
                _manifest1.Populate(scanOWK);
                return; //This OWK is part of the same Order the first "TrackedManifest" (_manifest1) belongs to.
            }
            if(_manifest2.IsSameOrder(scanOWK))
            {
                _manifest2.Populate(scanOWK);
                return;
            }

            //_logger.Log("-----In VerifyToyotaSkidBuildOrderConfirmation(): From this point forward, we MAY try to Submit to Toyota for Confirmation!");

            //
            //NOTE: If we are trying to determine the best Bander (Tow Motor to Truck), we would focus on the SubRoute, not the MainRoute.
            //
            //If we get this far, see if the OWK MainRoute or SubRoute matches either of the "TrackedManifests".
            //
            //NOTE: From this point forward, we try to Submit to Toyota for Confirmation!
            //      (Because we just scanned an OWK that isn't part of one of the SkidBuildOrders we are Tracking!)
            //
            //If one matches, use that one.
            if(_manifest1.MainRoute.Equals(scanOWK.MainRoute) || _manifest1.SubRoute.Equals(scanOWK.SubRoute))
            {
                //Has the associated SkidBuildOrder already been Confirmed? (Make sure by trying to query it again.)
                if (_manifest1.ConfirmationNumber.Length == 0) _manifest1.LoadConfirmation();
                //Now, check the ConfirmationNumber again, if there still isn't a ConfirmationNumber, lets try to get one.
                if (_manifest1.ConfirmationNumber.Length == 0) GetSkidBuildOrderConfirmation(_manifest1);
                _manifest1.Populate(scanOWK); //Now track this Manifest.
                return;
            }
            if(_manifest2.MainRoute.Equals(scanOWK.MainRoute) || _manifest2.SubRoute.Equals(scanOWK.SubRoute))
            {
                //Has the associated SkidBuildOrder already been Confirmed? (Make sure by trying to query it again.)
                if (_manifest2.ConfirmationNumber.Length == 0) _manifest2.LoadConfirmation();
                //Now, check the ConfirmationNumber again, if there still isn't a ConfirmationNumber, lets try to get one.
                if (_manifest2.ConfirmationNumber.Length == 0) GetSkidBuildOrderConfirmation(_manifest2);
                _manifest2.Populate(scanOWK); //Now track this Manifest.
                return;
            }

            //If we get this far, see if the leading alpha characters of the OWK MainRoute matches either of the "TrackedManifests".
            //If one matches, use that one.
            string owkMainRouteAlpha = string.Concat(scanOWK.MainRoute.TakeWhile(c => c < '0' || c > '9')); //Get all the characters up to the first Number.
            if(_manifest1.MainRoute.StartsWith(owkMainRouteAlpha))
            {
                //_manifest1.Replace(scanOWK);
                //Has the associated SkidBuildOrder already been Confirmed? (Make sure by trying to query it again.)
                if (_manifest1.ConfirmationNumber.Length == 0) _manifest1.LoadConfirmation();
                //Now, check the ConfirmationNumber again, if there still isn't a ConfirmationNumber, lets try to get one.
                if (_manifest1.ConfirmationNumber.Length == 0) GetSkidBuildOrderConfirmation(_manifest1);
                _manifest1.Populate(scanOWK); //Now track this Manifest.
                return;
            }
            if(_manifest2.MainRoute.StartsWith(owkMainRouteAlpha))
            {
                //Has the associated SkidBuildOrder already been Confirmed? (Make sure by trying to query it again.)
                if (_manifest2.ConfirmationNumber.Length == 0) _manifest2.LoadConfirmation();
                //Now, check the ConfirmationNumber again, if there still isn't a ConfirmationNumber, lets try to get one.
                if (_manifest2.ConfirmationNumber.Length == 0) GetSkidBuildOrderConfirmation(_manifest2);
                _manifest2.Populate(scanOWK); //Now track this Manifest.
                return;
            }

            //If we get this far, see if the leading alpha characters of the OWK SubRoute matches either of the "TrackedManifests".
            //If one matches, use that one.
            string owkSubRouteAlpha = string.Concat(scanOWK.SubRoute.TakeWhile(c => c < '0' || c > '9')); //Get all the characters up to the first Number.
            if(_manifest1.SubRoute.StartsWith(owkSubRouteAlpha))
            {
                //Has the associated SkidBuildOrder already been Confirmed? (Make sure by trying to query it again.)
                if (_manifest1.ConfirmationNumber.Length == 0) _manifest1.LoadConfirmation();
                //Now, check the ConfirmationNumber again, if there still isn't a ConfirmationNumber, lets try to get one.
                if (_manifest1.ConfirmationNumber.Length == 0) GetSkidBuildOrderConfirmation(_manifest1);
                _manifest1.Populate(scanOWK); //Now track this Manifest.
                return;
            }
            if(_manifest2.SubRoute.StartsWith(owkSubRouteAlpha))
            {
                //Has the associated SkidBuildOrder already been Confirmed? (Make sure by trying to query it again.)
                if (_manifest2.ConfirmationNumber.Length == 0) _manifest2.LoadConfirmation();
                //Now, check the ConfirmationNumber again, if there still isn't a ConfirmationNumber, lets try to get one.
                if (_manifest2.ConfirmationNumber.Length == 0) GetSkidBuildOrderConfirmation(_manifest2);
                _manifest2.Populate(scanOWK); //Now track this Manifest.
                return;
            }

            //If we get this far, just use the Oldest (LastOWKScanned)...
            if(_manifest1.LastOWKScanned > _manifest2.LastOWKScanned)
            {
                //Has the associated SkidBuildOrder already been Confirmed? (Make sure by trying to query it again.)
                if (_manifest2.ConfirmationNumber.Length == 0) _manifest2.LoadConfirmation();
                //Now, check the ConfirmationNumber again, if there still isn't a ConfirmationNumber, lets try to get one.
                if (_manifest2.ConfirmationNumber.Length == 0) GetSkidBuildOrderConfirmation(_manifest2);
                _manifest2.Populate(scanOWK); //Now track this Manifest.
                return;
            }
            else
            {
                //Has the associated SkidBuildOrder already been Confirmed? (Make sure by trying to query it again.)
                if (_manifest1.ConfirmationNumber.Length == 0) _manifest1.LoadConfirmation();
                //Now, check the ConfirmationNumber again, if there still isn't a ConfirmationNumber, lets try to get one.
                if (_manifest1.ConfirmationNumber.Length == 0) GetSkidBuildOrderConfirmation(_manifest1);
                _manifest1.Populate(scanOWK); //Now track this Manifest.
                return;
            }
        }

        /// <summary>
        /// This method will create a SkidBuildOrder from the OWK (passed in the ScanOWK parameter) and submit it to the Toyota SCS Rest API.
        /// </summary>
        /// <param name="scanOWK"></param>
        public void GetSkidBuildOrderConfirmation(TrackedManifest trackedManifest)
        {
            //Read in the ID from the Table and decide what to do.
            try
            {
                //TODO: Only Log this if "Debug"???
                _logger.Log("-----In GetSkidBuildOrderConfirmation(): Plant: " + trackedManifest.Plant +
                            " SupplierCode: " + trackedManifest.SupplierCode +
                            " OrderNumber: " + trackedManifest.OrderNumber +
                            " DockCode: " + trackedManifest.DockCode +
                            " PalleticationCode: " + trackedManifest.PalletizationCode);

                _logger.Log("-----In GetSkidBuildOrderConfirmation(): OWK: " + trackedManifest.Plant + trackedManifest.SupplierCode + trackedManifest.OrderNumber + trackedManifest.DockCode + trackedManifest.PalletizationCode +
                    "  _manifest1: " + _manifest1.Plant + _manifest1.SupplierCode + _manifest1.OrderNumber + _manifest1.DockCode + _manifest1.PalletizationCode +
                    "  _manifest2: " + _manifest2.Plant + _manifest2.SupplierCode + _manifest2.OrderNumber + _manifest2.DockCode + _manifest2.PalletizationCode);

                //Just create a "dummy" ScanManifest to pass to ToyotaSkidBuildRequest(), it only uses a few fields....
                //(Long term, change ToyotaSkidBuildRequest() to take the proper parameters, instead of the ScanManifest!)
                ScanManifest scanManifest = new ScanManifest();
                scanManifest.NAMC = trackedManifest.Plant;
                scanManifest.SupplierCode = trackedManifest.SupplierCode;
                scanManifest.OrderNumber = trackedManifest.OrderNumber;
                scanManifest.DockCode = trackedManifest.DockCode;
                scanManifest.Created = DateTime.Now; //Not used, because we are using ALL Scans, but including to be "standard".
                scanManifest.ID = 0;
                scanManifest.OrderSequence = "TransferScan";
                scanManifest.ScannedBy = "Transfer";  ///??? Used for CreatedBy on the SkidBuildOrder, APIResponse, etc.

                //Determine if we need to send a SkidBuild Request to TSCS.
                //(Use ALL OWK Scans (second parameter = FALSE), Picker, Transfer, Bander1, Bander2, etc!!)
                ToyotaSkidBuildRequest(scanManifest, false);
            }
            catch (Exception ex)
            {
                if (ex.InnerException != null)
                {
                    _logger.LogError("Exception in GetSkidBuildOrderConfirmation(): " + ex.Message + " (Inner Exception: " + ex.InnerException + ")");
                }
                else
                {
                    _logger.LogError("Exception in GetSkidBuildOrderConfirmation(): " + ex.Message);
                }
            }
        }

        private void ToyotaSkidBuildRequest(ScanManifest scanManifest, bool pickerScansOnly)
        {
            ///
            //Determine what all PartNumber/PANSREQ been been "Picked" by looking in "ScanOWK" where "CreatedBy=PickToLightClient".
            //Store Each PartNumber and PANSREQ  as "Ordered" (or "Planned").
            //Store Each PartNumber and Number of Unique/Distinct (Barcode) Scans as "Picked" (or "Pulled" or "Shipped").
            //(Maybe I should create a Class or Struct with "PartNumber", "PansOrdered", "PansPicked".)
            ///
            //var list = new[] { new { sn = "a1", sd = "b1" } }.ToList(); // declaring structure
            //list.Clear();                                               // clearing dummy element
            //list.Add(new { sn = "a", sd = "b" });                       // adding real element
            //foreach (var leaf in list) if (leaf.sn == "a") break;       // using it
            var partsOrdered = new Dictionary<string, int>();
            var partsPulled = new Dictionary<string, int>();
            var partsPulledDuplicate = new Dictionary<string, int>();

            bool DEBUG = false; // true;   // false;

            List<ScanOWK> pickerScansForAllPartsIncludingDuplicates = new List<ScanOWK>();
            List<ToyotaShipment> toyotaOrderShipments = new List<ToyotaShipment>();

            ////(As a "backup", if we can get PalletizationCode from CMS and at least one part for each Palletization has been scanned, but the order isn't complete, we should send email notifiation!

            //First, we need to determine if a SkidBuildRequest is necessary.
            //Determine if this is the only Manifest / Skid for the order:
            using (var ctx = new PickToLightEntities())
            {
                //  Use the NAMC (NAMCDestination) and SupplierCode from the Manifest to get the TRPT that corresponds to the NAMC in ToyotaShipments
                NAMC_TRPT_CrossRef namcTRPTcrossRef;
                namcTRPTcrossRef = (from n in ctx.NAMC_TRPT_CrossRef
                                    where scanManifest.NAMC == n.NAMCDestination && scanManifest.SupplierCode == n.SupplierCode
                                    select n).SingleOrDefault<NAMC_TRPT_CrossRef>();
                if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaSkidBuildRequest()----- NAMC_TRPT_CrossRef.TRPT = " + namcTRPTcrossRef.TRPT + "  (where scanManifest.NAMC (" + scanManifest.NAMC.ToString() + ") == n.NAMCDestination && scanManifest.SupplierCode (" + scanManifest.SupplierCode.ToString() + ") == n.SupplierCode)");

                //  Using OrderNumber, NAMC, Supplier Code and Dock Code, get Rows from ToyotaShipments where COMPLETED = FALSE (0)!!!
                //  (The NAMC in ToyotaShipments is a combination of the NAMC and Supplier Code!)
                toyotaOrderShipments = (from s in ctx.ToyotaShipments
                                        where namcTRPTcrossRef.TRPT == s.NAMC
                                        && scanManifest.OrderNumber == s.ORDERNUM
                                        && scanManifest.DockCode == s.DOCKCODE
                                        && s.Completed == false
                                        select s).ToList(); //Do a "ToList()" here??
                if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaSkidBuildRequest()----- Found " + toyotaOrderShipments.Count().ToString() + " toyotaOrderShipments, where namcTRPTcrossRef.TRPT (" + namcTRPTcrossRef.TRPT.ToString() + ") == s.NAMC && scanManifest.OrderNumber (" + scanManifest.OrderNumber.ToString() + ") == s.ORDERNUM && scanManifest.DockCode (" + scanManifest.DockCode.ToString() + ") == s.DOCKCODE");
                //RIGHT HERE, IF THERE AREN'T ANY SHIPMENTS (not Completed), WE NEED TO STOP AND SEND A MESSAGE!!! Normally, this shouldn't happen!!!!)
                if (toyotaOrderShipments.Count() == 0)
                {
                    //Console.WriteLine("-----ToyotaSkidBuildRequest()----- NO ToyotaShipments (not marked as COMPLETED) exist for scanManifest.OrderNumber = " + scanManifest.OrderNumber + " AND scanManifest.DockCode = " + scanManifest.DockCode + " AND NAMC_TRPT_CrossRef.TRPT = " + namcTRPTcrossRef.TRPT + "  (where scanManifest.NAMC (" + scanManifest.NAMC.ToString() + ") == n.NAMCDestination && scanManifest.SupplierCode (" + scanManifest.SupplierCode.ToString() + ") == n.SupplierCode)");
                    SendEMailNotificationAndLogException(false, "NOTE: The most common reason for this Exception is when the spImportToyotaShipments (SQL Stored Procedure called via a SQL Job) has NOT been executed or had problems importing this Order. -----ToyotaSkidBuildRequest()----- NO ToyotaShipments (not marked as COMPLETED) exist for scanManifest.OrderNumber = " + scanManifest.OrderNumber + " AND scanManifest.DockCode = " + scanManifest.DockCode + " AND NAMC_TRPT_CrossRef.TRPT = " + namcTRPTcrossRef.TRPT + "  (where scanManifest.NAMC (" + scanManifest.NAMC.ToString() + ") == n.NAMCDestination && scanManifest.SupplierCode (" + scanManifest.SupplierCode.ToString() + ") == n.SupplierCode)");
                    return;
                }
                //  There will be one Row per Part…get all the Parts with ORDERQTY, PANQTY and PANSREQ…
                foreach (var shipment in toyotaOrderShipments)
                {
                    if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaSkidBuildRequest()----- Shipment for SNAPARTNUM:" + shipment.SNAPARTNUM + " PANSREQ:" + shipment.PANSREQ + " ORDERQTY:" + shipment.ORDERQTY + " PANQTY:" + shipment.PANQTY + "   (ORDERNUM:" + shipment.ORDERNUM + " NAMC:" + shipment.NAMC + " DOCKCODE:" + shipment.DOCKCODE + " SUBROUTE:" + shipment.SUBROUTE + "  SHIPDATE:" + shipment.SHIPDATE + " SHIPTIME:" + shipment.SHIPTIME + " CUSTPARTNUM:" + shipment.CUSTPARTNUM + ")");
                    if (partsOrdered.ContainsKey(shipment.CUSTPARTNUM))
                    {
                        partsOrdered[shipment.CUSTPARTNUM] = partsOrdered[shipment.CUSTPARTNUM] + Int32.Parse(shipment.PANSREQ.ToString());
                    }
                    else
                    {
                        partsOrdered.Add(shipment.CUSTPARTNUM, Int32.Parse(shipment.PANSREQ.ToString()));
                        //Also "seed" partsPulled and partsPulledDuplicate with 0 values....
                        partsPulled.Add(shipment.CUSTPARTNUM, 0);
                        partsPulledDuplicate.Add(shipment.CUSTPARTNUM, 0);
                    }

                    List<ScanOWK> pickerScans = new List<ScanOWK>();
                    if(pickerScansOnly)
                    {
                        //     Get all the matching ScanOWK entries for Pickers (PickToLightClient).
                        //          Each "unique" ROW (NAMC, SupplierCode, OrderNumber,DockCode,PartNumber,Box...) is one PAN (PANREQ)
                        //List<ScanOWK> pickerScans = (from p in ctx.ScanOWKs
                        pickerScans = (from p in ctx.ScanOWKs
                                       where scanManifest.NAMC == p.NAMCDestination  //Use the NAMC from the Manifest!
                                       && scanManifest.SupplierCode == p.SupplierCode
                                       && scanManifest.OrderNumber == p.OrderNumber
                                       && scanManifest.DockCode == p.DockCode
                                       && p.Decoded == true
                                       && shipment.CUSTPARTNUM == p.PartNumber
                                       && p.CreatedBy.Equals("PickToLightClient")
                                       && p.Created < scanManifest.Created //We should only process the Scans that happened BEFORE this "B Manifest"....
                                       orderby p.Created
                                       select p).ToList();
                    }
                    else
                    {
                        pickerScans = (from p in ctx.ScanOWKs
                                       where scanManifest.NAMC == p.NAMCDestination  //Use the NAMC from the Manifest!
                                       && scanManifest.SupplierCode == p.SupplierCode
                                       && scanManifest.OrderNumber == p.OrderNumber
                                       && scanManifest.DockCode == p.DockCode
                                       && p.Decoded == true
                                       && shipment.CUSTPARTNUM == p.PartNumber
                                       //
                                       //If pickerScansOnly == FALSE, include ALL Scans... Pickers, Transfer, Bander1, Bander2.
                                       //This is used when called in situations other than "P2L_COMMAND_ScanManifestEnd"
                                       //
                                       //&& p.CreatedBy.Equals("PickToLightClient")
                                       //&& p.Created < scanManifest.Created //We should only process the Scans that happened BEFORE this "B Manifest"....
                                       orderby p.Created
                                       select p).ToList();
                    }
                    //
                    //
                    //If no matching OWKSupplierText Row, we have a problem.... but this isn't something we care about at this point...
                    //Commenting this block out, don't need "SupplierInformation" (SNA Part #)...
                    //
                    //
                    ////Iterate through and log info just for debug.
                    //foreach (var scan in pickerScans)
                    //{
                    //    //[SupplierCode]
                    //    //,[DockCode]
                    //    //,[KanbanNumber]
                    //    //,[PartNumber]
                    //    //,[SupplierTextLine1]   //SNA Part #
                    //    //FROM [PickToLightDev].[dbo].[OWKSupplierText]
                    //    var kanban = (from k in ctx.OWKSupplierTexts
                    //                  where scan.SupplierCode == k.SupplierCode
                    //                  && scan.DockCode == k.DockCode
                    //                  && scan.PartNumber == k.PartNumber
                    //                  select k).FirstOrDefault<OWKSupplierText>();
                    //    //
                    //    //
                    //    //If this is NULL, we have a problem.... but this isn't something we care about at this point...
                    //    //Commenting this block out, don't need "SupplierInformation" (SNA Part #)...
                    //    //
                    //    //
                    //    if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaSkidBuildRequest()----- PickerScans -- Palletization:" + scan.PalletizationCode + " LineSideAddress:" + scan.LineSideAddress + " PartNumber:" + scan.PartNumber + " SNAPartNumber:" + kanban.SupplierTextLine1 + " Kanban:" + scan.KanbanNumber + " LotSize:" + scan.LotSize + " BoxNumber:" + scan.BoxNumber + " BoxTotal:" + scan.BoxTotal + "   (OrderNumber:" + scan.OrderNumber + " NAMCDestination:" + scan.NAMCDestination + " DockCode:" + scan.DockCode + " SubRoute:" + scan.SubRoute + "  ShipDate:" + scan.ShipDate + " ShipTime:" + scan.ShipTime + " CreatedBy:" + scan.CreatedBy + " ScannedBy:" + scan.ScannedBy + " Created:" + scan.Created.ToString() + ")");
                    //    //Let's add these parts to "pickerScansForAllPartsIncludingDuplicates" so they can be passed to the method that sends them to Toyota...
                    //    scan.SupplierInformation = kanban.SupplierTextLine1; //Save the SNAPartNumber as "SupplierInformation.
                    //    pickerScansForAllPartsIncludingDuplicates.Add(scan);
                    //}
                    pickerScansForAllPartsIncludingDuplicates.AddRange(pickerScans);

                    //          Actually, can use the "Barcode" to Group By or get "Distinct", to omit any duplicate Scans!
                    int numPartsPulled = pickerScans.Count(); //This includes Duplicate Scans!!
                    int numUniquePartsPulled = pickerScans.Select(barcode => barcode.Barcode).Distinct().Count(); //This omits any duplicates!
                    if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaSkidBuildRequest()----- PickerScans (" + numPartsPulled.ToString() + ") with distinct/unique barcode:" + numUniquePartsPulled.ToString());
                    if (partsPulled.ContainsKey(shipment.CUSTPARTNUM))
                    {
                        partsPulled[shipment.CUSTPARTNUM] = partsPulled[shipment.CUSTPARTNUM] + numUniquePartsPulled;
                    }
                    else //This normally shouldn't happen, becasue all "partsPulled" are seeded with a 0 above.....but just in case they pulled the wrong part!
                    {
                        partsPulled.Add(shipment.CUSTPARTNUM, numUniquePartsPulled);
                    }
                    //Store the duplicate scans too, just so the notification can be tailored!
                    if (numPartsPulled != numUniquePartsPulled)
                    {
                        if (partsPulledDuplicate.ContainsKey(shipment.CUSTPARTNUM))
                        {
                            partsPulledDuplicate[shipment.CUSTPARTNUM] = partsPulledDuplicate[shipment.CUSTPARTNUM] + numPartsPulled;
                        }
                        else //This normally shouldn't happen, becasue all "partsPulledDuplicate" are seeded with a 0 above.....but just in case they pulled the wrong part!
                        {
                            partsPulledDuplicate.Add(shipment.CUSTPARTNUM, numPartsPulled);
                        }
                    }
                }
            }

            if (DEBUG)
            {
                foreach (var pair in partsPulled)
                {
                    //Console.WriteLine("Pulled = {0}, {1}", pair.Key, pair.Value);
                    _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaSkidBuildRequest()----- Part# " + pair.Key + " Pulled: " + pair.Value + " Ordered:" + partsOrdered[pair.Key]);
                }
                foreach (var pair in partsOrdered)
                {
                    //Console.WriteLine("Pulled = {0}, {1}", pair.Key, pair.Value);
                    _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaSkidBuildRequest()----- Part# " + pair.Key + " Ordered: " + pair.Value + "  Pulled:" + partsPulled[pair.Key]);
                }
            }

            //     If the Order is complete, send it off for confirmation.
            //     Otherwise, "log" it and continue on.

            //if partsOrdered = partsPulled, order is 100% complete, SEND it!
            //if partsOrdered has at least 1 part pulled in partsPulled, then send Email notification and warn of possible intervention.
            //Otherwise, (one of the PartNumbers doesn't have ANY parts pulled for it) lets just assume another Manifest is coming and we will pick up the entire order then!

            bool EachPartHasAtLeastOneScan = true;
            bool AllPartsHaveBeenCompleted = true;
            bool AllPartsHaveBeenCompletedWithDuplicates = false;

            foreach (var pair in partsOrdered)
            {
                if (partsPulled[pair.Key] == 0)
                {
                    EachPartHasAtLeastOneScan = false;
                    if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaSkidBuildRequest()----- Part# " + pair.Key + " had ZERO parts Pulled. (DON'T DO ANYTHING??? WAIT FOR ANOTHER MANIFEST???)");
                }
                else if (partsPulled[pair.Key] >= pair.Value)
                {
                    if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaSkidBuildRequest()----- Part# " + pair.Key + " was FULLY Pulled. (IF ALL PARTS ARE FULLY PULLED, SEND SkidBuild!)");
                }
                else
                {
                    AllPartsHaveBeenCompleted = false;
                    if (partsPulledDuplicate[pair.Key] >= pair.Value && pickerScansOnly) //We only care about "Duplicate Scans" by the "Pickers" (users scanning with a handheld scanner)... Otherwise, we don't need to mention it.
                    {
                        AllPartsHaveBeenCompletedWithDuplicates = true;
                        if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaSkidBuildRequest()----- Part# " + pair.Key + " was NOT FULLY Pulled because the same barcode/boxnumber was scanned multiple times! (SEND A NOTIFICATION THAT ONLY XXX were PULLED FOR PART#, UNLESS ONE OF THE PARTS PULLED ARE ZERO, THEN IGNORE!)");
                    }
                    else
                    {
                        AllPartsHaveBeenCompletedWithDuplicates = false;
                        if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----ToyotaSkidBuildRequest()----- Part# " + pair.Key + " was NOT FULLY Pulled. (SEND A NOTIFICATION THAT ONLY XXX were PULLED FOR PART#, UNLESS ONE OF THE PARTS PULLED ARE ZERO, THEN IGNORE!)");
                    }
                }
            }

            if (EachPartHasAtLeastOneScan)
            {
                if (AllPartsHaveBeenCompleted)
                {
                    DoSkidBuildTransaction(scanManifest, pickerScansForAllPartsIncludingDuplicates, toyotaOrderShipments, pickerScansOnly); //NOTE, pickerScans parameter may not be unique, hence the name!
                    _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "INFO", "-----ToyotaSkidBuildRequest()----- Sent to Toyota SCS API for Approval!");
                }
                else
                {
                    //Make sure we really want to send the email.
                    //Don't send it if there are two pickers working on the same manifest and this is the "EndManifest" for the "first picker"!!
                    //(Wait until the second Picker scans his "EndManifest"!!)

                    string orderSequenceMinusAorB = scanManifest.OrderSequence.Remove(scanManifest.OrderSequence.Length - 1);
                    DateTime createdMinus30Minutes = scanManifest.Created.AddMinutes(-30);
                    List<ScanManifest> manifestScans = new List<ScanManifest>();
                    using (var ctx = new PickToLightEntities())
                    {
                        manifestScans = (from m in ctx.ScanManifests
                                         where scanManifest.OrderNumber == m.OrderNumber
                                         && scanManifest.SupplierCode == m.SupplierCode
                                         && scanManifest.NAMC == m.NAMC
                                         && scanManifest.DockCode == m.DockCode
                                         && scanManifest.PalletizationCode == m.PalletizationCode    //Also need Palletization Code! Already had an instance where it was important!!
                                         && m.Decoded == true
                                             //&& m.OrderSequence == orderSequenceMinusAorB
                                         && m.OrderSequence.StartsWith(orderSequenceMinusAorB)
                                         && scanManifest.DeviceName != m.DeviceName
                                         && m.Created < scanManifest.Created
                                         && m.Created > createdMinus30Minutes //Only include it if its within 30 minutes of this Scan. (To ccount for "day cross-over" Manifests.)
                                         //&& m.CreatedBy.Equals("PickToLightClient")
                                         orderby m.Created
                                         select m).ToList();
                    }

                    if (manifestScans.Count == 1)
                    {
                        //Console.WriteLine("Don't send EMAIL, there is only ONE Manifest Scan in the result set, so ther other user hasn't scanned their \"EndManifest\"!!");
                        //If there is only one Manifest Scan (by a different Device) in this result set, then we can assume the user is still picking. So, log it and return!
                        _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "INFO", "-----ToyotaSkidBuildRequest()----- DO NOT send the EMAIL Notifcation! Another Device/User has scanned this Manifest, but hasn't finished (because there is only ONE Manifest Scan for User: " + manifestScans[0].ScannedBy + " on Device: " + manifestScans[0].DeviceName + " in the last 30 minutes)!!");
                        return;
                    }
                    else
                    {
                        //manifestScans.Dump();
                        //Step through each (foreach) returned Manifest...
                        //  If there are any (other) Device's (DeviceName) that don't have a "matching" (Begin and End) Scan, then we can assume that Device/User is still picking the order...
                        //  (We can determine this by "Counting" them for each Device. Even numbers probably mean all "Begins" also have an "End".
                        foreach (var currentScan in manifestScans)
                        {
                            //How many Manifest Scans for this DeviceName, in the Result Set...
                            int countScans = manifestScans.Count(m => m.DeviceName == currentScan.DeviceName);
                            //If there is an odd number for this Device, then we can assume the user is still picking. So, log it and return!
                            if (countScans % 2 != 0)
                            {
                                _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "INFO", "-----ToyotaSkidBuildRequest()----- DO NOT send the EMAIL Notifcation! Another Device/User has scanned this Manifest, but hasn't finished (because there is an Odd number of Manifest Scans for User: " + currentScan.ScannedBy + " on Device: " + currentScan.DeviceName + " in the last 30 minutes)!!");
                                return;
                            }
                        }
                    }

                    //Right here, we need to build the missingScansMessage
                    string missingScansMessage = "";
                    foreach (var pair in partsOrdered)
                    {
                        for(int i=1; i <= pair.Value; i++ )
                        {
                            //List<ScanOWK> nonUniquePickerScans
                            if(pickerScansForAllPartsIncludingDuplicates.Find(p => p.PartNumber == pair.Key && p.BoxNumber == i.ToString("D4") ) == null)
                            {
                                if (missingScansMessage.Length == 0)
                                {
                                    if (pickerScansOnly)
                                    {
                                        missingScansMessage = "<br>The following Parts/Box Numbers were NOT scanned by a Picker:<br><ul>";
                                    }
                                    else
                                    {
                                        missingScansMessage = "<br>The following Parts/Box Numbers were NOT scanned by a Picker OR a Fixed Camera:<br><ul>";
                                    }
                                }
                                missingScansMessage += "<li>Part: " + pair.Key + " Box: " + i.ToString("D4") + "</li>";
                            }
                        }
                    }
                    if (missingScansMessage.Length > 0)
                    {
                        missingScansMessage += "</ul>";
                    }

                    SendNotificationEmail_OrderNotComplete(scanManifest, AllPartsHaveBeenCompletedWithDuplicates, missingScansMessage, "");
                    //Use "Error" for "TSCSType" (ThreadName in the Log) when AllPartsHaveBeenCompletedWithDuplicates = TRUE, because we SHOULD now be preventing duplicate scans at the device level.
                    //(If two users are pulling the same manifest (from two different devices), they could scan the same OWK twice...once per user/device... so it can definately happen and needs to me tagged as an "ERROR"..)
                    _logger.LogToSQL_TSCS("TSCS_PickToLightServer", (AllPartsHaveBeenCompletedWithDuplicates ? "ERROR" : "INFO"), "-----ToyotaSkidBuildRequest()----- EMAIL Notifcation Sent! (AllPartsHaveBeenCompletedWithDuplicates = " + (AllPartsHaveBeenCompletedWithDuplicates ? "TRUE" : "FALSE"));
                }
            }
            else
            {
                //MOST of the time, this means there is still another Manifest to Pull, so just wait.
                _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "INFO", "-----ToyotaSkidBuildRequest()----- One of the PartNumbers doesn't have ANY parts pulled, so don't send to TSCS API, also NO Email Notification!");
            }
        }

        private void DoSkidBuildTransaction(ScanManifest scanManifest, List<ScanOWK> nonUniquePickerScans, List<ToyotaShipment> toyotaOrderShipments, bool pickerScansOnly)
        {
            bool DEBUG = false;   // true;
            bool TestException = false; //true
            bool TEST_RETRY = false;

            // TODO - FINISH!
            if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- scanManifest.ID:" + scanManifest.ID.ToString() + " scanManifest.NAMC:" + scanManifest.NAMC.ToString() + " scanManifest.SupplierCode:" + scanManifest.SupplierCode.ToString() + " scanManifest.DockCode:" + scanManifest.DockCode.ToString() + " scanManifest.OrderNumber:" + scanManifest.OrderNumber.ToString() + " scanManifest.OrderSequence:" + scanManifest.OrderSequence.ToString());
            //int numUniquePartsPulled = pickerScans.Select(barcode => barcode.Barcode).Distinct().Count(); //This omits any duplicates!
            int parsedInt;
            List<ScanOWK> uniquePickerScans = (from ps in nonUniquePickerScans
                                               where ps.CreatedBy == "PickToLightClient" //Only get the actual PickerScans here!
                                               group ps by ps.Barcode  //There can be duplicates, so group on Barcode and take the last Scan.
                                                   into grp
                                                   select new ScanOWK     //Or, I could make the list of Kanban's here!
                                                   {
                                                       Barcode = grp.Key,
                                                       ID = grp.Select(ex => ex.ID).LastOrDefault(), //There can be duplicates, so group on Barcode and take the last Scan.
                                                       SupplierCode = grp.Select(ex => ex.SupplierCode).LastOrDefault(),
                                                       DockCode = grp.Select(ex => ex.DockCode).LastOrDefault(),
                                                       KanbanNumber = grp.Select(ex => ex.KanbanNumber).LastOrDefault(),
                                                       PartNumber = grp.Select(ex => ex.PartNumber).LastOrDefault(),
                                                       LineSideAddress = grp.Select(ex => ex.LineSideAddress).LastOrDefault(),
                                                       StoreAddress = grp.Select(ex => ex.StoreAddress).LastOrDefault(),
                                                       LotSize = grp.Select(ex => ex.LotSize).LastOrDefault(),
                                                       SupplierName = grp.Select(ex => ex.SupplierName).LastOrDefault(),
                                                       MainRoute = grp.Select(ex => ex.MainRoute).LastOrDefault(),
                                                       SubRoute = grp.Select(ex => ex.SubRoute).LastOrDefault(),
                                                       UnloadDate = grp.Select(ex => ex.UnloadDate).LastOrDefault(),
                                                       ShipDate = grp.Select(ex => ex.ShipDate).LastOrDefault(),
                                                       ShipTime = grp.Select(ex => ex.ShipTime).LastOrDefault(),
                                                       OrderNumber = grp.Select(ex => ex.OrderNumber).LastOrDefault(),
                                                       BoxNumber = grp.Select(ex => ex.BoxNumber).LastOrDefault(),
                                                       BoxTotal = grp.Select(ex => ex.BoxTotal).LastOrDefault(),
                                                       NAMCDestination = grp.Select(ex => ex.NAMCDestination).LastOrDefault(),
                                                       PalletizationCode = grp.Select(ex => ex.PalletizationCode).LastOrDefault(),
                                                       DeviceName = grp.Select(ex => ex.DeviceName).LastOrDefault(),
                                                       DeviceIdentifier = grp.Select(ex => ex.DeviceIdentifier).LastOrDefault(),
                                                       ScannedBy = grp.Select(ex => ex.ScannedBy).LastOrDefault(),
                                                       Created = grp.Select(ex => ex.Created).LastOrDefault(),
                                                       CreatedBy = grp.Select(ex => ex.CreatedBy).LastOrDefault(),
                                                       Filler = "" //Later on, we will "stuff" the SkidId into this field, since we aren't using it for building the Kanbans...
                                                   }).ToList();

            List<ScanOWK> cameraScansMissingFromPickerScans = new List<ScanOWK>();
            if (pickerScansOnly == false)
            {
                //Add the missing Camera Scans!!!
                //
                //First, get the uniqueCameraScans
                List<ScanOWK> uniqueCameraScans = (from ps in nonUniquePickerScans
                                                   where ps.CreatedBy != "PickToLightClient" //Only get the NON PickerScans here (the Camera Scans)!
                                                   group ps by ps.Barcode  //There can be duplicates, so group on Barcode and take the last Scan.
                                                       into grp
                                                       select new ScanOWK     //Or, I could make the list of Kanban's here!
                                                       {
                                                           Barcode = grp.Key,
                                                           ID = grp.Select(ex => ex.ID).LastOrDefault(), //There can be duplicates, so group on Barcode and take the last Scan.
                                                           SupplierCode = grp.Select(ex => ex.SupplierCode).LastOrDefault(),
                                                           DockCode = grp.Select(ex => ex.DockCode).LastOrDefault(),
                                                           KanbanNumber = grp.Select(ex => ex.KanbanNumber).LastOrDefault(),
                                                           PartNumber = grp.Select(ex => ex.PartNumber).LastOrDefault(),
                                                           LineSideAddress = grp.Select(ex => ex.LineSideAddress).LastOrDefault(),
                                                           StoreAddress = grp.Select(ex => ex.StoreAddress).LastOrDefault(),
                                                           LotSize = grp.Select(ex => ex.LotSize).LastOrDefault(),
                                                           SupplierName = grp.Select(ex => ex.SupplierName).LastOrDefault(),
                                                           MainRoute = grp.Select(ex => ex.MainRoute).LastOrDefault(),
                                                           SubRoute = grp.Select(ex => ex.SubRoute).LastOrDefault(),
                                                           UnloadDate = grp.Select(ex => ex.UnloadDate).LastOrDefault(),
                                                           ShipDate = grp.Select(ex => ex.ShipDate).LastOrDefault(),
                                                           ShipTime = grp.Select(ex => ex.ShipTime).LastOrDefault(),
                                                           OrderNumber = grp.Select(ex => ex.OrderNumber).LastOrDefault(),
                                                           BoxNumber = grp.Select(ex => ex.BoxNumber).LastOrDefault(),
                                                           BoxTotal = grp.Select(ex => ex.BoxTotal).LastOrDefault(),
                                                           NAMCDestination = grp.Select(ex => ex.NAMCDestination).LastOrDefault(),
                                                           PalletizationCode = grp.Select(ex => ex.PalletizationCode).LastOrDefault(),
                                                           DeviceName = grp.Select(ex => ex.DeviceName).LastOrDefault(),
                                                           DeviceIdentifier = grp.Select(ex => ex.DeviceIdentifier).LastOrDefault(),
                                                           ScannedBy = grp.Select(ex => ex.ScannedBy).LastOrDefault(),
                                                           Created = grp.Select(ex => ex.Created).LastOrDefault(),
                                                           CreatedBy = grp.Select(ex => ex.CreatedBy).LastOrDefault(),
                                                           Filler = "" //Later on, we will "stuff" the SkidId into this field, since we aren't using it for building the Kanbans...
                                                       }).ToList();

                //Now get the barcodes that were only scanned by a Camera
                cameraScansMissingFromPickerScans = uniqueCameraScans.Where(uCS => !uniquePickerScans.Any(uPS => uPS.Barcode == uCS.Barcode)).ToList();
            }

            foreach (var scan in cameraScansMissingFromPickerScans)
            {
                //if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- Camera Scans missing from Picker Scans:" + );
                //if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- Camera Scans missing from Picker Scans: OrderNumber:" + scan.OrderNumber + " NAMCDestination:" + scan.NAMCDestination + " DockCode:" + scan.DockCode + " Palletization:" + scan.PalletizationCode + " Created:" + scan.Created.ToString() + " PartNumber:" + scan.PartNumber + " SNAPartNumber:" + scan.SupplierInformation + " Kanban:" + scan.KanbanNumber + " BoxNumber:" + scan.BoxNumber + " BoxTotal:" + scan.BoxTotal + " CreatedBy:" + scan.CreatedBy + " ScannedBy:" + scan.ScannedBy);
                if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- Camera Scans missing from Picker Scans: OrderNumber:" + scan.OrderNumber + " NAMCDestination:" + scan.NAMCDestination + " DockCode:" + scan.DockCode + " Palletization:" + scan.PalletizationCode + " Created:" + scan.Created.ToString() + " PartNumber:" + scan.PartNumber + " SupplierInformation:" + scan.SupplierInformation + " Kanban:" + scan.KanbanNumber + " BoxNumber:" + scan.BoxNumber + " BoxTotal:" + scan.BoxTotal + " CreatedBy:" + scan.CreatedBy + " ScannedBy:" + scan.ScannedBy);
            }

            //RequestSkidBuild reqSkidBuild = new RequestSkidBuild("ExampleFromGarry");
            RequestSkidBuild reqSkidBuild = new RequestSkidBuild();

            ////////////////////////////////////////Build the RequestSkidBuild!!!!!////////////////////////////////////////

            ///I could do all this in a constructor for "RequestSkidBuild" and pass scanManifest and kanbans...

            reqSkidBuild.order = scanManifest.OrderNumber;
            reqSkidBuild.supplier = scanManifest.SupplierCode;
            reqSkidBuild.plant = scanManifest.NAMC;
            reqSkidBuild.dock = scanManifest.DockCode;


            //
            //Skid Build – Order Level
            //Shipment Load – Skid Level
            //Shipment Load – Trailer Level
            //
            //
            //We will need a SkidBuild (actually now SkidBuild), Exception Code table to choose the Codes from.
            //     (SkidBuildOrderLevelExceptionCodes, Columns = "Code,NVARCHAR(2)" and "Description,NVARCHAR(100)"....)
            //
            //Also, one for "Shipment Load - Skid Level" and "Shipment Load = Trailer Level"...
            //
            //We will need a ShipmentLoad - SkidLevel, Exception Code table to choose the Codes from.
            //     (ShipmentLoadSkidLevelExceptionCodes, Columns = "Code,NVARCHAR(2)" and "Description,NVARCHAR(100)"....)
            //We will need a ShipmentLoad = TrailerLevel, Exception Code table to choose the Codes from.
            //     (ShipmentLoadTrailerLevelExceptionCodes, Columns = "Code,NVARCHAR(2)" and "Description,NVARCHAR(100)"....)
            //
            //Add an Exception for Code 20
            //
            //It appears if there aren't any Exceptions, we don't have to add any!!!
            //BUT.... the method that builds the JSON adds a "null" exception... so lets add an empty one for now so the Request format is correct!)
            //
            //++++++++++
            //UPDATED 11/25/18!
            //++++++++++
            //Now, we can set this to null and have it omitted from the Request, because we can:
            //Tell the Serializer to ignore this by adding the Json Attribute: [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
            //to the "exceptions" property in the RequestSkidBuild class.
            //-----
            //reqSkidBuild.exceptions = new List<APIexception>();
            //APIexception exceptionItem1 = new APIexception();
            //exceptionItem1.exceptionCode = (TestException ? "20" : "");
            //exceptionItem1.comments = (TestException ? "Expendable Packaging" : "");
            //reqSkidBuild.exceptions.Add(exceptionItem1);
            ////////APIexception exceptionItem2 = new APIexception();
            ////////exceptionItem2.exceptionCode = "";
            ////////exceptionItem2.comments = "";
            ////////reqSkidBuild.exceptions.Add(exceptionItem2);
            //-----
            //++++++++++
            if (TestException)
            {
                reqSkidBuild.exceptions = new List<APIexception>();
                APIexception exceptionItem1 = new APIexception();
                exceptionItem1.exceptionCode = "20";
                exceptionItem1.comments = "Expendable Packaging";
                reqSkidBuild.exceptions.Add(exceptionItem1);
            }
            else
            {
                reqSkidBuild.exceptions = null;
            }

            //First, let's get all the Manifests that have been scanned for this Order...
            //(OrderNumber, SupplierCode, NAMC and DockCode)
            //(But only this one (that we are processing) AND the ones "older" than this one.)
            //This can be done by "ID", since we have the ScanManifest and are only querying ScanManifest.
            List<ScanManifest> manifestScans = new List<ScanManifest>();
            using (var ctx = new PickToLightEntities())
            {
                if (pickerScansOnly)
                {
                    manifestScans = (from m in ctx.ScanManifests
                                     where scanManifest.OrderNumber == m.OrderNumber
                                     && scanManifest.SupplierCode == m.SupplierCode
                                     && scanManifest.NAMC == m.NAMC
                                     && scanManifest.DockCode == m.DockCode
                                     && m.Decoded == true
                                     && m.CreatedBy.Equals("PickToLightClient")
                                     //&& scanManifest.ID > m.ID //Let's just use the "ID", since its faster, because its the Primary Key and Indexed.
                                     //
                                     //1-18-19
                                     //-------
                                     //We also want to include the Manifest from the scanManifest parameter!
                                     //This is really for accuracy when this method is called by some other means (like after a "TransferScan")
                                     //***NOTE: On second thought, let's omit the ID check entirely!***
                                     //&& scanManifest.ID >= m.ID
                                     //&& m.Created < scanManifest.Created //We should only process the Scans that happened BEFORE this "B Manifest"....
                                     orderby m.Created
                                     select m).ToList();
                }
                else //1-25-19 - Load ALL Scan Manifests if we are using ALL Scans.
                {
                    manifestScans = (from m in ctx.ScanManifests
                                     where scanManifest.OrderNumber == m.OrderNumber
                                     && scanManifest.SupplierCode == m.SupplierCode
                                     && scanManifest.NAMC == m.NAMC
                                     && scanManifest.DockCode == m.DockCode
                                     && m.Decoded == true
                                     //&& m.CreatedBy.Equals("PickToLightClient")
                                     //&& scanManifest.ID > m.ID //Let's just use the "ID", since its faster, because its the Primary Key and Indexed.
                                     //&& m.Created < scanManifest.Created //We should only process the Scans that happened BEFORE this "B Manifest"....
                                     orderby m.Created
                                     select m).ToList();
                }
            }

            //Now, lets go through all the OWK Scans, Sorted by Palletization Code, then Created (Date/Time) (...NO, Just use "ID"!).
            //For each one, lets just use the Manifest that was Scanned "most recent".
            //In other words, only use the Manifests that Match the Palletization Code...
            //  sorted by Created (Date/Time) (or just ID)...
            //  and get the "Last" (newest) one that came before (less than) the OWK Scan we are processing.
            //Lets store the SkidID in a field that we aren't going to use, like "Filler"...
            //1-25-19 - We need to match the ScannedBy and/or DeviceName. I'm going to try both, that should be accurate..
            //foreach (var scan in uniquePickerScans.OrderBy(p => p.PalletizationCode).OrderBy(p => p.ID))
            //Also changed second OrderBy to ThenBy!!!! 
            //(Handle cameraScansMissingFromPickerScans differently than uniquePickerScans, try to determine the Manifest using one of the similar uniquePickerScans.
            string manifestNotFoundMessage = "";
            foreach (var scan in uniquePickerScans.OrderBy(p => p.PalletizationCode).ThenBy(p => p.ID))
            {
                //if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- uniquePickerScans.OrderBy(PalletizationCode).ThenBy(ID) -- Palletization:" + scan.PalletizationCode + " Created:" + scan.Created.ToString() + " LineSideAddress:" + scan.LineSideAddress + " PartNumber:" + scan.PartNumber + " SNAPartNumber:" + scan.SupplierInformation + " Kanban:" + scan.KanbanNumber + " LotSize:" + scan.LotSize + " BoxNumber:" + scan.BoxNumber + " BoxTotal:" + scan.BoxTotal + "   (OrderNumber:" + scan.OrderNumber + " NAMCDestination:" + scan.NAMCDestination + " DockCode:" + scan.DockCode + " SubRoute:" + scan.SubRoute + "  ShipDate:" + scan.ShipDate + " ShipTime:" + scan.ShipTime + " CreatedBy:" + scan.CreatedBy + " ScannedBy:" + scan.ScannedBy + ")");
                if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- uniquePickerScans.OrderBy(PalletizationCode).ThenBy(ID) -- Palletization:" + scan.PalletizationCode + " Created:" + scan.Created.ToString() + " LineSideAddress:" + scan.LineSideAddress + " PartNumber:" + scan.PartNumber + " SupplierInformation:" + scan.SupplierInformation + " Kanban:" + scan.KanbanNumber + " LotSize:" + scan.LotSize + " BoxNumber:" + scan.BoxNumber + " BoxTotal:" + scan.BoxTotal + "   (OrderNumber:" + scan.OrderNumber + " NAMCDestination:" + scan.NAMCDestination + " DockCode:" + scan.DockCode + " SubRoute:" + scan.SubRoute + "  ShipDate:" + scan.ShipDate + " ShipTime:" + scan.ShipTime + " CreatedBy:" + scan.CreatedBy + " ScannedBy:" + scan.ScannedBy + ")");
                ScanManifest manifestScan = (from m in manifestScans
                                             where scan.PalletizationCode == m.PalletizationCode
                                             && scan.Created > m.Created //Only get the Manifests that were scanned BEFORE this one...
                                                 //
                                                 //1-25-19 - We need to match the ScannedBy and/or DeviceName. I'm going to try both, that should be accurate.
                                                 //This is to handle when:
                                                 //     A picker has started one SkidId (Manifest) such as 001.
                                                 //     Another picker starts a different SkidId (Manifest) such as 002
                                                 //     The first picker finishes
                                                 //
                                             && scan.ScannedBy.Equals(m.ScannedBy) && scan.DeviceName.Equals(m.DeviceName)
                                             orderby m.ID
                                             select m).LastOrDefault();
                //Now, lets save the SkidId this OWK belongs to, in the "Filler" column (if we can find a Manifest/SkidId!!)
                if (manifestScan != null)
                {
                    if (string.IsNullOrEmpty(manifestScan.OrderSequence) == false)
                    {
                        int orderSequenceLength = manifestScan.OrderSequence.Length;
                        if (orderSequenceLength > 3) //The Skid
                        {
                            //The SkidId+AorBcode is the last 4 characters: XX001A, 14001B, 11002A, 1A002B, etc......
                            //But, we don't need the last character (AorBcode), we only need the 3 character "SkidId" 001, 002, 003, etc.
                            scan.Filler = manifestScan.OrderSequence.Substring(orderSequenceLength - 4, 3);
                        }
                    }
                    if (string.IsNullOrEmpty(scan.Filler))
                    {
                        //if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- Unable to find a matching manifest to use for uniquePickerScan -- Palletization:" + scan.PalletizationCode + " Created:" + scan.Created.ToString() + " PartNumber:" + scan.PartNumber + " SNAPartNumber:" + scan.SupplierInformation + " Kanban:" + scan.KanbanNumber + " LotSize:" + scan.LotSize + " BoxNumber:" + scan.BoxNumber + " BoxTotal:" + scan.BoxTotal + "   (OrderNumber:" + scan.OrderNumber + " NAMCDestination:" + scan.NAMCDestination + " DockCode:" + scan.DockCode + " SubRoute:" + scan.SubRoute + "  ShipDate:" + scan.ShipDate + " ShipTime:" + scan.ShipTime + " CreatedBy:" + scan.CreatedBy + " ScannedBy:" + scan.ScannedBy + ")");
                        if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- Unable to find a matching manifest to use for uniquePickerScan -- Palletization:" + scan.PalletizationCode + " Created:" + scan.Created.ToString() + " PartNumber:" + scan.PartNumber + " SupplierInformation:" + scan.SupplierInformation + " Kanban:" + scan.KanbanNumber + " LotSize:" + scan.LotSize + " BoxNumber:" + scan.BoxNumber + " BoxTotal:" + scan.BoxTotal + "   (OrderNumber:" + scan.OrderNumber + " NAMCDestination:" + scan.NAMCDestination + " DockCode:" + scan.DockCode + " SubRoute:" + scan.SubRoute + "  ShipDate:" + scan.ShipDate + " ShipTime:" + scan.ShipTime + " CreatedBy:" + scan.CreatedBy + " ScannedBy:" + scan.ScannedBy + ")");
                        if (manifestNotFoundMessage.Length == 0)
                        {
                            manifestNotFoundMessage = "<br>Unable to find a matching Manifest Scan for the following Picker Scanned OWKs:<br><ul>";
                        }
                        //manifestNotFoundMessage += "<li>SNAPart# " + scan.SupplierInformation + "<br>-----> Kanban# " + scan.KanbanNumber + " Box# " + scan.BoxNumber + " ScannedBy " + scan.ScannedBy + " Scanned " + scan.Created.ToString() + "</li>";
                        manifestNotFoundMessage += "<li>SupplierInformation " + scan.SupplierInformation + "<br>-----> Kanban# " + scan.KanbanNumber + " Box# " + scan.BoxNumber + " ScannedBy " + scan.ScannedBy + " Scanned " + scan.Created.ToString() + "</li>";
                    }
                }
            }
            if (manifestNotFoundMessage.Length > 0)
            {
                manifestNotFoundMessage += "</ul>";
            }

            //1-25-19 - Now, lets see if there are any cameraScansMissingFromPickerScans (not null)?
            //Handle cameraScansMissingFromPickerScans differently than uniquePickerScans:
            //try to determine the Manifest using one of the similar uniquePickerScans.
            bool firstMatch = true;
            foreach (var scan in cameraScansMissingFromPickerScans.OrderBy(p => p.PalletizationCode).ThenBy(p => p.ID))
            {
                //if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- Determine which SkidId to use for cameraScansMissingFromPickerScans.OrderBy(PalletizationCode).ThenBy(ID) -- Palletization:" + scan.PalletizationCode + " Created:" + scan.Created.ToString() + " PartNumber:" + scan.PartNumber + " SNAPartNumber:" + scan.SupplierInformation + " Kanban:" + scan.KanbanNumber + " LotSize:" + scan.LotSize + " BoxNumber:" + scan.BoxNumber + " BoxTotal:" + scan.BoxTotal + "   (OrderNumber:" + scan.OrderNumber + " NAMCDestination:" + scan.NAMCDestination + " DockCode:" + scan.DockCode + " SubRoute:" + scan.SubRoute + "  ShipDate:" + scan.ShipDate + " ShipTime:" + scan.ShipTime + " CreatedBy:" + scan.CreatedBy + " ScannedBy:" + scan.ScannedBy + ")");
                if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- Determine which SkidId to use for cameraScansMissingFromPickerScans.OrderBy(PalletizationCode).ThenBy(ID) -- Palletization:" + scan.PalletizationCode + " Created:" + scan.Created.ToString() + " PartNumber:" + scan.PartNumber + " SupplierInformation:" + scan.SupplierInformation + " Kanban:" + scan.KanbanNumber + " LotSize:" + scan.LotSize + " BoxNumber:" + scan.BoxNumber + " BoxTotal:" + scan.BoxTotal + "   (OrderNumber:" + scan.OrderNumber + " NAMCDestination:" + scan.NAMCDestination + " DockCode:" + scan.DockCode + " SubRoute:" + scan.SubRoute + "  ShipDate:" + scan.ShipDate + " ShipTime:" + scan.ShipTime + " CreatedBy:" + scan.CreatedBy + " ScannedBy:" + scan.ScannedBy + ")");
                ScanOWK similarPickerScan = null;
                //First, lets see if there is a scan in uniquePickerScans that matches the Palletization Code and Kanban
                similarPickerScan = (from ps in uniquePickerScans
                                     where scan.PalletizationCode == ps.PalletizationCode && scan.KanbanNumber == ps.KanbanNumber
                                     orderby ps.ID
                                     select ps).LastOrDefault();
                //If we found a match, use the SkidId (Filler)
                if (similarPickerScan != null)
                {
                    scan.Filler = similarPickerScan.Filler;
                    //if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- Used SkidId for Camera Scan from uniquePickerScans matching Palletization Code and Kanban. Palletization:" + similarPickerScan.PalletizationCode + " Created:" + similarPickerScan.Created.ToString() + " PartNumber:" + similarPickerScan.PartNumber + " SNAPartNumber:" + similarPickerScan.SupplierInformation + " Kanban:" + similarPickerScan.KanbanNumber + " LotSize:" + similarPickerScan.LotSize + " BoxNumber:" + similarPickerScan.BoxNumber + " BoxTotal:" + similarPickerScan.BoxTotal + "   (OrderNumber:" + similarPickerScan.OrderNumber + " NAMCDestination:" + similarPickerScan.NAMCDestination + " DockCode:" + similarPickerScan.DockCode + " SubRoute:" + similarPickerScan.SubRoute + "  ShipDate:" + similarPickerScan.ShipDate + " ShipTime:" + similarPickerScan.ShipTime + " CreatedBy:" + similarPickerScan.CreatedBy + " ScannedBy:" + similarPickerScan.ScannedBy + ")");
                    if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- Used SkidId for Camera Scan from uniquePickerScans matching Palletization Code and Kanban. Palletization:" + similarPickerScan.PalletizationCode + " Created:" + similarPickerScan.Created.ToString() + " PartNumber:" + similarPickerScan.PartNumber + " SupplierInformation:" + similarPickerScan.SupplierInformation + " Kanban:" + similarPickerScan.KanbanNumber + " LotSize:" + similarPickerScan.LotSize + " BoxNumber:" + similarPickerScan.BoxNumber + " BoxTotal:" + similarPickerScan.BoxTotal + "   (OrderNumber:" + similarPickerScan.OrderNumber + " NAMCDestination:" + similarPickerScan.NAMCDestination + " DockCode:" + similarPickerScan.DockCode + " SubRoute:" + similarPickerScan.SubRoute + "  ShipDate:" + similarPickerScan.ShipDate + " ShipTime:" + similarPickerScan.ShipTime + " CreatedBy:" + similarPickerScan.CreatedBy + " ScannedBy:" + similarPickerScan.ScannedBy + ")");
                }
                else //Otherwise, just use the "last" one matching the Palletization Code.
                {
                    //We could get fancy here and add more logic when there are more than one Skid for this Palletization Code.
                    //But, considering how rare it is that we are ever going to his this code anyway, this is good enough!!!
                    similarPickerScan = (from ps in uniquePickerScans
                                         where scan.PalletizationCode == ps.PalletizationCode // && scan.KanbanNumber == ps.KanbanNumber
                                         orderby ps.ID
                                         select ps).LastOrDefault();
                    if (similarPickerScan != null)
                    {
                        scan.Filler = similarPickerScan.Filler;
                        //if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- Used SkidId for Camera Scan from uniquePickerScans matching Palletization Code. (No matching Kanban found, this could prevent Confirmation!) Palletization:" + similarPickerScan.PalletizationCode + " Created:" + similarPickerScan.Created.ToString() + " PartNumber:" + similarPickerScan.PartNumber + " SNAPartNumber:" + similarPickerScan.SupplierInformation + " Kanban:" + similarPickerScan.KanbanNumber + " LotSize:" + similarPickerScan.LotSize + " BoxNumber:" + similarPickerScan.BoxNumber + " BoxTotal:" + similarPickerScan.BoxTotal + "   (OrderNumber:" + similarPickerScan.OrderNumber + " NAMCDestination:" + similarPickerScan.NAMCDestination + " DockCode:" + similarPickerScan.DockCode + " SubRoute:" + similarPickerScan.SubRoute + "  ShipDate:" + similarPickerScan.ShipDate + " ShipTime:" + similarPickerScan.ShipTime + " CreatedBy:" + similarPickerScan.CreatedBy + " ScannedBy:" + similarPickerScan.ScannedBy + ")");
                        if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- Used SkidId for Camera Scan from uniquePickerScans matching Palletization Code. (No matching Kanban found, this could prevent Confirmation!) Palletization:" + similarPickerScan.PalletizationCode + " Created:" + similarPickerScan.Created.ToString() + " PartNumber:" + similarPickerScan.PartNumber + " SupplierInformation:" + similarPickerScan.SupplierInformation + " Kanban:" + similarPickerScan.KanbanNumber + " LotSize:" + similarPickerScan.LotSize + " BoxNumber:" + similarPickerScan.BoxNumber + " BoxTotal:" + similarPickerScan.BoxTotal + "   (OrderNumber:" + similarPickerScan.OrderNumber + " NAMCDestination:" + similarPickerScan.NAMCDestination + " DockCode:" + similarPickerScan.DockCode + " SubRoute:" + similarPickerScan.SubRoute + "  ShipDate:" + similarPickerScan.ShipDate + " ShipTime:" + similarPickerScan.ShipTime + " CreatedBy:" + similarPickerScan.CreatedBy + " ScannedBy:" + similarPickerScan.ScannedBy + ")");
                    }
                    else
                    {
                        //if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- Unable to determine a SkidId to use for cameraScansMissingFromPickerScans -- Palletization:" + scan.PalletizationCode + " Created:" + scan.Created.ToString() + " PartNumber:" + scan.PartNumber + " SNAPartNumber:" + scan.SupplierInformation + " Kanban:" + scan.KanbanNumber + " LotSize:" + scan.LotSize + " BoxNumber:" + scan.BoxNumber + " BoxTotal:" + scan.BoxTotal + "   (OrderNumber:" + scan.OrderNumber + " NAMCDestination:" + scan.NAMCDestination + " DockCode:" + scan.DockCode + " SubRoute:" + scan.SubRoute + "  ShipDate:" + scan.ShipDate + " ShipTime:" + scan.ShipTime + " CreatedBy:" + scan.CreatedBy + " ScannedBy:" + scan.ScannedBy + ")");
                        if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- Unable to determine a SkidId to use for cameraScansMissingFromPickerScans -- Palletization:" + scan.PalletizationCode + " Created:" + scan.Created.ToString() + " PartNumber:" + scan.PartNumber + " SupplierInformation:" + scan.SupplierInformation + " Kanban:" + scan.KanbanNumber + " LotSize:" + scan.LotSize + " BoxNumber:" + scan.BoxNumber + " BoxTotal:" + scan.BoxTotal + "   (OrderNumber:" + scan.OrderNumber + " NAMCDestination:" + scan.NAMCDestination + " DockCode:" + scan.DockCode + " SubRoute:" + scan.SubRoute + "  ShipDate:" + scan.ShipDate + " ShipTime:" + scan.ShipTime + " CreatedBy:" + scan.CreatedBy + " ScannedBy:" + scan.ScannedBy + ")");
                        if (firstMatch)
                        {
                            firstMatch = false;
                            manifestNotFoundMessage += "<br>Manifest (SkidId) can't be determined!  Unable to find a matching Picker Scan for the following Camera Scanned OWKs:<br><ul>";
                        }
                        //manifestNotFoundMessage += "<li>SNAPart# " + scan.SupplierInformation + "<br>-----> Kanban# " + scan.KanbanNumber + " Box# " + scan.BoxNumber + " ScannedBy " + scan.ScannedBy + " Scanned " + scan.Created.ToString() + "</li>";
                        manifestNotFoundMessage += "<li>SupplierInformation " + scan.SupplierInformation + "<br>-----> Kanban# " + scan.KanbanNumber + " Box# " + scan.BoxNumber + " ScannedBy " + scan.ScannedBy + " Scanned " + scan.Created.ToString() + "</li>";
                    }
                }
            }
            if (manifestNotFoundMessage.Length > 0 && firstMatch == false)
            {
                manifestNotFoundMessage += "</ul>";
            }

            //If we didn't find a matching Manifest for any of the OWK Scans, we need to send an EmailNotification and just return...
            if (string.IsNullOrEmpty(manifestNotFoundMessage) == false)//If one of the Manifests wasn't found, send the notification and return!
            {
                SendNotificationEmail_OrderNotComplete(scanManifest, false, "", manifestNotFoundMessage);
                if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "ERROR", "-----DoSkidBuildTransaction()----- SendNotificationEmail_OrderNotComplete, manifestNotFoundMessage = " + manifestNotFoundMessage);
                return;
            }


            //
            //1-25-19 - Build uniqueScans from uniquePickerScans and cameraScansMissingFromPickerScans!
            //
            //
            //List<ScanOWK> uniqueScans = new List<ScanOWK>();
            //uniqueScans.AddRange(uniquePickerScans);
            //uniqueScans.AddRange(cameraScansMissingFromPickerScans);
            //(Both of these methods work, but the one below is a little better/quicker, I think.)
            List<ScanOWK> uniqueScans = uniquePickerScans;
            uniqueScans.AddRange(cameraScansMissingFromPickerScans);


            //Now, lets build the Skids and Kanbans!
            //Actually...the logic in this "foreach" and the "foreach" above could all be combined in the first one!!!
            string lastPalletizationCode = "";
            string lastSkidId = "";
            reqSkidBuild.skids = new List<Skid>();
            Skid skidItem = null;
            Kanban kanbanItem = null;
            //
            //1-25-19 - We need to include the SkidId ("Filler") in the OrderBy, after the Palletication Code!!!
            //foreach (var scan in uniquePickerScans.OrderBy(p => p.PalletizationCode).OrderBy(p => p.ID))
            if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- *****Creating the Skids and Kanbans***** ");
            //Also changed second OrderBy to ThenBy!!!! 
            foreach (var scan in uniqueScans.OrderBy(p => p.PalletizationCode).ThenBy(p => p.Filler).ThenBy(p => p.ID))
            {
                if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- : lastPalletizationCode:" + lastPalletizationCode + " scan:" + scan.PalletizationCode + "    lastSkidId:" + lastSkidId + " Filler (SkidId):" + scan.Filler.ToString() + "  Created:" + scan.Created.ToString() +  "  Kanban:" + scan.KanbanNumber + " BoxNumber:" + scan.BoxNumber + "  CreatedBy:" + scan.CreatedBy + "  ScannedBy:" + scan.ScannedBy);
                //First, let's see if we have a new "Skid", if so, add one, then we all all the KanBans for that Skid.
                if (lastPalletizationCode != scan.PalletizationCode || lastSkidId != scan.Filler)
                {
                    if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- : ***NEW Skid***");
                    lastPalletizationCode = scan.PalletizationCode;
                    lastSkidId = scan.Filler;
                    if (skidItem != null)
                    {
                        if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- : ***Add Skid to Order***");
                        //
                        //Not implemented yet, since it may change, just comment out for now!!
                        //
                        ////It appears we don't have to add the rfidDetails!!!
                        ////BUT.... the method that builds the JSON adds a "null" rfidDetails... so lets add an empty one for now so the Request format is correct!)
                        //skidItem.rfidDetails = new List<RfidDetail>();

                        //RfidDetail rfidItem1 = new RfidDetail();
                        //rfidItem1.rfId = null; //rfId = "";
                        //rfidItem1.type = "";
                        //skidItem.rfidDetails.Add(rfidItem1);
                        ////RfidDetail rfidItem2 = new RfidDetail();
                        ////rfidItem2.rfId = null; //rfId = "";
                        ////rfidItem2.type = "";
                        ////skidItem.rfidDetails.Add(rfidItem2);

                        reqSkidBuild.skids.Add(skidItem); //Add the first SkidItem (when there is more than one)!
                    }
                    skidItem = new Skid();
                    skidItem.palletization = scan.PalletizationCode;
                    skidItem.skidId = scan.Filler;
                    skidItem.kanbans = new List<Kanban>();
                }
                kanbanItem = new Kanban();
                kanbanItem.lineSideAddress = scan.LineSideAddress;
                kanbanItem.partNumber = scan.PartNumber;
                kanbanItem.kanban = scan.KanbanNumber;
                kanbanItem.qpc = (Int32.TryParse(scan.LotSize, out parsedInt) ? parsedInt : 0);
                kanbanItem.boxNumber = (Int32.TryParse(scan.BoxNumber, out parsedInt) ? parsedInt : 0);
                kanbanItem.manifestNumber = null; //manifestNumber = "";
                kanbanItem.rfId = null; //rfId = "";
                skidItem.kanbans.Add(kanbanItem);
            }
            if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()----- *****DONE Creating the Skids and Kanbans***** ");
            //
            //Not implemented yet, since it may change, just comment out for now!!
            //
            ////It appears we don't have to add the rfidDetails!!!
            ////BUT.... the method that builds the JSON adds a "null" rfidDetails... so lets add an empty one for now so the Request format is correct!)
            //skidItem.rfidDetails = new List<RfidDetail>();

            //RfidDetail rfidItem = new RfidDetail();
            //rfidItem.rfId = null; //rfId = "";
            //rfidItem.type = "";
            //skidItem.rfidDetails.Add(rfidItem);
            ////RfidDetail rfidItem2 = new RfidDetail();
            ////rfidItem2.rfId = null; //rfId = "";
            ////rfidItem2.type = "";
            ////skidItem.rfidDetails.Add(rfidItem2);

            reqSkidBuild.skids.Add(skidItem); //Add the last SkidItem.

            //Lets order the Skids by SkidId (001,002,Etc) and the Kanbans by Part#, then Box#.
            //It makes the Request String/Json/SQL all easier to evaluate/debug/look at!
            reqSkidBuild.skids.Sort((a, b) => a.skidId.CompareTo(b.skidId));
            foreach (var skid in reqSkidBuild.skids)
            {
                //skid.kanbans.Sort((a, b) => a.partNumber.CompareTo(b.partNumber));
                skid.kanbans = skid.kanbans.OrderBy(o => o.partNumber).ThenBy(o => o.boxNumber).ToList();
            }

            SkidBuildOrder newSkidBuildOrder = CreateSkidBuildSQLEntry(reqSkidBuild, scanManifest.ScannedBy);
            if (newSkidBuildOrder == null)
            {
                _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "EXCEPTION", "-----DoSkidBuildTransaction()==== Problem creating SkidBuild SQL Rows for scanManifest.ID: " + scanManifest.ID + ", scanManifest.NAMC:" + scanManifest.NAMC.ToString() + ", scanManifest.SupplierCode:" + scanManifest.SupplierCode.ToString() + " scanManifest.DockCode:" + scanManifest.DockCode);
            }

            ////////////////////////////////////////Build the RequestSkidBuild!!!!!////////////////////////////////////////

            String Username = "24d058ee-4775-4426-9ae0-6d3e612b5e10";  //AppID
            String Password = "W8aD2pM3qO7fS8xC3wE7bD1kX1nN8fG3gS8iN1kE8gH2iF3aX0";  //AppSecret

            String SkidURL = "https://api.toyota.com/tmna/prod/Logistics/v/SupplierOrderInformation/skid";
            String TrailerURL = "https://api.toyota.com/tmna/prod/Logistics/v/SupplierOrderInformation/trailer";

            //if (DEBUG) _logger.Log("-----DoSkidBuildTransaction()-----++++++++++New Skid Build Request++++++++++");
            //if (DEBUG) _logger.Log("-----DoSkidBuildTransaction()SkidURL: " + SkidURL);
            //if (DEBUG) _logger.Log("-----DoSkidBuildTransaction()Request (ObjectDumper): " + ObjectDumper.Dump(reqSkidBuild));
            //if (DEBUG) _logger.Log("-----DoSkidBuildTransaction()Request (JSON): " + JsonConvert.SerializeObject(reqSkidBuild));

            ToyotaSCSWebAPI tscsWebAPI = new ToyotaSCSWebAPI(Username, Password, SkidURL, TrailerURL);

            APIresponse response = null;

            //Testing API Communication!
            //response = tscsWebAPI.SendRequest<APIresponse>(SkidURL, "[{\"order\":\"2018090501SA\"}]");
            //if (DEBUG) _logger.Log("-----DoSkidBuildTransaction()==========(Only Sending Order, for test...) Response: " + Misc.ClassToString(response));

            List<RequestSkidBuild> orders = new List<RequestSkidBuild>();
            orders.Add(reqSkidBuild);
            string jsonRequest = JsonConvert.SerializeObject(orders);
            //SIMULATE AN ERROR HERE!
            if (TEST_RETRY)
            {
                string jsonRequest_BAD = jsonRequest.Replace("order", "CAUSERETRYorder");
                if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()=======Request (JSON): " + jsonRequest_BAD);
                response = tscsWebAPI.SendRequest<APIresponse>(SkidURL, jsonRequest_BAD);
            }
            else
            {
                if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()=======Request (JSON): " + jsonRequest);
                response = tscsWebAPI.SendRequest<APIresponse>(SkidURL, jsonRequest);
            }

            if (response.dotNetException != null) //If there was an Exception...
            {
                if (response.dotNetException.GetType().Name.Equals("WebException")) //...and it was a "WebException"...
                {
                    //APIResponse aPIResponse = CreateAPIResponseSQLEntry(true, newSkidBuildOrder.ID, response, pickerName);
                    APIResponse aPIResponse = CreateAPIResponseSQLEntry(true, newSkidBuildOrder.ID, response, scanManifest.ScannedBy);

                    //SendEMailNotificationAndLogException("In HandleAPIResponse() - There was an Exception when sending the SkidBuild! Exception was (" + aPIResponse.Exception + ")");
                    _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "INFO", "-----DoSkidBuildTransaction()----- 1st Send Failed with WebException, Retrying... Web Exception was:" + aPIResponse.Exception);
                    if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()=======RETRY! Request (JSON): " + jsonRequest);
                    response = tscsWebAPI.SendRequest<APIresponse>(SkidURL, jsonRequest);
                }
            }

            //Console.WriteLine("-----DoSkidBuildTransaction()==========Response: " + Misc.ClassToString(response));
            //Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            //Console.WriteLine("-----DoSkidBuildTransaction()==========Response (ObjectDumper): " + ObjectDumper.Dump(response));
            //Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            //if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()==========Response: " + Misc.ClassToString(response));
            if (DEBUG) _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "-----DoSkidBuildTransaction()==========Response (ObjectDumper): " + ObjectDumper.Dump(response));

            //
            //HandleAPIResponse() creates the SQL Rows for APIResponse, APIResonseMessage and SkidBuildOrderResponse (Maybe ShipmentLoadTrailerResponse in future???)
            //      It also "parses" the response and determines what to do? Like update ToyotaShipments or SkidBuildOrder Tables, or send an EMAIL Notification to "Managers" or "Developers"????
            //      RIGHT??? Make sure it does do all that!
            //
            HandleAPIResponse(response, newSkidBuildOrder, toyotaOrderShipments, scanManifest.ScannedBy);

            #region SimulateMoreTestResponses

            //////
            //////Simulate more responses, just to test Methods and proper SQL creation!
            //////
            //////Bad UserName
            ////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            ////Console.WriteLine("");
            ////Console.WriteLine("");
            ////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            ////Console.WriteLine("Press any Key and I will Send A BAD UserName!");
            ////Console.ReadKey(true);
            ////tscsWebAPI.UserName = "BAD";
            ////response = tscsWebAPI.SendRequest<APIresponse>(SkidURL, jsonRequest);
            //////Console.WriteLine("-----DoSkidBuildTransaction()==========Response: " + Misc.ClassToString(response));
            //////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            //////Console.WriteLine("-----DoSkidBuildTransaction()==========Response (ObjectDumper): " + ObjectDumper.Dump(response));
            //////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            ////HandleAPIResponse(response, newSkidBuildOrder, toyotaOrderShipments, scanManifest.ScannedBy);

            //////Wrong URL "method"
            ////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            ////Console.WriteLine("");
            ////Console.WriteLine("");
            ////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            ////Console.WriteLine("Press any Key and I will Send the wrong URL/WebMethod!");
            ////tscsWebAPI.UserName = Username;
            ////Console.ReadKey(true);
            ////response = tscsWebAPI.SendRequest<APIresponse>("https://api.toyota.com/tmna/prod/Logistics/v/SupplierOrderInformation/skidBAD", jsonRequest);
            //////Console.WriteLine("-----DoSkidBuildTransaction()==========Response: " + Misc.ClassToString(response));
            //////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            //////Console.WriteLine("-----DoSkidBuildTransaction()==========Response (ObjectDumper): " + ObjectDumper.Dump(response));
            //////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            ////HandleAPIResponse(response, newSkidBuildOrder, toyotaOrderShipments, scanManifest.ScannedBy);

            //////Sending to HTTP URL
            ////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            ////Console.WriteLine("");
            ////Console.WriteLine("");
            ////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            ////Console.WriteLine("Press any Key and I will Send to HTTP URL!");
            ////Console.ReadKey(true);
            ////response = tscsWebAPI.SendRequest<APIresponse>("http://api.toyota.com/tmna/prod/Logistics/v/SupplierOrderInformation/skid", jsonRequest);
            //////Console.WriteLine("-----DoSkidBuildTransaction()==========Response: " + Misc.ClassToString(response));
            //////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            //////Console.WriteLine("-----DoSkidBuildTransaction()==========Response (ObjectDumper): " + ObjectDumper.Dump(response));
            //////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            ////HandleAPIResponse(response, newSkidBuildOrder, toyotaOrderShipments, scanManifest.ScannedBy);

            //////Wrong URL...
            ////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            ////Console.WriteLine("");
            ////Console.WriteLine("");
            ////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            ////Console.WriteLine("Press any Key and I will Send the wrong URL... No Method!");
            ////Console.ReadKey(true);
            ////response = tscsWebAPI.SendRequest<APIresponse>("https://api.toyota.com/tmna/prod/Logistics/v/SupplierOrderInformation/", jsonRequest);
            //////Console.WriteLine("-----DoSkidBuildTransaction()==========Response: " + Misc.ClassToString(response));
            //////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            //////Console.WriteLine("-----DoSkidBuildTransaction()==========Response (ObjectDumper): " + ObjectDumper.Dump(response));
            //////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            ////HandleAPIResponse(response, newSkidBuildOrder, toyotaOrderShipments, scanManifest.ScannedBy);

            //////Sending only an Order #
            ////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            ////Console.WriteLine("");
            ////Console.WriteLine("");
            ////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            ////Console.WriteLine("Press any Key and I will Send only an Order Num!");
            ////Console.ReadKey(true);
            ////response = tscsWebAPI.SendRequest<APIresponse>(SkidURL, "[{\"order\":\"2018090501SA\"}]");
            //////Console.WriteLine("-----DoSkidBuildTransaction()==========Response: " + Misc.ClassToString(response));
            //////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            //////Console.WriteLine("-----DoSkidBuildTransaction()==========Response (ObjectDumper): " + ObjectDumper.Dump(response));
            //////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            ////HandleAPIResponse(response, newSkidBuildOrder, toyotaOrderShipments, scanManifest.ScannedBy);

            //////Sending only an Order #, but with multiple APIMessages!!
            ////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            ////Console.WriteLine("");
            ////Console.WriteLine("");
            ////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            ////Console.WriteLine("Press any Key and I will Send only an Order Num, but testing Multi APIResponseMessage SQL!!!");
            ////Console.ReadKey(true);
            ////response = tscsWebAPI.SendRequest<APIresponse>(SkidURL, "[{\"order\":\"2018090501SA\"}]");
            //////Console.WriteLine("-----DoSkidBuildTransaction()==========Response: " + Misc.ClassToString(response));
            //////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            //////Console.WriteLine("-----DoSkidBuildTransaction()==========Response (ObjectDumper): " + ObjectDumper.Dump(response));
            //////Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            //////RIGHT HERE, LETS TEST:
            //////NOTE: There can be multiple APIResponseMessages received, and within each of those there can be multiple Messages!
            //////Test multiple APIResponseMessages, some with ONE Message and some with more than one!!
            ////Message tempTesting = new Message();
            ////tempTesting.message = new List<string>();
            ////tempTesting.keyObject = "Extra APIMessage for testing SQL. (One Message.)";
            ////tempTesting.message.Add("This is the only Message in this Test.");
            ////response.messages.Add(tempTesting);
            ////tempTesting = new Message();
            ////tempTesting.message = new List<string>();
            ////tempTesting.keyObject = response.messages[0].keyObject;
            ////tempTesting.message.Add("Extra APIMessage for testing SQL. (First of two Messages.).");
            ////tempTesting.message.Add("Added another Message for Testing, Message 2");
            ////response.messages.Add(tempTesting);
            ////HandleAPIResponse(response, newSkidBuildOrder, toyotaOrderShipments, scanManifest.ScannedBy);
            //////
            //////Simulate more responses (above), just to test Methods and proper SQL creation!
            //////

            #endregion //SimulateMoreTestResponses
        }

        private void SendNotificationEmail_OrderNotComplete(ScanManifest scanManifest, bool CompletedWithDuplicates, string missingScansMessage, string manifestNotFoundMessage)
        {
            String emailSendTo = "";
            using (var ctx = new PickToLightEntities())
            {
                AppSetting email = (from s in ctx.AppSettings
                                    where s.Name == "TSCS_EmailNotification"
                                    select s).SingleOrDefault<AppSetting>();
                if (email != null)
                {
                    emailSendTo = email.Value;
                }
            }
            if (string.IsNullOrEmpty(emailSendTo))
            {
                emailSendTo = "sjudkins@shiroki-na.com";
            }

            _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "INFO", "-----SendNotificationEmail_OrderNotComplete()----- to " + emailSendTo);

            string body = "";
            // TODO - FINISH!
            if (scanManifest.ID > 0) //This means we are processing a "ManifestEnd" command.....
            {
                body = "<br>This Manifest was just pulled, but the system is unable to send it to the \"Toyota SCS\" for Approval.<br>" +
                        "Please corect and submit to Toyota for Approval, ASAP!<br>" +
                        "<br>" +
                        //"             ID: " + scanManifest.ID.ToString() + "<br>" +
                        //"    OrderNumber:" + scanManifest.OrderNumber.ToString() + "<br>" +
                        //"  OrderSequence:" + scanManifest.OrderSequence.ToString() + "<br>" +
                        //"   SupplierCode:" + scanManifest.SupplierCode.ToString() + "<br>" +
                        //"           NAMC: " + scanManifest.NAMC.ToString() + "<br>" +
                        //"       DockCode:" + scanManifest.DockCode.ToString() + "<br>" +
                        "<table>" +
                        "<tr><td>ID:</td><td>" + scanManifest.ID.ToString() + "</td></tr>" +
                        "<tr><td>NAMC:</td><td>" + scanManifest.NAMC.ToString() + "</td></tr>" +
                        "<tr><td>SupplierCode:</td><td>" + scanManifest.SupplierCode.ToString() + "</td></tr>" +
                        "<tr><td>OrderNumber:</td><td>" + scanManifest.OrderNumber.ToString() + "</td></tr>" +
                        "<tr><td>OrderSequence:</td><td>" + scanManifest.OrderSequence.Substring(scanManifest.OrderSequence.Length - 4, 3) + "</td></tr>" +
                        "<tr><td>DockCode:</td><td>" + scanManifest.DockCode.ToString() + "</td></tr>" +
                        "</table><br>" +
                        "(Provide Link to SHIROKInet for this _Manifest/ToyotaShipment_.)<br>";
            }
            else
            {
                body = "<br>The last OWK for this Order was just scanned by the Transfer Camera. The Order is INCOMPLETE, so the system is unable to send it to the \"Toyota SCS\" for Approval.<br>" +
                        "Please corect and submit to Toyota for Approval, ASAP!<br>" +
                        "<br>" +
                        "<table>" +
                        //"<tr><td>ID:</td><td>" + scanManifest.ID.ToString() + "</td></tr>" +
                        "<tr><td>NAMC:</td><td>" + scanManifest.NAMC.ToString() + "</td></tr>" +
                        "<tr><td>SupplierCode:</td><td>" + scanManifest.SupplierCode.ToString() + "</td></tr>" +
                        "<tr><td>OrderNumber:</td><td>" + scanManifest.OrderNumber.ToString() + "</td></tr>" +
                        //"<tr><td>OrderSequence:</td><td>" + scanManifest.OrderSequence.Substring(scanManifest.OrderSequence.Length - 4, 3) + "</td></tr>" +
                        "<tr><td>DockCode:</td><td>" + scanManifest.DockCode.ToString() + "</td></tr>" +
                        "</table><br>" +
                        "(Provide Link to SHIROKInet for this _Manifest/ToyotaShipment_.)<br>";
            }
            //Right here, I want to tell the user exactly which Scans are missing.
            //It would be easier, I think, to pass this in from the calling function!
            if (string.IsNullOrEmpty(missingScansMessage) == false) //Right now, this is used to include the OWKs that haven't been scanned (by the Picker OR by the Fixed Cameras).
            {
                body = body + "<span style=\"font-size:120%;font-weight:bold\">" + missingScansMessage + "</span>";
                _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "ERROR", "-----SendNotificationEmail_OrderNotComplete()----- Some of the OWK Scans are missing! scanManifest.ID:" + scanManifest.ID.ToString() + " scanManifest.NAMC:" + scanManifest.NAMC.ToString() + " scanManifest.SupplierCode:" + scanManifest.SupplierCode.ToString() + " scanManifest.DockCode:" + scanManifest.DockCode.ToString() + " scanManifest.OrderNumber:" + scanManifest.OrderNumber.ToString() + " scanManifest.OrderSequence:" + scanManifest.OrderSequence.ToString());
                _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "ERROR", "-----SendNotificationEmail_OrderNotComplete()----- missingScansMessage: " + missingScansMessage);
            }

            if (CompletedWithDuplicates) //I'm going to eliminate most (or ALL) of these by changing the PickToLightClient software!
            {
                body = body + "<span style=\"font-size:120%;font-weight:bold\">(Note: There were \"Duplicate Scans\" (the same OWK Label was scanned multiple times) in the system for this Manifest!!)</span>";
                _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "ERROR", "-----SendNotificationEmail_OrderNotComplete()----- The same Barcode/BoxNumber was scanned Multiple times! scanManifest.ID:" + scanManifest.ID.ToString() + " scanManifest.NAMC:" + scanManifest.NAMC.ToString() + " scanManifest.SupplierCode:" + scanManifest.SupplierCode.ToString() + " scanManifest.DockCode:" + scanManifest.DockCode.ToString() + " scanManifest.OrderNumber:" + scanManifest.OrderNumber.ToString() + " scanManifest.OrderSequence:" + scanManifest.OrderSequence.ToString());
            }
            else
            {
                _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "INFO", "-----SendNotificationEmail_OrderNotComplete()----- scanManifest.ID:" + scanManifest.ID.ToString() + " scanManifest.NAMC:" + scanManifest.NAMC.ToString() + " scanManifest.SupplierCode:" + scanManifest.SupplierCode.ToString() + " scanManifest.DockCode:" + scanManifest.DockCode.ToString() + " scanManifest.OrderNumber:" + scanManifest.OrderNumber.ToString() + " scanManifest.OrderSequence:" + scanManifest.OrderSequence.ToString());
            }
            if (string.IsNullOrEmpty(manifestNotFoundMessage) == false) //Right now, this is used to include the OWKs that couldn't be matched up with a Manifest...
            {
                body = body + "<span style=\"font-size:120%;font-weight:bold\">" + manifestNotFoundMessage + "</span>";
                _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "ERROR", "-----SendNotificationEmail_OrderNotComplete()----- Unable to figure out the matching Manifest for some of the OWKs! scanManifest.ID:" + scanManifest.ID.ToString() + " scanManifest.NAMC:" + scanManifest.NAMC.ToString() + " scanManifest.SupplierCode:" + scanManifest.SupplierCode.ToString() + " scanManifest.DockCode:" + scanManifest.DockCode.ToString() + " scanManifest.OrderNumber:" + scanManifest.OrderNumber.ToString() + " scanManifest.OrderSequence:" + scanManifest.OrderSequence.ToString());
                _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "ERROR", "-----SendNotificationEmail_OrderNotComplete()----- manifestNotFoundMessage: " + manifestNotFoundMessage);
            }

            Misc.SendEmail("PickToLightServer@shiroki-na.com", emailSendTo, "Toyota SCS SkidBuild Issue - ATTENTION REQUIRED!", body);
        }

        //private static void SendEMailNotificationAndLogException(string exceptionMessage)
        private void SendEMailNotificationAndLogException(bool isWebException, string exceptionMessage)
        {
            _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "EXCEPTION", "-----SendEMailNotificationAndLogException()----- Message:" + exceptionMessage);

            String exceptionsEmailSendTo = ""; // Use "TSCS_ApplicationException_EmailNotification" for any critical notifications. Users such as Developers and IT Staff.
            String notificationEmailSendTo = ""; // Use "TSCS_EmailNotification" for any Skid Build or Shipment Load notifications.
            using (var ctx = new PickToLightEntities())
            {
                AppSetting email = (from s in ctx.AppSettings
                                    where s.Name == "TSCS_ApplicationException_EmailNotification"
                                    select s).SingleOrDefault<AppSetting>();
                if (email != null)
                {
                    exceptionsEmailSendTo = email.Value;
                }

                email = (from s in ctx.AppSettings
                         where s.Name == "TSCS_EmailNotification"
                         select s).SingleOrDefault<AppSetting>();
                if (email != null)
                {
                    notificationEmailSendTo = email.Value;
                }
            }
            if (string.IsNullOrEmpty(exceptionsEmailSendTo) && string.IsNullOrEmpty(notificationEmailSendTo))
            {
                exceptionsEmailSendTo = "sjudkins@shiroki-na.com";
            }

            _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "INFO", "-----SendEMailNotificationAndLogException()----- to " + exceptionsEmailSendTo + " and " + notificationEmailSendTo);

            //For "WebException", the message should blame the Toyota Servers...
            if (isWebException)
            {
                if (string.IsNullOrEmpty(notificationEmailSendTo) == false)
                {
                    string body = "<br><span style=\"font-size:120%;font-weight:bold;color:red;\">ERROR communicating with the Toyota Shipping Confirmation System (TSCS). The TSCS servers are currently DOWN and/or not responding. This transaction will need to be Re-Sent (via ShirokiNet), once TSCS is up and working correctly!!!</span><br>";
                    Misc.SendEmail("PickToLightServer@shiroki-na.com", notificationEmailSendTo, "Toyota SCS - Servers Down!!!!", body);
                }

                if (string.IsNullOrEmpty(exceptionsEmailSendTo) == false)
                {
                    string body = "<br><span style=\"font-size:120%;font-weight:bold;color:red;\">ERROR communicating with the Toyota Shipping Confirmation System (TSCS). The TSCS servers are currently DOWN and/or not responding. This transaction will need to be Re-Sent (via ShirokiNet), once TSCS is up and working correctly!!!</span><br>" +
                                  "<br><br> Exception: " + exceptionMessage;
                    Misc.SendEmail("PickToLightServer@shiroki-na.com", exceptionsEmailSendTo, "Toyota SCS - Application Exception!!!!", body);
                }
            }
            else
            {
                string body = "<br><span style=\"font-size:120%;font-weight:bold;color:red;\">There is a SERIOUS problem in the PickToLightServer program. Please investigate!!!</span><br>" +
                                "<br> Error Message: " + exceptionMessage;
                if (string.IsNullOrEmpty(notificationEmailSendTo) == false)
                {
                    Misc.SendEmail("PickToLightServer@shiroki-na.com", notificationEmailSendTo, "Toyota SCS - Application Error!!!!", body);
                }
                if (string.IsNullOrEmpty(exceptionsEmailSendTo) == false)
                {
                    Misc.SendEmail("PickToLightServer@shiroki-na.com", exceptionsEmailSendTo, "Toyota SCS - Application Error!!!!", body);
                }
            }
        }

        //private static void SendEMailNotificationToFixValidationErrors(SkidBuildOrder SkidBuildOrder,string emailMessage)
        private void SendEMailNotificationToFixValidationErrors(SkidBuildOrder SkidBuildOrder, string emailMessage)
        {
            _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "ERROR", "-----SendEMailNotificationToFixValidationErrors()----- Message:" + emailMessage);

            String emailSendTo = "";
            using (var ctx = new PickToLightEntities())
            {
                AppSetting email = (from s in ctx.AppSettings
                                    where s.Name == "TSCS_EmailNotification"
                                    select s).SingleOrDefault<AppSetting>();
                if (email != null)
                {
                    emailSendTo = email.Value;
                }
            }
            if (string.IsNullOrEmpty(emailSendTo))
            {
                emailSendTo = "sjudkins@shiroki-na.com";
            }

            _logger.LogToSQL_TSCS("TSCS_PickToLightServer", "INFO", "-----SendEMailNotificationToFixValidationErrors()----- to " + emailSendTo);

            // TODO - FINISH!
            string body = emailMessage +
            "<br> This occured while processing a \"Pick To Light Command\" (P2L_COMMAND_ScanManifestEnd), for this Manifest:<br>" +
            "<table style=\"margin-left: 10px;\">" +
            "<tr><td>ID:</td><td>" + SkidBuildOrder.ID.ToString() + "</td></tr>" +
            "<tr><td>OrderNumber:</td><td>" + SkidBuildOrder.OrderNumber.ToString() + "</td></tr>" +
            "<tr><td>SupplierCode:</td><td>" + SkidBuildOrder.SupplierCode.ToString() + "</td></tr>" +
            "<tr><td>Plant (NAMC):</td><td>" + SkidBuildOrder.Plant.ToString() + "</td></tr>" +
            "<tr><td>DockCode:</td><td>" + SkidBuildOrder.DockCode.ToString() + "</td></tr>" +
            "</table><br>" +
            "(Provide Link to SHIROKInet for this SkidBuildOrder.)<br>";

            Misc.SendEmail("PickToLightServer@shiroki-na.com", emailSendTo, "Toyota SCS - Validation Errors!!!!", body);
        }

        //private static SkidBuildOrder CreateSkidBuildSQLEntry(RequestSkidBuild reqSkidBuild, string pickerName)
        private SkidBuildOrder CreateSkidBuildSQLEntry(RequestSkidBuild reqSkidBuild, string pickerName)
        {
            SkidBuildOrder newSkidBuildOrder = null; // new SkidBuildOrder();

            //
            //public partial class SkidBuildOrder()
            //{
            //public int ID { get; set; }
            //public string OrderNumber { get; set; }
            //public string SupplierCode { get; set; }
            //public string Plant { get; set; }
            //public string DockCode { get; set; }
            //public string ConfirmationNumber { get; set; }
            //public System.DateTime Created { get; set; }
            //public string CreatedBy { get; set; }
            //public System.DateTime Modified { get; set; }
            //public string ModifiedBy { get; set; }
            //this.SkidBuildOrderExceptions = new HashSet<SkidBuildOrderException>();
            //this.SkidBuildOrderResponses = new HashSet<SkidBuildOrderResponse>();
            //this.SkidBuildSkids = new HashSet<SkidBuildSkid>();
            //}

            var SkidBuildOrder = new SkidBuildOrder();

            SkidBuildOrder.OrderNumber = reqSkidBuild.order;
            SkidBuildOrder.SupplierCode = reqSkidBuild.supplier;
            SkidBuildOrder.Plant = reqSkidBuild.plant;
            SkidBuildOrder.DockCode = reqSkidBuild.dock;
            //SkidBuildOrder.Created = DateTime.Now; SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
            SkidBuildOrder.CreatedBy = pickerName;
            //SkidBuildOrder.Modified = DateTime.Now;  SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
            SkidBuildOrder.ModifiedBy = pickerName; //= ""; //Empty or NULL, until actually Modified?? Or, store the CreatedBy user??

            //
            //Now add the Skids...
            //
            //
            //public partial class SkidBuildSkid
            //{
            //public int ID { get; set; }
            //public int SkidBuildOrderID { get; set; }
            //public string SkidId { get; set; }
            //public string PalletizationCode { get; set; }
            //public string RFId { get; set; }
            //public System.DateTime Created { get; set; }
            //public string CreatedBy { get; set; }
            //public System.DateTime Modified { get; set; }
            //public string ModifiedBy { get; set; }
            //this.SkidBuildKanbans = new HashSet<SkidBuildKanban>();
            //}
            //Use Foreign Key and add the Skids
            if (reqSkidBuild.skids != null)
            {
                if (reqSkidBuild.skids.Count > 0)
                {
                    SkidBuildSkid SkidBuildSkid;
                    foreach (var skid in reqSkidBuild.skids)
                    {
                        SkidBuildSkid = new SkidBuildSkid();
                        //SkidBuildSkid.SkidBuildOrderID = //ID of SkidBuildOrder, but it hasn't been created yet!! May need to change the ordering here...
                        SkidBuildSkid.SkidId = skid.skidId.PadLeft(3, '0');
                        SkidBuildSkid.PalletizationCode = skid.palletization;
                        //SkidBuildSkid.Created = DateTime.Now;  SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
                        SkidBuildSkid.CreatedBy = pickerName;
                        //SkidBuildSkid.Modified = DateTime.Now;  SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
                        SkidBuildSkid.ModifiedBy = pickerName; //= ""; //Empty or NULL, until actually Modified?? Or, store the CreatedBy user??
                        //WAIT, Add this AFTER the kanbans!! -- SkidBuildOrder.SkidBuildSkids.Add(SkidBuildSkid);
                        //
                        //Now add the Kanbans, for this Skid!!
                        //
                        //
                        //public partial class SkidBuildKanban
                        //{
                        //public int ID { get; set; }
                        //public int SkidBuildSkidID { get; set; }
                        //public string PartNumber { get; set; }
                        //public string KanbanNumber { get; set; }
                        //public Nullable<int> QPC { get; set; }
                        //public Nullable<int> BoxNumber { get; set; }
                        //public string LineSideAddress { get; set; }
                        //public string RFId { get; set; }
                        //public string ManifestNumber { get; set; }
                        //public System.DateTime Created { get; set; }
                        //public string CreatedBy { get; set; }
                        //public System.DateTime Modified { get; set; }
                        //public string ModifiedBy { get; set; }
                        //}
                        if (skid.kanbans != null)
                        {
                            if (skid.kanbans.Count > 0)
                            {
                                SkidBuildKanban SkidBuildKanban;
                                foreach (var kanban in skid.kanbans)
                                {
                                    SkidBuildKanban = new SkidBuildKanban();

                                    //SkidBuildSkid.SkidBuildSkidID = //ID of SkidBuildSkid, but it hasn't been created yet!! May need to change the ordering here...
                                    SkidBuildKanban.PartNumber = kanban.partNumber;
                                    SkidBuildKanban.KanbanNumber = kanban.kanban;
                                    SkidBuildKanban.QPC = kanban.qpc;
                                    SkidBuildKanban.BoxNumber = kanban.boxNumber;
                                    SkidBuildKanban.LineSideAddress = kanban.lineSideAddress;
                                    SkidBuildKanban.RFId = kanban.rfId; //Will be Empty or NULL, not doing RFID right now!
                                    SkidBuildKanban.ManifestNumber = null;  //Not doing ManifestNumbers right now...
                                    //SkidBuildKanban.Created = DateTime.Now;  SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
                                    SkidBuildKanban.CreatedBy = pickerName;
                                    //SkidBuildKanban.Modified = DateTime.Now;  SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
                                    SkidBuildKanban.ModifiedBy = pickerName; //= ""; //Empty or NULL, until actually Modified?? Or, store the CreatedBy user??
                                    SkidBuildSkid.SkidBuildKanbans.Add(SkidBuildKanban);
                                }
                            }
                        }
                        SkidBuildOrder.SkidBuildSkids.Add(SkidBuildSkid);
                    }
                }
            }

            //
            //public partial class SkidBuildOrderException
            //{
            //public int ID { get; set; }
            //public int SkidBuildOrderID { get; set; }
            //public string Code { get; set; }
            //public string Comments { get; set; }
            //public System.DateTime Created { get; set; }
            //public string CreatedBy { get; set; }
            //public System.DateTime Modified { get; set; }
            //public string ModifiedBy { get; set; }
            //}
            //
            //Use Foreign Key and add the Exceptions
            if (reqSkidBuild.exceptions != null)
            {
                if (reqSkidBuild.exceptions.Count > 0)
                {
                    SkidBuildOrderException SkidBuildOrderException;
                    foreach (var exception in reqSkidBuild.exceptions)
                    {
                        SkidBuildOrderException = new SkidBuildOrderException();
                        //SkidBuildSkid.SkidBuildOrderID = //ID of SkidBuildOrder, but it hasn't been created yet!! May need to change the ordering here...
                        SkidBuildOrderException.Code = exception.exceptionCode;
                        SkidBuildOrderException.Comments = exception.comments;
                        //SkidBuildOrderException.Created = DateTime.Now;  SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
                        SkidBuildOrderException.CreatedBy = pickerName;
                        //SkidBuildOrderException.Modified = DateTime.Now;  SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
                        SkidBuildOrderException.ModifiedBy = pickerName; //= ""; //Empty or NULL, until actually Modified?? Or, store the CreatedBy user??
                        SkidBuildOrder.SkidBuildOrderExceptions.Add(SkidBuildOrderException);
                    }
                }
            }

            using (PickToLightEntities context = new PickToLightEntities())
            {
                context.SkidBuildOrders.Add(SkidBuildOrder);
                context.SaveChanges();
                //return (SkidBuildOrder.ID); //return the newly created ID!
                //Console.WriteLine("New SkidBuildOrder ID: " + SkidBuildOrder.ID.ToString());
                newSkidBuildOrder = SkidBuildOrder;
            }
            return (newSkidBuildOrder);
        }

        //private static APIResponse CreateAPIResponseSQLEntry(int idForSkidBuildOrShipmentLoad, APIresponse response, string pickerName)
        private APIResponse CreateAPIResponseSQLEntry(bool isSkidBuild, int idForSkidBuildOrShipmentLoad, APIresponse response, string pickerName)
        {
            bool DEBUG = false;

            //
            //public partial class APIResponse()
            //{
            //public int ID { get; set; }
            //public string Exception { get; set; }
            //public Nullable<int> Code { get; set; }
            //public string ConfirmationNumber { get; set; }
            //public string ConfirmedOrderNumber { get; set; }
            //public string ConfirmedOrderSupplierCode { get; set; }
            //public string ConfirmedOrderPlant { get; set; }
            //public string ConfirmedOrderDockCode { get; set; }
            //public string ConfirmedTrailerSupplierCode { get; set; }
            //public string ConfirmedTrailerRoute { get; set; }
            //public string ConfirmedTrailerRun { get; set; }
            //public string ConfirmedTrailerNumber { get; set; }
            //public Nullable<System.DateTime> ConfirmedTrailerPickUp { get; set; }
            //public string HTTPCode { get; set; }
            //public string HTTPMessage { get; set; }
            //public string HTTPMoreInformation { get; set; }
            //public System.DateTime Created { get; set; }
            //public string CreatedBy { get; set; }
            //this.APIResponseMessages = new HashSet<APIResponseMessage>();
            //this.SkidBuildOrderResponses = new HashSet<SkidBuildOrderResponse>();
            //}

            APIResponse aPIResponse = new APIResponse();

            //aPIResponse.Exception = "Parse dotNetException Object, HERE OR END OF Method????";
            aPIResponse.Code = response.code;
            aPIResponse.ConfirmationNumber = string.IsNullOrEmpty(response.confirmationNumber) ? "" : response.confirmationNumber;
            if (response.confirmedOrders != null)
            {
                if (response.confirmedOrders.Count > 1) //We don't send "batch orders", only one order at a time!!!
                {
                    //Console.WriteLine("TODO - //Called From - CreateAPIResponseSQLEntry() - SendEMailNotificationAndLogException");
                    //Console.WriteLine("Application ERROR! More than one confirmedOrder received in API Response!!!");
                    SendEMailNotificationAndLogException(false, "Application ERROR! More than one confirmedOrder received in API Response!!!");
                }
                if (response.confirmedOrders.Count > 0)
                {
                    aPIResponse.ConfirmedOrderNumber = string.IsNullOrEmpty(response.confirmedOrders[0].order) ? "" : response.confirmedOrders[0].order; //response.confirmedOrders[0].order;
                    aPIResponse.ConfirmedOrderSupplierCode = string.IsNullOrEmpty(response.confirmedOrders[0].supplier) ? "" : response.confirmedOrders[0].supplier; //response.confirmedOrders[0].supplier;
                    aPIResponse.ConfirmedOrderPlant = string.IsNullOrEmpty(response.confirmedOrders[0].plant) ? "" : response.confirmedOrders[0].plant; //response.confirmedOrders[0].plant;
                    aPIResponse.ConfirmedOrderDockCode = string.IsNullOrEmpty(response.confirmedOrders[0].dock) ? "" : response.confirmedOrders[0].dock; //response.confirmedOrders[0].dock;
                }
            }
            //This can now be called for a SkidBuildOrder or a ShipmentLoadTrailer!!!
            if (response.confirmedTrailer != null)
            {
                aPIResponse.ConfirmedTrailerSupplierCode = string.IsNullOrEmpty(response.confirmedTrailer.supplier) ? "" : response.confirmedTrailer.supplier; //response.confirmedTrailer.supplier;
                aPIResponse.ConfirmedTrailerRoute = string.IsNullOrEmpty(response.confirmedTrailer.route) ? "" : response.confirmedTrailer.route; //response.confirmedTrailer.route;
                aPIResponse.ConfirmedTrailerRun = string.IsNullOrEmpty(response.confirmedTrailer.run) ? "" : response.confirmedTrailer.run; //response.confirmedTrailer.run;
                aPIResponse.ConfirmedTrailerNumber = string.IsNullOrEmpty(response.confirmedTrailer.trailerNumber) ? "" : response.confirmedTrailer.trailerNumber; //response.confirmedTrailer.trailerNumber;

                //
                //This date is in the format of: 2018-11-15T13:50 (11/15/2018 13:50) yyyy-MM-ddTHH:mm As defined by datetime - RFC3339
                //To parse it, replace the "T" between the Date and Time with a "space".
                DateTime dateTime;
                //if (DateTime.TryParse(response.confirmedTrailer.pickUp, out dateTime) == false)
                //CultureInfo enUS = new CultureInfo("en-US");
                //if( DateTime.TryParseExact(response.confirmedTrailer.pickUp, "o", CultureInfo.InvariantCulture, DateTimeStyles.None, out dateTime) == false)
                //if (DateTime.TryParse(response.confirmedTrailer.pickUp.Replace('T', ' '), out dateTime) == false)
                if (DateTime.TryParseExact(response.confirmedTrailer.pickUp, "yyyy-MM-ddTHH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out dateTime) == false)
                {
                    aPIResponse.ConfirmedTrailerPickUp = null;
                    //Console.WriteLine("TODO - //Called From - CreateAPIResponseSQLEntry() - SendEMailNotificationAndLogException");
                    //Console.WriteLine("Application ERROR! Unable to parse the confirmed trailer Pickup Date/Time in API Response!!!");
                    SendEMailNotificationAndLogException(false, "Application ERROR! Unable to parse the confirmed trailer Pickup Date/Time in API Response!!!");
                }
                else
                {
                    aPIResponse.ConfirmedTrailerPickUp = dateTime;
                }
            }

            aPIResponse.HTTPCode = string.IsNullOrEmpty(response.httpCode) ? "" : response.httpCode; //response.httpCode;
            aPIResponse.HTTPMessage = string.IsNullOrEmpty(response.httpMessage) ? "" : response.httpMessage; //response.httpMessage;
            aPIResponse.HTTPMoreInformation = string.IsNullOrEmpty(response.moreInformation) ? "" : response.moreInformation; //response.moreInformation;
            //aPIResonse.Created = DateTime.Now;  SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
            aPIResponse.CreatedBy = pickerName;

            //Now add APIResponseMessages
            if (response.messages != null)
            {
                if (response.messages.Count > 0)
                {
                    //
                    //public partial class APIResponseMessage
                    //{
                    //    public int ID { get; set; }
                    //    public int APIResponseID { get; set; }
                    //    public string KeyObject { get; set; }
                    //    public string Message { get; set; }
                    //    public System.DateTime Created { get; set; }
                    //    public string CreatedBy { get; set; }
                    //
                    //    public virtual APIResponse APIResponse { get; set; }
                    //}
                    //NOTE: There can be multiple APIResponseMessages received, and within each of those there can be multiple Messages!
                    APIResponseMessage aPIResponseMessage;
                    foreach (var message in response.messages)
                    {
                        if (message.message != null)
                        {
                            if (message.message.Count == 1)
                            {
                                aPIResponseMessage = new APIResponseMessage();
                                //aPIResponseMessage.APIResponseID = //ID of APIResponse, but it hasn't been created yet!! May need to change the ordering here...
                                aPIResponseMessage.KeyObject = string.IsNullOrEmpty(message.keyObject) ? "" : message.keyObject; //message.keyObject;
                                aPIResponseMessage.Message = string.IsNullOrEmpty(message.message[0]) ? "" : message.message[0]; //message.message[0];
                                //aPIResponseMessage.Created = DateTime.Now;  SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
                                aPIResponseMessage.CreatedBy = pickerName;
                                aPIResponse.APIResponseMessages.Add(aPIResponseMessage);
                            }
                            else if (message.message.Count > 1) //If more than one message for this "APIResponseMessage", add additional Rows!
                            {
                                //NOTE: This handles multiple "messages" inside an "APIResponseMessage"!
                                foreach (var innerMessage in message.message)
                                {
                                    aPIResponseMessage = new APIResponseMessage();
                                    //aPIResponseMessage.APIResponseID = //ID of APIResponse, but it hasn't been created yet!! May need to change the ordering here...
                                    aPIResponseMessage.KeyObject = string.IsNullOrEmpty(message.keyObject) ? "" : message.keyObject; //message.keyObject;
                                    aPIResponseMessage.Message = string.IsNullOrEmpty(innerMessage) ? "" : innerMessage; //innerMessage; //message.message[0];
                                    //aPIResponseMessage.Created = DateTime.Now;  SET_BY DB! "StoreGeneratedPattern = Computed" in EF Designer for the Column!!!
                                    aPIResponseMessage.CreatedBy = pickerName;
                                    aPIResponse.APIResponseMessages.Add(aPIResponseMessage);
                                }
                            }
                        }
                    }
                }
            }

            if (idForSkidBuildOrShipmentLoad <= 0)
            {
                SendEMailNotificationAndLogException(false, "Application ERROR! CreateAPIResponseSQLEntry() was called with idForSkidBuildOrShipmentLoad <= 0!!!!");
            }
            else
            {
                if (isSkidBuild) //If this APIResponse is for a SkidBuild, then add a SkidBuildOrderResponse
                {
                    SkidBuildOrderResponse SkidBuildOrderResponse = new SkidBuildOrderResponse();
                    SkidBuildOrderResponse.SkidBuildOrderID = idForSkidBuildOrShipmentLoad;
                    SkidBuildOrderResponse.CreatedBy = pickerName;
                    aPIResponse.SkidBuildOrderResponses.Add(SkidBuildOrderResponse);
                }
                else //Otherwise, it must be fore a ShipmentLoad, so add a ShipmentLoadTrailerResponse
                {
                    ShipmentLoadTrailerResponse shipmentLoadTrailerResponse = new ShipmentLoadTrailerResponse();
                    shipmentLoadTrailerResponse.ShipmentLoadTrailerID = idForSkidBuildOrShipmentLoad;
                    shipmentLoadTrailerResponse.CreatedBy = pickerName;
                    aPIResponse.ShipmentLoadTrailerResponses.Add(shipmentLoadTrailerResponse);
                }
            }

            aPIResponse.Exception = ""; // "Parse dotNetException Object, HERE OR BEGIN of Method????";

            if (response.dotNetException != null)
            {
                aPIResponse.Exception = "Exception Type (" + response.dotNetException.GetType().Name + ")  ";
                //All status codes are standard HTTP status codes. The below ones are used in this API.
                //2XX - Success of some kind
                //4XX - Error occurred in client’s part
                //5XX - Error occurred in server’s part
                //--
                //200 OK, Created, Accepted, Validation errors
                //400 Bad request
                //401 Authentication failure
                //403 Forbidden
                //404 Resource not found
                //405 Method Not Allowed
                //409 Conflict
                //412 Precondition Failed
                //413 Request Entity Too Large
                //500 Internal Server Error
                //501 Not Implemented
                //503 Service Unavailable

                //class System.Exception();
                //
                //public Exception(string message);
                //[SecuritySafeCritical]
                //protected Exception(SerializationInfo info, StreamingContext context);
                //public Exception(string message, Exception innerException);

                //public virtual IDictionary Data { get; }
                //public virtual string HelpLink { get; set; }
                //public int HResult { get; protected set; }
                //public Exception InnerException { get; }
                //public virtual string Message { get; }
                //public virtual string Source { get; set; }
                //public virtual string StackTrace { get; }
                //public MethodBase TargetSite { get; }
                //
                //public virtual Exception GetBaseException();

                if (response.dotNetException.GetType().Name.Equals("WebException"))
                {
                    //All status codes are standard HTTP status codes. The below ones are used in this API.
                    //2XX - Success of some kind
                    //4XX - Error occurred in client’s part
                    //5XX - Error occurred in server’s part

                    //public int ID { get; set; }
                    //public string Exception { get; set; }
                    //public Nullable<int> Code { get; set; }
                    //
                    //public string HTTPCode { get; set; }
                    //public string HTTPMessage { get; set; }
                    //public string HTTPMoreInformation { get; set; }

                    //Console.WriteLine("A WebException has been caught.");
                    System.Net.WebException webException = (System.Net.WebException)response.dotNetException;
                    //
                    //public class WebException : InvalidOperationException, ISerializable
                    //
                    //public WebException();
                    //public WebException(string message);
                    //protected WebException(SerializationInfo serializationInfo, StreamingContext streamingContext);
                    //public WebException(string message, Exception innerException);
                    //public WebException(string message, WebExceptionStatus status);
                    //public WebException(string message, Exception innerException, WebExceptionStatus status, WebResponse response);
                    //
                    //public WebResponse Response { get; }
                    //public WebExceptionStatus Status { get; }
                    //

                    //WebResponse webResponse;
                    //WebExceptionStatus webExceptionStatus;

                    if (webException.Response != null)
                    {
                        HttpWebResponse httpResponse = (HttpWebResponse)webException.Response;
                        aPIResponse.Exception = aPIResponse.Exception + "Response Status Code (" + httpResponse.StatusCode.ToString() + ")  ";
                        if (string.IsNullOrEmpty(aPIResponse.HTTPCode))
                        {
                            //Console.WriteLine((int)httpResponse.StatusCode + " - " + httpResponse.StatusCode);
                            //aPIResponse.HTTPCode = httpResponse.StatusCode.ToString(); //NO! This can be longer than three???
                            aPIResponse.HTTPCode = ((int)httpResponse.StatusCode).ToString(); //Use the int value!
                        }
                    }

                    // Write out the WebException message.  
                    //Console.WriteLine(webException.ToString());
                    aPIResponse.Exception = aPIResponse.Exception + webException.ToString();
                    // Get the WebException status code.  
                    WebExceptionStatus status = webException.Status;
                    //Console.WriteLine(status.ToString());
                    aPIResponse.Exception = aPIResponse.Exception + "  WebException Status Code (" + status.ToString() + ")  ";
                    if (string.IsNullOrEmpty(aPIResponse.HTTPCode))
                    {
                        //Console.WriteLine((int)httpResponse.StatusCode + " - " + httpResponse.StatusCode);
                        //aPIResponse.HTTPCode = status.ToString(); //NO! This can be longer than three???
                        aPIResponse.HTTPCode = ((int)status).ToString(); //Use the int value!
                    }
                    //// If status is WebExceptionStatus.ProtocolError,   
                    ////   there has been a protocol error and a WebResponse   
                    ////   should exist. Display the protocol error.  
                    //if (status == WebExceptionStatus.ProtocolError)
                    //{
                    //    Console.WriteLine("The server returned protocol error ");
                    //    //// Get HttpWebResponse so that you can check the HTTP status code.  
                    //    //HttpWebResponse httpResponse = (HttpWebResponse)webException.Response;
                    //    //Console.WriteLine((int)httpResponse.StatusCode + " - " + httpResponse.StatusCode);
                    //}  
                }
                else  //An exception that isn't a WebException!
                {
                    //Console.WriteLine("A WebException has been caught.");

                    //aPIResponse.Exception = "Exception Type (" + response.dotNetException.GetType().Name + ")";

                    //genericClass.GetType().GetProperty("webException").SetValue(genericClass, ex);
                    //genericClass.GetType().GetProperty("dotNetException").SetValue(genericClass, ex);

                    aPIResponse.Exception = aPIResponse.Exception + "Message (" + response.dotNetException.Message + ")  ";

                    if (response.dotNetException.InnerException != null && response.dotNetException.InnerException.Message.Length > 0)
                    {
                        aPIResponse.Exception = aPIResponse.Exception + "Inner (" + response.dotNetException.InnerException.Message + ")  ";
                    }
                }
            }

            if (aPIResponse.Exception.Length > 4000)
            {
                string trimmedIndicator = " *TRIMMED*";
                aPIResponse.Exception = aPIResponse.Exception.Substring(0, 4000 - trimmedIndicator.Length) + trimmedIndicator;
            }

            using (PickToLightEntities context = new PickToLightEntities())
            {
                context.APIResponses.Add(aPIResponse);
                try
                {
                    context.SaveChanges();
                }
                catch (Exception ex)
                {
                    //Console.WriteLine("Exception Saving API Response: " + ex.Message);
                    //foreach(var err in context.GetValidationErrors())
                    //{
                    //    Console.WriteLine(  "Validation Error -- Valid? " + (err.IsValid ? "YES" : "NO"));
                    //        //" Entity: " + err.Entry.Entity.ToString() + " CurrentValues: " + err.Entry.CurrentValues.ToString() + " State: " + err.Entry.State.ToString());
                    //    foreach (var valErr in err.ValidationErrors)
                    //    {
                    //        Console.WriteLine("    ValidationErrors - PropertyName: " + valErr.PropertyName + " ErrorMessage: " + valErr.ErrorMessage);
                    //    }
                    //}
                    StringBuilder exceptionMessage = new StringBuilder();
                    exceptionMessage.Append("Application Exception in CreateAPIResponseSQLEntry(), saving API Response: " + ex.Message);
                    if (ex.InnerException != null && ex.InnerException.Message.Length > 0)
                    {
                        exceptionMessage.Append(" Inner (" + ex.InnerException.Message + ")  ");
                    }
                    foreach (var err in context.GetValidationErrors())
                    {
                        exceptionMessage.Append("<br>Validation Error -- Valid? " + (err.IsValid ? "YES" : "NO"));
                        foreach (var valErr in err.ValidationErrors)
                        {
                            exceptionMessage.Append("  PropertyName: " + valErr.PropertyName + " ErrorMessage: " + valErr.ErrorMessage);
                        }
                    }
                    SendEMailNotificationAndLogException(false, exceptionMessage.ToString());
                }
                //return (aPIResponse.ID); //return the newly created ID!
                //Console.WriteLine("New APIResponse ID: " + aPIResponse.ID.ToString());
            }
            return (aPIResponse);
        }

        //private static void HandleAPIResponse(APIresponse response, SkidBuildOrder newSkidBuildOrder, List<ToyotaShipment> toyotaOrderShipments, string pickerName)
        private void HandleAPIResponse(APIresponse response, SkidBuildOrder newSkidBuildOrder, List<ToyotaShipment> toyotaOrderShipments, string pickerName)
        {
            APIResponse aPIResponse = CreateAPIResponseSQLEntry(true, newSkidBuildOrder.ID, response, pickerName);

            //if (string.IsNullOrEmpty(aPIResponse.Exception) == false || response.dotNetException != null)
            if (string.IsNullOrEmpty(aPIResponse.Exception) == false)
            {
                //TODO!   Right here, don't I need to REMOVE the Confirmation Number from previous success????
                //Maybe NOT, but I DO need to REMOVE the Confirmation Number from previous success if the Request FAILED!!!!!
                
                //If the Exception was a "WebException", lets email a different error to indicate the problem is probably with the Toyota Servers.
                //(Since, as of 9/18/19, this has happened twice in the last couple of months!)
                bool isWebException = false;
                if (response.dotNetException != null) //If there was an Exception...
                {
                    if (response.dotNetException.GetType().Name.Equals("WebException")) //...and it was a "WebException"...
                    {
                        isWebException = true;
                    }
                }
                SendEMailNotificationAndLogException(isWebException, "In HandleAPIResponse() - There was an Exception when sending the SkidBuild! Exception was (" + aPIResponse.Exception + ")");
            }
            else if (response.code.ToString().StartsWith("2"))
            {
                //Store the ConfirmationNumber in the SkidBuildOrder table for this Order!
                //Mark SkidBuildOrder "Success"...
                //Indicate the ToyotaShipments used for the Order are "Shipped", done, completed, etc.
                if (aPIResponse.ConfirmationNumber != null && aPIResponse.ConfirmationNumber.Length > 0)
                {
                    //Console.WriteLine("+++++++++++++++++++Order was Successfully sent and Approved!!!, The Confirmation Number was " + aPIResponse.ConfirmationNumber + "+++++++++++++++++++");
                    //Console.WriteLine("");
                    //Console.WriteLine("//In HandleAPIResponse() - Updating ConfirmationNumber in SkidBuildOrderID:" + newSkidBuildOrder.ID.ToString());
                    PickToLightData.SkidBuildOrder.UpdateConfirmationNumber(newSkidBuildOrder.ID, aPIResponse.ConfirmationNumber);

                    //Console.WriteLine("TODO - //In HandleAPIResponse() - Mark ToyotaShipments used for the Order as \"Completed\"...");
                    PickToLightData.ToyotaShipment.UpdateToyotaShipmentsCompleted(toyotaOrderShipments, aPIResponse.ConfirmationNumber);
                }
                else
                {
                    //Console.WriteLine("+++++++++++++++++++Order was Successfully sent, but not Approved, due to one or more Validation Errors:");
                    StringBuilder emailMessage = new StringBuilder();
                    emailMessage.Append("<br><span style=\"font-size:120%;font-weight:bold\">Skid Build Order was <u><span style=\"color:red;\">NOT APPROVED</span></u>, due to one or more Validation Errors:</span>");
                    foreach (var message in aPIResponse.APIResponseMessages)
                    {
                        //Console.WriteLine("                   KeyObject: " + message.KeyObject);
                        //Console.WriteLine("                   Message: " + message.Message);
                        //emailMessage.Append("<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;KeyObject: " + message.KeyObject);
                        //emailMessage.Append("<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Message: " + message.Message);
                        emailMessage.Append("<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Message: " + message.Message + "  (KeyObject: " + message.KeyObject + ")");
                        emailMessage.Append("<br>");
                    }
                    //EMAIL the above information to the "Managers"...
                    SendEMailNotificationToFixValidationErrors(newSkidBuildOrder, emailMessage.ToString());
                }
            }
            else
            {
                //TODO!   Right here, don't I need to REMOVE the Confirmation Number from previous success!!!!!
                //REMOVE ConfirmationNumber!!!!!
                //REMOVE ConfirmationNumber!!!!!
                //REMOVE ConfirmationNumber!!!!!
                //REMOVE ConfirmationNumber!!!!!
                //_logger.LogToSQL_TSCS("TSCS_PickToLightServer", "DEBUG", "In HandleAPIResponse() - There wasn't an Exception, but the transaction failed, because the response code was " + response.code.ToString());
                SendEMailNotificationAndLogException(false, "In HandleAPIResponse() - There wasn't an Exception, but the transaction failed, because the response code was " + response.code.ToString());
                //Do THIS???
                //PickToLightData.SkidBuildOrder.UpdateConfirmationNumber(newSkidBuildOrder.ID, "");
            }
        }

        int DetermineBander(ScanOWK scanOWK)
        {
            //Determine which Banding Machine to use:
            // First, check the Order Info (SupplierCode,NAMC,DockCode,OrderNumber).
            // Then check the MainRoute and SubRoute
            // Lastly, just use the bander that hasn't been used for the longest

            //if (string.IsNullOrEmpty(_manifestNum1) == false)
            //{
            //    //This should mean _mainRoute1 and _subRoute1 have values.
            //    //If one of them doesn't, lets try to populate them.
            //    //(I belive this will only be used when the program starts up!)
            //    if (string.IsNullOrEmpty(_mainRoute1) || string.IsNullOrEmpty(_subRoute1))
            //    {
            //        //PopulateManifestRoutes(true); //Populate the _mainRoute1 and _subRoute1 for (Bander 1) _manifestNum1.
            //        PickToLightData.ScanOWK.PopulateManifestRoutes(_manifestNum1, out _mainRoute1, out _subRoute1); //Populate the _mainRoute1 and _subRoute1 for (Bander 1) _manifestNum1.
            //    }
            //}

            //if (string.IsNullOrEmpty(_manifestNum2) == false)
            //{
            //    //This should mean _mainRoute2 and _subRoute2 have values.
            //    //If one of them doesn't, lets try to populate them.
            //    //(I belive this will only be used when the program starts up!)
            //    if (string.IsNullOrEmpty(_mainRoute2) || string.IsNullOrEmpty(_subRoute2))
            //    {
            //        //PopulateManifestRoutes(false); //Populate the _mainRoute2 and _subRoute2 for (Bander 2) _manifestNum2.
            //        PickToLightData.ScanOWK.PopulateManifestRoutes(_manifestNum2, out _mainRoute2, out _subRoute2);  //Populate the _mainRoute2 and _subRoute2 for (Bander 2) _manifestNum2.
            //    }
            //}

            //if (string.IsNullOrEmpty(_manifestNum1))
            //{
            //    _manifestNum1 = "NONE";
            //    _bander1Used = _dateTimeDefault;
            //}
            //if (string.IsNullOrEmpty(_manifestNum2))
            //{
            //    _manifestNum2 = "NONE";
            //    _bander2Used = _dateTimeDefault;
            //}

            //Need to handle some new situations.
            //Sometimes the same Order/Manifest Number is being picked for two different Customers or Locations.
            //
            //Don't just check the OrderNumber, also check the Order Info (SupplierCode,NAMC,DockCode,OrderNumber).
            //If no match, then check the MainRoute and SubRoute.
            //
            //Handle when the same Order/Manifest Number is assigned to BOTH Banders, but for different locations (MainRoute and/or SubRoute).
            //if (_manifestNum1.Equals(scanOWK.OrderNumber) && _manifestNum2.Equals(scanOWK.OrderNumber))
            //
            //
            //Also handle when the above situation, but then a third one starts being picked with the same Order/Manifest, but different MainRoute/SubRoute!


            //See if the "Order Info" is on "Bander1" or "Bander2"
            if (_bander1Order.IsMatch(scanOWK))
            {
                if(TransferDebug) _logger.Log("USE BANDER 1! Because, it matches this Scan (ID=" + scanOWK.ID.ToString() + ")!");
                return(1);
            }
            //else if (textBoxD1200Read.Text.Equals(scanOWK.OrderNumber))
            else if (_bander2Order.IsMatch(scanOWK))
            {
                if (TransferDebug) _logger.Log("USE BANDER 2! Because, it matches this Scan (ID=" + scanOWK.ID.ToString() + ")!");
                return(2);
            }
            else
            {
                //If the Manifest Register is Empty (or the first time it runs in this new format), the OrderNumber property will be empty...
                //If _bander1Order is NullOrEmpty and _bander2Order is NOT NullOrEmpty, use _bander1Order.
                if (string.IsNullOrEmpty(_bander1Order.OrderNumber) && (string.IsNullOrEmpty(_bander2Order.OrderNumber) == false))
                {
                    if (TransferDebug) _logger.Log("USE BANDER 1! The _bander1Order is EMPTY, but 2 ISN'T!");
                    //Writing to Bander in calling method...
                    //if (_plcDevice != null) _plcDevice.WriteBanderManifest(true, scanOWK.OrderNumber);
                    return (1);
                }
                //Else If _bander2Order is NullOrEmpty and _bander1Order is NOT NullOrEmpty, use _bander2Order.
                else if (string.IsNullOrEmpty(_bander2Order.OrderNumber) && (string.IsNullOrEmpty(_bander1Order.OrderNumber) == false))
                {
                    if (TransferDebug)  _logger.Log("USE BANDER 2! The _bander2Order is EMPTY, but 1 ISN'T!");
                    //Writing to Bander in calling method...
                    //if (_plcDevice != null) _plcDevice.WriteBanderManifest(false, scanOWK.OrderNumber);
                    return (2);
                }
                //
                //I no longer need this logic, DO I??
                //
                ////Else If Bander 1 has NEVER been used AND Bander 2 HAS been used, use Bander 1
                ////(This is to cover when the program starts up!)
                //else if (_bander1Used.Equals(_dateTimeDefault) && (false == _bander2Used.Equals(_dateTimeDefault)))
                //{
                //    //determineBanderMessage = string.Format("USE BANDER 1! Bander 1 has never been used and Bander 2 has ({0})!", _bander2Used.ToString());
                //    _logger.Log(string.Format("USE BANDER 1! Bander 1 has never been used and Bander 2 has ({0})!", _bander2Used.ToString()));
                //    _manifestNum1 = scanOWK.OrderNumber;
                //    //_mainRoute1 = scanOWK.MainRoute;
                //    //_subRoute1 = scanOWK.SubRoute;
                //    //_bander1Used = DateTime.Now;
                //    //WriteCommand("0101");
                //    if (_plcDevice != null) _plcDevice.WriteBanderManifest(true, scanOWK.OrderNumber);
                //    return (1);
                //}
                ////Else If Bander 2 has NEVER been used AND Bander 1 HAS been used, use Bander 2
                ////(This is to cover when the program starts up!)
                //else if (_bander2Used.Equals(_dateTimeDefault) && (false == _bander1Used.Equals(_dateTimeDefault)))
                //{
                //    //determineBanderMessage = string.Format("USE BANDER 2! Bander 2 has never been used and Bander 1 has ({0})!", _bander1Used.ToString());
                //    _logger.Log(string.Format("USE BANDER 2! Bander 2 has never been used and Bander 1 has ({0})!", _bander1Used.ToString()));
                //    _manifestNum2 = scanOWK.OrderNumber;
                //    //_mainRoute2 = scanOWK.MainRoute;
                //    //_subRoute2 = scanOWK.SubRoute;
                //    //_bander2Used = DateTime.Now;
                //    //WriteCommand("0102");
                //    if (_plcDevice != null) _plcDevice.WriteBanderManifest(false, scanOWK.OrderNumber);
                //    return (2);
                //}
                //Else... make the best decision using the SubRoute and/or MainRoute (and finally the "LastUsed" timestamp).
                else
                {
                    if (TransferDebug) _logger.Log(string.Format("Find Bander using SubRoute({0})/MainRoute({1})...", scanOWK.SubRoute, scanOWK.MainRoute));
                    //Lets make the best decision, based on Truck (SubRoute) OR timestamp on _bander1Used and _bander2Used.
                    return (GetBestBanderMatch(scanOWK));
                    
                    //if (scanOWK.SubRoute.Length > 0 && _subRoute1.Length > 0 && _subRoute2.Length > 0)
                    //{
                    //    _logger.Log(string.Format("     SubRoute1({0})/MainRoute1({1}) SubRoute2({2})/MainRoute2({3})", _subRoute1, _mainRoute1, _subRoute2, _mainRoute2));
                    //    //Compare with the SubRoute (and_bander1Used, _bander2Used) on Bander1 and Bander2 and return true if 1 is the "best" choice.
                    //    useRoute1 = IsFirstBestMatch(scanOWK.SubRoute, _subRoute1, _subRoute2);
                    //    _logger.Log(string.Format(" Bander{0} was Chosen!", (useRoute1 ? "1" : "2")));
                    //}
                    //else
                    //{
                    //    _logger.Log(string.Format("CAN'T Find Bander with SubRoute1({0})/MainRoute1({1}) SubRoute2({2})/MainRoute2({3})", _subRoute1, _mainRoute1, _subRoute2, _mainRoute2));
                    //    _logger.Log("So, Bander 1 will be used!");
                    //}
                    //if (useRoute1)
                    //{
                    //    _manifestNum1 = scanOWK.OrderNumber;
                    //    if (_plcDevice != null) _plcDevice.WriteBanderManifest(true, scanOWK.OrderNumber);
                    //    return (1);
                    //}
                    //else
                    //{
                    //    _manifestNum2 = scanOWK.OrderNumber;
                    //    if (_plcDevice != null) _plcDevice.WriteBanderManifest(false, scanOWK.OrderNumber);
                    //    return (2);
                    //}
                }
            }
        }

        ////useRoute1 = IsFirstBestMatch(subRoute, _subRoute1, _subRoute2);
        //private bool IsFirstBestMatch(string source, string compare1, string compare2)
        private int GetBestBanderMatch(ScanOWK scanOWK)
        {
            //return 1 or 2!

            //Compare with the SubRoute on _bander1Order and _bander2Order and if a match is found return 1 or 2...otherwise check the LastUsed timestamp

            if (_bander1Order.SubRoute.Equals(scanOWK.SubRoute))
            {
                return(1);
            }
            else if (_bander2Order.SubRoute.Equals(scanOWK.SubRoute))
            {
                return(2);
            }
            //If the SubRoute isn't an exact match, then take into account the last time the Banders were used.
            //else if (_bander1Order.LastUsed.CompareTo(_bander2Order.LastUsed) <= 0)
            else if (_bander1Order.LastUsed < _bander2Order.LastUsed)
            {
                return(1);
            }
            else
            {
                return(2);
            }
        }

        ////Compare with the SubRoute on Bander1 and Bander2 and if 1 is the Best, return true.
        ////useRoute1 = IsFirstBestMatch(subRoute, _subRoute1, _subRoute2);
        //private bool IsFirstBestMatch(string source, string compare1, string compare2)
        //{
        //    bool is1stBest = true;
        //    if (source.Equals(compare1))
        //    {
        //        return true;
        //    }
        //    if (source.Equals(compare2))
        //    {
        //        return false;
        //    }
        //    //If the SubRoute isn't an exact match, then take into account the last time the Banders were used (_bander1Used and _bander2Used).
        //    if (_bander1Used.CompareTo(_bander2Used) <= 0)
        //    {
        //        is1stBest = true;
        //    }
        //    else
        //    {
        //        is1stBest = false;
        //    }
        //    //int maxCompareChars = Math.Min(compare1.Length, compare2.Length);
        //    //maxCompareChars = Math.Min(maxCompareChars, source.Length);
        //    //for (int i = 0; i < maxCompareChars; i++)
        //    //{
        //    //    char sourceChar, compare1Char, compare2Char;
        //    //    sourceChar = source[i];
        //    //    compare1Char = compare1[i];
        //    //    compare2Char = compare2[i];
        //    //    if (sourceChar == compare2Char)
        //    //    {
        //    //        is1stBest = false;
        //    //    }
        //    //    if (sourceChar == compare1Char)
        //    //    {
        //    //        is1stBest = true;
        //    //    }
        //    //    //As soon as EITHER of the characters dont match, RETURN.
        //    //    if(sourceChar != compare1Char || sourceChar != compare2Char)
        //    //    {
        //    //        return is1stBest;
        //    //    }
        //    //}
        //    return is1stBest;
        //}

        //Scanner Related
        //public void StartTransferScanner() //Call this from TransferScannerThread() instead of directly from OnStart()!
        //{

        //    if (_transferScannerIP.Length > 10 && _transferScannerIP.Split('.').Length == 4)//At least 11 characters (10.10.10.10) and 4 periods/dots.
        //    {
        //        ConnectToIP();
        //    }
        //    else
        //    {
        //        _logger.LogToEventLog("The TransferScannerIP setting is invalid or not specified!");
        //        return;
        //    }
        //}


        //Scanner Related
        //Start Transfer Scanner this way?
        //private void TransferScannerThread(object state)
        //{
        //    Thread.CurrentThread.Name = "Scanner Transfer Thread";
        //    _logger.Log("The Scanner TransferThread has started.");

        //    if (_transferScannerIP.Length > 10 && _transferScannerIP.Split('.').Length == 4)//At least 11 characters (10.10.10.10) and 4 periods/dots.
        //    {
        //        StartTransferScanner();
        //    }
        //    else
        //    {
        //        _logger.LogToEventLog("The TransferScannerIP setting is invalid or not specified!");
        //        return;
        //    }

        //    DateTime lastLogTime = DateTime.Now;

        //    // Periodically check if the service is stopping. 
        //    while (!this.stopping)
        //    {
        //        //If we haven't "logged" anything in 5 minute, lets write to the log to show its still running!
        //        TimeSpan timeElapsed = DateTime.Now.Subtract(lastLogTime);
        //        if (timeElapsed.TotalMinutes > 5.0D)
        //        {
        //            lastLogTime = DateTime.Now;
        //            _logger.Log("TransferScannerThread() at " + lastLogTime.ToString());
        //        }

        //        // Perform main service function here... 
        //        // BUT, only the Synchronous Actions!
        //        //ProcessMessagesReceivedFromDolphin


        //        //Thread.Sleep(2000);  // Simulate some lengthy operations. 
        //    }

        //    // Signal the stopped event. 
        //    this.stoppedEvent.Set();
        //}

        protected override void OnStop()
        {
            Thread.CurrentThread.Name = "OnStop Thread";

            // Log a service stop message to the Application log.
            _logger.LogMainEvent(this.ServiceName + " is Stopping.");

            //Close the PLC Device
            if (_plcDevice != null)
            {
                _logger.LogMainEvent("Close PLC Device");
                _plcDevice.Close();
            }

            //// Stop the Server. Release it.
            //_tcpServer.StopServer();
            ////TODO: I don't think we should EVER set TCPServer instance to null AFTER calling StopServer(), because the TCPServer "deconstructor" handles that!
            //// (It causes the Logger to throw an Exception when it tries to log to the db!)
            //_tcpServer = null;

            //New Networking Code
            _tcpServerV2.StopServer();
        }

        public void LoadSettings()
        {
            string appSetting;

            try
            {
                //Read in the LogMode (NoLogging, FileLog, EventLog, SQLLog)
                appSetting = GetSetting("LogMode");
                //if(String.IsNullOrEmpty(appSetting))
                if (appSetting.Length == 0)
                {
                    _logger.LogMode = Logger.LogModes.NoLogging;
                    _logger.LogFolder = "LogMode=NoLogging";
                }
                else
                {
                    if (appSetting.ToUpper().Equals("NOLOGGING"))
                    {
                        _logger.LogMode = Logger.LogModes.NoLogging;
                        _logger.LogFolder = "LogMode=NoLogging";
                    }
                    else if (appSetting.ToUpper().Equals("FILELOG"))
                    {
                        _logger.LogMode = Logger.LogModes.FileLog;
                        //Read in the LogFolder (Used when LogMode = FileLog)
                        appSetting = GetSetting("LogFolder");
                        //if(String.IsNullOrEmpty(appSetting))
                        if (appSetting.Length > 0)
                        {
                            if (Directory.Exists(appSetting))
                            {
                                _logger.LogFolder = appSetting;
                            }
                            else
                            {
                                _logger.LogError("LogFolder (" + _logger.LogFolder + ") does not exist!");
                            }
                        }
                    }
                    else if (appSetting.ToUpper().Equals("EVENTLOG"))
                    {
                        _logger.LogMode = Logger.LogModes.EventLog;
                        _logger.LogFolder = "LogMode=EventLog";
                    }
                    else if (appSetting.ToUpper().Equals("SQLLOG"))
                    {
                        _logger.LogMode = Logger.LogModes.SQLLog;
                        _logger.LogFolder = "LogMode=SQLLog";
                    }
                    else // Unrecognized, so lets do EventLog!
                    {
                        _logger.LogMode = Logger.LogModes.EventLog;
                        _logger.LogFolder = "LogMode=EventLog";
                    }
                }

                //Read in the PLCIP
                appSetting = GetSetting("PLCIP");
                //if(String.IsNullOrEmpty(appSetting))
                if (appSetting.Length == 0)
                {
                    _plcIP = "";
                    throw new ConfigurationErrorsException("PLCIP is missing or empty!");
                }
                else
                {
                    _plcIP = appSetting;
                }

                //Log all the Settings loaded to the EventLog
                _logger.LogMainEvent("LogMode = (" + _logger.LogMode.ToString() + "), LogFolder = (" + _logger.LogFolder + "), PLCIP = (" + _plcIP + ")");
            }
            catch (Exception e)
            {
                _logger.LogError("Exception in LoadSettings: " + e.Message);
                throw new ConfigurationErrorsException("Exception in LoadSettings: " + e.Message);
            }
        }

        private static string GetSetting(string appSetting)
        {

            if (ConfigurationManager.AppSettings == null)
            {
                return "";
            }
            if (ConfigurationManager.AppSettings.Get(appSetting) == null)
            {
                return "";
            }

            return ConfigurationManager.AppSettings.Get(appSetting);
        }

        public void LoadAppSettings()
        {
            //Load the TransferDebug AppSetting.
            //We dfefault this AppSetting to true, so we only need to change it if there is a value and that value is "NO" or "FALSE"...
            string value = GetAppSetting(TransferDebug_AppSettingName);
            if(string.IsNullOrEmpty(value) == false)
            {
                if (value.ToUpper().Equals("NO") || value.ToUpper().Equals("FALSE")) TransferDebug = false;
            }
        }

        public static string GetAppSetting(string appSettingName)
        {
            using (var ctx = new PickToLightEntities())
            {
                AppSetting appSetting = (from b in ctx.AppSettings
                                         where b.Name.Equals(appSettingName)
                                         select b).SingleOrDefault<AppSetting>();
                if (appSetting != null)
                {
                    return(appSetting.Value);
                }
            }
            return ("");
        }
    }

    //public partial class TrackedManifest
    public partial class TrackedManifest
    {
        public string ConfirmationNumber { get; set; }
        public string Plant { get; set; }  //Also the "NAMC"
        public string SupplierCode { get; set; }
        public string OrderNumber { get; set; }
        public string DockCode { get; set; }
        public string PalletizationCode { get; set; }
        //public string SkidId { get; set; }  //001,002,etc Leave out for now, not easy to get from OWK.
        public string MainRoute { get; set; }
        public string SubRoute { get; set; }
        public System.DateTime LastOWKScanned { get; set; }

        private Logger _logger;

        /// <summary>
        /// Constructors.
        /// </summary>
        public TrackedManifest(Logger logger)
        {
            _logger = logger;
            LastOWKScanned = DateTime.Now;
        }

        /// <summary>
        /// Populate the TrackedManifest properties with the values passed from the OWK that was just scanned.
        /// If this new Manifest is associated with a new SkidBuildOrder, this method will also (clear and) set the ConfirmationNumber from the new SkidBuildOrder (assmung there is one).
        /// </summary>
        /// <param name="scanOWK">The OWK that was just scanned.</param>
        public void Populate(ScanOWK scanOWK)
        {
            try
            {
                //_logger.Log("-----In TrackedManifest.Populate()");
                //Before changing the existing values, we need to determine if a new ConfirmationNumber will need to be loaded. 
                //If there is already a ConfirmationNumber AND none of these properties changed: Plant, SupplierCode, OrderNumber or DockCode):
                //  The Manifest is still referring to the same SkidBuildOrder, so we don't need a new ConfirmationNumber!
                bool loadConfirmation = true;
                //if( string.IsNullOrEmpty(this.ConfirmationNumber) == false
                if( String.IsNullOrEmpty(this.ConfirmationNumber) == false && this.IsSameOrder(scanOWK) )
                //&& this.Plant.Equals(scanOWK.NAMCDestination)
                //&& this.SupplierCode.Equals(scanOWK.SupplierCode)
                //&& this.OrderNumber.Equals(scanOWK.OrderNumber)
                //&& this.DockCode.Equals(scanOWK.DockCode) )
                {
                    loadConfirmation = false;
                }
                else
                {
                    this.ConfirmationNumber = "";
                    loadConfirmation = true;
                }
                //_logger.Log("-----In TrackedManifest.Populate() - Done checking if same Order");

                this.Plant = scanOWK.NAMCDestination;
                this.SupplierCode = scanOWK.SupplierCode;
                this.OrderNumber = scanOWK.OrderNumber;
                this.DockCode = scanOWK.DockCode;
                this.PalletizationCode = scanOWK.PalletizationCode;
                //this.SkidId = ???
                this.MainRoute = scanOWK.MainRoute;
                this.SubRoute = scanOWK.SubRoute;
                this.LastOWKScanned = DateTime.Now; //scanOWK.Created; //Store the DateTime, in case we need it when determining which one to replace.

                //Before trying to load the ConfirmationNumber:
                //   Should I first check to see if the new Manifest is for the same SkidBuildOrder, or a "new" SkidBuildOrder?
                //   (If any of these properties changed, it will refer to a "new" SkidBuildOrder: Plant, SupplierCode, OrderNumber or DockCode).
                if(loadConfirmation)
                {
                    //_logger.Log("-----In TrackedManifest.Populate() - Loading Confirmation");
                    this.LoadConfirmation();
                }
            }
            catch (Exception ex)
            {
                if (ex.InnerException != null)
                {
                    _logger.LogError("Exception in TrackedManifest.Populate(): " + ex.Message + " (Inner Exception: " + ex.InnerException + ")");
                }
                else
                {
                    _logger.LogError("Exception in TrackedManifest.Populate(): " + ex.Message);
                }
            }
        }

        /// <summary>
        /// Retrieves the SkidBuildOrder from the SQL Table and if there is a ConfirmationNumber, it sets the ConfirmationNumber property to that value.
        /// (Note: This method doesn't check to see if the ConfirmationNumber property already has a value, in fact if one isn't retrieved the property value will be "".)
        /// </summary>
        public void LoadConfirmation()
        {
            try
            {
                this.ConfirmationNumber = "";
                //See if there is a SkidBuildOrder for this Manifest
                //_logger.Log("-----In TrackedManifest.LoadConfirmation() - Checking for SkidBuildOrder.");
                SkidBuildOrder skidBuildOrder = SkidBuildOrder.GetSkidBuildOrder(this.Plant, this.SupplierCode, this.OrderNumber, this.DockCode);
                if(skidBuildOrder != null)
                {
                    //The SkidBuildOrder was retrieved, now check for a ConfirmationNumber
                    if(string.IsNullOrEmpty(skidBuildOrder.ConfirmationNumber) == false )
                    {
                        this.ConfirmationNumber = skidBuildOrder.ConfirmationNumber;
                    }
                    else //Thre is already a SkidBuildOrder, (so we really don't want to create a new one,) lets load Confirmation# with a value to indicate this.
                    {
                        this.ConfirmationNumber = "NEED CONFIRMATION!";
                    }
                    _logger.Log("-----In TrackedManifest.LoadConfirmation() - SkidBuildOrder Found! Confirmation(" + this.ConfirmationNumber + ").");
                }
                else
                {
                    _logger.Log("-----In TrackedManifest.LoadConfirmation() - SkidBuildOrder NOT Found!");
                }
            }
            catch (Exception ex)
            {
                if (ex.InnerException != null)
                {
                    _logger.LogError("Exception in TrackedManifest.LoadConfirmation(): " + ex.Message + " (Inner Exception: " + ex.InnerException + ")");
                }
                else
                {
                    _logger.LogError("Exception in TrackedManifest.LoadConfirmation(): " + ex.Message);
                }
            }
        }

        /// <summary>
        /// Returns TRUE if the scanOWK (parameter) is for the SAME, EXACT Manifest as the TrackedManifest.
        /// </summary>
        /// <param name="scanOWK"></param>
        /// <returns></returns>
        public bool IsSameManifest(ScanOWK scanOWK)
        {
            try
            {
                //_logger.Log("-----In TrackedManifest.IsSameManifest() - scanOWK.NAMCDestination: " + scanOWK.NAMCDestination.ToString()
                //            + " scanOWK.SupplierCode: " + scanOWK.SupplierCode.ToString()
                //            + " scanOWK.OrderNumber: " + scanOWK.OrderNumber.ToString()
                //            + " scanOWK.DockCode: " + scanOWK.DockCode.ToString()
                //            + " scanOWK.PalletizationCode: " + scanOWK.PalletizationCode.ToString()
                //            + " scanOWK.MainRoute: " + scanOWK.MainRoute.ToString()
                //            + " scanOWK.SubRoute: " + scanOWK.SubRoute.ToString());
                //_logger.Log("-----In TrackedManifest.IsSameManifest() - this.NAMCDestination: " + this.Plant.ToString()
                //            + " this.SupplierCode: " + this.SupplierCode.ToString()
                //            + " this.OrderNumber: " + this.OrderNumber.ToString()
                //            + " this.DockCode: " + this.DockCode.ToString()
                //            + " this.PalletizationCode: " + this.PalletizationCode.ToString()
                //            + " this.MainRoute: " + this.MainRoute.ToString()
                //            + " this.SubRoute: " + this.SubRoute.ToString());
                if (this.Plant == scanOWK.NAMCDestination
                        && this.SupplierCode == scanOWK.SupplierCode
                        && this.OrderNumber == scanOWK.OrderNumber
                        && this.DockCode == scanOWK.DockCode
                        && this.PalletizationCode == scanOWK.PalletizationCode
                        && this.MainRoute == scanOWK.MainRoute
                        && this.SubRoute == scanOWK.SubRoute)
                {
                    return true;
                }
            }
            catch (Exception ex)
            {
                if (ex.InnerException != null)
                {
                    _logger.LogError("Exception in TrackedManifest.IsSameManifest(): " + ex.Message + " (Inner Exception: " + ex.InnerException + ")");
                }
                else
                {
                    _logger.LogError("Exception in TrackedManifest.IsSameManifest(): " + ex.Message);
                }
            }
            return false;
        }

        /// <summary>
        /// Returns TRUE if the scanOWK (parameter) is for the same SkidBuildOrder as the TrackedManifest.
        /// </summary>
        /// <param name="scanOWK"></param>
        /// <returns></returns>
        public bool IsSameOrder(ScanOWK scanOWK)
        {
            try
            {
                //_logger.Log("-----In TrackedManifest.IsSameOrder() - scanOWK.NAMCDestination: " + scanOWK.NAMCDestination.ToString()
                //            + " scanOWK.SupplierCode: " + scanOWK.SupplierCode.ToString()
                //            + " scanOWK.OrderNumber: " + scanOWK.OrderNumber.ToString()
                //            + " scanOWK.DockCode: " + scanOWK.DockCode.ToString() );
                //_logger.Log("-----In TrackedManifest.IsSameOrder() - this.NAMCDestination: " + this.Plant.ToString()
                //            + " this.SupplierCode: " + this.SupplierCode.ToString()
                //            + " this.OrderNumber: " + this.OrderNumber.ToString()
                //            + " this.DockCode: " + this.DockCode.ToString());
                if (this.Plant == scanOWK.NAMCDestination
                        && this.SupplierCode == scanOWK.SupplierCode
                        && this.OrderNumber == scanOWK.OrderNumber
                        && this.DockCode == scanOWK.DockCode)
                //A "SkidBuildOrder" consists of a Unique: Plant (NAMC), SupplierCode, OrderNumber and DockCode.
                //A "SkidBuildOrderSkid" consists of a Unique: Plant (NAMC), SupplierCode, OrderNumber, DockCode AND PalletizationCode.
                //The MainRoute and/or SubRoute don't change per "SkidBuildOrderSkid"
                //(There is only one MainRoute/SubRoute for the entire "SkidBuildOrder")
                //&& this.PalletizationCode == scanOWK.PalletizationCode
                //&& this.MainRoute == scanOWK.MainRoute
                //&& this.SubRoute == scanOWK.SubRoute)
                {
                    return true;
                }
            }
            catch (Exception ex)
            {
                if (ex.InnerException != null)
                {
                    _logger.LogError("Exception in TrackedManifest.IsSameOrder(): " + ex.Message + " (Inner Exception: " + ex.InnerException + ")");
                }
                else
                {
                    _logger.LogError("Exception in TrackedManifest.IsSameOrder(): " + ex.Message);
                }
            }
            return false;
        }

        ///// <summary>
        ///// Call this method when a TrackedManifest no longer needs to be Tracked.
        ///// This method will try to obtain a ConfirmationNumber (only when there isn't one), by creating a SkidBuildOrder (when appropriate) and submitting it to the Toyota SCS REST API.
        ///// Then the Manifest for the OWK that was just scanned (and passed in the scanOWK parameter) will be "tracked".
        ///// </summary>
        ///// <param name="scanOWK"></param>
        //public void Replace(ScanOWK scanOWK)
        //{
        //    //if(String.IsNullOrEmpty(_manifest2.ConfirmationNumber)) //If No Confirmation Number, try to get one
        //    //{
        //    //    _manifest2.ConfirmOrder();
        //    //}
        //    //_manifest2.Populate(scanOWK); //Now track this Manifest using "_manifest2".

        //    //Has the associated SkidBuildOrder already been Confirmed?
        //    if(this.ConfirmationNumber.Length == 0)
        //    {
        //        //No... let's try to load the Confirmation from matching SkidBuildOrder
        //        LoadConfirmation();
        //    }
        //    //Now, check the ConfirmationNumber again, if there still isn't a ConfirmationNumber, lets try to get one.
        //    //if(string.IsNullOrEmpty(this.ConfirmationNumber))
        //    if(this.ConfirmationNumber.Length == 0)
        //    {
        //        //TODO: Only Log this if "Debug"???
        //        //TODO: Only Log this if "Debug"???
        //        //TODO: Only Log this if "Debug"???
        //        _logger.Log("-----In TrackedManifest.Replace(): Calling GetSkidBuildOrderConfirmation() for: Plant: " + scanOWK.NAMCDestination +
        //                    " SupplierCode: " + scanOWK.SupplierCode +
        //                    " OrderNumber: " + scanOWK.OrderNumber +
        //                    " DockCode: " + scanOWK.DockCode +
        //                    " PalleticationCode: " + scanOWK.PalletizationCode);
        //        this.GetSkidBuildOrderConfirmation(scanOWK);
        //    }
        //    this.Populate(scanOWK); //Now track this Manifest.
        //}
    }

    public class BanderOrder
    {
        private Logger _logger;
        public string SupplierCode { get; set; }
        public string NAMC { get; set; }
        public string DockCode { get; set; }
        public string OrderNumber { get; set; }
        public string MainRoute { get; set; }
        public string SubRoute { get; set; }
        public DateTime LastUsed { get; set; }

        //This Property/Value is written to the PLC and shown on the HMI (touch screen).
        //The user may "swap" the parts going up each conveyor/bander (the Banders/Orders) by pressing a button on the HMI (touch screen).
        public string PLCString
        {
            get { return this.SupplierCode + ":" + this.NAMC + ":" + this.DockCode + ":" + this.OrderNumber; }
        }

        public BanderOrder (Logger logger)
	    {
            this.SupplierCode = "";
            this.NAMC = "";
            this.DockCode = "";
            this.OrderNumber = "";
            this.MainRoute = "";
            this.SubRoute = "";
            this.LastUsed = new DateTime(2000, 1, 1);
            _logger = logger;
	    }

        /// <summary>
        /// Using the value from the PLC (passed in the "plcString" parameter), parses the SupplierCode, NAMC, DockCode and OrderNumber.
        /// Lastly, it will load the MainRoute and SubRoute properties from the ScanOWK table.
        /// (Format: "SupplierCode":"NAMC":DockCode":"OrderNumber" Example: "22602:01TMK:N2:2019041125SB")
        /// </summary>
        /// <param name="plcString"></param>
        public void ReplaceWith(string plcString)
        {
            if (string.IsNullOrEmpty(plcString)) //We can't really do anything with an empty string, but let's log it!
            {
                _logger.LogError("*****BanderOrder.ReplaceWith()***** ERROR: The plcString is NULL or Empty!");
                return;
            }
            //If this is the same Order/plcString, lets just return and not do an unnecessary SQL Query.
            //Especially, since this is called for both BanderOrders, EVERY time a ScanTransfer Command is received!
            if (plcString.Equals(this.PLCString)) return;

            string[] properties = plcString.Split(':');

            if(properties.Length < 4) //There should be 4 properties stored in this string.
            {
                _logger.LogError("*****BanderOrder.ReplaceWith()***** ERROR: No field seperator (:) in plcString (" + plcString + ")!");
                return;
            }
            this.SupplierCode = properties[0];
            this.NAMC = properties[1];
            this.DockCode = properties[2];
            this.OrderNumber = properties[3];
            this.LastUsed = DateTime.Now;
            //Now, lets get the MainRoute and SubRoute from the ScanOWK Table.
            using (var ctx = new PickToLightEntities())
            {
                ScanOWK scanOWK = (from s in ctx.ScanOWKs
                                   where s.SupplierCode == this.SupplierCode
                                   && s.NAMCDestination == this.NAMC
                                   && s.OrderNumber == this.OrderNumber
                                   && s.DockCode == this.DockCode
                                   orderby s.ID descending
                                   select s).FirstOrDefault<ScanOWK>();
                if (scanOWK != null)
                {
                    this.MainRoute = scanOWK.MainRoute;
                    this.SubRoute = scanOWK.SubRoute;
                }
            }
        }

        /// <summary>
        /// Populate all the properties using the values from the OWK that was just scanned.
        /// </summary>
        /// <param name="scanOWK"></param>
        public void ReplaceWith(ScanOWK scanOWK)
        {
            this.SupplierCode = scanOWK.SupplierCode;
            this.NAMC = scanOWK.NAMCDestination;
            this.DockCode = scanOWK.DockCode;
            this.OrderNumber = scanOWK.OrderNumber;
            this.MainRoute = scanOWK.MainRoute;
            this.SubRoute = scanOWK.SubRoute;
            this.LastUsed = DateTime.Now;
        }

        /// <summary>
        /// Return true if the BanderOrder matches the scanOWK.
        /// </summary>
        /// <param name="scanOWK"></param>
        public bool IsMatch(ScanOWK scanOWK)
        {
            if( this.SupplierCode.Equals(scanOWK.SupplierCode)
                && this.NAMC.Equals(scanOWK.NAMCDestination)
                && this.DockCode.Equals(scanOWK.DockCode)
                && this.OrderNumber.Equals(scanOWK.OrderNumber)
            )
            {
                return(true);
            }
            return(false);

        }
    }
}
